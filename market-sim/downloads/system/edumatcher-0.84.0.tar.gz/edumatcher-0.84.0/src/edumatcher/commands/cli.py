"""
pm-admin-cli — non-interactive CLI tool for ADMIN exchange operations.

Each subcommand maps 1-to-1 to a method on ExchangeCommandClient.
All output formatting and command execution is delegated to
:func:`~edumatcher.commands.console.execute_command` — the same function
used by the interactive ``pm-admin`` REPL — so adding a new command only
requires changes in that one place plus an argparse subcommand here.

Exit codes
----------
  0  Command accepted / completed successfully
  1  Auth failure, command rejected (including an unknown or, for kick, a
     disconnected gateway), timeout, or engine connection lost
  2  Usage error (argparse)
"""

from __future__ import annotations

import argparse
import json
import sys
from typing import Any

import zmq
from rich.console import Console

from edumatcher.cli_pipe import pipe_safe
from edumatcher.commands import CommandTimeoutError, ExchangeCommandClient
from edumatcher.commands import console as console_mod
from edumatcher.commands.console import execute_command
from edumatcher.config import ENGINE_PUB_ADDR, ENGINE_PULL_ADDR


def _positive_int(text: str) -> int:
    value = int(text)
    if value < 1:
        raise argparse.ArgumentTypeError(f"must be at least 1, got {value}")
    return value


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pm-admin-cli",
        description="EduMatcher ADMIN CLI — send a single exchange command and exit.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  pm-admin-cli --id GW_ADMIN halt\n"
            "  pm-admin-cli --id GW_ADMIN resume\n"
            "  pm-admin-cli --id GW_ADMIN halt-sym --sym AAPL\n"
            "  pm-admin-cli --id GW_ADMIN resume-sym --sym AAPL\n"
            "  pm-admin-cli --id GW_ADMIN cancel-sym --sym AAPL\n"
            "  pm-admin-cli --id GW_ADMIN reopen --sym AAPL --dry-run\n"
            "  pm-admin-cli --id GW_ADMIN reopen --sym AAPL\n"
            "  pm-admin-cli --id GW_ADMIN reopen --sym AAPL --price 100.00 --note 'manual open'\n"
            "  pm-admin-cli --id GW_ADMIN kill --gw TRADER01\n"
            "  pm-admin-cli --id GW_ADMIN kill --gw TRADER01 --sym AAPL\n"
            "  pm-admin-cli --id GW_ADMIN kick --gw TRADER01 --reason 'Compliance hold'\n"
            "  pm-admin-cli --id GW_ADMIN qcancel --gw MM01 --sym AAPL\n"
            "  pm-admin-cli --id GW_ADMIN book --sym AAPL\n"
            "  pm-admin-cli --id GW_ADMIN orders --gw TRADER01\n"
            "  pm-admin-cli --id GW_ADMIN level --sym AAPL\n"
            "  pm-admin-cli --id GW_ADMIN level --sym AAPL --price 189.50\n"
            "  pm-admin-cli --id GW_ADMIN symbols\n"
            "  pm-admin-cli --id GW_ADMIN session --state CONTINUOUS\n"
            "  pm-admin-cli --id GW_ADMIN session-status\n"
            "  pm-admin-cli --id GW_ADMIN schedule\n"
            "  pm-admin-cli --id GW_ADMIN gateways\n"
            "  pm-admin-cli --id GW_ADMIN volume\n"
        ),
    )
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-admin-cli")

    # Global flags
    parser.add_argument(
        "--id",
        required=True,
        metavar="GW_ID",
        help=(
            "ADMIN gateway ID configured in engine_config.yaml (e.g. ADMIN_CLI); "
            "not one a running pm-admin console holds"
        ),
    )
    parser.add_argument(
        "--push",
        default=ENGINE_PULL_ADDR,
        metavar="ADDR",
        help=f"Engine PULL socket address (default: {ENGINE_PULL_ADDR})",
    )
    parser.add_argument(
        "--sub",
        default=ENGINE_PUB_ADDR,
        metavar="ADDR",
        help=f"Engine PUB socket address (default: {ENGINE_PUB_ADDR})",
    )
    parser.add_argument(
        "--timeout",
        type=_positive_int,
        default=3000,
        metavar="MS",
        help="Ack timeout in milliseconds (default: 3000)",
    )
    parser.add_argument(
        "--format",
        choices=("text", "json"),
        default="text",
        help=(
            "Output format for the command's result: 'text' (default, "
            "human-readable) or 'json' (machine-readable, printed to stdout)"
        ),
    )

    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")

    # ---- ADMIN-only ----
    sub.add_parser(
        "halt",
        help="Exchange-wide circuit-breaker halt (ADMIN role required)",
    )
    sub.add_parser(
        "resume",
        help="Resume all symbols halted by 'halt' (ADMIN role required)",
    )

    p = sub.add_parser(
        "halt-sym",
        help="Halt trading on a single symbol (ADMIN role required)",
    )
    p.add_argument("--sym", required=True, metavar="SYMBOL", help="Symbol to halt")

    p = sub.add_parser(
        "resume-sym",
        help="Resume a single symbol halted by 'halt-sym' or a circuit breaker (ADMIN role required)",
    )
    p.add_argument("--sym", required=True, metavar="SYMBOL", help="Symbol to resume")

    p = sub.add_parser(
        "cancel-sym",
        help="Cancel all resting orders on a symbol across every gateway (ADMIN role required)",
    )
    p.add_argument("--sym", required=True, metavar="SYMBOL", help="Symbol to clear")

    p = sub.add_parser(
        "reopen",
        help=(
            "Force one symbol to uncross now and clear any halt in one step "
            "(ADMIN role required)"
        ),
    )
    p.add_argument("--sym", required=True, metavar="SYMBOL", help="Symbol to reopen")
    p.add_argument(
        "--price",
        type=float,
        default=None,
        metavar="PRICE",
        help=(
            "Operator opening price; omit to open at the naturally computed "
            "equilibrium"
        ),
    )
    p.add_argument(
        "--dry-run",
        action="store_true",
        help="Peek the indicative print without changing any state",
    )
    p.add_argument(
        "--note",
        default="",
        metavar="TEXT",
        help="Reason string recorded in the engine log",
    )

    # ---- Per-gateway (another gateway: ADMIN only) ----
    p = sub.add_parser(
        "kill",
        help=(
            "Cancel all resting orders and quotes for a gateway, connected or "
            "not (another gateway: ADMIN role required)"
        ),
    )
    p.add_argument("--gw", required=True, metavar="GW_ID", help="Target gateway ID")
    p.add_argument(
        "--sym",
        default="",
        metavar="SYMBOL",
        help="Scope cancellation to one symbol (omit for all symbols)",
    )

    p = sub.add_parser(
        "kick",
        help=(
            "Forcefully disconnect a connected gateway (no ack; refused for an "
            "unknown or disconnected one)"
        ),
    )
    p.add_argument("--gw", required=True, metavar="GW_ID", help="Target gateway ID")
    p.add_argument(
        "--reason",
        default="",
        metavar="TEXT",
        help="Reason string recorded in the engine log",
    )

    p = sub.add_parser(
        "qcancel",
        help=(
            "Cancel the active two-sided quote for a gateway on one symbol "
            "(another gateway: ADMIN role required)"
        ),
    )
    p.add_argument("--gw", required=True, metavar="GW_ID", help="Target gateway ID")
    p.add_argument("--sym", required=True, metavar="SYMBOL", help="Symbol to cancel")

    p = sub.add_parser(
        "book",
        help="Print the L1/L2 order-book snapshot for a symbol",
    )
    p.add_argument("--sym", required=True, metavar="SYMBOL", help="Symbol to query")

    p = sub.add_parser(
        "orders",
        help="List all resting orders for a gateway, connected or not",
    )
    p.add_argument("--gw", required=True, metavar="GW_ID", help="Target gateway ID")

    p = sub.add_parser(
        "level",
        help=(
            "Show every resting order making up a symbol (or one price "
            "level), across all gateways (ADMIN role required)"
        ),
    )
    p.add_argument("--sym", required=True, metavar="SYMBOL", help="Symbol to query")
    p.add_argument(
        "--price",
        default="",
        metavar="PRICE",
        help="Narrow to orders resting at exactly this price (omit for the whole symbol)",
    )

    sub.add_parser(
        "symbols",
        help="List all instruments configured in the engine",
    )

    p = sub.add_parser(
        "session",
        help="Request a session-phase transition",
    )
    p.add_argument(
        "--state",
        required=True,
        type=str.upper,
        metavar="STATE",
        help=(
            "Target session state.  "
            "One of: PRE_OPEN OPENING_AUCTION CONTINUOUS CLOSING_AUCTION CLOSED"
        ),
    )

    sub.add_parser(
        "session-status",
        help="Show the current session state (read-only, no transition)",
    )

    sub.add_parser(
        "schedule",
        help="Show the automatic session-transition schedule from the engine config",
    )

    sub.add_parser(
        "gateways",
        help="List all configured gateways and their connection status",
    )

    sub.add_parser(
        "volume",
        help="Show daily traded volume per symbol and exchange total",
    )

    p = sub.add_parser(
        "position",
        help=(
            "Show net position, avg cost, and live bid/ask/spread/mid per "
            "symbol for a gateway (any gateway, not just a market maker)"
        ),
    )
    p.add_argument("--gw", required=True, metavar="GW_ID", help="Target gateway ID")
    p.add_argument(
        "--sym",
        default="",
        metavar="SYMBOL[,SYMBOL...]",
        help="Narrow to one or more comma-separated symbols (omit for all)",
    )

    return parser


def _args_to_fields(args: Any) -> dict[str, str]:
    """Convert a parsed args namespace to the ``fields`` dict expected by execute_command."""
    fields: dict[str, str] = {}
    if getattr(args, "gw", None):
        fields["GW"] = args.gw
    if getattr(args, "sym", None):
        fields["SYM"] = args.sym
    if getattr(args, "reason", None):
        fields["REASON"] = args.reason
    if getattr(args, "note", None):
        fields["NOTE"] = args.note
    if getattr(args, "dry_run", False):
        fields["DRY_RUN"] = "1"
    if getattr(args, "state", None):
        fields["STATE"] = args.state
    price = getattr(args, "price", None)
    if price is not None and price != "":
        fields["PRICE"] = str(price)
    return fields


@pipe_safe
def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    client = ExchangeCommandClient(
        args.id,
        push_addr=args.push,
        pub_addr=args.sub,
        timeout_ms=args.timeout,
    )

    # Connect / authenticate
    try:
        auth = client.connect()
    except CommandTimeoutError:
        print(
            f"Connection timed out.  Is the engine running at {args.push}?",
            file=sys.stderr,
        )
        client.close()
        sys.exit(1)

    if not auth.get("accepted"):
        print(f"Auth refused: {auth.get('reason', '')}", file=sys.stderr)
        client.close()
        sys.exit(1)

    # Text output for scripts: let rich detect the destination, so a pipe or
    # file gets plain text (and NO_COLOR is honoured). The shared console
    # forces ANSI only for the REPL, whose patch_stdout hides the terminal.
    console_mod.console = Console()

    # Execute the single command
    # argparse uses hyphens; normalise to UNDERSCORE for execute_command
    cmd = args.command.upper().replace("-", "_")
    fields = _args_to_fields(args)
    ok = True
    try:
        ok, _result = execute_command(
            client, cmd, fields, json_output=args.format == "json"
        )
    except CommandTimeoutError as exc:
        if args.format == "json":
            print(json.dumps({"error": "timeout", "detail": str(exc)}))
        else:
            print(f"Timeout: {exc}", file=sys.stderr)
        ok = False
    except zmq.Again:
        # The PUSH socket fails fast (SNDTIMEO 0, IMMEDIATE): the engine went
        # away after the connect.
        if args.format == "json":
            print(json.dumps({"error": "engine_unreachable"}))
        else:
            print(f"Engine connection lost ({args.push}).", file=sys.stderr)
        ok = False
    finally:
        try:
            client.disconnect()
        except zmq.Again:
            pass  # nobody left to log out from
        client.close()

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
