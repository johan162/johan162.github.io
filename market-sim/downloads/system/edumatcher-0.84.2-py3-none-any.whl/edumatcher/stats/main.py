"""
Statistics Process — records market data to a SQLite database.

Usage:
  poetry run pm-stats [--db data/stats.db] [--snapshot-interval SEC]
                      [--keep-days N]
                      [--keep-order-events-days N]
                      [--human-gateways GLOB,...]
                      [--keep-human-order-events-days N]

  The session timezone is not an option: it comes from engine config (see
  "Dates and timestamps" below).

Retention
---------
  With ``--keep-days N`` the per-event tables (trade_log, order_events,
  price_snapshots, feed_gaps) keep the last N days; a deletion round starts
  at startup and once an hour, and deletes in small batches between
  messages. The daily rollups are kept for good. The file stops growing once
  it holds N days (SQLite reuses the freed pages).
  ``--keep-order-events-days`` gives order_events a retention of its own:
  under an AI swarm they are almost all of the file, so a long run keeps
  hours of them and days of everything else.

  A single order-event retention has to be set short enough for the
  bots, which then deletes a human trader's handful of rows along with
  the swarm's millions. ``--human-gateways`` names the gateways that are
  not bots (glob patterns, e.g. ``TRADER*``) and
  ``--keep-human-order-events-days`` gives them a retention of their own,
  so a person can keep a week of their own fills while the swarm keeps
  hours. Matched gateways are still pruned — just on a slower clock.

Dates and timestamps
--------------------
  ``ts`` columns are UTC instants. ``date`` columns hold the *trading date* —
  the calendar date in the exchange's session timezone (engine config's
  ``locale.session_timezone``, default Europe/Stockholm) that the event's
  own timestamp falls on. pm-stats and pm-clearing both read it from the
  same engine config, so their daily rollups reconcile by construction. See
  edumatcher/stats/trading_day.py.

Subscribes to (engine PUB, ENGINE_PUB_ADDR):
  trade.executed  — trade_log, and OHLCV, VWAP, min/max, volume in daily_stats
  book.{symbol}   — opening bid/ask, and periodic price snapshots
                    (default: every 15 min)
  system.eod      — engine shutdown: record closing bid/ask
  system.symbols.STATS — reply to the startup symbols request: tick scale per
                    symbol, then one book snapshot request each
  order.{ack,fill,amended,cancelled,expired}.*, combo.{ack,status}.*,
  oco.{ack,cancelled}.*, quote.{ack,status}.*
                  — order_events, the private order lifecycle history

Subscribes to (pm-index PUB, INDEX_PUB_CONNECT_ADDR — a separate socket,
since pm-index binds its own PUB endpoint distinct from the engine's):
  index.update    — every throttled index level publication from pm-index

Binds (STATS_HEALTH_BIND_ADDR, a REP socket):
  answers `pm-stats-cli health`'s ping with the current UTC time, proving the
  receive loop is alive and pumping rather than just the OS process existing.

SQLite tables
-------------
  Prices are INTEGER ticks with a tick_decimals column beside them, except
  order_events' prices (REAL display money, as the engine published them).
  The DDL in SCHEMA below is the authoritative column list.

  stats_meta
    Key/value: session timezone, snapshot interval, retention in force.

  instruments
    Tick scale per symbol, from engine config or observed on the wire.

  daily_stats
    Columns: date, symbol, open_price, high_price, low_price, close_price,
             open_bid, open_ask, close_bid, close_ask, volume, trade_count,
             turnover, vwap, largest_trade_qty, largest_trade_price,
             tick_decimals
    One row per (date, symbol), upserted on each trade, on the day's first
    book quote, and on EOD.

  price_snapshots
    Columns: ts, symbol, mid_price, best_bid, best_ask, pct_change,
             tick_decimals
    One row every N seconds per symbol (default: 900 s / 15 minutes).
    Override with --snapshot-interval.

  trade_log
    Columns: ts, trade_id, symbol, price, quantity, tick_decimals,
             buy_gateway_id, sell_gateway_id, aggressor_side,
             buy_order_id, sell_order_id, match_type, msg_id
    Append-only log of every individual trade, keyed on the engine trade id.

  order_events
    One row per private order lifecycle event (ack/reject, fill, amend,
    cancel, expire, and the combo/OCO/quote equivalents).

  feed_gaps
    One row per detected loss: a publisher-sequence jump on any stream, or a
    jump in the engine trade-id suffix (column ``source``).

  index_daily_stats
    Columns: date, index_id, open_level, high_level, low_level, close_level,
             close_session_state, open_aggregate_cap, close_aggregate_cap,
             update_count
    One row per (date, index_id), upserted on each index.update event.
    IMPORTANT: close_level (and close_session_state) reflect the *most
    recent* update received for that day, not necessarily the final EOD
    print. For today's date, while the session is still open, close_level
    is a live "last level so far" and will keep changing. It only becomes
    the true end-of-day close once no further updates arrive for that date
    — which is guaranteed once the date has rolled over, or can be
    confirmed immediately by checking close_session_state == "CLOSED"
    (set from pm-index's forced EOD publish). See pm-stats-cli's
    index-daily command and ../../../docs/books/operator-guide/part-4-run-a-market/060-statistics-and-reporting.md
    for how to query this reliably.

  index_level_snapshots
    Columns: ts, index_id, level, aggregate_cap, divisor, session_state,
             day_open, day_high, day_low
    One row per index.update event received (no additional throttling —
    pm-index already throttles via its own publish_interval_sec before
    publishing). Indexed on (index_id, ts) for fast range queries, unlike
    pm-index's own JSONL history file which pm-stats does not replace but
    complements: the JSONL file remains the source for corporate-action /
    constituent-change audit records, while this table is the queryable
    time series for index level history.
"""

from __future__ import annotations

import argparse
import copy
import json
import logging
import signal
import sqlite3
import sys
import threading
import time
from collections import defaultdict
from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone, tzinfo
from pathlib import Path
from typing import Any, NamedTuple, Optional

import errno

import zmq

from edumatcher.config_artifact import exit_on_config_error
from edumatcher.health import HealthReporter, counter
from edumatcher.models.generated.health import MetricSample
from edumatcher.config import (
    ENGINE_PULL_ADDR,
    ENGINE_PUB_ADDR,
    INDEX_PUB_CONNECT_ADDR,
    STATS_HEALTH_BIND_ADDR,
    STATS_DB_FILE,
    resolve_data_path,
)
from edumatcher.log_srv.config import (
    load_default_log_client_config,
    load_default_log_server_config,
    resolve_host_default,
)
from edumatcher.logclient.discovery import resolve_handler
from edumatcher.healthcheck import answer_health_ping
from edumatcher.messaging.bus import make_pusher, make_replier, make_subscriber
from edumatcher.models.generated.trade import TOPIC_TRADE_EXECUTED
from edumatcher.models.message import (
    decode,
    decode_envelope,
    decode_sequence,
    make_book_snapshot_request_msg,
    make_symbols_request_msg,
)
from edumatcher.models.price import DEFAULT_TICK_DECIMALS
from edumatcher.stats.event_types import UNKNOWN_EVENT_TYPE
from edumatcher.stats.trading_day import (
    resolve_timezone,
    timezone_name,
    trading_date,
    trading_day_bounds,
)
from edumatcher.models.generated.order import (
    PREFIX_ORDER_ACK,
    PREFIX_ORDER_AMENDED,
    PREFIX_ORDER_CANCELLED,
    PREFIX_ORDER_EXPIRED,
    PREFIX_ORDER_FILL,
)
from edumatcher.models.generated.book import PREFIX_BOOK_SNAPSHOT
from edumatcher.models.generated.index import TOPIC_INDEX_UPDATE
from edumatcher.stats.query import (
    META_HUMAN_GATEWAYS,
    META_KEEP_HUMAN_ORDER_EVENTS_DAYS,
    META_KEEP_ORDER_EVENTS_DAYS,
)
from edumatcher.models.generated.quote import (
    PREFIX_QUOTE_ACK,
    PREFIX_QUOTE_STATUS,
)
from edumatcher.models.generated.structure import (
    PREFIX_COMBO_ACK,
    PREFIX_COMBO_STATUS,
    PREFIX_OCO_ACK,
    PREFIX_OCO_CANCELLED,
)
from edumatcher.models.generated.system import (
    TOPIC_EOD,
    topic_symbols,
)

#: The fixed gateway id pm-stats identifies itself with. It subscribes
#: `system.symbols.STATS` and requests on the same id, so the two were the same
#: literal written twice -- one of them in a subscription and one in a request.
STATS_GATEWAY_ID = "STATS"

_CLIENT_NAME = "pm-stats"
_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s - %(message)s"

log = logging.getLogger(__name__)
_sql_log = logging.getLogger("edumatcher.stats.sql")

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SNAPSHOT_INTERVAL_SEC = 15 * 60  # 15 minutes — overridable via --snapshot-interval

#: Floor for --snapshot-interval. price_snapshots' primary key is (ts, symbol)
#: with ts at second precision, so one second is the finest resolution the
#: table can actually represent.
MIN_SNAPSHOT_INTERVAL_SEC = 1.0
_DEBUG_SUMMARY_INTERVAL_SEC = 5.0

# Receive high-water mark for both subscriber sockets. ZMQ's default of 1000
# messages is shallow for a recorder that also writes to SQLite between reads:
# a burst deeper than the mark is dropped silently at the socket. Matches the
# order of magnitude pm-log-srv already uses for its publisher.
_SUB_RCVHWM = 100_000
_ENGINE_RETRY_SEC = 1.0


# ---------------------------------------------------------------------------
# Per-symbol intraday accumulator
# ---------------------------------------------------------------------------


@dataclass
class _DayAccum:
    """Holds intraday statistics for one symbol on one trading date.

    Every price here is an integer count of ticks, never display money. The
    engine matches in ticks and only converts to a float to publish, so
    converting straight back at ingress keeps the arithmetic exact: the day's
    turnover is an integer sum that cannot drift however many fills it spans.
    """

    date: str  # ISO date string YYYY-MM-DD
    symbol: str
    #: Decimal scale these ticks were captured at, carried through to the row
    #: so a reader can turn them back into display money.
    tick_decimals: int = DEFAULT_TICK_DECIMALS

    open_price: Optional[int] = None
    high_price: Optional[int] = None
    low_price: Optional[int] = None
    close_price: Optional[int] = None

    open_bid: Optional[int] = None
    open_ask: Optional[int] = None
    close_bid: Optional[int] = None
    close_ask: Optional[int] = None

    volume: int = 0
    trade_count: int = 0

    # VWAP numerator, sum(price_ticks * qty). An exact integer.
    _pv_sum: int = field(default=0, repr=False)
    _q_sum: int = field(default=0, repr=False)

    largest_trade_qty: int = 0
    largest_trade_price: Optional[int] = None

    def on_trade(self, price: int, qty: int) -> None:
        if self.open_price is None:
            self.open_price = price
        self.close_price = price
        self.high_price = (
            price if self.high_price is None else max(self.high_price, price)
        )
        self.low_price = price if self.low_price is None else min(self.low_price, price)
        self.volume += qty
        self.trade_count += 1
        self._pv_sum += price * qty
        self._q_sum += qty
        if qty > self.largest_trade_qty:
            self.largest_trade_qty = qty
            self.largest_trade_price = price

    @property
    def vwap(self) -> Optional[float]:
        """Volume-weighted average price in ticks — derived, so a float.

        Both inputs are stored exactly, so a consumer needing full precision
        computes ``turnover / volume`` itself rather than reading this.
        """
        return self._pv_sum / self._q_sum if self._q_sum else None

    @property
    def turnover(self) -> int:
        """Traded notional in ticks x quantity — the exact VWAP numerator."""
        return self._pv_sum

    def restore_totals(self, *, trade_count: int, volume: int, pv_sum: int) -> None:
        """Seed the running totals from already-persisted trades.

        Used when rebuilding this accumulator after a restart. ``pv_sum`` is
        the VWAP numerator, ``sum(price * qty)``; the denominator is always
        the traded volume, so it is derived rather than passed separately.
        """
        self.trade_count = trade_count
        self.volume = volume
        self._pv_sum = pv_sum
        self._q_sum = volume

    def on_eod_book(self, best_bid: Optional[int], best_ask: Optional[int]) -> None:
        self.close_bid = best_bid
        self.close_ask = best_ask


# ---------------------------------------------------------------------------
# Per-index intraday accumulator
# ---------------------------------------------------------------------------


@dataclass
class _IndexDayAccum:
    """Holds intraday OHLC statistics for one index on one trading date.

    Mirrors ``_DayAccum``'s day-rollover/upsert shape, but tracks index
    *level* (a computed, dimensionless value) rather than instrument price,
    and has no volume/trade_count concept — an index has no independent
    trades of its own, only updates driven by its constituents.
    """

    date: str  # ISO date string YYYY-MM-DD
    index_id: str

    open_level: Optional[float] = None
    high_level: Optional[float] = None
    low_level: Optional[float] = None
    close_level: Optional[float] = None
    close_session_state: Optional[str] = None

    open_aggregate_cap: Optional[float] = None
    close_aggregate_cap: Optional[float] = None

    update_count: int = 0

    def on_update(
        self,
        level: float,
        aggregate_cap: Optional[float],
        session_state: Optional[str] = None,
    ) -> None:
        if self.open_level is None:
            self.open_level = level
            self.open_aggregate_cap = aggregate_cap
        self.close_level = level
        self.close_aggregate_cap = aggregate_cap
        # close_session_state mirrors close_level: it always reflects the
        # most recent update. It only means "final" once it equals CLOSED
        # (set by pm-index's forced EOD publish) — see the module docstring
        # and the index_daily_stats column comment below.
        self.close_session_state = session_state
        self.high_level = (
            level if self.high_level is None else max(self.high_level, level)
        )
        self.low_level = level if self.low_level is None else min(self.low_level, level)
        self.update_count += 1


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

#: Bumped whenever the DDL below changes in a way that makes an older file
#: unreadable, or whenever the *meaning* of stored values changes. Stamped into
#: ``PRAGMA user_version`` at creation and checked on every open — see
#: :func:`_check_schema_version`.
#:
#: 2 — ``order_events.event_type`` gained distinct accept/reject/cancel/status
#:     values for combo, OCO and quote events. The DDL is unchanged, but a file
#:     holding both the old collapsed values and the new ones would filter
#:     inconsistently, so old files are refused rather than appended to.
#: 3 — added ``feed_gaps``.
#: 4 — prices are stored as INTEGER ticks with a per-row ``tick_decimals``,
#:     replacing REAL display floats. Index levels stay REAL: a level is a
#:     computed, dimensionless number, not a price on a tick grid.
#: 5 — added ``instruments`` reference data (tick scale per symbol, plus a
#:     reserved ``currency`` column).
#: 6 — ``order_events.client_order_id`` renamed to ``client_tag`` to match the
#:     engine/REST correlation field and avoid implying FIX-style idempotency.
#: 7 — ``trade_log`` uses the durable engine ``trade_id`` as its sole primary
#:     key. Existing database files are deliberately refused, not migrated.
#: 8 — ``order_events.trade_id`` replaced by ``trade_ids``, a JSON array: the
#:     engine's fill names every trade it aggregates, and the old column read a
#:     ``trade_id`` key the fill never carried, so it was always NULL.
#: 9 — ``order_events.reject_code``: the engine's machine-readable rejection
#:     class, which only the reason text carried before (sim forensics X6).
#: 10 — EduMatcher 1.0 (sim forensics S26): ``trade_log`` gains the order ids,
#:     ``match_type`` and ``msg_id``; ``order_events`` gains ``msg_id`` -- the
#:     audit message each row records, so a row joins its audit line.
#: 11 — ``index_level_snapshots`` is keyed on an arrival ``seq`` instead of
#:     ``(ts, index_id)``: two updates in one millisecond used to collapse into
#:     one row, so a rehydrated rollup under-counted them.
#: 12 — ``feed_gaps.source`` names the check that found a gap; both checks
#:     fire on one lost trade and their rows were indistinguishable (C5).
#:     ``trade_log`` gains an index on ``ts`` (P3).
SCHEMA_VERSION = 12

#: How long pm-stats keeps recording already-queued engine messages after it
#: is told to stop (see StatsProcess._drain).
_DRAIN_SEC = 0.5

#: Most engine messages handled per poll wake-up before the loop polls the
#: other sockets (health ping, index) and runs a prune batch again.
_DRAIN_PER_WAKE = 1_000

#: Stream name recorded in ``feed_gaps.stream`` for engine trade prints.
#: Taken from the generated binding rather than retyped, so a topic rename in
#: spec/messages/trade.yaml reaches this recorder instead of silently leaving
#: it subscribed to a topic nobody publishes any more.
TRADE_STREAM = TOPIC_TRADE_EXECUTED

#: ``feed_gaps.source`` values: which check found a gap.
GAP_SOURCE_PUBLISHER_SEQ = "publisher_seq"
GAP_SOURCE_TRADE_ID = "trade_id"
#: The run's last trade id on ``system.eod`` against the last one received:
#: trades lost just before the engine stopped (L022).
GAP_SOURCE_RUN_END = "run_end"


def _payload_tick_decimals(payload: dict[str, Any]) -> int:
    """Read the tick scale a payload's display prices were produced at.

    Taken from the message rather than from the local tick registry: that
    registry is populated from engine config at startup, which pm-stats does
    not load, so trusting it would mean guessing. Every message carrying a
    price now carries its scale.
    """
    try:
        return int(payload.get("tick_decimals", DEFAULT_TICK_DECIMALS))
    except TypeError, ValueError:
        return DEFAULT_TICK_DECIMALS


def _to_ticks(price: float | int | None, tick_decimals: int) -> Optional[int]:
    """Convert a published display price back to exact integer ticks.

    The engine holds the price as an integer and divides by 10^tick_decimals
    to publish it, so multiplying back and rounding to nearest recovers the
    original integer exactly — the float only ever has to be within half a
    tick of the true value, which it is by orders of magnitude.
    """
    if price is None:
        return None
    if isinstance(price, int):
        # Already ticks — the engine never publishes an int price, so this is
        # a caller passing through a value that was converted upstream.
        return price
    return int(round(price * (10**tick_decimals)))


SCHEMA = """
CREATE TABLE IF NOT EXISTS stats_meta (
    key   TEXT NOT NULL PRIMARY KEY,
    value TEXT
);

-- Reference data making the file self-describing: without it a consumer has
-- the tick scale on every row but no statement of what an instrument *is*,
-- and no way to list the instruments at all without scanning the tape.
CREATE TABLE IF NOT EXISTS instruments (
    symbol        TEXT    NOT NULL PRIMARY KEY,
    -- Decimal places a price trades in; 1 tick = 10^-tick_decimals.
    tick_decimals INTEGER NOT NULL,
    -- Stored as well as derivable, so a BI tool can join without arithmetic.
    tick_size     REAL    NOT NULL,
    -- RESERVED FOR FUTURE USE. EduMatcher has no currency model: prices carry
    -- no currency, aggregate_cap sums across whatever the constituents are
    -- priced in, and nothing converts. Always NULL today. The column exists so
    -- that adding a currency model later does not require a schema migration
    -- of the reference table, and so a consumer can see the field is absent
    -- rather than assume a currency.
    currency      TEXT,
    -- 'config'  — from the engine's symbol_meta, authoritative
    -- 'observed'— inferred from a message's tick_decimals, best effort
    source        TEXT    NOT NULL,
    updated_ts    TEXT    NOT NULL
);

-- Price columns below are INTEGER *ticks*, not display money — except
-- order_events.price and fill_price (REAL display money, see there). Divide
-- by 10^tick_decimals to get a display price. See the tick handling section of
-- ../../../docs/books/operator-guide/part-4-run-a-market/060-statistics-and-reporting.md.
CREATE TABLE IF NOT EXISTS daily_stats (
    date                TEXT NOT NULL,
    symbol              TEXT NOT NULL,
    open_price          INTEGER,
    high_price          INTEGER,
    low_price           INTEGER,
    close_price         INTEGER,
    open_bid            INTEGER,
    open_ask            INTEGER,
    close_bid           INTEGER,
    close_ask           INTEGER,
    volume              INTEGER NOT NULL DEFAULT 0,
    trade_count         INTEGER NOT NULL DEFAULT 0,
    -- Traded notional in ticks x quantity: sum(price_ticks * quantity). Exact,
    -- and the VWAP numerator — so vwap is exactly reproducible as
    -- turnover / volume without any float round-trip.
    turnover            INTEGER NOT NULL DEFAULT 0,
    -- Derived, therefore REAL: turnover / volume is a ratio and lands between
    -- ticks far more often than on one. The exact inputs are stored alongside,
    -- so a consumer needing full precision computes it rather than reading it.
    vwap                REAL,
    largest_trade_qty   INTEGER,
    largest_trade_price INTEGER,
    tick_decimals       INTEGER NOT NULL DEFAULT 2,
    PRIMARY KEY (date, symbol)
);

CREATE TABLE IF NOT EXISTS price_snapshots (
    ts            TEXT NOT NULL,
    symbol        TEXT NOT NULL,
    -- Derived, therefore REAL and expressed in ticks: the midpoint of two
    -- adjacent ticks is a half tick, which no integer can hold. best_bid and
    -- best_ask beside it are exact.
    mid_price     REAL,
    best_bid      INTEGER,
    best_ask      INTEGER,
    -- A percentage, not money — never converted.
    pct_change    REAL,
    tick_decimals INTEGER NOT NULL DEFAULT 2,
    PRIMARY KEY (ts, symbol)
);

CREATE INDEX IF NOT EXISTS idx_ps_symbol_ts ON price_snapshots(symbol, ts);

CREATE TABLE IF NOT EXISTS trade_log (
    -- The durable engine trade id is the sole execution identity.
    ts              TEXT NOT NULL,
    trade_id        TEXT NOT NULL,
    symbol          TEXT NOT NULL,
    price           INTEGER NOT NULL,
    quantity        INTEGER NOT NULL,
    tick_decimals   INTEGER NOT NULL DEFAULT 2,
    buy_gateway_id  TEXT,
    sell_gateway_id TEXT,
    -- Mirrored from the engine payload verbatim: BUY or SELL for a
    -- continuous match, AUCTION for an uncross print where both sides were
    -- resting and there is no true aggressor. Without this column the table
    -- cannot support trade classification or order-flow imbalance, and
    -- auction prints are indistinguishable from continuous ones.
    aggressor_side  TEXT,
    buy_order_id    TEXT,
    sell_order_id   TEXT,
    -- How the trade came about (trade.executed.match_type).
    match_type      TEXT,
    -- The audit message id of the print (its line's msg=).
    msg_id          TEXT,
    PRIMARY KEY (trade_id)
);

CREATE INDEX IF NOT EXISTS idx_tl_symbol_ts ON trade_log(symbol, ts);
-- Time order across all symbols: the tape page of `trades` without a symbol
-- (and GET /history/trades) reads it instead of sorting the whole table.
CREATE INDEX IF NOT EXISTS idx_tl_ts ON trade_log(ts);
-- Covers the largest-trade-of-the-day rehydration: symbol equality then an
-- ordered scan, so LIMIT 1 short-circuits instead of sorting into a temp
-- B-tree.
CREATE INDEX IF NOT EXISTS idx_tl_symbol_qty ON trade_log(symbol, quantity DESC, ts);

CREATE TABLE IF NOT EXISTS feed_gaps (
    seq             INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              TEXT    NOT NULL,
    stream          TEXT    NOT NULL,
    -- Which check found the gap, and so which counter the ids below are in:
    -- 'publisher_seq' (the per-topic publisher sequence; any stream, counts
    -- messages), 'trade_id' (the engine trade-id suffix; trade.executed
    -- only, counts trades) or 'run_end' (the run's last trade id on
    -- system.eod; received_id is one past it). One lost trade is usually
    -- found by both of the first two.
    source          TEXT    NOT NULL,
    -- The id we expected next, the one that actually arrived, and how many
    -- are unaccounted for between them.
    expected_id     INTEGER NOT NULL,
    received_id     INTEGER NOT NULL,
    missing_count   INTEGER NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fg_ts ON feed_gaps(ts);

CREATE TABLE IF NOT EXISTS order_events (
    seq             INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              TEXT NOT NULL,
    event_type      TEXT NOT NULL,
    order_id        TEXT NOT NULL,
    gateway_id      TEXT NOT NULL,
    symbol          TEXT NOT NULL,
    side            TEXT,
    order_type      TEXT,
    tif             TEXT,
    -- price and fill_price are display money exactly as the engine published
    -- them on the private order events, not ticks; there is no tick_decimals
    -- column here.
    price           REAL,
    quantity        INTEGER,
    remaining_qty   INTEGER,
    status          TEXT,
    fill_price      REAL,
    fill_qty        INTEGER,
    -- JSON array of the durable engine trade ids behind a FILL. One fill
    -- event aggregates everything the order executed in one dispatch, so it
    -- can name several trades; NULL for every other event type.
    trade_ids       TEXT,
    reason          TEXT,
    -- The ack's reject_code on a *_REJECT event; NULL otherwise.
    reject_code     TEXT,
    client_tag      TEXT,
    combo_parent_id TEXT,
    oco_group_id    TEXT,
    priority_reset  INTEGER,
    -- The audit message id this row records (its line's msg=).
    msg_id          TEXT
);

CREATE INDEX IF NOT EXISTS idx_oe_order_id ON order_events(order_id);
CREATE INDEX IF NOT EXISTS idx_oe_gateway_ts ON order_events(gateway_id, ts);
CREATE INDEX IF NOT EXISTS idx_oe_symbol_ts ON order_events(symbol, ts);
CREATE INDEX IF NOT EXISTS idx_oe_type_ts ON order_events(event_type, ts);

CREATE TABLE IF NOT EXISTS index_daily_stats (
    date                TEXT NOT NULL,
    index_id            TEXT NOT NULL,
    open_level          REAL,
    high_level          REAL,
    low_level           REAL,
    close_level         REAL,
    -- session_state as of the most recent update, i.e. the one that set
    -- close_level. Only means "close_level is final" when this is CLOSED;
    -- for the current trading day it will typically show CONTINUOUS or
    -- another intraday state until pm-index's forced EOD publish arrives.
    close_session_state TEXT,
    open_aggregate_cap  REAL,
    close_aggregate_cap REAL,
    update_count        INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (date, index_id)
);

CREATE TABLE IF NOT EXISTS index_level_snapshots (
    -- Arrival order. ts has millisecond resolution, so it cannot identify an
    -- update: two in one millisecond are two rows (K9 / S4).
    seq             INTEGER PRIMARY KEY AUTOINCREMENT,
    ts              TEXT NOT NULL,
    index_id        TEXT NOT NULL,
    level           REAL NOT NULL,
    aggregate_cap   REAL,
    divisor         REAL,
    session_state   TEXT,
    day_open        REAL,
    day_high        REAL,
    day_low         REAL
);

CREATE INDEX IF NOT EXISTS idx_ids_index_ts ON index_level_snapshots(index_id, ts);
CREATE INDEX IF NOT EXISTS idx_ds_index_id_date ON index_daily_stats(index_id, date);
"""

UPSERT_DAILY = """
INSERT INTO daily_stats
    (date, symbol, open_price, high_price, low_price, close_price,
     open_bid, open_ask, close_bid, close_ask,
     volume, trade_count, turnover, vwap,
     largest_trade_qty, largest_trade_price, tick_decimals)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
ON CONFLICT(date, symbol) DO UPDATE SET
    open_price          = excluded.open_price,
    high_price          = excluded.high_price,
    low_price           = excluded.low_price,
    close_price         = excluded.close_price,
    open_bid            = excluded.open_bid,
    open_ask            = excluded.open_ask,
    close_bid           = excluded.close_bid,
    close_ask           = excluded.close_ask,
    volume              = excluded.volume,
    trade_count         = excluded.trade_count,
    turnover            = excluded.turnover,
    vwap                = excluded.vwap,
    largest_trade_qty   = excluded.largest_trade_qty,
    largest_trade_price = excluded.largest_trade_price,
    tick_decimals       = excluded.tick_decimals
"""

INSERT_SNAPSHOT = """
INSERT OR IGNORE INTO price_snapshots
    (ts, symbol, mid_price, best_bid, best_ask, pct_change, tick_decimals)
VALUES (?,?,?,?,?,?,?)
"""

INSERT_TRADE = """
INSERT OR IGNORE INTO trade_log
    (ts, trade_id, symbol, price, quantity, tick_decimals,
     buy_gateway_id, sell_gateway_id, aggressor_side,
     buy_order_id, sell_order_id, match_type, msg_id)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
"""

UPSERT_META = """
INSERT INTO stats_meta (key, value) VALUES (?,?)
ON CONFLICT(key) DO UPDATE SET value = excluded.value
"""

UPSERT_INSTRUMENT = """
INSERT INTO instruments (symbol, tick_decimals, tick_size, currency, source, updated_ts)
VALUES (?,?,?,NULL,?,?)
ON CONFLICT(symbol) DO UPDATE SET
    tick_decimals = excluded.tick_decimals,
    tick_size     = excluded.tick_size,
    source        = excluded.source,
    updated_ts    = excluded.updated_ts
WHERE
    -- Config is authoritative: never let an observed value overwrite it, and
    -- never rewrite a row that already says the same thing.
    (excluded.source = 'config' OR instruments.source != 'config')
    AND (instruments.tick_decimals != excluded.tick_decimals
         OR instruments.source != excluded.source)
"""

INSERT_FEED_GAP = """
INSERT INTO feed_gaps (ts, stream, source, expected_id, received_id, missing_count)
VALUES (?,?,?,?,?,?)
"""

INSERT_ORDER_EVENT = """
INSERT INTO order_events
    (ts, event_type, order_id, gateway_id, symbol, side, order_type, tif, price,
     quantity, remaining_qty, status, fill_price, fill_qty, trade_ids, reason,
     reject_code, client_tag, combo_parent_id, oco_group_id, priority_reset,
     msg_id)
VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
"""

UPSERT_INDEX_DAILY = """
INSERT INTO index_daily_stats
    (date, index_id, open_level, high_level, low_level, close_level,
     close_session_state, open_aggregate_cap, close_aggregate_cap, update_count)
VALUES (?,?,?,?,?,?,?,?,?,?)
ON CONFLICT(date, index_id) DO UPDATE SET
    open_level           = excluded.open_level,
    high_level           = excluded.high_level,
    low_level            = excluded.low_level,
    close_level          = excluded.close_level,
    close_session_state  = excluded.close_session_state,
    open_aggregate_cap   = excluded.open_aggregate_cap,
    close_aggregate_cap  = excluded.close_aggregate_cap,
    update_count         = excluded.update_count
"""

INSERT_INDEX_SNAPSHOT = """
INSERT INTO index_level_snapshots
    (ts, index_id, level, aggregate_cap, divisor, session_state, day_open, day_high, day_low)
VALUES (?,?,?,?,?,?,?,?,?)
"""


def _configure_sql_trace(conn: sqlite3.Connection, enabled: bool) -> None:
    """Enable/disable SQLite statement trace logging for this connection."""
    if not enabled:
        conn.set_trace_callback(None)
        return

    def _trace(statement: str) -> None:
        stmt = statement.strip()
        if not stmt:
            return
        _sql_log.debug("sqlite: %s", stmt)

    conn.set_trace_callback(_trace)


_PRAGMAS = """
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA busy_timeout = 5000;
"""


class IncompatibleDatabaseError(RuntimeError):
    """Raised when an existing stats DB cannot be safely written to."""


class DatabaseInUseError(RuntimeError):
    """Raised when another pm-stats process already owns the database."""


def _acquire_writer_lock(db_path: Path) -> sqlite3.Connection:
    """Take an exclusive, process-lifetime lock on *db_path*.

    Two recorders against one file each keep their own in-memory rollup and
    overwrite the other's ``daily_stats`` rows, so the figures end up
    describing neither process. Nothing about that is visible in the output,
    which makes it worth refusing outright.

    The lock is an exclusive SQLite transaction on a sidecar ``.lock`` file
    rather than an OS file lock: ``fcntl`` is not available on Windows, which
    is a supported platform, whereas SQLite already implements whatever
    locking the host provides. It lives in a separate file because an
    exclusive transaction on ``stats.db`` itself would block every reader for
    as long as the recorder ran.

    Returns the connection holding the lock; closing it releases the lock, so
    the caller must keep it alive.
    """
    # This runs before _open_db, so it is now the first thing to touch the
    # path and owns creating the directory — otherwise pointing --db at a
    # not-yet-existing directory fails here instead of being created.
    db_path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = db_path.with_name(db_path.name + ".lock")
    conn = sqlite3.connect(str(lock_path))
    # Fail immediately rather than waiting: a second recorder is a
    # configuration mistake, not congestion to be ridden out.
    conn.execute("PRAGMA busy_timeout = 0")
    try:
        conn.execute("BEGIN EXCLUSIVE")
    except sqlite3.OperationalError as exc:
        conn.close()
        raise DatabaseInUseError(
            f"another pm-stats process is already recording to {db_path} "
            f"(lock held on {lock_path}). Two recorders on one database "
            f"overwrite each other's daily rollups — use a different --db."
        ) from exc
    return conn


def _check_schema_version(conn: sqlite3.Connection, path: Path) -> bool:
    """Validate ``user_version``. Returns True if the file is newly created.

    A file whose version does not match this build is refused outright rather
    than opened optimistically. Silently writing new-format rows into an
    old-format file is exactly the kind of failure that produces a database
    that looks fine and reports wrong numbers.
    """
    found = int(conn.execute("PRAGMA user_version").fetchone()[0])
    is_new = found == 0 and not _has_tables(conn)
    if is_new:
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        return True
    if found != SCHEMA_VERSION:
        raise IncompatibleDatabaseError(
            f"{path} was written with statistics schema version {found}, "
            f"but this build requires version {SCHEMA_VERSION}. "
            f"Move or delete the file and let pm-stats create a new one."
        )
    return False


def _has_tables(conn: sqlite3.Connection) -> bool:
    row = conn.execute(
        "SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' "
        "AND name NOT LIKE 'sqlite_%'"
    ).fetchone()
    return bool(row[0])


def _reconcile_meta(conn: sqlite3.Connection, path: Path, session_tz_name: str) -> None:
    """Record the session timezone, or refuse if it contradicts the file.

    The session timezone determines which trading date every rollup is filed
    under, so it cannot change part-way through a database's life without
    making the ``date`` column mean two different things. Recording it also
    lets readers resolve it themselves instead of relying on every operator
    rereading engine config.
    """
    row = conn.execute(
        "SELECT value FROM stats_meta WHERE key = 'session_timezone'"
    ).fetchone()
    if row is not None and row[0] != session_tz_name:
        raise IncompatibleDatabaseError(
            f"{path} was recorded with session timezone {row[0]!r}, but "
            f"engine config now says {session_tz_name!r}. Its date columns "
            f"would then mean two different things. Fix engine config's "
            f"locale.session_timezone back to {row[0]!r}, or record into a "
            f"different --db."
        )
    conn.execute(UPSERT_META, ("session_timezone", session_tz_name))


def initialize_schema(conn: sqlite3.Connection) -> None:
    """Create the current statistics schema on an open SQLite connection."""
    conn.executescript(SCHEMA)


def _open_db(
    path: Path,
    *,
    sql_trace: bool = False,
    session_tz_name: str = "UTC",
    snapshot_interval_sec: float = SNAPSHOT_INTERVAL_SEC,
) -> sqlite3.Connection:
    """Open the writer connection.

    WAL matters for correctness here, not just speed: in the default rollback
    journal a concurrent reader (pm-stats-cli, pm-ticker) holds a lock that
    makes the recorder's write fail, and the receive loop's catch-all handler
    would swallow that failure and silently drop the record. WAL lets readers
    and the single writer proceed together, and busy_timeout absorbs the brief
    exclusive lock taken during a checkpoint instead of failing instantly.
    Mirrors clearing/store.py, which already runs this way.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    resolved_path = path.resolve()
    conn = sqlite3.connect(str(path), check_same_thread=False)
    # Everything from here on can reject the file. Close the connection before
    # letting that escape: the caller only ever sees the exception, so it has
    # no handle to close, and the orphan lingers until GC (which on Python
    # 3.14+ also raises a "unclosed database" ResourceWarning).
    try:
        conn.executescript(_PRAGMAS)
        is_new = _check_schema_version(conn, resolved_path)
        initialize_schema(conn)
        _reconcile_meta(conn, resolved_path, session_tz_name)
        conn.execute(UPSERT_META, ("snapshot_interval_sec", str(snapshot_interval_sec)))
        conn.execute(UPSERT_META, ("recorder", _CLIENT_NAME))
        _configure_sql_trace(conn, enabled=sql_trace)
        conn.commit()
    except BaseException:
        conn.close()
        raise
    journal_mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
    log.info(
        "opened stats DB connection path=%s journal_mode=%s schema_version=%d "
        "session_timezone=%s%s",
        resolved_path,
        journal_mode,
        SCHEMA_VERSION,
        session_tz_name,
        " (new file)" if is_new else "",
    )
    return conn


# ---------------------------------------------------------------------------
# Stats process
# ---------------------------------------------------------------------------


class StatsProcess:
    def __init__(
        self,
        db_path: Path,
        snapshot_interval_sec: float = SNAPSHOT_INTERVAL_SEC,
        sql_trace: bool = False,
        session_tz: tzinfo = timezone.utc,
        keep_days: float = 0.0,
        keep_order_events_days: float | None = None,
        human_gateways: Sequence[str] = (),
        keep_human_order_events_days: float | None = None,
    ) -> None:
        self._db_path = db_path
        #: Days of per-event rows to keep; 0 keeps everything.
        self._keep_days = keep_days
        #: The same for order_events alone; None follows keep_days.
        self._keep_order_events_days = (
            keep_days if keep_order_events_days is None else keep_order_events_days
        )
        #: Glob patterns for gateways that are people rather than bots.
        #: Empty means one retention for everyone, as before.
        self._human_gateways = tuple(human_gateways)
        #: order_events retention for those gateways; None follows the
        #: ordinary order-event retention, making the split a no-op.
        self._keep_human_order_events_days = (
            self._keep_order_events_days
            if keep_human_order_events_days is None
            else keep_human_order_events_days
        )
        self._last_prune: float | None = None
        #: (statement, cutoff) still to run in the current prune round; a
        #: round deletes in batches, one per statement per loop iteration.
        self._prune_pending: list[tuple[str, dict[str, Any]]] = []
        self._prune_deleted = 0
        self._sql_trace = bool(sql_trace)
        # Taken before the database is opened, so a rejected second recorder
        # never touches the file at all.
        self._lock_conn = _acquire_writer_lock(db_path)
        try:
            self._conn = _open_db(
                db_path,
                sql_trace=self._sql_trace,
                session_tz_name=timezone_name(session_tz),
                snapshot_interval_sec=snapshot_interval_sec,
            )
        except BaseException:
            # A refused database must not leave the lock held, or a corrected
            # restart would report the file as in use by a process that no
            # longer exists.
            self._lock_conn.close()
            raise
        self._lock = threading.Lock()
        self._running = True
        # Health beacon (operator dashboard §8.5), attached by main(). Ticked
        # and sampled on the *receive* thread, which does all the work -- the
        # main thread only join()s it, so ticking there would report HEALTHY
        # while recording had stopped (finding F7).
        self._reporter: HealthReporter | None = None
        self._events_recorded = 0
        self._records_dropped = 0
        self._feed_gaps = 0
        self._record_retention_meta()
        # Built once: the retention settings do not change while running.
        self._prune_plan = self._prune_statements()
        self._snapshot_interval_sec = snapshot_interval_sec
        self._tz = session_tz
        # Set when the receive thread stops for any reason other than a clean
        # shutdown request, so run() can exit non-zero instead of reporting
        # success after having recorded nothing.
        self._receive_failure: str | None = None

        # symbol → _DayAccum for the trading date it last saw
        self._accum: dict[str, _DayAccum] = {}

        # symbol → mid_price of the last *persisted* snapshot row. The value
        # may be None: a row with no usable mid still becomes the baseline, so
        # pct_change always refers to the immediately preceding row.
        self._last_snap_mid: dict[str, Optional[float]] = {}

        # symbol → time.monotonic() of the last snapshot written. A plain dict
        # with an explicit "absent means never" check, not defaultdict(float):
        # monotonic() is seconds since boot on Linux/macOS, so a 0.0 default
        # made the first snapshot wait until the *host* had been up for a full
        # snapshot interval. On a fresh VM or container that silently skipped
        # the opening snapshot the startup book request exists to capture.
        self._last_snap_ts: dict[str, float] = {}

        # index_id → _IndexDayAccum for the trading date it last saw
        self._index_accum: dict[str, _IndexDayAccum] = {}

        # Last engine trade id seen, split as (run_seq, suffix), for gap
        # detection. None until the first trade; _trade_seq_disabled latches
        # when ids are not in the engine's durable id format so the warning is
        # logged once rather than per trade.
        self._last_trade_id: tuple[int, int] | None = None
        self._trade_seq_disabled = False
        # Seeded from trade_log, so a restart compares the run's end and its
        # next trade with what was recorded before it (as pm-clearing does).
        row = self._conn.execute(
            "SELECT trade_id FROM trade_log"
            " WHERE trade_id GLOB '[0-9][0-9][0-9][0-9][0-9][0-9]-[0-9]*'"
            " ORDER BY trade_id DESC LIMIT 1"
        ).fetchone()
        if row is not None:
            run_text, suffix_text = str(row[0]).split("-", 1)
            self._last_trade_id = (int(run_text), int(suffix_text))

        # topic -> last publisher sequence seen, for detecting drops on every
        # subscribed stream. _unsequenced_topics latches topics with no
        # sequence frame so the warning is logged once per topic.
        self._last_topic_seq: dict[str, int] = {}
        self._unsequenced_topics: set[str] = set()

        # symbol -> (tick_decimals, source) last written to instruments, so an
        # unchanged scale costs no write (P1).
        self._instrument_written: dict[str, tuple[int, str]] = {}
        # (symbol, date) whose mid-day scale change was already reported.
        self._scale_change_reported: set[tuple[str, str]] = set()

        # Initialised before the sockets so close() is safe to call for
        # cleanup if socket construction fails part-way — it flushes the
        # debug counters, which must therefore already exist.
        self._push_lock = threading.Lock()
        self._debug_counts: defaultdict[str, int] = defaultdict(int)
        self._debug_last_summary = time.monotonic()

        # The database is already open at this point, and each socket after
        # the first compounds what is left dangling if a later one fails.
        # close() guards every attribute with hasattr, so it handles a
        # partially-built instance.
        try:
            self.sub = make_subscriber(
                ENGINE_PUB_ADDR,
                TOPIC_TRADE_EXECUTED,
                PREFIX_BOOK_SNAPSHOT,
                TOPIC_EOD,
                topic_symbols(STATS_GATEWAY_ID),
                PREFIX_ORDER_ACK,
                PREFIX_ORDER_FILL,
                PREFIX_ORDER_AMENDED,
                PREFIX_ORDER_CANCELLED,
                PREFIX_ORDER_EXPIRED,
                PREFIX_COMBO_ACK,
                PREFIX_COMBO_STATUS,
                PREFIX_OCO_ACK,
                PREFIX_OCO_CANCELLED,
                PREFIX_QUOTE_ACK,
                PREFIX_QUOTE_STATUS,
                rcvhwm=_SUB_RCVHWM,
            )
            # Separate socket: pm-index binds its own PUB endpoint, distinct
            # from the engine's PUB (mirrors md_gateway's two-subscriber
            # pattern for the same reason — index.update is not an engine
            # topic).
            self.index_sub = make_subscriber(
                INDEX_PUB_CONNECT_ADDR,
                TOPIC_INDEX_UPDATE,
                rcvhwm=_SUB_RCVHWM,
            )
            self.push = make_pusher(ENGINE_PULL_ADDR)
            # Bound, not connected: pm-stats-cli health's ZMQ ping is the
            # only thing that speaks to this socket, proving the receive
            # loop itself is alive rather than just the OS process.
            self.health_rep = make_replier(STATS_HEALTH_BIND_ADDR)
        except BaseException:
            self.close()
            raise

        log.debug(
            "stats process initialized db=%s snapshot_interval=%ss sub=%s push=%s index_sub=%s health=%s",
            self._db_path,
            self._snapshot_interval_sec,
            ENGINE_PUB_ADDR,
            ENGINE_PULL_ADDR,
            INDEX_PUB_CONNECT_ADDR,
            STATS_HEALTH_BIND_ADDR,
        )
        if self._sql_trace:
            log.info("SQLite SQL trace enabled for stats writer connection")

    def _dbg_count(self, key: str, amount: int = 1) -> None:
        """Count an event. Always counts; only the *summary* needs DEBUG.

        Counting used to be skipped entirely unless DEBUG was on, which meant
        a production run had no record of how many messages it handled or
        dropped — exactly the numbers you want when asking whether the
        recording is complete. A dict increment is far too cheap to gate.
        """
        self._debug_counts[key] += amount
        self._flush_debug_summary()

    def _flush_debug_summary(self, force: bool = False) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        now = time.monotonic()
        if not force and now - self._debug_last_summary < _DEBUG_SUMMARY_INTERVAL_SEC:
            return
        if not self._debug_counts:
            self._debug_last_summary = now
            return
        summary = ", ".join(
            f"{key}={value}" for key, value in sorted(self._debug_counts.items())
        )
        log.debug("stats flow summary: %s", summary)
        self._debug_counts.clear()
        self._debug_last_summary = now

    # ------------------------------------------------------------------
    # Accumulator helpers
    # ------------------------------------------------------------------

    def _check_topic_sequence(self, topic: str, seq: int | None) -> None:
        """Detect messages dropped between a publisher and this recorder.

        Publishers stamp a per-topic monotonic counter (``messaging/bus.py``),
        so a jump means ZeroMQ discarded messages at the high-water mark —
        the one failure mode that otherwise leaves no trace at all. Covers
        every subscribed stream, not just trades.

        A counter that moves *backwards* is a publisher restart, since
        sequences begin again at 1. Runs on the receive thread, outside the
        write lock, so it takes the lock itself.
        """
        if seq is None:
            if topic not in self._unsequenced_topics:
                self._unsequenced_topics.add(topic)
                log.warning(
                    "topic %s carries no sequence frame; loss on it cannot be "
                    "detected",
                    topic,
                )
            return

        last = self._last_topic_seq.get(topic)
        self._last_topic_seq[topic] = seq
        if last is None or seq <= last:
            if last is not None and seq <= last:
                log.info(
                    "%s sequence went from %d to %d — publisher restart",
                    topic,
                    last,
                    seq,
                )
            return
        missing = seq - last - 1
        if not missing:
            return

        log.error(
            "detected %d missing message(s) on %s: expected %d, received %d",
            missing,
            topic,
            last + 1,
            seq,
        )
        self._feed_gaps += 1
        with self._lock, self._conn:
            self._conn.execute(
                INSERT_FEED_GAP,
                (
                    datetime.now(tz=timezone.utc).isoformat(timespec="milliseconds"),
                    topic,
                    GAP_SOURCE_PUBLISHER_SEQ,
                    last + 1,
                    seq,
                    missing,
                ),
            )
        self._dbg_count("messages_missing", missing)

    def _check_trade_sequence(self, raw_id: str, ts: str) -> None:
        """Detect trades the recorder never received.

        Trade ids are ``run_seq-counter``. The suffix is dense within a run;
        the prefix changes at engine restart. Callers must hold the lock.
        """
        try:
            run_text, suffix_text = raw_id.split("-", 1)
            received = (int(run_text), int(suffix_text))
        except TypeError, ValueError:
            # Not the engine's durable counter — a synthetic or legacy id.
            # Sequence checking does not apply; say so once, not per trade.
            if not self._trade_seq_disabled:
                self._trade_seq_disabled = True
                log.warning(
                    "trade id %r is not the engine's durable counter; "
                    "trade-gap detection disabled for this run",
                    raw_id,
                )
            return

        last = self._last_trade_id
        self._last_trade_id = received
        if last is None:
            return
        last_run, last_suffix = last
        run_seq, suffix = received
        if run_seq != last_run:
            log.info(
                "trade run sequence changed from %d to %d — engine restart; "
                "resuming gap detection from the new run",
                last_run,
                run_seq,
            )
            return
        if suffix <= last_suffix:
            log.info(
                "trade id suffix went from %d to %d within run %d — duplicate or replay",
                last_suffix,
                suffix,
                run_seq,
            )
            return
        missing = suffix - last_suffix - 1
        if not missing:
            return

        log.error(
            "detected %d missing trade(s): expected id %d, received %d",
            missing,
            last_suffix + 1,
            suffix,
        )
        self._feed_gaps += 1
        self._conn.execute(
            INSERT_FEED_GAP,
            (ts, TRADE_STREAM, GAP_SOURCE_TRADE_ID, last_suffix + 1, suffix, missing),
        )
        self._dbg_count("trades_missing", missing)

    def _check_run_end(self, last_trade_id: object) -> None:
        """Record the trades of the ending run that never arrived: the run's
        last id (``system.eod``) beyond the last one received. Lock held."""
        if not isinstance(last_trade_id, str):
            return
        try:
            run_text, suffix_text = last_trade_id.split("-", 1)
            run_seq, final = int(run_text), int(suffix_text)
        except ValueError:
            return
        last = self._last_trade_id
        last_suffix = last[1] if last is not None and last[0] == run_seq else 0
        if final <= last_suffix:
            return
        missing = final - last_suffix
        log.error(
            "detected %d trade(s) lost before the engine run ended: expected id %d, the run ended at %d",
            missing,
            last_suffix + 1,
            final,
        )
        self._feed_gaps += 1
        ts = datetime.now(tz=timezone.utc).isoformat(timespec="milliseconds")
        with self._conn:
            self._conn.execute(
                INSERT_FEED_GAP,
                (
                    ts,
                    TRADE_STREAM,
                    GAP_SOURCE_RUN_END,
                    last_suffix + 1,
                    final + 1,
                    missing,
                ),
            )
        self._last_trade_id = (run_seq, final)

    def _record_instrument(self, symbol: str, tick_decimals: int, source: str) -> None:
        """Upsert reference data for *symbol*.

        Two sources, and config wins: ``system.symbols`` carries the engine's
        configured tick size, while message payloads only reveal the scale a
        particular message happened to be produced at. A symbol absent from
        config still gets a row from observation, so the reference table
        covers everything that actually traded rather than only what was
        configured.
        """
        if not symbol or self._instrument_written.get(symbol) == (
            tick_decimals,
            source,
        ):
            return
        now = datetime.now(tz=timezone.utc).isoformat(timespec="milliseconds")
        with self._conn:
            self._conn.execute(
                UPSERT_INSTRUMENT,
                (symbol, tick_decimals, 10.0**-tick_decimals, source, now),
            )
        self._instrument_written[symbol] = (tick_decimals, source)

    def _note_tick_decimals(self, acc: _DayAccum, tick_decimals: int) -> None:
        """Record the scale this symbol's prices are being captured at.

        A symbol's tick size changing mid-day would silently make the day's
        integers incomparable with each other, so it is worth saying out loud
        rather than quietly re-scaling — once per symbol and day, not on every
        later message. Callers must hold the lock.
        """
        if acc.trade_count == 0 and acc.open_bid is None and acc.open_ask is None:
            acc.tick_decimals = tick_decimals
        elif acc.tick_decimals != tick_decimals:
            if (acc.symbol, acc.date) in self._scale_change_reported:
                return
            self._scale_change_reported.add((acc.symbol, acc.date))
            log.error(
                "%s tick_decimals changed from %d to %d mid-day; "
                "keeping %d so today's stored ticks stay comparable",
                acc.symbol,
                acc.tick_decimals,
                tick_decimals,
                acc.tick_decimals,
            )
            return
        self._record_instrument(acc.symbol, acc.tick_decimals, "observed")

    def _trading_date(self, epoch_sec: float) -> str:
        """Trading date for an instant, in the configured session timezone."""
        return trading_date(epoch_sec, self._tz)

    def _accum_for(self, symbol: str, day: str) -> _DayAccum:
        """Return the accumulator for *symbol* on trading date *day*.

        Whenever the held accumulator is for another day (or there is none),
        the requested day is rebuilt from what is already in the database.
        Without that, a blank accumulator's next flush overwrites the day's
        real open/high/low/volume/VWAP with a handful of trades — silently,
        and with volume going *down*. That happens after a mid-session
        restart, and also when a symbol moves to another day and back (a late
        print, an EOD on the receipt clock, a clock step) (C1). A genuine
        forward rollover finds nothing on disk and starts empty.
        """
        acc = self._accum.get(symbol)
        if acc is not None and acc.date == day:
            return acc
        if acc is not None:
            self._flush_daily(acc)
        acc = self._rehydrate_daily(symbol, day)
        self._accum[symbol] = acc
        return acc

    def _rehydrate_daily(self, symbol: str, day: str) -> _DayAccum:
        """Rebuild one symbol's accumulator for *day* from persisted rows.

        Trade-derived fields come from ``trade_log`` rather than from
        ``daily_stats``: it is keyed on ``trade_id`` with ``INSERT OR IGNORE``,
        so it is a lossless per-trade record and reproduces the running sums
        exactly, including the VWAP numerator. The bid/ask fields have no
        per-event table behind them and are carried over from the existing
        ``daily_stats`` row.
        """
        acc = _DayAccum(date=day, symbol=symbol)
        day_start, day_end = trading_day_bounds(day, self._tz)
        window = (symbol, day_start, day_end)

        count, volume, pv_sum, acc.low_price, acc.high_price = self._conn.execute(
            "SELECT COUNT(*) , COALESCE(SUM(quantity), 0), "
            "COALESCE(SUM(price * quantity), 0), MIN(price), MAX(price) "
            "FROM trade_log WHERE symbol = ? AND ts >= ? AND ts < ?",
            window,
        ).fetchone()
        acc.restore_totals(trade_count=count, volume=volume, pv_sum=pv_sum)

        if acc.trade_count:
            acc.open_price = self._conn.execute(
                "SELECT price FROM trade_log WHERE symbol = ? AND ts >= ? AND ts < ? "
                "ORDER BY ts ASC, rowid ASC LIMIT 1",
                window,
            ).fetchone()[0]
            acc.close_price = self._conn.execute(
                "SELECT price FROM trade_log WHERE symbol = ? AND ts >= ? AND ts < ? "
                "ORDER BY ts DESC, rowid DESC LIMIT 1",
                window,
            ).fetchone()[0]
            # Ties go to the earliest trade, matching _DayAccum.on_trade's
            # strict `>` comparison.
            # INDEXED BY, not a hint: without stat1 the planner prefers
            # idx_tl_symbol_ts and then sorts the whole symbol-day into a
            # temp B-tree. idx_tl_symbol_qty matches the ORDER BY exactly,
            # so LIMIT 1 stops at the first in-window row. The index is
            # created by initialize_schema() on every open, so it is always
            # present here.
            acc.largest_trade_qty, acc.largest_trade_price = self._conn.execute(
                "SELECT quantity, price FROM trade_log "
                "INDEXED BY idx_tl_symbol_qty "
                "WHERE symbol = ? AND ts >= ? AND ts < ? "
                "ORDER BY quantity DESC, ts ASC, rowid ASC LIMIT 1",
                window,
            ).fetchone()

        quotes = self._conn.execute(
            "SELECT open_bid, open_ask, close_bid, close_ask, tick_decimals "
            "FROM daily_stats WHERE date = ? AND symbol = ?",
            (day, symbol),
        ).fetchone()
        if quotes is not None:
            (
                acc.open_bid,
                acc.open_ask,
                acc.close_bid,
                acc.close_ask,
                # Restored so the day continues on the scale its stored
                # integers were captured at, rather than silently reverting
                # to the default and mixing two scales in one row.
                acc.tick_decimals,
            ) = quotes

        if acc.trade_count or quotes is not None:
            log.info(
                "rehydrated %s for %s: %d trade(s), volume=%d",
                symbol,
                day,
                acc.trade_count,
                acc.volume,
            )
        return acc

    def _flush_daily(self, acc: _DayAccum) -> None:
        """Persist *acc* in its own transaction."""
        with self._conn:
            self._write_daily(acc)

    def _write_daily(self, acc: _DayAccum) -> None:
        """Persist *acc* without opening a transaction — caller owns one."""
        self._conn.execute(
            UPSERT_DAILY,
            (
                acc.date,
                acc.symbol,
                acc.open_price,
                acc.high_price,
                acc.low_price,
                acc.close_price,
                acc.open_bid,
                acc.open_ask,
                acc.close_bid,
                acc.close_ask,
                acc.volume,
                acc.trade_count,
                acc.turnover,
                acc.vwap,
                acc.largest_trade_qty,
                acc.largest_trade_price,
                acc.tick_decimals,
            ),
        )

    def _index_accum_for(self, index_id: str, day: str) -> _IndexDayAccum:
        """Index counterpart of :meth:`_accum_for`, with the same restart rule."""
        acc = self._index_accum.get(index_id)
        if acc is not None and acc.date == day:
            return acc
        if acc is not None:
            self._flush_index_daily(acc)
        acc = self._rehydrate_index_daily(index_id, day)
        self._index_accum[index_id] = acc
        return acc

    def _rehydrate_index_daily(self, index_id: str, day: str) -> _IndexDayAccum:
        """Rebuild one index's accumulator for *day* from persisted snapshots.

        ``update_count`` is recovered as the number of snapshot rows; every
        update is its own row (``seq``), so it equals the live count.
        """
        acc = _IndexDayAccum(date=day, index_id=index_id)
        day_start, day_end = trading_day_bounds(day, self._tz)
        window = (index_id, day_start, day_end)

        acc.update_count, acc.low_level, acc.high_level = self._conn.execute(
            "SELECT COUNT(*), MIN(level), MAX(level) FROM index_level_snapshots "
            "WHERE index_id = ? AND ts >= ? AND ts < ?",
            window,
        ).fetchone()
        if not acc.update_count:
            return acc

        acc.open_level, acc.open_aggregate_cap = self._conn.execute(
            "SELECT level, aggregate_cap FROM index_level_snapshots "
            "WHERE index_id = ? AND ts >= ? AND ts < ? "
            "ORDER BY ts ASC, rowid ASC LIMIT 1",
            window,
        ).fetchone()
        (
            acc.close_level,
            acc.close_aggregate_cap,
            acc.close_session_state,
        ) = self._conn.execute(
            "SELECT level, aggregate_cap, session_state FROM index_level_snapshots "
            "WHERE index_id = ? AND ts >= ? AND ts < ? "
            "ORDER BY ts DESC, rowid DESC LIMIT 1",
            window,
        ).fetchone()
        log.info(
            "rehydrated index %s for %s: %d update(s)",
            index_id,
            day,
            acc.update_count,
        )
        return acc

    def _flush_index_daily(self, acc: _IndexDayAccum) -> None:
        """Persist *acc* in its own transaction."""
        with self._conn:
            self._write_index_daily(acc)

    def _write_index_daily(self, acc: _IndexDayAccum) -> None:
        """Persist *acc* without opening a transaction — caller owns one."""
        self._conn.execute(
            UPSERT_INDEX_DAILY,
            (
                acc.date,
                acc.index_id,
                acc.open_level,
                acc.high_level,
                acc.low_level,
                acc.close_level,
                acc.close_session_state,
                acc.open_aggregate_cap,
                acc.close_aggregate_cap,
                acc.update_count,
            ),
        )

    # ------------------------------------------------------------------
    # Message handlers
    # ------------------------------------------------------------------

    def _on_trade(self, payload: dict[str, Any], msg_id: str | None = None) -> bool:
        """Record one trade print. Returns False if it was not stored."""
        symbol = payload.get("symbol", "")
        price = payload.get("price")
        qty = payload.get("quantity")
        trade_id = payload.get("id")
        if not symbol or price is None or qty is None or not trade_id:
            # The id is the dedupe key: storing an id-less trade under "" made
            # every later one a "duplicate" (C11). A malformed print is a
            # record pm-stats could not store, so it counts as dropped.
            log.warning(
                "dropping malformed trade without id, symbol, price or quantity: %s",
                payload,
            )
            self._dbg_count("records_dropped")
            self._records_dropped += 1
            return False

        ts_ns = payload.get("ts_ns")
        if ts_ns is None:
            epoch_sec = time.time()
            log.warning(
                "trade %s has no engine timestamp; using receipt time",
                payload.get("id", ""),
            )
        else:
            epoch_sec = int(ts_ns) / 1_000_000_000
        ts = datetime.fromtimestamp(epoch_sec, tz=timezone.utc).isoformat(
            timespec="milliseconds"
        )
        with self._lock:
            # Bucket on the trade's own timestamp, not on wall-clock time at
            # the moment of processing: a trade printed just before the
            # trading day rolls over must not be booked into the next day
            # because it happened to be handled a few milliseconds late.
            current = self._accum_for(symbol, self._trading_date(epoch_sec))
            # Work on a copy and install it only once the transaction has
            # committed: the live rollup then never gets ahead of (or differs
            # from) the database, whether the write fails or the trade turns
            # out to be a duplicate.
            acc = copy.copy(current)
            self._note_tick_decimals(acc, _payload_tick_decimals(payload))
            # Convert with the accumulator's scale, not the payload's, so the
            # integer written and the tick_decimals written beside it always
            # describe each other — even if a payload disagrees mid-day.
            tick_decimals = acc.tick_decimals
            price_ticks = _to_ticks(price, tick_decimals)
            assert price_ticks is not None  # price is not None, checked above
            # One transaction for both writes. The rollup is reconstructed
            # from trade_log on restart, so committing them separately would
            # let a crash in between leave the two permanently disagreeing.
            with self._conn:
                # The insert decides first whether this is a new trade (K9 /
                # S1): a repeated trade_id is dropped before it can touch the
                # rollup or the gap tracker.
                inserted = self._conn.execute(
                    INSERT_TRADE,
                    (
                        ts,
                        trade_id,
                        symbol,
                        price_ticks,
                        qty,
                        tick_decimals,
                        payload.get("buy_gateway_id"),
                        payload.get("sell_gateway_id"),
                        payload.get("aggressor_side"),
                        payload.get("buy_order_id"),
                        payload.get("sell_order_id"),
                        payload.get("match_type"),
                        msg_id,
                    ),
                ).rowcount
                if inserted:
                    # Inside the same transaction as the trade itself, so a
                    # recorded gap can never survive without the trade that
                    # revealed it, or vice versa.
                    self._check_trade_sequence(str(trade_id), ts)
                    acc.on_trade(price_ticks, qty)
                    self._write_daily(acc)
            if not inserted:
                self._dbg_count("duplicate_trades")
                return False
            self._accum[symbol] = acc
        self._dbg_count("trades_persisted")
        return True

    def _snapshot_baseline(self, symbol: str) -> Optional[float]:
        """The mid of the last persisted snapshot for *symbol*, or None.

        After a restart the in-memory baseline is empty, and starting from
        nothing would leave the first ``pct_change`` NULL although the table
        holds the row it should be measured from. So the first time a symbol is
        asked about, the latest stored row is the baseline — including a row
        whose mid is NULL, which is the baseline like any other.
        """
        if symbol not in self._last_snap_mid:
            row = self._conn.execute(
                "SELECT mid_price FROM price_snapshots WHERE symbol = ? "
                "ORDER BY ts DESC LIMIT 1",
                (symbol,),
            ).fetchone()
            if row is None:
                return None
            self._last_snap_mid[symbol] = row[0]
        return self._last_snap_mid[symbol]

    def _on_book(self, symbol: str, payload: dict[str, Any]) -> None:
        # Event time, not receipt time: book.{symbol} carries the instant the
        # snapshot was produced (ts_ns), and a book handled just after the
        # trading day rolls over still belongs to the day it describes. Receipt
        # time is only the fallback for a message that lacks one.
        ts_ns = payload.get("ts_ns")
        if isinstance(ts_ns, int) and not isinstance(ts_ns, bool) and ts_ns > 0:
            now_epoch = ts_ns / 1_000_000_000
        else:
            now_epoch = time.time()
            log.warning("book %s has no engine timestamp; using receipt time", symbol)
        with self._lock:
            # Record opening bid/ask once per day
            acc = self._accum_for(symbol, self._trading_date(now_epoch))
            self._note_tick_decimals(acc, _payload_tick_decimals(payload))
            tick_decimals = acc.tick_decimals
            bids = payload.get("bids", [])
            asks = payload.get("asks", [])
            best_bid = _to_ticks(bids[0].get("price") if bids else None, tick_decimals)
            best_ask = _to_ticks(asks[0].get("price") if asks else None, tick_decimals)

            opened = False
            if acc.open_bid is None and best_bid is not None:
                acc.open_bid = best_bid
                opened = True
            if acc.open_ask is None and best_ask is not None:
                acc.open_ask = best_ask
                opened = True
            # Persist opening prices as soon as we know them, so the row
            # exists in daily_stats even if no trades occur today. Only then:
            # a later book changes nothing in the row (P1).
            if opened:
                self._flush_daily(acc)

            # 15-minute price snapshot
            now = time.monotonic()
            last_snap = self._last_snap_ts.get(symbol)
            if last_snap is None or now - last_snap >= self._snapshot_interval_sec:
                self._last_snap_ts[symbol] = now
                # In ticks, and a float: the midpoint of two adjacent ticks
                # is a half tick, which no integer can hold.
                mid: Optional[float] = None
                if best_bid is not None and best_ask is not None:
                    mid = (best_bid + best_ask) / 2
                elif best_bid is not None:
                    mid = float(best_bid)
                elif best_ask is not None:
                    mid = float(best_ask)
                elif payload.get("last_price") is not None:
                    last_ticks = _to_ticks(payload["last_price"], tick_decimals)
                    mid = None if last_ticks is None else float(last_ticks)

                # pct_change is the move since the *immediately preceding
                # persisted row* for this symbol, so a reader can reproduce it
                # from two consecutive rows. That means the baseline may only
                # advance once a row is actually written, and a row whose mid
                # is NULL becomes the new baseline rather than being skipped
                # over — otherwise a percentage silently spans several
                # intervals while still looking like a one-interval move.
                prev = self._snapshot_baseline(symbol)
                pct = None
                if mid is not None and prev is not None and prev != 0:
                    pct = round((mid - prev) / prev * 100, 4)

                snap_ts = datetime.fromtimestamp(now_epoch, tz=timezone.utc).isoformat(
                    timespec="seconds"
                )
                with self._conn:
                    cursor = self._conn.execute(
                        INSERT_SNAPSHOT,
                        (
                            snap_ts,
                            symbol,
                            mid,
                            best_bid,
                            best_ask,
                            pct,
                            tick_decimals,
                        ),
                    )
                if not cursor.rowcount:
                    # INSERT OR IGNORE dropped it — another row already holds
                    # this (ts, symbol). Advancing the baseline to a value that
                    # was never stored would make the next row's percentage
                    # reference something absent from the table.
                    self._dbg_count("snapshots_deduplicated")
                    return
                self._last_snap_mid[symbol] = mid
                log.debug(
                    "wrote snapshot symbol=%s ts=%s",
                    symbol,
                    snap_ts,
                )
                self._dbg_count("snapshots_written")

    def _on_index_update(self, payload: dict[str, Any]) -> bool:
        """Persist one throttled index.update event from pm-index.

        Every message received here already represents one throttled
        publication (pm-index applies its own publish_interval_sec before
        emitting index.update), so — unlike price_snapshots, which further
        throttles a firehose of book updates — every index.update we see is
        recorded as its own index_level_snapshots row with no additional
        throttling in pm-stats.
        """
        index_id = str(payload.get("index_id", "")).strip()
        level = payload.get("level")
        if not index_id or level is None:
            log.warning(
                "ignoring malformed index.update payload (missing index_id/level): %s",
                payload,
            )
            self._dbg_count("index_updates_ignored")
            return False

        aggregate_cap = payload.get("aggregate_cap")
        divisor = payload.get("divisor")
        session_state = payload.get("session_state")
        # One nullable record on the wire (design section 16.2); three flat
        # columns in index_level_snapshots. The table keeps its shape — a
        # column per value is what SQL wants, and rewriting a schema to mirror
        # a message is the tail wagging the dog.
        day = payload.get("day") or {}
        day_open = day.get("open")
        day_high = day.get("high")
        day_low = day.get("low")

        # AR-0.3 renamed index.update's wire field from "timestamp" (float
        # epoch seconds) to "ts_ns" (int epoch nanoseconds); AR-0.3b caught
        # this call site still reading the old key -- every index.update
        # since AR-0.3 was silently falling into the "no timestamp" branch
        # below and logging a spurious warning on every single message.
        ts_ns = payload.get("ts_ns")
        if ts_ns is None:
            # Receipt time is a different clock from the rest of the series;
            # silently mixing the two would make an index history that looks
            # continuous but is not.
            epoch_sec = time.time()
            log.warning(
                "index.update for %s has no ts_ns; using receipt time",
                index_id,
            )
        else:
            epoch_sec = ts_ns / 1_000_000_000
        ts = datetime.fromtimestamp(epoch_sec, tz=timezone.utc).isoformat(
            timespec="milliseconds"
        )

        with self._lock:
            current = self._index_accum_for(index_id, self._trading_date(epoch_sec))
            acc = copy.copy(current)  # installed only after the commit, as for trades
            acc.on_update(level, aggregate_cap, session_state)
            # Single transaction — the rollup is reconstructed from these
            # snapshot rows on restart, so the two must not diverge.
            with self._conn:
                self._write_index_daily(acc)
                self._conn.execute(
                    INSERT_INDEX_SNAPSHOT,
                    (
                        ts,
                        index_id,
                        level,
                        aggregate_cap,
                        divisor,
                        session_state,
                        day_open,
                        day_high,
                        day_low,
                    ),
                )
            self._index_accum[index_id] = acc
        log.debug(
            "recorded index update index_id=%s level=%s session_state=%s ts=%s",
            index_id,
            level,
            session_state,
            ts,
        )
        self._dbg_count("index_updates_persisted")
        return True

    def _on_eod(self, payload: dict[str, Any]) -> None:
        # system.eod carries no timestamp, so receipt time is the only clock.
        # It closes the session a symbol was trading in, though, so a symbol
        # with an accumulator keeps that accumulator's day: an EOD handled just
        # after midnight, or on a host whose clock runs ahead of the engine's,
        # must not file the closing quotes under the next day (C4).
        receipt_day = self._trading_date(time.time())
        with self._lock:
            for book in payload.get("books", []):
                symbol = book.get("symbol", "")
                if not symbol:
                    continue
                held = self._accum.get(symbol)
                acc = held if held is not None else self._accum_for(symbol, receipt_day)
                self._note_tick_decimals(acc, _payload_tick_decimals(book))
                bids = book.get("bids", [])
                asks = book.get("asks", [])
                best_bid = _to_ticks(
                    bids[0].get("price") if bids else None, acc.tick_decimals
                )
                best_ask = _to_ticks(
                    asks[0].get("price") if asks else None, acc.tick_decimals
                )
                acc.on_eod_book(best_bid, best_ask)
                # close_price already set by last trade; if no trades today keep None
                self._flush_daily(acc)
            self._check_run_end(payload.get("last_trade_id"))
            log.info(
                "EOD received; flushed %d symbol(s)",
                len(payload.get("books", [])),
            )

    def _on_order_event(
        self, topic: str, payload: dict[str, Any], msg_id: str | None = None
    ) -> bool:
        """Persist one private order lifecycle event for history queries.

        Returns False for an event without a gateway or an id, which is not
        stored.
        """
        parts = topic.split(".")
        gateway_id = (
            parts[-1] if len(parts) >= 3 else str(payload.get("gateway_id", ""))
        )
        event_name = _event_type_from_topic(topic, payload)
        order_id = str(
            payload.get("order_id")
            or payload.get("combo_id")
            or payload.get("oco_id")
            or payload.get("quote_id")
            or ""
        )
        # A quote rejection may name no quote: cancelling a symbol with no
        # live quote is refused for (gateway, symbol), which the row keeps
        # (X6). Every other event without an id is noise.
        if not gateway_id or not (order_id or event_name == "QUOTE_REJECT"):
            self._dbg_count("order_events_ignored")
            return False
        ts = datetime.now(tz=timezone.utc).isoformat(timespec="milliseconds")
        # `or` would treat a legitimate quantity of 0 as absent and fall
        # through to `qty`, recording NULL when that is missing too.
        quantity = payload.get("quantity")
        if quantity is None:
            quantity = payload.get("qty")

        with self._lock, self._conn:
            self._conn.execute(
                INSERT_ORDER_EVENT,
                (
                    ts,
                    event_name,
                    order_id,
                    gateway_id,
                    str(payload.get("symbol", "")),
                    payload.get("side"),
                    payload.get("order_type"),
                    payload.get("tif"),
                    payload.get("price"),
                    quantity,
                    payload.get("remaining_qty"),
                    payload.get("status"),
                    payload.get("fill_price"),
                    payload.get("fill_qty"),
                    (
                        json.dumps(payload["trade_ids"])
                        if "trade_ids" in payload
                        else None
                    ),
                    payload.get("cancel_reason") or payload.get("reason"),
                    payload.get("reject_code"),
                    payload.get("client_tag"),
                    payload.get("combo_parent_id"),
                    payload.get("oco_group_id"),
                    (
                        int(bool(payload.get("priority_reset")))
                        if "priority_reset" in payload
                        else None
                    ),
                    msg_id,
                ),
            )
            leg = payload.get("cancelled_order_id")
            if event_name == "OCO_CANCEL" and leg:
                # The engine reports an OCO sibling's cancel only here (no
                # order.cancelled for it), so the leg's own history gets the
                # CANCEL it would otherwise never have (X7).
                self._conn.execute(
                    INSERT_ORDER_EVENT,
                    (ts, "CANCEL", str(leg), gateway_id, str(payload.get("symbol", "")))
                    + (None,) * 10  # side ... trade_ids
                    + (payload.get("reason"), None, None, None, order_id, None, msg_id),
                )
        self._dbg_count("order_events_written")
        return True

    # ------------------------------------------------------------------
    # Main receive loop
    # ------------------------------------------------------------------

    def _receive(self) -> None:
        """Poll both sockets until stopped.

        Any exit other than ``self._running`` going false is a failure that
        must stop the whole process. Leaving ``_running`` set here would park
        run() in a busy loop joining a dead thread: the process would stay up,
        keep logging "recording market statistics", record nothing at all, and
        eventually exit 0 — invisible to anything watching the process table.
        """
        try:
            self._receive_loop()
        except Exception as exc:
            self._receive_failure = f"{type(exc).__name__}: {exc}"
            log.exception("stats receive loop terminated")
        finally:
            self._running = False

    def _receive_loop(self) -> None:
        poller = zmq.Poller()
        poller.register(self.sub, zmq.POLLIN)
        poller.register(self.index_sub, zmq.POLLIN)
        poller.register(self.health_rep, zmq.POLLIN)
        reporter = self._reporter
        while self._running:
            if reporter is not None:
                reporter.tick_and_publish(self.metric_samples)
            try:
                socks = dict(poller.poll(timeout=300))
            except zmq.ZMQError as exc:
                if exc.errno != errno.EINTR:
                    raise
                continue  # interrupted, not failed: poll again (C13)

            # On this thread, so the deletes never interleave with the
            # writes sharing the connection.
            self._prune_if_due()

            if self.health_rep in socks:
                answer_health_ping(self.health_rep)

            if self.index_sub in socks:
                self._receive_one_index_message()

            if self.sub in socks:
                # Take what is already queued, up to a bound, before polling
                # again: one poll per message was a syscall, a prune check and
                # a health tick for every book update (P4).
                self._receive_one_engine_message()
                drained = 1
                while drained < _DRAIN_PER_WAKE and self.sub.poll(0):
                    self._receive_one_engine_message()
                    drained += 1
        self._drain()

    def _drain(self) -> None:
        """After a stop, record what is already queued on the engine SUB.

        A stop arrives while the engine is still publishing -- its last
        trades, and system.eod, which it sends on its own shutdown. Leaving
        the loop at once lost whatever was queued (X4: a run's last trade
        and fill). Bounded by _DRAIN_SEC so a live engine cannot hold the
        shutdown open; run() joins this thread for one second.
        """
        deadline = time.monotonic() + _DRAIN_SEC
        while time.monotonic() < deadline and self.sub.poll(timeout=50):
            self._receive_one_engine_message()

    def _receive_one_engine_message(self) -> None:
        try:
            frames = self.sub.recv_multipart()
            topic, payload = decode(frames)
        except Exception as exc:
            log.warning("failed to decode engine message: %s", exc)
            self._dbg_count("messages_undecodable")
            return

        self._dbg_count("messages_received")
        self._check_topic_sequence(topic, decode_sequence(frames))

        try:
            env = decode_envelope(frames)
            recorded = self._dispatch(
                topic, payload, env.msg_id if env is not None else None
            )
        except Exception as exc:
            # Reaching here means the event was not persisted. That is a
            # dropped record, not a warning-level curiosity.
            log.error("failed to record topic=%s err=%s", topic, exc)
            self._dbg_count("records_dropped")
            self._records_dropped += 1
        else:
            # A message the handler deliberately ignored (malformed, a
            # duplicate, a topic pm-stats does not store) is not a record.
            if recorded:
                self._events_recorded += 1

    def _record_retention_meta(self) -> None:
        """Publish the order-event retention into ``stats_meta``.

        A reader cannot otherwise tell a pruned history from an idle
        gateway: both look like a short list of rows. Written on every
        start so the file always describes the retention actually in
        force, not the one it was created with.
        """
        self._conn.execute(
            UPSERT_META,
            (META_KEEP_ORDER_EVENTS_DAYS, str(self._keep_order_events_days)),
        )
        self._conn.execute(
            UPSERT_META, (META_HUMAN_GATEWAYS, ",".join(self._human_gateways))
        )
        self._conn.execute(
            UPSERT_META,
            (
                META_KEEP_HUMAN_ORDER_EVENTS_DAYS,
                str(self._keep_human_order_events_days),
            ),
        )
        self._conn.commit()

    def _order_event_prune_tiers(self) -> list[tuple[_Prune, float]]:
        """``(statement, days)`` for each order-event retention tier.

        Without ``--human-gateways`` this is a single statement. With it, the
        table is split in two: matched gateways prune on their own (longer)
        clock, everyone else on the ordinary one. A tier with retention 0 keeps
        everything, so it contributes no statement — which is how exempting a
        gateway outright works.
        """
        if not self._human_gateways:
            days = self._keep_order_events_days
            return [(_prune_order_events((), human=False), days)] if days > 0 else []
        tiers = [
            (self._keep_order_events_days, False),
            (self._keep_human_order_events_days, True),
        ]
        return [
            (_prune_order_events(self._human_gateways, human=human), days)
            for days, human in tiers
            if days > 0
        ]

    def _prune_statements(self) -> list[tuple[_Prune, float]]:
        """Every ``(statement, days)`` retention runs; empty keeps everything."""
        statements = [
            (statement, self._keep_days)
            for statement in (_PRUNE_STATEMENTS if self._keep_days > 0 else ())
        ]
        return statements + self._order_event_prune_tiers()

    def _prune_if_due(self) -> None:
        """Run retention in bounded batches, on this (the receive) thread.

        Once an hour a round starts, fixing every statement's cutoff. Each call
        then deletes at most ``_PRUNE_BATCH_ROWS`` rows per statement, each
        batch in its own short transaction, and the receive loop reads its
        sockets between calls. One transaction for the whole round held the
        lock for seconds under a swarm (900 000 rows took 3.4 s) while ZeroMQ
        queued, and then dropped, the messages arriving meanwhile (P2).
        """
        if not self._prune_plan:
            return
        if not self._prune_pending:
            now = time.monotonic()
            if (
                self._last_prune is not None
                and now - self._last_prune < _PRUNE_INTERVAL_SEC
            ):
                return
            self._last_prune = now
            self._prune_pending = [
                (prune.delete, self._prune_params(prune, days))
                for prune, days in self._prune_plan
            ]
            self._prune_deleted = 0
        still_pending = []
        for statement, params in self._prune_pending:
            with self._lock, self._conn:
                deleted = self._conn.execute(statement, params).rowcount
            self._prune_deleted += deleted
            if deleted >= _PRUNE_BATCH_ROWS:
                still_pending.append((statement, params))
        self._prune_pending = still_pending
        if not still_pending and self._prune_deleted:
            log.info("retention: deleted %d rows", self._prune_deleted)

    def _prune_params(self, prune: _Prune, days: float) -> dict[str, Any]:
        """Bind one statement's cutoff (and watermark) for this round."""
        cutoff = datetime.fromtimestamp(
            time.time() - days * 86_400, tz=timezone.utc
        ).isoformat(timespec="seconds")
        params: dict[str, Any] = {"cutoff": cutoff, "batch": _PRUNE_BATCH_ROWS}
        if prune.watermark is not None:
            with self._lock:
                (params["watermark"],) = self._conn.execute(
                    prune.watermark, {"cutoff": cutoff}
                ).fetchone()
        return params

    def _dispatch(
        self, topic: str, payload: dict[str, Any], msg_id: str | None = None
    ) -> bool:
        """Route one decoded engine message to its handler.

        Returns whether the message was recorded; False for one that was
        ignored. Split out of the receive loop so the topic-matching rules are
        reachable from a test without driving a socket.
        """
        if topic.startswith(TOPIC_TRADE_EXECUTED):
            self._dbg_count("trade_topics")
            return self._on_trade(payload, msg_id)
        elif topic.startswith(PREFIX_BOOK_SNAPSHOT):
            self._dbg_count("book_topics")
            symbol = topic.split(".", 1)[1]
            # A `book.` subscription matches any topic under `book.`. Today the
            # engine publishes only `book.{symbol}` there (depth is on
            # `depth.{symbol}`), but a future sub-topic such as `book.x.AAPL`
            # would otherwise be recorded as a phantom instrument "x.AAPL".
            # Symbols are alphanumeric (balf_gwy/protocol.py::validate_symbol),
            # so a dot here means this is not a single-symbol book snapshot.
            if "." in symbol:
                self._dbg_count("book_subtopics_ignored")
                log.warning(
                    "ignoring %s: not a book snapshot for a single symbol", topic
                )
                return False
            self._on_book(symbol, payload)
            return True
        elif topic == TOPIC_EOD:
            self._dbg_count("eod_topics")
            self._on_eod(payload)
            return True
        elif topic == topic_symbols(STATS_GATEWAY_ID):
            self._dbg_count("startup_symbols_topics")
            self._on_startup_symbols(payload)
            return True
        elif _is_order_event_topic(topic):
            self._dbg_count("order_event_topics")
            return self._on_order_event(topic, payload, msg_id)
        return False

    def _receive_one_index_message(self) -> None:
        """The index counterpart of :meth:`_receive_one_engine_message`, with
        the same accounting (C8)."""
        try:
            frames = self.index_sub.recv_multipart()
            topic, payload = decode(frames)
        except Exception as exc:
            log.warning("failed to decode index_sub message: %s", exc)
            self._dbg_count("messages_undecodable")
            return

        self._dbg_count("index_messages_received")
        self._check_topic_sequence(topic, decode_sequence(frames))
        if topic != TOPIC_INDEX_UPDATE:
            return
        self._dbg_count("index_update_topics")
        try:
            recorded = self._on_index_update(payload)
        except Exception as exc:
            log.error("failed to record topic=%s err=%s", topic, exc)
            self._dbg_count("records_dropped")
            self._records_dropped += 1
        else:
            if recorded:
                self._events_recorded += 1

    def _on_startup_symbols(self, payload: dict[str, Any]) -> None:
        """Received in response to our startup symbols request.
        Request a current book snapshot for every symbol so opening bid/ask
        and an initial price_snapshots row are recorded even if no new orders
        arrive after the stats process starts.
        """
        # Each entry carries the engine's configured tick scale, which is
        # authoritative for every symbol — including ones that never trade and
        # would otherwise never appear in the reference table.
        entries = payload.get("symbols", [])
        symbols = [str(e.get("symbol", "")) for e in entries]
        for entry in entries:
            sym = str(entry.get("symbol", ""))
            tick_decimals = entry.get("tick_decimals")
            if not sym or tick_decimals is None:
                continue
            # The engine sends the exponent it holds. This used to recover it
            # from `tick_size` with `round(-log10(x))`, one of three spellings
            # of the same number the wire carried before 6.1e.
            self._record_instrument(sym.upper(), int(tick_decimals), "config")
        if entries:
            log.info("recorded tick metadata for %d symbol(s)", len(entries))

        with self._push_lock:
            for sym in symbols:
                self.push.send_multipart(make_book_snapshot_request_msg(sym))
        if symbols:
            log.info("requested opening snapshots for: %s", ", ".join(symbols))

    def _request_startup_symbols(self) -> bool:
        """Request engine symbols, reporting whether the engine is reachable."""
        try:
            with self._push_lock:
                self.push.send_multipart(make_symbols_request_msg(STATS_GATEWAY_ID))
        except zmq.Again:
            return False
        return True

    def run(self) -> int:
        """Run until stopped. Returns the intended process exit code."""
        signal.signal(signal.SIGINT, lambda *_: self._stop())
        signal.signal(signal.SIGTERM, lambda *_: self._stop())

        t = threading.Thread(target=self._receive, daemon=True)
        t.start()

        # Give the SUB socket time to connect and filters to propagate,
        # then request the symbol list so we can pull opening book snapshots.
        # This handles the race where the engine seeded MM orders before we started.
        time.sleep(0.3)
        if not self._request_startup_symbols():
            log.info("pm-stats waiting for pm-engine to start")
            while self._running and not self._request_startup_symbols():
                time.sleep(_ENGINE_RETRY_SEC)
        if not self._running:
            # Either a stop arrived while waiting for the engine, or the
            # receive thread died; only the first is a clean exit (C2).
            t.join(timeout=1.0)
            self.close()
            return self._exit_code()
        log.debug("requested startup symbols for gateway_id=STATS")

        log.info("recording market statistics (Ctrl-C to stop)")
        try:
            while self._running:
                t.join(timeout=0.5)
        finally:
            # Wait for the receive thread to finish its current message before
            # closing the database and sockets to avoid mid-transaction errors.
            t.join(timeout=1.0)
            if t.is_alive():
                log.error(
                    "receive thread did not stop within 1s; "
                    "closing anyway may abort an in-flight write"
                )
            self.close()
        return self._exit_code()

    def _exit_code(self) -> int:
        """1 when the receive loop failed, else 0, logging the failure."""
        if self._receive_failure is not None:
            log.critical("pm-stats stopped recording: %s", self._receive_failure)
            return 1
        return 0

    def _stop(self) -> None:
        self._running = False
        log.info("stopped")

    def _log_session_totals(self) -> None:
        """Report what this run actually recorded, at INFO.

        The per-interval summary is DEBUG-only, so without this a normal run
        ends having said nothing about how much it handled or dropped — the
        first question anyone asks when checking whether a session's figures
        are complete.
        """
        counts = getattr(self, "_debug_counts", None)
        if not counts:
            return
        summary = ", ".join(f"{key}={value}" for key, value in sorted(counts.items()))
        log.info("session totals: %s", summary)
        missing = counts.get("trades_missing", 0)
        if missing:
            log.error(
                "%d trade(s) were never received this session; see the "
                "feed_gaps table for the affected id ranges",
                missing,
            )

    def attach_reporter(self, reporter: HealthReporter) -> None:
        """Ship this process's health beacon through ``reporter`` (main())."""
        self._reporter = reporter

    def metric_samples(self) -> list[MetricSample]:
        """Design §8.5, plus records_dropped: events that failed to persist."""
        return [
            counter("stats.events_recorded", self._events_recorded),
            counter("stats.records_dropped", self._records_dropped),
            counter("stats.feed_gaps", self._feed_gaps),
        ]

    def close(self) -> None:
        if self._reporter is not None:
            self._reporter.stop()
        self._flush_debug_summary(force=True)
        self._log_session_totals()
        log.info("closing stats process")
        # Held so the connection cannot be closed out from under a receive
        # thread that is still inside a transaction.
        with self._lock:
            if hasattr(self, "_conn"):
                self._conn.close()
        if hasattr(self, "sub") and getattr(self.sub, "closed", False) is not True:
            self.sub.close()
        if (
            hasattr(self, "index_sub")
            and getattr(self.index_sub, "closed", False) is not True
        ):
            self.index_sub.close()
        if hasattr(self, "push") and getattr(self.push, "closed", False) is not True:
            self.push.close()
        if (
            hasattr(self, "health_rep")
            and getattr(self.health_rep, "closed", False) is not True
        ):
            self.health_rep.close()
        # Released last: no other recorder should be able to take over until
        # this one has finished writing and closed its sockets.
        if hasattr(self, "_lock_conn"):
            self._lock_conn.close()


_PRUNE_INTERVAL_SEC = 3600.0


#: Rows one retention statement deletes per transaction. About 20 ms of
#: order_events on a typical disk, so the receive loop is never held for long.
_PRUNE_BATCH_ROWS = 5_000


# ``ts`` is an ISO UTC instant, so text order is time order. trade_log and
# order_events are append-only, and order_events has no index leading on ts:
# the watermark (the first row, in insertion order, still inside the window)
# is found by a scan from the head of the table, which holds only rows being
# deleted. trade_log uses the same form (it has idx_tl_ts since schema 12,
# which the planner may use for the watermark). Each run deletes at most
# :batch rows below it, oldest first.
class _Prune(NamedTuple):
    """One retention statement, run in batches of ``:batch`` rows.

    ``watermark``, when set, is evaluated once when a round starts and bound
    as ``:watermark``: finding it scans the rows due for deletion, so doing
    it per batch made a round quadratic.
    """

    delete: str
    watermark: str | None = None


def _prune_by_key(table: str, key: str, predicate: str = "") -> _Prune:
    extra = f" AND {predicate}" if predicate else ""
    return _Prune(
        delete=f"""DELETE FROM {table} WHERE {key} IN (
        SELECT {key} FROM {table} WHERE {key} < :watermark{extra}
        ORDER BY {key} LIMIT :batch)""",
        watermark=f"""SELECT COALESCE(
        (SELECT {key} FROM {table} WHERE ts >= :cutoff ORDER BY {key} LIMIT 1),
        (SELECT MAX({key}) + 1 FROM {table}))""",
    )


def _gateway_glob_predicate(patterns: Sequence[str], *, negate: bool) -> str:
    """``gateway_id`` test matching (or not matching) any of *patterns*.

    SQLite's ``GLOB`` takes the shell-style patterns the flag documents,
    so ``TRADER*`` means what a user expects without a regex detour. The
    patterns are inlined as SQL string literals rather than bound
    parameters because the prune statements are built once and cached as
    text; they come from the command line and are validated at parse
    time, and the quote-doubling here keeps a stray apostrophe from
    terminating the literal.
    """
    quoted = [p.replace("'", "''") for p in patterns]
    joined = " OR ".join(f"gateway_id GLOB '{p}'" for p in quoted)
    return f"NOT ({joined})" if negate else f"({joined})"


def _prune_order_events(patterns: Sequence[str], *, human: bool) -> _Prune:
    """Prune ``order_events`` for one retention tier.

    The ``seq`` watermark is the first row inside the window in primary-key
    order, so the delete only touches rows at the head of the table. The
    ``gateway_id`` test then splits that range between the two tiers, which is
    why each tier's cutoff can differ.
    """
    if not patterns:
        return _prune_by_key("order_events", "seq")
    return _prune_by_key(
        "order_events", "seq", _gateway_glob_predicate(patterns, negate=not human)
    )


_PRUNE_STATEMENTS = (
    _prune_by_key("trade_log", "rowid"),
    _Prune(
        "DELETE FROM price_snapshots WHERE rowid IN (SELECT rowid FROM"
        " price_snapshots WHERE ts < :cutoff LIMIT :batch)"
    ),
    _Prune(
        "DELETE FROM feed_gaps WHERE rowid IN (SELECT rowid FROM feed_gaps"
        " WHERE ts < :cutoff LIMIT :batch)"
    ),
)


def _is_order_event_topic(topic: str) -> bool:
    return topic.startswith(
        (
            PREFIX_ORDER_ACK,
            PREFIX_ORDER_FILL,
            PREFIX_ORDER_AMENDED,
            PREFIX_ORDER_CANCELLED,
            PREFIX_ORDER_EXPIRED,
            PREFIX_COMBO_ACK,
            PREFIX_COMBO_STATUS,
            PREFIX_OCO_ACK,
            PREFIX_OCO_CANCELLED,
            PREFIX_QUOTE_ACK,
            PREFIX_QUOTE_STATUS,
        )
    )


def _accept_reject(
    topic: str,
    payload: dict[str, Any],
    accepted_value: str,
    rejected_value: str,
) -> str:
    """Resolve an ack-style event to its accepted or rejected type.

    A missing ``accepted`` flag records :data:`UNKNOWN_EVENT_TYPE` rather than
    falling through to the rejected value. Every one of these payloads carries
    the flag today, so its absence means a bug or a corrupted message — and
    writing a confident "rejected" into an audit trail on that basis fabricates
    a fact. Missing information is recoverable; wrong information is not.
    """
    accepted = payload.get("accepted")
    if accepted is None:
        log.error(
            "%s carries no 'accepted' flag; recording %s rather than assuming "
            "a rejection",
            topic,
            UNKNOWN_EVENT_TYPE,
        )
        return UNKNOWN_EVENT_TYPE
    return accepted_value if accepted else rejected_value


def _event_type_from_topic(topic: str, payload: dict[str, Any]) -> str:
    """Map a private engine topic to a normalized ``order_events.event_type``.

    Combo, OCO and quote topics resolve to their own accept / reject / cancel /
    status values instead of collapsing to a bare family name. Collapsing them
    made a rejected combo indistinguishable from an accepted one, and filed
    ``oco.cancelled`` under ``OCO``, where no cancel-oriented filter could
    find it.
    """
    if topic.startswith(PREFIX_ORDER_ACK):
        return _accept_reject(topic, payload, "ACK", "REJECT")
    if topic.startswith(PREFIX_ORDER_FILL):
        return "FILL"
    if topic.startswith(PREFIX_ORDER_AMENDED):
        return "AMEND"
    if topic.startswith(PREFIX_ORDER_CANCELLED):
        return "CANCEL"
    if topic.startswith(PREFIX_ORDER_EXPIRED):
        return "EXPIRE"
    if topic.startswith(PREFIX_COMBO_ACK):
        return _accept_reject(topic, payload, "COMBO_ACK", "COMBO_REJECT")
    if topic.startswith(PREFIX_COMBO_STATUS):
        return "COMBO_STATUS"
    if topic.startswith(PREFIX_OCO_ACK):
        return _accept_reject(topic, payload, "OCO_ACK", "OCO_REJECT")
    if topic.startswith(PREFIX_OCO_CANCELLED):
        return "OCO_CANCEL"
    if topic.startswith(PREFIX_QUOTE_ACK):
        return _accept_reject(topic, payload, "QUOTE_ACK", "QUOTE_REJECT")
    if topic.startswith(PREFIX_QUOTE_STATUS):
        return "QUOTE_STATUS"
    return "EVENT"


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="EduMatcher statistics recorder")
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-stats")
    parser.add_argument(
        "--db",
        default=str(STATS_DB_FILE),
        metavar="PATH",
        help=f"SQLite database path (default: {STATS_DB_FILE})",
    )
    parser.add_argument(
        "--snapshot-interval",
        type=float,
        default=SNAPSHOT_INTERVAL_SEC,
        metavar="SEC",
        help=(
            f"Seconds between price_snapshots rows per symbol "
            f"(default: {SNAPSHOT_INTERVAL_SEC} = 15 min). "
            "Use a smaller value for higher-resolution intraday history, "
            "e.g. 60 for one-minute snapshots."
        ),
    )
    parser.add_argument(
        "--keep-days",
        type=float,
        default=0.0,
        metavar="N",
        help=(
            "Keep N days of trades, order events and snapshots; older rows "
            "are deleted hourly. Daily rollups are always kept "
            "(default: 0 = keep everything)"
        ),
    )
    parser.add_argument(
        "--keep-order-events-days",
        type=float,
        default=None,
        metavar="N",
        help=(
            "Keep N days of order events, overriding --keep-days for them; "
            "fractions are fine, e.g. 0.1 for about 2.4 hours "
            "(default: as --keep-days)"
        ),
    )
    parser.add_argument(
        "--human-gateways",
        default="",
        metavar="GLOB[,GLOB...]",
        help=(
            "Comma-separated glob patterns for gateways that are people "
            "rather than bots, e.g. 'TRADER*'. Their order events prune on "
            "--keep-human-order-events-days instead of the ordinary "
            "retention (default: none, one retention for everyone)"
        ),
    )
    parser.add_argument(
        "--keep-human-order-events-days",
        type=float,
        default=None,
        metavar="N",
        help=(
            "Keep N days of order events for --human-gateways; a single "
            "retention short enough for a swarm also deletes a person's few "
            "rows (default: as --keep-order-events-days)"
        ),
    )
    parser.add_argument(
        "--sql-trace",
        action="store_true",
        help="Log executed SQLite statements from the stats writer connection",
    )
    parser.add_argument(
        "--log-level",
        choices=["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"],
        help="Logging level override (default: WARNING)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase log verbosity (-v: INFO, -vv: DEBUG)",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help=(
            "Explicit WARNING log level (the default); -v and --log-level take precedence"
        ),
    )
    parser.add_argument(
        "--log-target",
        choices=["server", "stdout", "file"],
        default=None,
        help=(
            "Where this process's own operational log records go: "
            "server (default, auto-detected pm-log-srv), stdout, or file"
        ),
    )
    parser.add_argument(
        "--log-file",
        default=None,
        metavar="PATH",
        help="Operational log file path — required when --log-target file",
    )
    parser.add_argument(
        "--log-failover-timeout",
        type=float,
        default=None,
        metavar="SECONDS",
        help=(
            "Grace window before falling back to a local log file once "
            "pm-log-srv becomes unreachable (default: 30, from config)"
        ),
    )
    return parser


def _configure_logging(args: argparse.Namespace) -> int:
    log_level = getattr(args, "log_level", None)
    verbose = getattr(args, "verbose", 0)
    quiet = getattr(args, "quiet", False)

    if log_level:
        level_name = str(log_level).upper()
        level = getattr(logging, level_name, logging.WARNING)
    elif verbose >= 2:
        level = logging.DEBUG
    elif verbose == 1:
        level = logging.INFO
    elif quiet:
        level = logging.WARNING
    else:
        level = logging.WARNING

    client_config = load_default_log_client_config()
    server_config = load_default_log_server_config()
    failover_timeout = getattr(args, "log_failover_timeout", None)
    handler = resolve_handler(
        log_target=getattr(args, "log_target", None),
        log_file=getattr(args, "log_file", None),
        client_name=_CLIENT_NAME,
        instance=None,
        host=resolve_host_default(),
        port=server_config.port,
        connect_timeout_sec=client_config.connect_timeout_sec,
        failover_timeout_sec=(
            failover_timeout
            if failover_timeout is not None
            else client_config.failover_timeout_sec
        ),
        failover_dir=client_config.failover_dir,
    )
    logging.basicConfig(level=level, format=_LOG_FORMAT, handlers=[handler])
    return int(level)


def _enable_sql_trace_logging() -> None:
    """Install a dedicated handler for verbose SQLite statement tracing."""
    _sql_log.setLevel(logging.DEBUG)
    _sql_log.propagate = False
    if _sql_log.handlers:
        return
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s - %(message)s")
    )
    _sql_log.addHandler(handler)


@exit_on_config_error
def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    log_level = _configure_logging(args)
    if args.sql_trace:
        _enable_sql_trace_logging()
    log.info("starting pm-stats with log level %s", logging.getLevelName(log_level))
    log.debug(
        "resolved stats config: db=%s snapshot_interval=%s",
        args.db,
        args.snapshot_interval,
    )
    if args.keep_days < 0:
        parser.error("--keep-days must be >= 0")
    if args.keep_order_events_days is not None and args.keep_order_events_days < 0:
        parser.error("--keep-order-events-days must be >= 0")
    if (
        args.keep_human_order_events_days is not None
        and args.keep_human_order_events_days < 0
    ):
        parser.error("--keep-human-order-events-days must be >= 0")
    human_gateways = tuple(
        pattern
        for pattern in (p.strip() for p in args.human_gateways.split(","))
        if pattern
    )
    if args.keep_human_order_events_days is not None and not human_gateways:
        # The retention would apply to nobody, so the flag would appear to
        # work while changing nothing at all.
        parser.error(
            "--keep-human-order-events-days needs --human-gateways to say "
            "which gateways it applies to"
        )
    if args.snapshot_interval < MIN_SNAPSHOT_INTERVAL_SEC:
        # price_snapshots is keyed on (ts, symbol) at second precision, so a
        # sub-second interval asks for rows the table cannot hold: the extras
        # collide and INSERT OR IGNORE discards them without a word. Refuse
        # rather than accept a setting that silently does not work.
        parser.error(
            f"--snapshot-interval must be at least {MIN_SNAPSHOT_INTERVAL_SEC} "
            f"second: price_snapshots stores at most one row per second per "
            f"symbol, so a shorter interval would silently discard rows"
        )
    from edumatcher.config_artifact import load_compiled_config
    from edumatcher.engine.config_loader import DEFAULT_SESSION_TIMEZONE

    compiled = load_compiled_config()
    session_tz_name = (
        DEFAULT_SESSION_TIMEZONE
        if compiled is None
        else compiled.engine.locale.session_timezone
    )
    session_tz = resolve_timezone(session_tz_name)
    if session_tz is None:
        parser.error(
            f"engine config locale.session_timezone: unknown timezone {session_tz_name!r}"
        )
    try:
        process = StatsProcess(
            resolve_data_path(args.db),
            snapshot_interval_sec=args.snapshot_interval,
            sql_trace=args.sql_trace,
            session_tz=session_tz,
            keep_days=args.keep_days,
            keep_order_events_days=args.keep_order_events_days,
            human_gateways=human_gateways,
            keep_human_order_events_days=args.keep_human_order_events_days,
        )
    except Exception as exc:
        log.critical("fatal startup error: %s", exc)
        sys.exit(1)
    reporter = HealthReporter.start_from_compiled_config(_CLIENT_NAME)
    if reporter is not None:
        process.attach_reporter(reporter)
    sys.exit(process.run())


if __name__ == "__main__":
    main()
