"""pm-opctl - start, stop, and monitor named EduMatcher process profiles.

EduMatcher runs as a set of cooperating ``pm-*`` processes connected by a
ZeroMQ message bus. This module is the operator front end for that stack: it
launches a named group of those processes, tracks them, reports their health,
and shuts them down again.

Profiles
--------
A *profile* is a named list of processes to run together. Six profiles are
built in:

``micro``
    Centralized logging plus the matching engine only.
``mini``
    A trading-capable subset: logging, stats, engine, scheduler, market data,
    the desk API gateway, and the ALF/post-trade/drop-copy gateways.
``default``
    The full nominal exchange stack, including audit, clearing, both API
    gateway instances, and the BALF gateway.
``mm-demo``
    ``default`` plus one ``pm-mm-bot`` running the ``passive`` strategy at a
    deliberately slow pace, so a student can watch a market maker work. It
    quotes as gateway ``MM01``, which the bundled example configs register, on
    every symbol of the deployed configuration.
``ai-swarm``
    ``mm-demo`` plus ``pm-ai-swarm`` running the AI traders ``AI001``-``AI020``
    (one worker, about 40 order actions a second). Needs a configuration that
    registers them, such as the ``s150`` examples or ``s300-load``.
``ai-sim``
    ``ai-swarm`` with the swarm of the ``s300-sim`` example: ``AI001``-``AI100``
    on 300 symbols (its ``swarm.yaml``), a symmetric market maker, a quiet
    engine log, a week of trade statistics and an hour of order events. The
    long-running simulation of the
    ``edumatcher-ai-sim`` container image; needs ``s300-sim`` deployed.

The built-ins are used as-is when no configuration file exists. Running
``init`` writes them to ``<DATA_DIR>/emo-config.yaml`` so they can be edited.
Once that file exists its profiles replace the built-ins entirely; a missing
``default`` profile is backfilled from the built-in nominal stack.

Each process entry supports:

``name`` (required)
    Unique identifier used for the PID and log file names.
``command`` (required)
    A YAML list of argv tokens, or a shell-like string that is split with
    ``shlex``. The command is executed directly, never through a shell.
``healthcheck`` (optional)
    A command that exits ``0`` when the process is responsive.
``tcp`` (optional)
    A ``"host:port"`` address to probe with a plain TCP connect.

Health checking
---------------
There is no general way to prove an arbitrary process is not internally hung,
so health is reported at three levels of confidence:

* ``dead`` - no live PID could be found for the entry.
* ``not responding`` - the PID is alive but its ``healthcheck`` failed or its
  ``tcp`` address refused or timed out.
* ``running`` - the PID is alive and any configured check passed.

``healthcheck`` takes precedence over ``tcp`` because it exercises the
application itself. The ``tcp`` probe is far cheaper but weaker: libzmq's I/O
thread accepts connections independently of the application's own message
loop, so a successful connect proves the process is alive and bound to its
port, not that it is still processing messages.

Process tracking
----------------
Started processes are detached into their own session and recorded as
``<DATA_DIR>/emo/<name>.pid``, with combined stdout/stderr appended to
``<DATA_DIR>/emo/<name>.log``. The active profile name is remembered in
``<DATA_DIR>/emo/active-profile``.

Because a process restarted outside this tool gets a new PID, a stale PID file
is not treated as final. ``pgrep`` is used to look for a live process whose
command line matches the profile entry, and any match is re-adopted and
written back to the PID file. Matching ignores ``argv[0]`` and compares the
remaining arguments, since a console script appears in ``ps`` as
``python /path/to/pm-engine --verbose`` rather than ``pm-engine --verbose``.

Commands
--------
``start [profile]`` (alias ``up``)
    Start a profile (``default`` when omitted), skipping entries already
    running. When both ``pm-audit`` and ``pm-engine`` are configured, wait for
    the audit healthcheck before starting the engine.
``list``
    Print a status table for the active profile, including each process's
    uptime as ``HH:MM`` and resident memory in MiB, and offer to restart any
    dead entries. Use ``-y`` to restart without asking or ``--no-restart`` to
    suppress the offer; the prompt is skipped automatically when stdin is not
    a terminal. ``--no-tcp-probe`` leaves out the connect to each process's
    port (a gateway sees that as a client that logs on nothing); a live
    process then reads as running.
``health [-q]``
    Same checks as ``list``, but exits ``0`` only when every process is
    running. ``-q`` suppresses output for use in monitoring scripts.
``stop`` (alias ``down``)
    Send ``SIGTERM`` only to processes recorded in the PID directory.
``kill``
    Emergency stop: ``pkill -15 -f -i -l pm-``, which signals every process
    whose command line contains ``pm-``, including ones this tool did not
    start.
``init``
    Write the built-in profiles to ``<DATA_DIR>/emo-config.yaml``, refusing to
    overwrite an existing file.
``show [--json]``
    Print the version, resolved data directory, and the deployed
    configuration paths (source and compiled -- same paths as
    ``pm-config-deploy --show``). ``--json`` emits the same information as a
    JSON object instead of plain text.
``clear (--state | --all) [--yes]``
    Delete persisted data under the data directory. ``--state`` removes only
    engine/session state (order books, GTC orders, derived stats, index and
    clearing state) — the files whose staleness causes surprises like a
    ``seed_once: true`` market-maker quote silently failing to re-seed
    because ``book_stats.json`` still remembers the symbol from a previous
    run. ``--all`` additionally removes logs and the audit trail. Exactly one
    of ``--state``/``--all`` must be given; ``--yes`` skips the confirmation
    prompt. Configuration under ``ref_data/`` is never touched.

All paths resolve through :func:`edumatcher.config.resolve_data_path`, so the
tool and the processes it launches agree on ``EDUMATCHER_DATA_DIR``.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

import psutil
import yaml

from edumatcher.cli_pipe import pipe_safe
from edumatcher.cli_version import package_version
from edumatcher.examples import examples_root
from edumatcher.config import (
    AUDIT_INDEX_DB_FILE,
    AUDIT_LOG_FILE,
    CLEARING_DB_FILE,
    COMPILED_CONFIG_FILE,
    DATA_DIR,
    ENGINE_CONFIG_FILE,
    EOD_DB_FILE,
    GTC_COMBOS_FILE,
    GTC_ORDERS_FILE,
    BOOK_STATS_FILE,
    LOG_DB_FILE,
    METRICS_DB_FILE,
    LOG_FALLBACK_DIR,
    SETTLEMENT_DIR,
    STATS_DB_FILE,
    resolve_data_path,
)

CONFIG_NAME = "emo-config.yaml"
RUNTIME_DIR_NAME = "emo"
ACTIVE_PROFILE_FILE = "active-profile"
HEALTHCHECK_TIMEOUT_SEC = 2.0
TCP_CHECK_TIMEOUT_SEC = 0.3
LOG_SRV_COMMAND = "pm-log-srv"
LOG_SRV_READY_TIMEOUT_SEC = 10.0
LOG_SRV_READY_POLL_SEC = 0.1
AUDIT_COMMAND = "pm-audit"
AUDIT_READY_TIMEOUT_SEC = 10.0
# `stop` signals in waves, each waited out before the next: everything else,
# then the engine, then the recorders that must see its last messages, then the
# log server that hears the others' farewells.
STOP_WAVES: tuple[tuple[str, ...], ...] = (
    ("pm-engine",),
    ("pm-clearing", "pm-stats", "pm-audit", "pm-index", "pm-monitor"),
    (LOG_SRV_COMMAND,),
)
STOP_WAIT_SEC = 15.0
STOP_POLL_SEC = 0.1
GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
RESET = "\033[0m"

# All default processes necessary for a full exchange setup
DEFAULT_PROCESSES: list[dict[str, Any]] = [
    {"name": "log", "command": ["pm-log-srv"], "tcp": "127.0.0.1:5600"},
    # pm-monitor (operator dashboard): after the log server, so it can log,
    # and before the engine, so the engine's first beacons are received.
    {
        "name": "monitor",
        "command": ["pm-monitor", "--verbose"],
        # A snapshot proves the collector loop runs; a TCP connect only
        # proved the socket was bound (WP-B6).
        "healthcheck": ["pm-monitor-cli", "health", "-q"],
    },
    {
        "name": "audit",
        "command": ["pm-audit", "--verbose"],
        "healthcheck": ["pm-audit-cli", "health", "-q"],
    },
    {
        "name": "stats",
        "command": ["pm-stats", "--verbose"],
        "healthcheck": ["pm-stats-cli", "health", "-q"],
    },
    {
        "name": "clearing",
        "command": ["pm-clearing", "--verbose"],
        "healthcheck": ["pm-clearing-cli", "health", "-q"],
    },
    {"name": "engine", "command": ["pm-engine", "--verbose"], "tcp": "127.0.0.1:5555"},
    {
        "name": "scheduler",
        "command": [
            "pm-scheduler",
            "--daily",
            "--verbose",
            "--on-close",
            "pm-eod run --pending",
        ],
    },
    {
        "name": "market-data-gwy (md-gwy)",
        "command": ["pm-md-gwy", "--verbose"],
        "tcp": "127.0.0.1:5570",
    },
    {
        "name": "post-trade-gwy (ralf-gwy)",
        "command": ["pm-ralf-gwy", "--verbose"],
        "tcp": "127.0.0.1:5580",
    },
    {
        "name": "drop-copy-gwy (dc-gwy)",
        "command": ["pm-dc-gwy", "--verbose"],
        "tcp": "127.0.0.1:5590",
    },
    {
        "name": "api-desk-gwy (api-gwy)",
        "command": ["pm-api-gwy", "--verbose", "--instance", "desk"],
        "tcp": "127.0.0.1:8080",
    },
    {
        "name": "api-dashboards-gwy (api-gwy)",
        "command": ["pm-api-gwy", "--verbose", "--instance", "dashboards"],
        "tcp": "127.0.0.1:8081",
    },
    {
        "name": "alf-gwy",
        "command": ["pm-alf-gwy", "--verbose"],
        "tcp": "127.0.0.1:5565",
    },
    {
        "name": "balf-gwy",
        "command": ["pm-balf-gwy", "--verbose"],
        "tcp": "127.0.0.1:5560",
    },
    {
        "name": "index-srv",
        "command": ["pm-index", "--verbose"],
        "healthcheck": ["pm-index-cli", "health", "-q"],
    },
]

# Minimal set of processes for micro exchange setup. No Gwys
MICRO_PROCESSES: list[dict[str, Any]] = [
    {"name": "log", "command": ["pm-log-srv"], "tcp": "127.0.0.1:5600"},
    {"name": "engine", "command": ["pm-engine", "--verbose"], "tcp": "127.0.0.1:5555"},
]

# A minimal set of processes for a mini exchange setup that allows external clients to connect
MINI_PROCESSES: list[dict[str, Any]] = [
    {"name": "log", "command": ["pm-log-srv"], "tcp": "127.0.0.1:5600"},
    # pm-monitor (operator dashboard): after the log server, so it can log,
    # and before the engine, so the engine's first beacons are received.
    {
        "name": "monitor",
        "command": ["pm-monitor", "--verbose"],
        # A snapshot proves the collector loop runs; a TCP connect only
        # proved the socket was bound (WP-B6).
        "healthcheck": ["pm-monitor-cli", "health", "-q"],
    },
    {
        "name": "stats",
        "command": ["pm-stats", "--verbose"],
        "healthcheck": ["pm-stats-cli", "health", "-q"],
    },
    {"name": "engine", "command": ["pm-engine", "--verbose"], "tcp": "127.0.0.1:5555"},
    {"name": "scheduler", "command": ["pm-scheduler", "--daily", "--verbose"]},
    {
        "name": "market-data-gwy",
        "command": ["pm-md-gwy", "--verbose"],
        "tcp": "127.0.0.1:5570",
    },
    {
        "name": "api-desk-gwy",
        "command": ["pm-api-gwy", "--verbose", "--instance", "desk"],
        "tcp": "127.0.0.1:8080",
    },
    {
        "name": "alf-gwy",
        "command": ["pm-alf-gwy", "--verbose"],
        "tcp": "127.0.0.1:5565",
    },
    {
        "name": "post-trade-gwy",
        "command": ["pm-ralf-gwy", "--verbose"],
        "tcp": "127.0.0.1:5580",
    },
    {
        "name": "drop-copy-gwy",
        "command": ["pm-dc-gwy", "--verbose"],
        "tcp": "127.0.0.1:5590",
    },
]


# The default stack plus a slow, passive market-maker bot for classroom demos.
# Every bot setting is a command-line argument, so no bot config file is needed.
# The bot quotes as MM01 (the MARKET_MAKER gateway of the bundled example
# configs) on every symbol of the deployed configuration (--all-symbols), so
# the profile works with whatever config it is run against; --gap stays within
# the examples' mm_max_spread_ticks of 20 (0.20 at two-decimal ticks).
MM_DEMO_PROCESSES: list[dict[str, Any]] = [
    *DEFAULT_PROCESSES,
    {
        "name": "mm-bot",
        "command": [
            "pm-mm-bot",
            "--gateway-id",
            "MM01",
            "--all-symbols",
            "--strategy",
            "passive",
            "--gap",
            "0.20",
            "--qty",
            "200",
            "--reissue-delay-ms",
            "5000",
            "--fade-ticks",
            "3",
            "--fade-sec",
            "20",
            "--drift-ticks",
            "15",
        ],
    },
]

# The default set, the market model, mm-demo's market maker quoting around the
# model's true values, and twenty AI traders (AI001-AI020, as the s150 examples
# register), every built-in preset in equal shares, each trading every symbol
# (--symbols-per-agent is capped at the number of symbols). An unanchored
# passive market maker refills its quotes at its own mid and pins prices, so
# informed flow could not move them. --verbose logs one status line per
# minute and one summary per trading day.
AI_SWARM_PROCESSES: list[dict[str, Any]] = [
    *DEFAULT_PROCESSES,
    {
        "name": "mm-bot",
        "command": [*MM_DEMO_PROCESSES[-1]["command"], "--anchor-sim", "0.3"],
    },
    # The value and news presets trade on the market model's values and
    # headlines; without it they stand idle.
    {"name": "market-sim", "command": ["pm-market-sim", "--verbose"]},
    {
        "name": "ai-swarm",
        "command": [
            "pm-ai-swarm",
            "--count",
            "20",
            "--budget",
            "40",
            "--symbols-per-agent",
            "1000",
            "--verbose",
        ],
    },
]

# ai-swarm on the s300-sim example, set up to run for weeks: the example's
# swarm file (AI001-AI100, 30 symbols each); the engine without --verbose, which
# logs every order at INFO and would fill log.db; pm-audit closing 256 MB
# day parts (never deleted; ~1.2 GB an hour) that it compresses to one ~13:1
# archive per day, kept for a week, so whole sessions can be checked
# afterwards; pm-stats keeping a week
# of trades and two days of order events, which are nearly all of stats.db
# under a swarm (~1.2 GB a trading day; daily rollups are kept for good);
# pm-clearing keeping a week of raw
# trades (not 90 days: ~150 MB a trading day here) and without its console P&L
# table, which it redraws every 100 trades into its emo log; and a
# symmetric market maker: the passive one re-quotes whenever other traders'
# orders change whether its sides are covered, which with a hundred traders on
# 300 symbols was most of the exchange's messages, CPU and disk.
_AI_SIM_COMMANDS = {
    "engine": ["pm-engine"],
    # pm-eod settles every simulated day, but backs up less than the default:
    # two days, and not stats.db (about 3 GB of mostly disposable order events;
    # the money record is clearing.db and eod.db).
    "scheduler": [
        "pm-scheduler",
        "--daily",
        "--verbose",
        "--on-close",
        "pm-eod run --pending --backup-keep-days 2 --backup-skip stats.db",
    ],
    "mm-bot": [
        "pm-mm-bot",
        "--gateway-id",
        "MM01",
        "--all-symbols",
        "--strategy",
        "symmetric",
        "--gap",
        "0.20",
        "--qty",
        "200",
        "--reissue-delay-ms",
        "5000",
        "--drift-ticks",
        "15",
        "--anchor-sim",
        "0.3",
    ],
    "audit": [
        "pm-audit",
        "--verbose",
        "--max-file-mb",
        "256",
        "--keep-days",
        "7",
    ],
    "stats": [
        "pm-stats",
        "--verbose",
        "--keep-days",
        "7",
        "--keep-order-events-days",
        "2",
        "--human-gateways",
        "TRADER*",
        "--keep-human-order-events-days",
        "7",
    ],
    "clearing": [
        "pm-clearing",
        "--verbose",
        "--print-every",
        "0",
        "--retention-days",
        "7",
    ],
    "ai-swarm": [
        "pm-ai-swarm",
        "--swarm",
        str(examples_root() / "s300-sim-setup" / "swarm.yaml"),
        "--verbose",
    ],
}
# s300-sim gives the admin monitor feed an API gateway instance of its own
# ('monitor', admin id MON01): its fan-out saturated the event loop of 'desk'
# at the open. trader-gui sends only that socket there.
_AI_SIM_MONITOR_GWY: dict[str, Any] = {
    "name": "api-monitor-gwy (api-gwy)",
    "command": ["pm-api-gwy", "--verbose", "--instance", "monitor"],
    "tcp": "127.0.0.1:8082",
}
AI_SIM_PROCESSES: list[dict[str, Any]] = []
for _process in AI_SWARM_PROCESSES:
    AI_SIM_PROCESSES.append(
        {
            **_process,
            "command": _AI_SIM_COMMANDS.get(_process["name"], _process["command"]),
        }
    )
    if _process["name"] == "api-dashboards-gwy (api-gwy)":
        AI_SIM_PROCESSES.append(_AI_SIM_MONITOR_GWY)

# {"name": "trader", "command": ["pm-alf-console", "--id", "TRADER01", "--verbose"]},

BUILTIN_PROFILES = {
    "default": DEFAULT_PROCESSES,
    "micro": MICRO_PROCESSES,
    "mini": MINI_PROCESSES,
    "mm-demo": MM_DEMO_PROCESSES,
    "ai-swarm": AI_SWARM_PROCESSES,
    "ai-sim": AI_SIM_PROCESSES,
}


def runtime_dir() -> Path:
    return resolve_data_path(RUNTIME_DIR_NAME)


def config_path() -> Path:
    return resolve_data_path(CONFIG_NAME)


def pid_path(name: str) -> Path:
    return resolve_data_path(f"{RUNTIME_DIR_NAME}/{name}.pid")


def log_path(name: str) -> Path:
    return resolve_data_path(f"{RUNTIME_DIR_NAME}/{name}.log")


def active_profile_path() -> Path:
    return resolve_data_path(f"{RUNTIME_DIR_NAME}/{ACTIVE_PROFILE_FILE}")


def load_profiles() -> dict[str, list[dict[str, Any]]]:
    path = config_path()
    if not path.exists():
        return {name: list(processes) for name, processes in BUILTIN_PROFILES.items()}

    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if raw is None:
        return {"default": list(DEFAULT_PROCESSES)}
    if not isinstance(raw, dict):
        raise ValueError(f"{path} must contain a mapping of profile names")

    profiles: dict[str, list[dict[str, Any]]] = {}
    for profile_name, profile_raw in raw.items():
        if not isinstance(profile_name, str) or not profile_name.strip():
            raise ValueError("profile names must be non-empty strings")
        process_raw = (
            profile_raw.get("processes")
            if isinstance(profile_raw, dict)
            else profile_raw
        )
        if not isinstance(process_raw, list):
            raise ValueError(f"profile {profile_name!r}.processes must be a list")
        profiles[profile_name] = validate_processes(profile_name, process_raw)

    if "default" not in profiles:
        profiles["default"] = list(DEFAULT_PROCESSES)
    return profiles


def create_config() -> int:
    path = config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    document = {
        profile_name: {"processes": processes}
        for profile_name, processes in BUILTIN_PROFILES.items()
    }
    text = yaml.safe_dump(document, sort_keys=False, allow_unicode=False)
    try:
        with path.open("x", encoding="utf-8") as output:
            output.write(text)
    except FileExistsError:
        print(f"Refusing to overwrite existing configuration: {path}", file=sys.stderr)
        return 1
    print(f"Created pm-opctl configuration: {path}")
    print("Profiles: " + ", ".join(document))
    return 0


def validate_processes(
    profile_name: str, process_raw: list[Any]
) -> list[dict[str, Any]]:
    processes: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, item in enumerate(process_raw):
        if not isinstance(item, dict):
            raise ValueError(
                f"profile {profile_name!r} process {index} must be a mapping"
            )
        name = item.get("name")
        command = item.get("command")
        healthcheck = item.get("healthcheck")
        tcp = item.get("tcp")
        if not isinstance(name, str) or not name.strip():
            raise ValueError(f"profile {profile_name!r} process {index} needs a name")
        if name in seen:
            raise ValueError(f"profile {profile_name!r} repeats process name {name!r}")
        if isinstance(command, str):
            command = shlex.split(command)
        if (
            not isinstance(command, list)
            or not command
            or not all(isinstance(part, str) and part for part in command)
        ):
            raise ValueError(
                f"profile {profile_name!r} process {name!r} needs a command list or string"
            )
        if isinstance(healthcheck, str):
            healthcheck = shlex.split(healthcheck)
        if healthcheck is not None and (
            not isinstance(healthcheck, list)
            or not healthcheck
            or not all(isinstance(part, str) and part for part in healthcheck)
        ):
            raise ValueError(
                f"profile {profile_name!r} process {name!r} healthcheck must be a command list or string"
            )
        if tcp is not None:
            if not isinstance(tcp, str) or ":" not in tcp:
                raise ValueError(
                    f"profile {profile_name!r} process {name!r} tcp must be host:port"
                )
            _, _, port_text = tcp.rpartition(":")
            if not port_text.isdigit():
                raise ValueError(
                    f"profile {profile_name!r} process {name!r} tcp port must be numeric"
                )
        seen.add(name)
        process = {"name": name, "command": command}
        if healthcheck is not None:
            process["healthcheck"] = healthcheck
        if tcp is not None:
            process["tcp"] = tcp
        processes.append(process)
    return processes


def read_pid(name: str) -> int | None:
    try:
        pid = int(pid_path(name).read_text(encoding="ascii").strip())
    except FileNotFoundError, ValueError:
        return None
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        pid_path(name).unlink(missing_ok=True)
        return None
    except PermissionError:
        return pid
    return pid


def pgrep_pids(program: str) -> list[int]:
    try:
        result = subprocess.run(
            ["pgrep", "-f", program],
            capture_output=True,
            text=True,
            timeout=HEALTHCHECK_TIMEOUT_SEC,
            check=False,
        )
    except OSError, subprocess.TimeoutExpired:
        return []
    return [int(line) for line in result.stdout.split() if line.isdigit()]


def command_line(pid: int) -> str:
    try:
        result = subprocess.run(
            ["ps", "-p", str(pid), "-o", "args="],
            capture_output=True,
            text=True,
            timeout=HEALTHCHECK_TIMEOUT_SEC,
            check=False,
        )
    except OSError, subprocess.TimeoutExpired:
        return ""
    return result.stdout.strip()


def matches_command(cmdline: str, command: list[str]) -> bool:
    """Match ignoring argv[0]; console scripts run as `python /path/pm-foo ...`."""
    try:
        tokens = shlex.split(cmdline)
    except ValueError:
        tokens = cmdline.split()
    program = os.path.basename(command[0])
    for index, token in enumerate(tokens):
        if os.path.basename(token) == program:
            return tokens[index + 1 :] == list(command[1:])
    return False


def discover_pid(process: dict[str, Any], claimed: set[int]) -> int | None:
    """Find a running process matching this entry's command line."""
    command = process["command"]
    own_pid = os.getpid()
    for pid in pgrep_pids(os.path.basename(command[0])):
        if pid == own_pid or pid in claimed:
            continue
        if matches_command(command_line(pid), command):
            return pid
    return None


def resolve_pid(process: dict[str, Any], claimed: set[int]) -> tuple[int | None, bool]:
    """Return the live PID for a process, re-adopting it if it was restarted."""
    name = process["name"]
    pid = read_pid(name)
    if pid is not None:
        claimed.add(pid)
        return pid, False
    pid = discover_pid(process, claimed)
    if pid is None:
        return None, False
    claimed.add(pid)
    runtime_dir().mkdir(parents=True, exist_ok=True)
    pid_path(name).write_text(f"{pid}\n", encoding="ascii")
    return pid, True


def spawn_process(process: dict[str, Any]) -> int | None:
    """Launch one profile process and record its PID."""
    name = process["name"]
    command = process["command"]
    runtime_dir().mkdir(parents=True, exist_ok=True)
    output = log_path(name).open("ab")
    try:
        child = subprocess.Popen(
            command,
            env=os.environ.copy(),
            stdin=subprocess.DEVNULL,
            stdout=output,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )
    except OSError as exc:
        print(f"  failed to start {name}: {exc}", file=sys.stderr)
        return None
    finally:
        output.close()
    pid_path(name).write_text(f"{child.pid}\n", encoding="ascii")
    return child.pid


def write_active_profile(profile_name: str) -> None:
    active_profile_path().write_text(f"{profile_name}\n", encoding="utf-8")


def read_active_profile() -> str | None:
    try:
        profile_name = active_profile_path().read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        return None
    return profile_name or None


def check_tcp(address: str) -> tuple[str, str]:
    """Cheapest liveness probe for a ZMQ-bus process: connect, don't speak.

    A successful connect only proves the transport accepted it — libzmq's I/O
    thread accepts sockets independently of the application thread, so this
    does not prove the process's own message loop is unstuck. It is still the
    cheapest signal available without a protocol-specific client.
    """
    host, _, port_text = address.rpartition(":")
    try:
        with socket.create_connection(
            (host, int(port_text)), timeout=TCP_CHECK_TIMEOUT_SEC
        ):
            pass
    except OSError as exc:
        return "not responding", f"tcp connect to {address} failed: {exc}"
    return "running", f"tcp connect to {address} ok"


def check_health(
    process: dict[str, Any], pid: int | None, probe_tcp: bool = True
) -> tuple[str, str]:
    if pid is None:
        return "dead", "process is not running"
    healthcheck = process.get("healthcheck")
    if healthcheck is not None:
        try:
            result = subprocess.run(
                healthcheck,
                env=os.environ.copy(),
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=HEALTHCHECK_TIMEOUT_SEC,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            return "not responding", str(exc)
        if result.returncode == 0:
            return "running", "healthcheck passed"
        return "not responding", f"healthcheck exit {result.returncode}"
    tcp = process.get("tcp")
    if tcp is not None and probe_tcp:
        return check_tcp(tcp)
    return "running", "no healthcheck or tcp check configured"


def status_mark(status: str) -> str:
    if status == "running":
        return f"{GREEN}✅{RESET}"
    if status == "dead":
        return f"{RED}❌{RESET}"
    return f"{YELLOW}⚠️{RESET}"


def parse_etime(text: str) -> float | None:
    """Parse the portable ps elapsed-time format ``[[dd-]hh:]mm:ss`` to minutes."""
    days, _, clock = text.strip().rpartition("-")
    parts = clock.split(":")
    if not all(part.isdigit() for part in parts) or not 2 <= len(parts) <= 3:
        return None
    values = [int(part) for part in parts]
    seconds = values.pop()
    minutes = values.pop()
    hours = values.pop() if values else 0
    total = seconds + minutes * 60 + hours * 3600
    if days:
        if not days.isdigit():
            return None
        total += int(days) * 86400
    return total / 60


def process_stats(pid: int) -> tuple[float | None, float | None]:
    """Return (uptime minutes, resident memory MiB) for a running process."""
    try:
        result = subprocess.run(
            ["ps", "-p", str(pid), "-o", "etime=,rss="],
            capture_output=True,
            text=True,
            timeout=HEALTHCHECK_TIMEOUT_SEC,
            check=False,
        )
    except OSError, subprocess.TimeoutExpired:
        return None, None
    fields = result.stdout.split()
    if len(fields) != 2:
        return None, None
    etime, rss = fields
    return parse_etime(etime), int(rss) / 1024 if rss.isdigit() else None


def format_uptime(minutes: float | None) -> str:
    if minutes is None:
        return "-"
    total = int(minutes)
    return f"{total // 60:02d}:{total % 60:02d}"


def list_profile(restart: str = "ask", probe_tcp: bool = True) -> int:
    profile_name = read_active_profile()
    if profile_name is None:
        print("No pm-opctl profile is recorded as started.")
        return 1
    profiles = load_profiles()
    processes = profiles.get(profile_name)
    if processes is None:
        print(f"Active profile {profile_name!r} is no longer defined.", file=sys.stderr)
        return 1

    print(f"pm-opctl profile: {profile_name}")
    print(f"data directory: {DATA_DIR}")
    header = (
        f"{'':1} {'Process':<30} {'PID':>7} {'Uptime':>8} "
        f"{'RSS(MB)':>8}  {'Status':<15} Details"
    )
    print(header)
    print("-" * 94)
    claimed: set[int] = set()
    dead: list[dict[str, Any]] = []
    for process in processes:
        name = process["name"]
        pid, adopted = resolve_pid(process, claimed)
        state, detail = check_health(process, pid, probe_tcp)
        if adopted:
            detail = f"{detail} (re-adopted restarted process)"
        if state == "dead":
            dead.append(process)
        uptime, rss = process_stats(pid) if pid is not None else (None, None)
        uptime_text = format_uptime(uptime)
        rss_text = f"{rss:.1f}" if rss is not None else "-"
        print(
            f"{status_mark(state)} {name:<30} {str(pid or '-'):>7} "
            f"{uptime_text:>8} {rss_text:>8}  {state:<15} {detail}"
        )

    if dead and restart != "never":
        restart_dead(dead, assume_yes=restart == "always")
    return 0


def restart_dead(dead: list[dict[str, Any]], assume_yes: bool) -> None:
    names = ", ".join(process["name"] for process in dead)
    if not assume_yes:
        if not sys.stdin.isatty():
            return
        answer = input(f"\nRestart {len(dead)} dead process(es) ({names})? [y/N] ")
        if answer.strip().lower() not in {"y", "yes"}:
            return
    print(f"Restarting: {names}")
    for process in dead:
        pid = spawn_process(process)
        if pid is not None:
            command = " ".join(process["command"])
            print(f"  started {process['name']} (pid {pid}): {command}")


def health_profile(quiet: bool) -> int:
    """Like list_profile, but exits non-zero unless every process is running."""
    profile_name = read_active_profile()
    if profile_name is None:
        if not quiet:
            print("No pm-opctl profile is recorded as started.", file=sys.stderr)
        return 1
    profiles = load_profiles()
    processes = profiles.get(profile_name)
    if processes is None:
        if not quiet:
            print(
                f"Active profile {profile_name!r} is no longer defined.",
                file=sys.stderr,
            )
        return 1

    healthy = True
    claimed: set[int] = set()
    for process in processes:
        name = process["name"]
        pid, _ = resolve_pid(process, claimed)
        state, detail = check_health(process, pid)
        if state != "running":
            healthy = False
        if not quiet:
            print(f"{status_mark(state)} {name:<20} {state:<15} {detail}")
    if not quiet:
        print(f"health: {'OK' if healthy else 'FAIL'}")
    return 0 if healthy else 1


def wait_for_tcp(address: str, timeout_sec: float) -> bool:
    """Poll until a TCP connect to ``address`` succeeds or the timeout expires."""
    deadline = time.monotonic() + timeout_sec
    while True:
        if check_tcp(address)[0] == "running":
            return True
        if time.monotonic() >= deadline:
            return False
        time.sleep(LOG_SRV_READY_POLL_SEC)


def wait_for_health(process: dict[str, Any], pid: int, timeout_sec: float) -> bool:
    """Poll a process's application healthcheck until it passes or times out."""
    deadline = time.monotonic() + timeout_sec
    while True:
        if check_health(process, pid)[0] == "running":
            return True
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False
        time.sleep(min(LOG_SRV_READY_POLL_SEC, remaining))


def start_profile(profile_name: str, *, debug: bool = False) -> int:
    profiles = load_profiles()
    if profile_name not in profiles:
        available = ", ".join(sorted(profiles))
        print(
            f"Unknown configuration {profile_name!r}; available: {available}",
            file=sys.stderr,
        )
        return 2

    runtime_dir().mkdir(parents=True, exist_ok=True)
    processes = profiles[profile_name]
    if debug:
        processes = [
            {**process, "command": [*process["command"], "--log-level", "DEBUG"]}
            for process in processes
        ]
    write_active_profile(profile_name)
    print(f"Starting pm-opctl configuration {profile_name!r} from {config_path()}")
    print(f"Data directory: {DATA_DIR}")
    claimed: set[int] = set()
    # pm-log-srv always goes first: every other process probes for it once at
    # startup and never re-probes, so it has to be accepting connections by then.
    processes = sorted(processes, key=lambda p: p["command"][0] != LOG_SRV_COMMAND)
    if any(p["command"][0] == "pm-engine" for p in processes):
        audit_index = next(
            (i for i, p in enumerate(processes) if p["command"][0] == AUDIT_COMMAND),
            None,
        )
        engine_index = next(
            (i for i, p in enumerate(processes) if p["command"][0] == "pm-engine"),
            None,
        )
        if (
            audit_index is not None
            and engine_index is not None
            and audit_index > engine_index
        ):
            audit = processes.pop(audit_index)
            processes.insert(engine_index, audit)
    for process in processes:
        name = process["name"]
        command = process["command"][0]
        wait_for_audit = command == AUDIT_COMMAND and any(
            p["command"][0] == "pm-engine" for p in processes
        )
        health_process = process
        if wait_for_audit and process.get("healthcheck") is None:
            health_process = {
                **process,
                "healthcheck": ["pm-audit-cli", "health", "-q"],
            }
        existing, _ = resolve_pid(process, claimed)
        pid: int
        if existing is not None:
            print(f"  already running {name} (pid {existing})")
            pid = existing
        else:
            spawned_pid = spawn_process(process)
            if spawned_pid is None:
                return 1
            pid = spawned_pid
            print(f"  started {name} (pid {pid}): {' '.join(process['command'])}")
        if wait_for_audit and not wait_for_health(
            health_process, pid, AUDIT_READY_TIMEOUT_SEC
        ):
            print(
                f"  error: {name} not healthy after {AUDIT_READY_TIMEOUT_SEC:g}s; "
                "pm-engine was not started",
                file=sys.stderr,
            )
            return 1
        address = process.get("tcp")
        if existing is None and command == LOG_SRV_COMMAND and isinstance(address, str):
            if not wait_for_tcp(address, LOG_SRV_READY_TIMEOUT_SEC):
                print(
                    f"  warning: {name} not accepting connections on {address} "
                    f"after {LOG_SRV_READY_TIMEOUT_SEC:g}s; continuing",
                    file=sys.stderr,
                )
    return 0


def stop_wave(name: str, programs: dict[str, str]) -> int:
    """Index into STOP_WAVES for a process (0 is the first to stop)."""
    program = programs.get(name)
    for index, wave in enumerate(STOP_WAVES):
        if program in wave:
            return index + 1
    return 0


def is_alive(pid: int) -> bool:
    try:
        return psutil.Process(pid).status() != psutil.STATUS_ZOMBIE
    except psutil.NoSuchProcess:
        return False


def stop_profile() -> int:
    runtime = runtime_dir()
    pid_files = sorted(runtime.glob("*.pid"))
    if not pid_files:
        print("No pm-opctl-managed processes are running.")
        active_profile_path().unlink(missing_ok=True)
        return 0

    active = read_active_profile()
    programs = {
        process["name"]: os.path.basename(process["command"][0])
        for process in load_profiles().get(active or "", [])
    }
    waves: dict[int, dict[str, int]] = {}
    for path in pid_files:
        name = path.stem
        pid = read_pid(name)
        if pid is None:
            path.unlink(missing_ok=True)
            continue
        waves.setdefault(stop_wave(name, programs), {})[name] = pid

    for _, members in sorted(waves.items()):
        for name, pid in members.items():
            try:
                os.kill(pid, signal.SIGTERM)
                print(f"  stopped {name} (pid {pid})")
            except ProcessLookupError:
                pass
            pid_path(name).unlink(missing_ok=True)
        deadline = time.monotonic() + STOP_WAIT_SEC
        while any(is_alive(pid) for pid in members.values()):
            if time.monotonic() >= deadline:
                print(
                    f"  warning: {', '.join(members)} still running "
                    f"{STOP_WAIT_SEC:g}s after SIGTERM; continuing",
                    file=sys.stderr,
                )
                break
            time.sleep(STOP_POLL_SEC)
    active_profile_path().unlink(missing_ok=True)
    return 0


def kill_all_processes() -> int:
    """Send SIGTERM to every process whose full command line contains pm-."""
    print("Sending signal 15 to all matching EduMatcher processes...")
    result = subprocess.run(
        ["pkill", "-15", "-f", "-i", "-l", "pm-"],
        check=False,
    )
    runtime = runtime_dir()
    for path in runtime.glob("*.pid"):
        path.unlink(missing_ok=True)
    active_profile_path().unlink(missing_ok=True)
    if result.returncode == 0:
        return 0
    if result.returncode == 1:
        print("No matching EduMatcher processes were found.")
        return 0
    print(f"pkill failed with exit code {result.returncode}", file=sys.stderr)
    return result.returncode


def show_info(*, json_output: bool) -> int:
    """Print version, data directory, and the deployed config paths.

    The config paths mirror ``pm-config-deploy --show`` exactly -- both read
    the same ``ENGINE_CONFIG_FILE``/``COMPILED_CONFIG_FILE`` constants -- so
    the two commands can never disagree about where configuration lives.
    """
    version = package_version()
    if json_output:
        print(
            json.dumps(
                {
                    "version": version,
                    "data_dir": str(DATA_DIR),
                    "config_source": str(ENGINE_CONFIG_FILE),
                    "config_compiled": str(COMPILED_CONFIG_FILE),
                },
                indent=2,
            )
        )
        return 0
    print(f"Version: v{version}")
    print(f"EduMatcher data: {DATA_DIR}")
    print(f"Config source:  {ENGINE_CONFIG_FILE}")
    print(f"Config compiled:  {COMPILED_CONFIG_FILE}")
    return 0


# ---------------------------------------------------------------------------
# clear — reset the data directory
# ---------------------------------------------------------------------------
# "State" is everything the engine and its satellite processes persist and
# reload on the next start: resting/GTC orders, last-known prices, derived
# daily statistics, index levels, and clearing output. Stale state is exactly
# what causes surprises like a `seed_once: true` market-maker quote silently
# failing to re-seed because `book_stats.json` already remembers the symbol
# from a previous run — `clear --state` exists to get back to a clean slate
# without also discarding the operational record (logs, audit trail) of what
# already happened.
#
# ref_data/ (the deployed engine_config.yaml/.json) is configuration, not
# data, and is never touched by either mode — clearing state should not also
# undeploy the exchange's configuration.
STATE_PATHS: tuple[Path, ...] = (
    BOOK_STATS_FILE,
    GTC_ORDERS_FILE,
    GTC_COMBOS_FILE,
    STATS_DB_FILE,
    CLEARING_DB_FILE,
    DATA_DIR / "indexes",
)

# Everything else `--all` additionally removes: logs, the audit trail,
# pm-monitor's history (metrics.db, operational like the logs), pm-opctl's
# own process-tracking dir (PIDs + per-process stdout/stderr) and pm-eod's
# money record (eod.db, settlement/, backup/) -- never cleared with --state,
# because the balances outlive a reset of the exchange's working state.
# Anything already listed in STATE_PATHS is skipped here to avoid double
# work; ref_data/ is excluded — see the module note above.
NON_STATE_PATHS: tuple[Path, ...] = (
    AUDIT_LOG_FILE,
    AUDIT_LOG_FILE.parent / "audit",
    AUDIT_INDEX_DB_FILE,
    LOG_DB_FILE,
    METRICS_DB_FILE,
    LOG_FALLBACK_DIR,
    DATA_DIR / RUNTIME_DIR_NAME,
    EOD_DB_FILE,
    SETTLEMENT_DIR,
    DATA_DIR / "backup",
)


#: SQLite's companions of a database file. Deleting a database but leaving
#: its ``-wal`` lets SQLite replay the old pages into the next database of
#: that name, so they go with it.
SQLITE_SIDECARS = ("-wal", "-shm", "-journal")


def _sidecars(path: Path) -> list[Path]:
    return [path.with_name(path.name + suffix) for suffix in SQLITE_SIDECARS]


def _present(path: Path) -> bool:
    """*path* or any of its SQLite companions exists."""
    return path.exists() or any(p.exists() for p in _sidecars(path))


def _remove_path(path: Path) -> bool:
    """Delete *path* (and a file's SQLite companions) if it exists. Returns
    True if anything was removed."""
    if path.is_dir():
        shutil.rmtree(path)
        return True
    removed = False
    for p in (path, *_sidecars(path)):
        if p.exists():
            p.unlink()
            removed = True
    return removed


_PM_PROGRAM = re.compile(r"pm-[a-z0-9][a-z0-9-]*")


def _is_pm_program(cmdline: list[str]) -> bool:
    """True when the program itself is a pm-* command: argv[0], or the script
    a Python interpreter runs (console scripts run as ``python /path/pm-foo``).
    "pm-" elsewhere -- a shell's ``-c`` text, a file name, npm's
    ``npm-cli.js`` -- does not make a pm-* process."""
    if not cmdline:
        return False
    programs = [cmdline[0]]
    if os.path.basename(cmdline[0]).startswith("python") and len(cmdline) > 1:
        programs.append(cmdline[1])
    return any(_PM_PROGRAM.fullmatch(os.path.basename(p)) for p in programs)


def _running_pm_pids() -> list[str]:
    """Best-effort "pm-engine (pid 7)" for each live pm-* process, for the
    confirmation prompt.

    Excludes this process and its ancestors: the shell that ran
    ``pm-opctl-cli clear`` cannot write to the data directory.
    """
    try:
        me = psutil.Process()
        skip = {me.pid, *(parent.pid for parent in me.parents())}
        found: list[str] = []
        for proc in psutil.process_iter(["pid", "cmdline"]):
            pid, cmdline = proc.info["pid"], proc.info["cmdline"] or []
            if pid in skip or not _is_pm_program(cmdline):
                continue
            program = next(
                os.path.basename(p)
                for p in cmdline[:2]
                if _PM_PROGRAM.fullmatch(os.path.basename(p))
            )
            found.append(f"{program} (pid {pid})")
        return found
    except Exception:
        return []


def clear_data(*, scope: str, assume_yes: bool) -> int:
    """Delete persisted data under DATA_DIR.

    scope="state" removes only engine/session state (STATE_PATHS).
    scope="all" removes state plus logs, audit, and process-tracking data
    (STATE_PATHS + NON_STATE_PATHS). Configuration under ref_data/ is never
    touched by either scope.
    """
    paths = list(STATE_PATHS)
    if scope == "all":
        paths.extend(NON_STATE_PATHS)

    existing = [p for p in paths if _present(p)]

    label = "all data (including logs and audit files)" if scope == "all" else "state"
    print(f"This will permanently delete {label} under {DATA_DIR}:")
    if existing:
        for p in existing:
            print(f"  - {p}")
    else:
        print("  (nothing to delete — no matching files or directories exist)")

    live_pids = _running_pm_pids()
    if live_pids:
        print(
            f"\nWarning: {len(live_pids)} pm-* process(es) appear to be running "
            "and may recreate or write to these files during/after the clear: "
            f"{', '.join(live_pids)}."
        )

    if not assume_yes:
        if not sys.stdin.isatty():
            print(
                "Refusing to clear without --yes (not running interactively).",
                file=sys.stderr,
            )
            return 1
        answer = input(f"Delete {label}? [y/N] ")
        if answer.strip().lower() not in {"y", "yes"}:
            print("Aborted — nothing was deleted.")
            return 1

    removed = 0
    for p in existing:
        if _remove_path(p):
            removed += 1
    print(f"Deleted {removed} item(s).")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pm-opctl-cli", description="Manage EduMatcher operational process control"
    )
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-opctl-cli")

    subparsers = parser.add_subparsers(dest="command", required=True)
    start = subparsers.add_parser(
        "start", aliases=["up"], help="start a named process profile"
    )
    start.add_argument("config_name", nargs="?", default="default")
    start.add_argument(
        "-d",
        "--debug",
        "-vv",
        dest="debug",
        action="store_true",
        help="start every process with --log-level DEBUG",
    )
    subparsers.add_parser(
        "init", help="create the built-in process profile configuration"
    )
    subparsers.add_parser(
        "stop", aliases=["down"], help="stop processes started by pm-opctl"
    )
    subparsers.add_parser(
        "kill",
        help="send SIGTERM to every process whose command line contains pm-",
    )
    listing = subparsers.add_parser(
        "list", help="list status for the active process profile"
    )
    restart_group = listing.add_mutually_exclusive_group()
    restart_group.add_argument(
        "-y",
        "--restart",
        dest="restart",
        action="store_const",
        const="always",
        help="restart dead processes without asking",
    )
    restart_group.add_argument(
        "--no-restart",
        dest="restart",
        action="store_const",
        const="never",
        help="never offer to restart dead processes",
    )
    listing.add_argument(
        "--no-tcp-probe",
        action="store_true",
        help="do not connect to the processes' ports to check them (a "
        "connect-and-close is seen by a gateway as a client)",
    )
    listing.set_defaults(restart="ask")
    health = subparsers.add_parser(
        "health", help="check health of every process in the active profile"
    )
    health.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="print nothing; exit 0 when all processes are running, 1 otherwise",
    )
    show = subparsers.add_parser(
        "show", help="print version, data directory and configuration paths"
    )
    show.add_argument(
        "--json",
        action="store_true",
        help="emit machine-readable JSON instead of plain text",
    )
    clear = subparsers.add_parser(
        "clear",
        help="delete persisted data under the data directory",
        description=(
            "Delete persisted data under the data directory. Exactly one of "
            "--state or --all is required; configuration under ref_data/ is "
            "never touched."
        ),
    )
    clear.add_argument(
        "--state",
        action="store_true",
        help=(
            "delete persisted engine/session state (order books, GTC orders, "
            "stats, index/clearing state) but keep logs and audit files"
        ),
    )
    clear.add_argument(
        "--all",
        dest="clear_all",
        action="store_true",
        help="delete all data, including logs and audit files",
    )
    clear.add_argument(
        "--yes",
        action="store_true",
        help="skip the confirmation prompt",
    )
    return parser


@pipe_safe
def main() -> int:
    args = build_parser().parse_args()
    try:
        if args.command == "init":
            return create_config()
        if args.command in ("start", "up"):
            return start_profile(args.config_name or "default", debug=args.debug)
        if args.command in ("stop", "down"):
            return stop_profile()
        if args.command == "kill":
            return kill_all_processes()
        if args.command == "list":
            return list_profile(args.restart, not args.no_tcp_probe)
        if args.command == "health":
            return health_profile(args.quiet)
        if args.command == "show":
            return show_info(json_output=args.json)
        if args.command == "clear":
            if args.state and args.clear_all:
                print(
                    "Error: Only one of `--all` and `--state` options can be "
                    "given to `clear`",
                    file=sys.stderr,
                )
                return 2
            if not args.state and not args.clear_all:
                print(
                    "Error: One of `--all` or `--state` options must be given "
                    "to `clear`",
                    file=sys.stderr,
                )
                return 2
            scope = "all" if args.clear_all else "state"
            return clear_data(scope=scope, assume_yes=args.yes)
    except (OSError, ValueError, yaml.YAMLError) as exc:
        print(f"pm-opctl: {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
