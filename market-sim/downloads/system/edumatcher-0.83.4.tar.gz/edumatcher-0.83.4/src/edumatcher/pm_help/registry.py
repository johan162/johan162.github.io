"""Static reference data for every ``pm-*`` command.

This module is the single source of truth ``pm-help``/``pm-man`` render from.
It is hand-curated (not scraped from ``--help`` at runtime) so it can carry
information no ``argparse`` parser exposes on its own: which ports a process
binds or connects to, which ZeroMQ topics it sends/subscribes, which other
commands it works alongside, and a worked example of real-world use.

Content here should stay in sync with `../../../docs/books/reference-manual/part-1-command-line/010-processes-environment-and-ports.md`,
which is the canonical prose reference this data is distilled from. When one
changes, check the other.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Option:
    """A single command-line flag."""

    flags: str
    default: str = ""
    help: str = ""
    group: str = ""


@dataclass(frozen=True)
class Subcommand:
    """A subcommand of a multi-command CLI (e.g. ``pm-audit-cli events``)."""

    name: str
    args: str = ""
    purpose: str = ""
    aliases: tuple[str, ...] = ()


@dataclass(frozen=True)
class CommandInfo:
    """Everything ``pm-help``/``pm-man`` knows about one ``pm-*`` command."""

    name: str
    category: str
    title: str
    summary: str
    synopsis: tuple[str, ...]
    description: tuple[str, ...] = ()
    options: tuple[Option, ...] = ()
    has_common_log_options: bool = False
    has_version_option: bool = True
    subcommands: tuple[Subcommand, ...] = ()
    ports: str = ""
    messages: tuple[str, ...] = ()
    related: tuple[str, ...] = ()
    doc_anchor: str = (
        ""  # heading anchor within ../../../docs/books/reference-manual/part-1-command-line/010-processes-environment-and-ports.md
    )
    doc_page: str = (
        ""  # optional dedicated topic page (shown in addition to the anchor)
    )
    examples: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()
    aliases: tuple[str, ...] = ()


# ---------------------------------------------------------------------------
# Shared option groups
#
# Every long-running process that connects to the ZeroMQ bus shares the same
# six logging flags (see ../../../docs/books/operator-guide/part-3-run/010-running-the-exchange.md#logging-levels).
# Factoring them out here keeps each CommandInfo focused on what is actually
# distinctive about that command, and keeps the two docs from drifting apart
# on wording.
# ---------------------------------------------------------------------------

COMMON_LOG_OPTIONS: tuple[Option, ...] = (
    Option(
        "--log-level LEVEL",
        "WARNING",
        "Explicit level: CRITICAL, ERROR, WARNING, INFO, DEBUG",
    ),
    Option(
        "-v, --verbose",
        "off",
        "Increase verbosity (-v -> INFO, -vv -> DEBUG)",
    ),
    Option("-q, --quiet", "off", "Explicit WARNING log level (the default)"),
    Option(
        "--log-target TARGET",
        "server",
        "Where operational log records go: server (auto-detected pm-log-srv), stdout, or file",
    ),
    Option(
        "--log-file PATH",
        "none",
        "Operational log file path -- required when --log-target file",
    ),
    Option(
        "--log-failover-timeout SEC",
        "30 (from config)",
        "Grace window before falling back to a local log file once pm-log-srv becomes unreachable",
    ),
)

COMMON_VERSION_OPTION = Option("--version", "-", "Print version and exit")

# Display order for categories in the summary table and man-page "SEE ALSO"
# cross-references.
CATEGORY_ORDER: tuple[str, ...] = (
    "Core Runtime",
    "External Gateways",
    "Protocol Spies",
    "AI & Bots",
    "Index",
    "Query & Reporting CLIs",
    "Admin & Operations",
    "Setup & Configuration",
    "Logging",
    "Developer Tools",
    "Help",
)


# ---------------------------------------------------------------------------
# Core Runtime
# ---------------------------------------------------------------------------

_CORE_RUNTIME: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-engine",
        category="Core Runtime",
        title="Matching Engine",
        summary="The matching engine -- receives orders, matches them, publishes events.",
        synopsis=("pm-engine [-v|-vv] [--log-level LEVEL] [-q] [--log-target TARGET]",),
        description=(
            "The single writer to the order book and the heart of the system. Binds "
            "the ZeroMQ command socket (:5555) and the two publishing sockets "
            "(:5556 market events, :5557 drop-copy fills). Every other pm-* process "
            "is a producer (PUSH to :5555), a subscriber (SUB from :5556/:5557), or both.",
            "Start the engine first -- gateways and subscribers fail to connect, or "
            "silently miss early messages, if they start before it is bound.",
        ),
        has_common_log_options=True,
        ports="Binds 5555 (PULL, commands in), 5556 (PUB, market/session events), 5557 (PUB, drop-copy fills)",
        messages=(
            "Receives (PULL :5555): order.new, order.cancel, order.combo, system.gateway_connect, "
            "risk.kill_switch, risk.circuit_breaker_halt_all/resume_all, session.transition",
            "Publishes (PUB :5556): order.ack/fill/cancelled/expired.{GW_ID}, trade.executed, "
            "book.{SYMBOL}, session.state, auction.result.{SYMBOL}, system.eod",
            "Publishes (PUB :5557): drop_copy.event.{GW_ID}",
        ),
        related=(
            "pm-opctl-cli",
            "pm-alf-console",
            "pm-scheduler",
            "pm-audit",
            "pm-stats",
        ),
        doc_anchor="pm-engine-matching-engine",
        examples=("pm-engine -v   # start with INFO-level startup/lifecycle logging",),
        notes=(
            "On shutdown (Ctrl-C): expires resting DAY orders, serializes GTC orders "
            "to disk, publishes system.eod, then closes sockets.",
        ),
    ),
    CommandInfo(
        name="pm-alf-console",
        category="Core Runtime",
        title="User Gateway (ALF order entry)",
        summary="Interactive ALF order-entry terminal for a human trader; one instance per user.",
        synopsis=(
            "pm-alf-console --id <GW_ID> [--drop-copy] [-v|-vv] [--log-level LEVEL]",
        ),
        description=(
            "Accepts ALF pipe-delimited commands (NEW, AMEND, CANCEL, QUOTE, ...) on "
            "stdin and forwards them to the engine. The gateway ID must be listed in "
            "engine_config.yaml under participants or the connection is refused.",
        ),
        options=(
            Option(
                "--id GW_ID", "required", "Unique gateway identifier (e.g. GW01, ALICE)"
            ),
            Option(
                "--drop-copy",
                "off",
                "Enable the drop-copy relay on startup (same as sending DC|STATE=ON immediately after connecting)",
            ),
        ),
        has_common_log_options=True,
        related=("pm-engine", "pm-alf-gwy", "pm-orders", "pm-viewer"),
        doc_anchor="pm-alf-console-user-gateway",
        doc_page="../../../docs/books/participant-guide/part-2-orders/010-the-trader-console.md",
        examples=(
            "pm-alf-console --id GW01",
            "NEW|SYM=AAPL|SIDE=BUY|QTY=100|PRICE=96|TYPE=LIMIT|TIF=DAY   # enter a new limit order",
            "CANCEL|ID=<order-id>                                        # cancel a resting order",
            "ORDERS                                                      # list this gateway's own orders",
        ),
        notes=(
            "Full command vocabulary: NEW (LIMIT, MARKET, STOP, STOP_LIMIT, FOK, ICEBERG, "
            "IOC, TRAILING_STOP, OCO, COMBO), AMEND, CANCEL, QUOTE, QUOTE_CANCEL, QBOOT, "
            "QLEGS, KILL, DC, STATUS, ORDERS, POS, POS|GW=, SYMBOLS, SESSION, INDEX, "
            "HELP, CLEAR, EXIT/QUIT.",
            "Exit status: 0 when the user leaves (EXIT, QUIT, Ctrl-D, Ctrl-C); 1 when "
            "the logon is refused, the engine is not reachable or does not send its "
            "symbol list, or the engine connection is lost.",
        ),
    ),
    CommandInfo(
        name="pm-viewer",
        category="Core Runtime",
        title="Order Book Viewer",
        summary="Live full-screen terminal view of a single symbol's order book.",
        synopsis=(
            "pm-viewer --symbol AAPL [--depth N] [--db data/stats.db]",
            "          [--text-color COLOR] [--zebra-lines] [--zebra-lines-color COLOR]",
        ),
        description=(
            "Draws a bordered box on the alternate terminal buffer: a header (last "
            "price, change, session OHLC, bid/ask, spread, volume, clock) plus three "
            "columns (Bids, Asks, Trades). Repaints cleanly on terminal resize. Run "
            "multiple instances for different symbols simultaneously.",
        ),
        options=(
            Option("--symbol, -s SYMBOL", "required", "Symbol to watch"),
            Option("--depth, -d N", "fit to terminal", "Max price levels per side"),
            Option(
                "--db PATH",
                "data/stats.db",
                "Stats SQLite DB -- seeds session OHLC and previous-close",
            ),
            Option(
                "--text-color COLOR",
                "white",
                "Body text color (#rrggbb hex or Rich color name)",
            ),
            Option(
                "--zebra-lines", "off", "Shade every second row of Bids/Asks/Trades"
            ),
            Option(
                "--zebra-lines-color COLOR",
                "grey19",
                "Background tint used by --zebra-lines",
            ),
        ),
        has_common_log_options=True,
        related=("pm-board", "pm-ticker", "pm-orders", "pm-stats"),
        doc_anchor="pm-viewer-order-book-viewer",
        examples=(
            "pm-viewer --symbol AAPL &",
            "pm-viewer --symbol MSFT --depth 10 --zebra-lines",
        ),
        notes=(
            "Iceberg orders only ever show their displayed_qty -- the hidden quantity "
            "is intentionally invisible, demonstrating the iceberg privacy feature.",
        ),
    ),
    CommandInfo(
        name="pm-orders",
        category="Core Runtime",
        title="Order Status Monitor",
        summary="Live cross-gateway table of every order in the system.",
        synopsis=("pm-orders [--gateway GW01] [-v|-vv] [--log-level LEVEL]",),
        description=(
            "Displays ID | Gateway | Symbol | Side | Type | TIF | Qty | Remaining | "
            "Price | Status | Updated, colour-coded by status "
            "(green=NEW, yellow=PARTIAL, bright green=FILLED, red=REJECTED/CANCELLED, dim=EXPIRED).",
        ),
        options=(Option("--gateway, -g GW_ID", "all", "Filter to a single gateway"),),
        has_common_log_options=True,
        related=("pm-viewer", "pm-board", "pm-admin"),
        doc_anchor="pm-orders-order-status-monitor",
    ),
    CommandInfo(
        name="pm-board",
        category="Core Runtime",
        title="Market Board",
        summary="Full-screen multi-symbol market board for large monitors or projection.",
        synopsis=("pm-board [--rows 8] [--interval 10]",),
        description=(
            "Paged table of every active symbol with exchange-style colouring "
            "(Symbol, Last, Chg%, Bid, Ask, Spread, Last Buy/Sell, Vol, Updated). "
            "Auto-rotates pages every --interval seconds; press Enter to advance "
            "immediately. Symbols are auto-discovered -- no configuration needed.",
        ),
        options=(
            Option("--rows, -r N", "8", "Max symbols (rows) displayed per page"),
            Option(
                "--interval, -i SEC",
                "10",
                "Seconds before auto-rotating to the next page",
            ),
        ),
        has_common_log_options=True,
        related=("pm-viewer", "pm-ticker"),
        doc_anchor="pm-board-market-board",
        examples=(
            "pm-board --rows 15 --interval 8   # large-screen classroom/conference demo",
        ),
    ),
    CommandInfo(
        name="pm-ticker",
        category="Core Runtime",
        title="Scrolling Market Ticker",
        summary="Scrolling ticker-tape bar of live prices and OHLCV across all symbols.",
        synopsis=(
            "pm-ticker [--db data/stats.db] [--db-interval 900] [--timezone TZ]",
        ),
        description=(
            "A bordered header (brand, today's total volume, clock) plus a "
            "scrolling line combining live ZMQ data (last price, bid/ask) with "
            "historical DB data (OHLCV, trade count) from pm-stats's SQLite database, "
            "and a line with pm-market-sim's latest headline. "
            "Without pm-stats running it still works but omits OHLCV/volume/trade count.",
        ),
        options=(
            Option(
                "--db PATH", "data/stats.db", "Path to the statistics SQLite database"
            ),
            Option(
                "--db-interval SEC", "900", "Seconds between daily_stats DB re-queries"
            ),
            Option(
                "--timezone TZ",
                "DB-recorded timezone",
                "Exchange session timezone (IANA name)",
            ),
        ),
        has_common_log_options=True,
        related=("pm-stats", "pm-board", "pm-viewer"),
        doc_anchor="pm-ticker-scrolling-market-ticker",
    ),
    CommandInfo(
        name="pm-stats",
        category="Core Runtime",
        title="Statistics Recorder",
        summary="Records OHLCV, trade log, and index-level history to stats.db.",
        synopsis=(
            "pm-stats [--db data/stats.db] [--snapshot-interval SEC]",
            "         [--keep-days N] [--keep-order-events-days N]",
            "         [--human-gateways GLOB,...]",
            "         [--keep-human-order-events-days N]",
            "         [--sql-trace] [-v|-vv] [--log-level LEVEL]",
        ),
        description=(
            "The queryable time-series home for both trading statistics and index "
            "level history (pm-index's own JSONL only keeps structural/audit records, "
            "not level ticks). Maintains three tables: daily_stats (one row per "
            "date+symbol), price_snapshots (periodic mid-price), and trade_log "
            "(append-only per-trade rows). Recommended to run immediately after pm-engine.",
        ),
        options=(
            Option("--db PATH", "data/stats.db", "SQLite database file path"),
            Option(
                "--snapshot-interval SEC",
                "900",
                "Seconds between price_snapshots rows per symbol",
            ),
            Option(
                "--keep-days N",
                "0 (keep all)",
                "Keep N days of trades, order events and snapshots; older rows "
                "are deleted hourly. Daily rollups are always kept",
            ),
            Option(
                "--keep-order-events-days N",
                "as --keep-days",
                "Keep N days of order events alone (fractions allowed, e.g. "
                "0.05 for about an hour); under an AI swarm they are most of "
                "stats.db",
            ),
            Option(
                "--human-gateways GLOB,...",
                "none",
                "Comma-separated gateway id globs (e.g. TRADER*) that prune on "
                "--keep-human-order-events-days instead; a person's few rows "
                "need not die on the swarm's clock",
            ),
            Option(
                "--keep-human-order-events-days N",
                "as --keep-order-events-days",
                "Keep N days of order events for --human-gateways matches; "
                "0 keeps them for good. Requires --human-gateways",
            ),
            Option(
                "--sql-trace",
                "off",
                "Log executed SQLite statements from the stats writer connection",
            ),
        ),
        has_common_log_options=True,
        related=("pm-stats-cli", "pm-clearing", "pm-index", "pm-ticker", "pm-board"),
        doc_anchor="pm-stats-statistics-recorder",
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/060-statistics-and-reporting.md",
        notes=(
            "Opens two independent PUB/SUB connections: pm-engine (:5556) for "
            "trade.*/book.*/system.eod, and pm-index (:5558) for index.update.",
        ),
    ),
    CommandInfo(
        name="pm-monitor",
        category="Core Runtime",
        title="Health Collector",
        summary="Judges every pm-* process from its health beacon and publishes the exchange's health.",
        synopsis=(
            "pm-monitor [-v|-vv] [--log-level LEVEL] [--log-target server|stdout|file]",
        ),
        description=(
            "Every long-running pm-* process pushes a health beacon every 2 s: memory, "
            "CPU, how long ago its main loop last ran, and its counters. pm-monitor "
            "judges each process (HEALTHY, DEGRADED, HUNG, SILENT, DEAD, MISSING, "
            "STOPPED) and the exchange (OPERATIONAL, DEGRADED, IMPAIRED, DOWN), turns "
            "counters into rates, evaluates thresholds, keeps history in metrics.db, "
            "and publishes health.snapshot (1 Hz) and health.event.",
            "All settings come from the monitor section of the deployed config; there "
            "are no other flags. Started by every built-in pm-opctl-cli profile except "
            "micro, between pm-log-srv and pm-engine.",
        ),
        has_common_log_options=True,
        ports="Binds ZMQ 5610 (PULL, beacons in) and 5611 (PUB, snapshots/events); connects to 5556",
        messages=("health.beacon", "health.snapshot", "health.event"),
        related=("pm-monitor-cli", "pm-opctl-cli", "pm-log-srv"),
        doc_anchor="pm-monitor-health-collector",
        doc_page="../../../docs/books/operator-guide/part-6-observe-and-recover/060-health-monitor.md",
        notes=(
            "With monitor.enabled: false it idles until stopped (exit 0) instead of "
            "exiting, so a profile's restart loop does not restart it every minute.",
            "Exits 1 when another pm-monitor already writes metrics.db, or when "
            "metrics.db was recorded under another session timezone.",
        ),
    ),
    CommandInfo(
        name="pm-clearing",
        category="Core Runtime",
        title="Clearing & P&L",
        summary="SQLite-backed clearing writer computing realized/unrealized P&L and positions.",
        synopsis=(
            "pm-clearing [--datapath PATH] [--db-name NAME] [--flush-size N]",
            "            [--flush-interval SEC] [--retention-days N]",
        ),
        description=(
            "Subscribes to trade.executed and writes gateway positions, daily "
            "summaries, and raw trade events to clearing.db in batched transactions.",
        ),
        options=(
            Option(
                "--datapath PATH",
                "$EDUMATCHER_DATA_DIR",
                "Data directory or explicit .db path",
            ),
            Option(
                "--db-name NAME",
                "clearing.db",
                "SQLite filename when --datapath is a directory",
            ),
            Option(
                "--flush-size N",
                "100",
                "Flush immediately when buffered trades reach N",
            ),
            Option(
                "--flush-interval SEC",
                "5.0",
                "Flush interval when the buffer is non-empty",
            ),
            Option(
                "--print-every N",
                "0",
                "Print a P&L table of every position every N trades (0: never)",
            ),
            Option(
                "--retention-days N",
                "90",
                "Prune trade_events rows older than N days on startup and at "
                "every close of the market (0 disables)",
            ),
            Option(
                "--sql-trace",
                "off",
                "Log executed SQLite statements from the clearing writer connection",
            ),
        ),
        has_common_log_options=True,
        related=("pm-clearing-cli", "pm-stats"),
        doc_anchor="pm-clearing-clearing-pl",
        doc_page="../../../docs/books/participant-guide/part-5-positions-and-results/010-positions-and-pnl.md",
    ),
    CommandInfo(
        name="pm-audit",
        category="Core Runtime",
        title="Event Logger",
        summary="Records every message on the bus to a day-closing audit log file.",
        synopsis=(
            "pm-audit [--audit-log-file data/audit.log] [--terminal]",
            "         [--buffer-size 100] [--flush-interval 10]",
            "         [--max-file-mb 10] [--keep-days 0]",
        ),
        description=(
            "Subscribes to everything published on :5556 with an empty topic prefix "
            "and appends each entry to the active log file, closing it as a numbered day "
            "part (audit/audit-YYYY-MM-DD.N.log) at midnight in the session timezone or "
            "at 10 MB, never deleting anything. Entries are buffered to reduce disk wear. On shutdown, buffered messages are always "
            "flushed before exit.",
        ),
        options=(
            Option(
                "--audit-log-file PATH",
                "data/audit.log",
                "Audit-trail output log file path",
            ),
            Option("--terminal, -t", "off", "Also print each entry to stdout"),
            Option(
                "--buffer-size N",
                "100",
                "Messages buffered in memory before writing to disk",
            ),
            Option(
                "--flush-interval SEC",
                "10.0",
                "Max seconds before flushing the buffer to disk",
            ),
            Option(
                "--max-file-mb MB",
                "10",
                "Close the audit log as a day part when it reaches this size",
            ),
            Option(
                "--keep-days N",
                "0",
                "Delete daily archives older than N days (0 keeps all)",
            ),
        ),
        has_common_log_options=True,
        related=("pm-audit-cli", "pm-stats", "pm-clearing"),
        doc_anchor="pm-audit-event-logger",
        examples=(
            "pm-audit --terminal                              # show every event live during a demo",
            "pm-audit --buffer-size 500 --flush-interval 30    # high-traffic: larger buffer",
            "pm-audit --buffer-size 1 --flush-interval 0.1     # low-latency: flush almost every message",
        ),
    ),
    CommandInfo(
        name="pm-scheduler",
        category="Core Runtime",
        title="Session Scheduler",
        summary="Drives session-phase transitions at configured wall-clock times.",
        synopsis=(
            "pm-scheduler [--now] [--delay 3] [--daily] [--no-confirm]",
            "pm-scheduler --daily --speed F [--start YYYY-MM-DDTHH:MM]",
            "pm-scheduler --daily --on-close COMMAND [--on-close-delay SEC]",
        ),
        description=(
            "Sends session.transition to the engine to advance "
            "PRE_OPEN -> OPENING_AUCTION -> CONTINUOUS -> CLOSING_AUCTION -> CLOSED "
            "at the times in the deployed configuration's schedule. Closed-loop: "
            "it asks the engine for its state at start-up, confirms every "
            "transition on the engine's session.state broadcast, and brings a "
            "restarted engine back to the scheduled phase.",
        ),
        options=(
            Option(
                "--now",
                "off",
                "Skip wall-clock waiting: close the engine first if it is not CLOSED, "
                "then send all five transitions with --delay between each",
            ),
            Option(
                "--delay SEC",
                "3.0 (with --now)",
                "Seconds between transitions in --now mode",
            ),
            Option(
                "--daily",
                "off",
                "Run continuously, repeating the schedule every working day "
                "(days with no schedule, such as weekends and bank holidays, are skipped)",
            ),
            Option(
                "--speed F",
                "off",
                "Compressed mode (with --daily): simulated time runs F times faster",
            ),
            Option(
                "--start TIME",
                "now",
                "Compressed mode: local time the simulated clock starts at",
            ),
            Option(
                "--no-confirm",
                "off",
                "Do not ask the engine its state, confirm transitions or follow an "
                "engine restart; with no answer it assumes a CLOSED engine",
            ),
            Option(
                "--on-close COMMAND",
                "off",
                "Start COMMAND (for example 'pm-eod run --pending') after each CLOSED "
                "transition and once at start-up; runs detached, one at a time (a "
                "trigger while it runs starts it once more afterwards)",
            ),
            Option(
                "--on-close-delay SEC",
                "30",
                "Wait this long after CLOSED before starting --on-close, so pm-clearing "
                "can save its close snapshot first",
            ),
        ),
        has_common_log_options=True,
        related=("pm-engine", "pm-admin", "pm-eod"),
        doc_anchor="pm-scheduler-session-scheduler",
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/030-sessions-and-scheduling.md",
    ),
)


# ---------------------------------------------------------------------------
# External Gateways
# ---------------------------------------------------------------------------

_EXTERNAL_GATEWAYS: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-alf-gwy",
        category="External Gateways",
        title="ALF TCP Gateway",
        summary="External ALF order-entry gateway for bots/remote clients over plain TCP.",
        synopsis=("pm-alf-gwy [--bind 0.0.0.0] [--port 5565] [--engine-host HOST]",),
        description=(
            "Accepts the same ALF command vocabulary as pm-alf-console but over a "
            "TCP socket instead of stdin, for programmatic clients. Any configured "
            "participants ID may connect; each connection is one gateway session, "
            "starting with a HELLO|CLIENT=...|PROTO=ALF1|ID=<gateway-id> line.",
        ),
        options=(
            Option("--bind ADDR", "0.0.0.0", "TCP bind address for external clients"),
            Option("--port PORT", "5565", "TCP listen port for ALF clients"),
            Option(
                "--engine-host HOST",
                "from config",
                "Override engine host for ZMQ ports 5555/5556",
            ),
        ),
        has_common_log_options=True,
        ports="Listens on TCP 5565 (ALF); connects out to 5555, 5556, 5557",
        related=("pm-alf-console", "pm-engine", "pm-balf-gwy"),
        doc_anchor="pm-alf-gwy-alf-tcp-gateway",
        doc_page="../../../docs/books/operator-guide/part-5-gateways/010-alf-gateway.md",
    ),
    CommandInfo(
        name="pm-balf-gwy",
        category="External Gateways",
        title="BALF TCP Gateway",
        summary="External binary order-entry gateway (BALF) for low-latency programmatic clients.",
        synopsis=("pm-balf-gwy [--bind 0.0.0.0] [--port 5560] [--engine-host HOST]",),
        description=(
            "Accepts BALF binary frames over TCP and translates them into the same "
            "engine order flow used by the ALF gateways.",
        ),
        options=(
            Option("--bind ADDR", "0.0.0.0", "TCP bind address for BALF clients"),
            Option("--port PORT", "5560", "TCP listen port for BALF clients"),
            Option(
                "--engine-host HOST",
                "from config",
                "Override engine host for ZMQ ports 5555/5556",
            ),
        ),
        has_common_log_options=True,
        ports="Listens on TCP 5560 (BALF binary); connects out to 5555, 5556",
        related=("pm-alf-gwy", "pm-engine"),
        doc_anchor="pm-balf-gwy-balf-tcp-gateway",
        doc_page="../../../docs/books/operator-guide/part-5-gateways/020-balf-gateway.md",
    ),
    CommandInfo(
        name="pm-md-gwy",
        category="External Gateways",
        title="CALF Market-Data Gateway",
        summary="External market-data gateway distributing CALF channels over TCP.",
        synopsis=(
            "pm-md-gwy [--bind 0.0.0.0] [--port 5570] [--engine-pub tcp://127.0.0.1:5556]",
            "          [--index-pub tcp://127.0.0.1:5558]",
        ),
        description=(
            "Consumes the engine and index PUB feeds internally and republishes "
            "sequence-aware TOP, DEPTH, TRADE, STATE, AUCTION, CB and INDEX "
            "channels to external CALF clients.",
        ),
        options=(
            Option("--bind ADDR", "0.0.0.0", "TCP bind address for external clients"),
            Option("--port PORT", "5570", "TCP listen port for CALF clients"),
            Option(
                "--engine-pub ADDR",
                "tcp://127.0.0.1:5556",
                "Engine PUB address consumed by the gateway",
            ),
            Option(
                "--index-pub ADDR",
                "tcp://127.0.0.1:5558",
                "pm-index PUB address consumed by the gateway",
            ),
        ),
        has_common_log_options=True,
        ports="Listens on TCP 5570 (CALF); connects out to 5556, 5558",
        related=("pm-calf-spy", "pm-index", "pm-engine"),
        doc_anchor="pm-md-gwy-calf-market-data-gateway",
        doc_page="../../../docs/books/operator-guide/part-5-gateways/030-calf-gateway.md",
    ),
    CommandInfo(
        name="pm-ralf-gwy",
        category="External Gateways",
        title="Post-Trade Dissemination Gateway",
        summary="External post-trade dissemination gateway (RALF) for clearing/drop-copy/audit consumers.",
        synopsis=(
            "pm-ralf-gwy [--bind 0.0.0.0] [--port 5580] [--engine-pub tcp://127.0.0.1:5556]",
        ),
        description=(
            "Publishes RALF over TCP: WELCOME, SNAP, EXEC, EOD, HB, PONG, ERR, EXIT "
            "message types, role-gated (CLEARING, DROP_COPY, AUDIT).",
        ),
        options=(
            Option("--bind ADDR", "0.0.0.0", "TCP bind address for external clients"),
            Option("--port PORT", "5580", "TCP listen port for RALF clients"),
            Option(
                "--engine-pub ADDR",
                "tcp://$EDUMATCHER_ENGINE_HOST:5556",
                "Engine PUB address consumed by the gateway",
            ),
        ),
        has_common_log_options=True,
        ports="Listens on TCP 5580 (RALF); connects out to 5556",
        related=("pm-ralf-spy", "pm-engine"),
        doc_anchor="pm-ralf-gwy-post-trade-dissemination-gateway",
        doc_page="../../../docs/books/operator-guide/part-5-gateways/040-ralf-gateway.md",
    ),
    CommandInfo(
        name="pm-dc-gwy",
        category="External Gateways",
        title="Drop-Copy TCP Gateway",
        summary="Relays the engine's drop-copy fill feed as DC1 text lines to plain-TCP clients.",
        synopsis=(
            "pm-dc-gwy [--bind 0.0.0.0] [--port 5590] [--engine-dc-pub tcp://127.0.0.1:5557]",
        ),
        description=(
            "TCP counterpart to pm-dc-spy: fans drop_copy.event.<gateway_id> out to "
            "any number of concurrently connected external clients. No "
            "authentication, entitlement model, or replay-by-sequence -- any client "
            "may HELLO with any gateway ID.",
        ),
        options=(
            Option("--bind ADDR", "0.0.0.0", "TCP bind address for external clients"),
            Option("--port PORT", "5590", "TCP listen port for DC1 clients"),
            Option(
                "--engine-dc-pub ADDR",
                "tcp://$EDUMATCHER_ENGINE_HOST:5557",
                "Engine drop-copy PUB address consumed by the gateway",
            ),
        ),
        has_common_log_options=True,
        ports="Listens on TCP 5590 (DC1); connects out to 5557",
        related=("pm-dc-spy", "pm-engine"),
        doc_anchor="pm-dc-gwy-drop-copy-tcp-gateway",
        doc_page="../../../docs/books/operator-guide/part-5-gateways/060-drop-copy-gateway.md",
    ),
    CommandInfo(
        name="pm-api-gwy",
        category="External Gateways",
        title="REST/WebSocket API Gateway",
        summary="Exposes order entry, order management, and market data over REST/JSON and WebSocket.",
        synopsis=(
            "pm-api-gwy [--instance NAME] [--host ADDR] [--port PORT]",
            "           [--engine-host HOST] [--stats-db PATH]",
            "           [--clearing-db PATH]",
        ),
        description=(
            "Not a second matching engine -- translates HTTP/WebSocket requests into "
            "the same ZMQ order flow used by pm-alf-console. Reads its named entry "
            "from the api_gateways: section of engine_config.yaml. Authenticates via "
            "Authorization: Bearer <api_key> (REST) or a first JSON message "
            '{"api_key": "<key>"} (WebSocket).',
        ),
        options=(
            Option(
                "--instance NAME",
                "auto-selected if only one entry",
                "Named api_gateways entry to run",
            ),
            Option("--host ADDR", "config value", "Override HTTP bind address"),
            Option("--port PORT", "config value", "Override HTTP listen port"),
            Option(
                "--engine-host HOST",
                "config value",
                "Override engine host for ZMQ connections",
            ),
            Option(
                "--stats-db PATH",
                "config value",
                "Path to data/stats.db for /history/* endpoints",
            ),
            Option(
                "--clearing-db PATH",
                "config value",
                "Path to data/clearing.db (read-only) for realized P&L on /positions",
            ),
        ),
        has_common_log_options=True,
        ports="Listens on HTTP/WS at its configured port (e.g. 8080 desk, 8081 dashboards); connects out to 5555, 5556",
        related=("pm-alf-console", "pm-stats"),
        doc_anchor="pm-api-gwy-restwebsocket-api-gateway",
        doc_page="../../../docs/books/operator-guide/part-5-gateways/050-api-gateway.md",
        notes=(
            "Browse http://127.0.0.1:<PORT>/docs for interactive Swagger docs when swagger_enabled: true.",
        ),
    ),
)


# ---------------------------------------------------------------------------
# Protocol Spies -- read-only CLI clients that print exactly what a gateway
# sends, for learning the wire protocol without writing a client.
# ---------------------------------------------------------------------------

_PROTOCOL_SPIES: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-calf-spy",
        category="Protocol Spies",
        title="CALF Protocol Spy",
        summary="Read-only CALF client: prints every line pm-md-gwy sends, human or JSON.",
        synopsis=(
            "pm-calf-spy [--channels CH] [--symbols SYM] [--ping-interval SEC]",
            "            [--format human|json]",
        ),
        description=(
            "Opens a CALF TCP session against pm-md-gwy, subscribes to the requested "
            "channels/symbols, and prints every line received. Never mutates exchange "
            "state; any number of instances can run concurrently. Sends a periodic "
            "PING (default 60s) to avoid being dropped as idle.",
        ),
        options=(
            Option("--host ADDR", "127.0.0.1", "pm-md-gwy TCP host"),
            Option("--port PORT", "5570", "pm-md-gwy TCP port"),
            Option(
                "--client-name NAME",
                "calf-spy-<pid>",
                "HELLO|CLIENT= identifier reported in gateway logs",
            ),
            Option(
                "--channels CH",
                "*",
                "Comma-separated channels; * = every channel offered",
            ),
            Option(
                "--symbols SYM",
                "*",
                "Comma-separated symbols; * = wildcard where allowed",
            ),
            Option(
                "--resume CH:SYM:LASTSEQ:EPOCH",
                "none",
                "One-shot single-stream replay request on connect",
            ),
            Option(
                "--ping-interval SEC",
                "60",
                "Seconds between PING keepalives; 0 disables",
            ),
            Option("--format human|json", "human", "Output format"),
            Option(
                "--count N",
                "0",
                "Exit after N data-carrying lines (0 = run until Ctrl-C)",
            ),
            Option(
                "--raw", "off", "Print raw protocol bytes instead of decoded fields"
            ),
            Option("--no-color", "off", "Disable ANSI colour in output"),
            Option("--show-heartbeats", "off", "Include HB heartbeat lines in output"),
        ),
        has_common_log_options=True,
        related=("pm-md-gwy", "pm-ralf-spy", "pm-dc-spy"),
        doc_anchor="pm-calf-spy-calf-protocol-spy",
        doc_page="../../../docs/books/protocols-and-clients/part-4-writing-clients/040-the-spy-tools-calf.md",
    ),
    CommandInfo(
        name="pm-ralf-spy",
        category="Protocol Spies",
        title="RALF Protocol Spy",
        summary="Read-only RALF client: prints every line pm-ralf-gwy sends, human or JSON.",
        synopsis=(
            "pm-ralf-spy --role ROLE [--channels CH] [--symbols SYM]",
            "            [--ping-interval SEC] [--format human|json]",
        ),
        description=(
            "Opens a RALF TCP session under a chosen role (CLEARING, DROP_COPY, or "
            "AUDIT) and prints every line received. Never mutates exchange state; "
            "any number of instances can run concurrently, each with its own role/filter.",
        ),
        options=(
            Option("--host ADDR", "127.0.0.1", "pm-ralf-gwy TCP host"),
            Option("--port PORT", "5580", "pm-ralf-gwy TCP port"),
            Option(
                "--client-name NAME",
                "ralf-spy-<pid>",
                "HELLO|CLIENT= identifier reported in gateway logs",
            ),
            Option(
                "--role ROLE",
                "AUDIT",
                "HELLO|ROLE= to authenticate as: CLEARING, DROP_COPY, or AUDIT",
            ),
            Option(
                "--channels CH",
                "*",
                "Comma-separated channels; * = every channel --role is entitled to",
            ),
            Option("--symbols SYM", "*", "Comma-separated symbols; * = every symbol"),
            Option(
                "--lastseq N",
                "0",
                "Checkpoint sent as HELLO|LASTSEQ=N, replayed on SUB (0 = none)",
            ),
            Option(
                "--epoch HEX",
                "",
                "WELCOME|EPOCH of the run --lastseq came from; required with it",
            ),
            Option(
                "--ping-interval SEC",
                "60",
                "Seconds between PING keepalives; 0 disables",
            ),
            Option("--format human|json", "human", "Output format"),
            Option(
                "--count N",
                "0",
                "Exit after N data-carrying lines (0 = run until Ctrl-C)",
            ),
            Option(
                "--raw", "off", "Print raw protocol bytes instead of decoded fields"
            ),
            Option("--no-color", "off", "Disable ANSI colour in output"),
            Option("--show-heartbeats", "off", "Include HB heartbeat lines in output"),
        ),
        has_common_log_options=True,
        related=("pm-ralf-gwy", "pm-calf-spy", "pm-dc-spy"),
        doc_anchor="pm-ralf-spy-ralf-protocol-spy",
        doc_page="../../../docs/books/protocols-and-clients/part-4-writing-clients/040-the-spy-tools-ralf.md",
    ),
    CommandInfo(
        name="pm-dc-spy",
        category="Protocol Spies",
        title="Drop-Copy Spy",
        summary="Read-only drop-copy client: prints every fill event from the engine's :5557 feed.",
        synopsis=(
            "pm-dc-spy [--gateway GW_ID] [--replay-of ID] [--format human|json]",
        ),
        description=(
            "Opens a plain zmq.SUB connection directly to the engine's drop-copy PUB "
            "socket -- no handshake or heartbeat, unlike CALF/RALF. Subscribes to "
            "fills for one gateway or all gateways.",
        ),
        options=(
            Option("--host ADDR", "127.0.0.1", "Drop-copy PUB socket host"),
            Option("--port PORT", "5557", "Drop-copy PUB socket port"),
            Option("--gateway GW_ID", "none (all)", "Only show fills for this gateway"),
            Option(
                "--replay-of ID",
                "none",
                "Also subscribe to drop_copy.replay.<RECIPIENT_ID>",
            ),
            Option("--format human|json", "human", "Output format"),
            Option("--count N", "0", "Exit after N messages (0 = run until Ctrl-C)"),
            Option("--raw", "off", "Print raw bytes instead of decoded fields"),
            Option("--no-color", "off", "Disable ANSI colour in output"),
        ),
        has_common_log_options=True,
        related=("pm-dc-gwy", "pm-engine"),
        doc_anchor="pm-dc-spy-drop-copy-spy",
        doc_page="../../../docs/books/protocols-and-clients/part-4-writing-clients/040-the-spy-tools.md",
    ),
)


# ---------------------------------------------------------------------------
# AI & Bots
# ---------------------------------------------------------------------------

_AI_AND_BOTS: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-ai-trader",
        category="AI & Bots",
        title="Autonomous Trader Bot",
        summary="One autonomous trading agent whose behaviour comes from a preset.",
        synopsis=(
            "pm-ai-trader --id AI001 [--preset noise-retail | --preset-file PATH] "
            "[--symbols AAPL,MSFT] [options]",
            "pm-ai-trader --list-presets",
        ),
        description=(
            "A preset bundles a strategy (noise, trend, reversion, value), an execution "
            "style (passive, marketable, sweep, iceberg, twap), a tempo (how often, "
            "how big) and risk limits (position cap, order age, stop/bracket "
            "protection). On startup the agent logs on, learns the symbols, session "
            "state, reference data and halts, re-seeds its position from the "
            "engine, and asks for a book snapshot of every symbol it trades.",
        ),
        options=(
            Option(
                "--id GW_ID",
                "required",
                "Participant ID used by the agent (e.g. AI001)",
            ),
            Option("--preset NAME", "noise-retail", "Built-in preset"),
            Option("--preset-file PATH", "-", "Preset YAML file instead of a built-in"),
            Option("--list-presets", "-", "List the built-in presets and exit"),
            Option("--symbols LIST", "empty (all)", "Comma-separated symbols to trade"),
            Option("--seed N", "1", "RNG seed for deterministic behaviour"),
            Option("--duration SEC", "0 (until stopped)", "Runtime in seconds"),
        ),
        has_common_log_options=True,
        related=("pm-ai-swarm", "pm-mm-bot", "pm-engine"),
        doc_anchor="pm-ai-trader-autonomous-trader-bot",
        doc_page="../../../docs/books/participant-guide/part-4-automated-trading/010-ai-traders.md",
    ),
    CommandInfo(
        name="pm-ai-swarm",
        category="AI & Bots",
        title="Multi-Agent Trading Swarm",
        summary="Runs many AI traders in a few supervised worker processes.",
        synopsis=(
            "pm-ai-swarm [--swarm swarm.yaml] [--count 10] [--presets all] [options]",
        ),
        options=(
            Option(
                "--swarm PATH",
                "none",
                "swarm.yaml; flags given explicitly override its values",
            ),
            Option("--count N", "10", "Number of agents"),
            Option(
                "--prefix STR",
                "AI",
                "Gateway-ID prefix (IDs are PREFIX001, PREFIX002, ...)",
            ),
            Option("--start-index N", "1", "First numeric suffix for generated IDs"),
            Option(
                "--presets LIST",
                "all presets, equal weights",
                "Composition: 'a,b' or with weights 'a:3,b:1'",
            ),
            Option(
                "--symbols LIST", "from config", "Comma-separated symbol list override"
            ),
            Option(
                "--symbols-per-agent N",
                "just enough to cover all",
                "Symbols each agent trades (consecutive, wrapping)",
            ),
            Option("--seed-base N", "1000", "Base seed; agent i gets seed-base + i"),
            Option("--duration SEC", "0", "Run time in seconds; 0 = until stopped"),
            Option(
                "--workers K",
                "min(cpus-1, ceil(count/100))",
                "Worker processes; each hosts a contiguous block of agents",
            ),
            Option(
                "--budget N", "0 (presets decide)", "Total order actions per second"
            ),
            Option("--alf-host HOST", "EDUMATCHER_ENGINE_HOST", "Host of pm-alf-gwy"),
            Option("--alf-port PORT", "from config", "Port of pm-alf-gwy"),
        ),
        has_common_log_options=True,
        related=("pm-ai-trader", "pm-mm-bot"),
        doc_anchor="pm-ai-swarm-multi-agent-trading-swarm",
        doc_page="../../../docs/books/participant-guide/part-4-automated-trading/010-ai-traders.md",
    ),
    CommandInfo(
        name="pm-mm-bot",
        category="AI & Bots",
        title="Autonomous Market-Maker Bot",
        summary=(
            "Autonomous two-sided quoting bot for one or more symbols; "
            "connects as one MARKET_MAKER gateway."
        ),
        synopsis=(
            "pm-mm-bot --symbol AAPL [--gap 0.10] [--qty 500] [options]",
            "pm-mm-bot --symbol AAPL --gap 0.10 --symbol TSLA --gap 0.50 [options]",
            "pm-mm-bot --symbols AAPL,MSFT | --all-symbols | --config FILE [options]",
        ),
        description=(
            "Posts a two-sided quote per symbol and automatically reprices on "
            "fills, mid-price drift, halts and session transitions. One process "
            "is one gateway and can quote several symbols; per-symbol flags "
            "after a --symbol apply to that symbol only. The gateway ID is "
            "MM_<label>_<suffix> (the label is the symbol, SYM1_SYM2_... or ALL) "
            "unless --gateway-id names it, and must be registered with "
            "role: MARKET_MAKER.",
        ),
        options=(
            Option(
                "--symbol SYMBOL",
                "one symbol source required",
                "Instrument to quote; repeatable, each opens a per-symbol scope",
            ),
            Option(
                "--symbols A,B,...",
                "unset",
                "Several symbols on the same settings; not with --symbol",
            ),
            Option(
                "--all-symbols",
                "off",
                "Every symbol of the deployed configuration; gateway MM_ALL_<nn>",
            ),
            Option(
                "--config PATH",
                "unset",
                "YAML file (version: 1) with gateway, defaults and per-symbol blocks",
            ),
            Option(
                "--strategy NAME",
                "symmetric",
                "Pricing strategy: symmetric, inventory_skew or passive",
            ),
            Option(
                "--gap PRICE",
                "0.10",
                "Total spread (bid at mid-gap/2, ask at mid+gap/2)",
            ),
            Option("--qty N", "500", "Quote size on each leg"),
            Option(
                "--max-position N",
                "unset",
                "inventory_skew: position at which the skew saturates (required)",
            ),
            Option(
                "--retreat-ticks / --behind-ticks / --min-cover-qty",
                "5 / 1 / 1",
                "passive: how far to step back, how far behind others, "
                "and how much they must show",
            ),
            Option(
                "--fade-ticks / --fade-sec",
                "2 / 3.0",
                "passive: how far and how long a side backs off after a fill",
            ),
            Option(
                "--label NAME",
                "derived",
                "Gateway-ID symbol segment (MM_<label>_<suffix>)",
            ),
            Option(
                "--id-suffix STR", "01", "Running number for gateway ID (MM_AAPL_01)"
            ),
            Option(
                "--gateway-id STR",
                "MM_<label>_<id-suffix>",
                "Use this exact gateway ID (e.g. MM01) instead of deriving one",
            ),
            Option("--drift-ticks N", "3", "Reprice when mid moves by this many ticks"),
            Option(
                "--anchor-sim W",
                "0 (off)",
                "Quote around pm-market-sim's true value; W = share of the "
                "gap closed per model step (0-1)",
            ),
            Option(
                "--reissue-delay-ms MS",
                "200",
                "Milliseconds to wait after fill before re-issuing",
            ),
            Option("--tif DAY|GTC", "DAY", "Time-in-force for quote legs"),
            Option(
                "--heartbeat-interval-sec SEC",
                "5.0",
                "Periodic live-quote check interval",
            ),
            Option(
                "--initial_min / --initial_max",
                "unset",
                "Bounds for random bootstrap price",
            ),
            Option(
                "--engine-pull ADDR", "tcp://127.0.0.1:5555", "Engine PUSH/PULL address"
            ),
            Option("--engine-pub ADDR", "tcp://127.0.0.1:5556", "Engine PUB address"),
        ),
        has_common_log_options=True,
        related=("pm-ai-trader", "pm-engine", "pm-alf-console"),
        doc_anchor="pm-mm-bot-autonomous-market-maker-bot",
        doc_page="../../../docs/books/participant-guide/part-3-market-making/030-the-market-maker-bot.md",
        examples=(
            "pm-mm-bot --symbol AAPL --gap 0.10 --qty 500",
            "pm-mm-bot --config docs/examples/mm-bot/tech-desk.yaml",
        ),
        notes=(
            "Reference price resolution order: active quote from QBOOT (restart "
            "recovery), book mid-price, last trade price, QBOOT bootstrap snapshot, "
            "then a random price from [--initial_min, --initial_max].",
        ),
    ),
    CommandInfo(
        name="pm-market-sim",
        category="AI & Bots",
        title="Market Model (True Values)",
        summary="Publishes every symbol's true value from a seeded market model.",
        synopsis=(
            "pm-market-sim [options]",
            "pm-market-sim --init [--seed N] > market_sim.yaml",
            "pm-market-sim --status --id ADMIN_ID [--top 10]",
        ),
        description=(
            "Steps correlated log-normal values with jumps (market, sector and "
            "symbol factors) while the exchange trades continuously, and applies "
            "an overnight move when it reopens. Parameters come from the deployed "
            "market_sim.yaml. Values go to the AI traders' value strategy, to "
            "pm-mm-bot --anchor-sim and to ADMIN API keys; never to students. "
            "It also publishes news (generated at random, or sent with pm-news), "
            "which is public.",
        ),
        options=(
            Option("--init", "off", "Print a market_sim.yaml for the deployed symbols"),
            Option("--seed N", "1", "Seed written by --init"),
            Option("--status", "off", "Show the model's state and widest gaps"),
            Option("--id GW_ID", "-", "ADMIN participant ID that --status asks as"),
            Option("--top N", "10", "Gaps --status lists"),
        ),
        has_common_log_options=True,
        ports="5553 PUB (sim.value, sim.state, news.event), 5554 PULL (sim.command)",
        related=("pm-ai-swarm", "pm-mm-bot", "pm-news", "pm-scheduler"),
        doc_anchor="pm-market-sim-market-model",
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/090-market-model.md",
    ),
    CommandInfo(
        name="pm-news",
        category="AI & Bots",
        title="News Desk",
        summary="Publish, confirm and retract pm-market-sim headlines; play scenarios.",
        synopsis=(
            "pm-news --id ADMIN_ID inject (--symbol SYM | --sector SECTOR | --market) "
            "--kind KIND --sentiment S --impact I [--headline TEXT] "
            "[--rumour [--credibility C]]",
            "pm-news --id ADMIN_ID confirm|retract NEWS_ID",
            "pm-news --id ADMIN_ID play scenario.yaml",
            "pm-news list [--duration SECONDS]",
            "pm-news past [--limit N] [--date YYYY-MM-DD]",
        ),
        description=(
            "Sends commands to the running pm-market-sim as an ADMIN participant. "
            "A headline's sentiment is public; its impact (the log move of the "
            "true value when confirmed) is not. A rumour moves nothing until it "
            "is confirmed; a retracted rumour never moves anything.",
        ),
        options=(
            Option("--id GW_ID", "-", "ADMIN participant ID the commands come from"),
        ),
        subcommands=(
            Subcommand("inject", purpose="Publish a headline; prints its ID"),
            Subcommand("confirm", "NEWS_ID", "Confirm a rumour (the values move)"),
            Subcommand("retract", "NEWS_ID", "Retract a rumour (nothing moves)"),
            Subcommand("play", "SCENARIO", "Run a timed scenario YAML"),
            Subcommand("list", purpose="Print headlines as they are published"),
            Subcommand("past", purpose="List previously published news"),
        ),
        ports="connects to 5553 (SUB) and 5554 (PUSH); play also to 5555/5556",
        related=("pm-market-sim", "pm-ai-swarm"),
        doc_anchor="pm-news",
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/090-market-model.md",
        examples=(
            "pm-news --id OPS01 inject --symbol AAPL --kind EARNINGS --sentiment 0.8 --impact 0.08",
            "pm-news --id OPS01 play docs/examples/news/rumour-confirmed.yaml",
        ),
    ),
)


# ---------------------------------------------------------------------------
# Index
# ---------------------------------------------------------------------------

_INDEX: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-index",
        category="Index",
        title="Index Calculation Process",
        summary="Maintains one or more cap-weighted market indices in real time.",
        synopsis=("pm-index [--reset] [-v|-vv] [--log-level LEVEL]",),
        description=(
            "Subscribes to trade.executed from the engine and publishes live index "
            "values on a dedicated PUB socket so pm-md-gwy can forward them over the "
            "CALF INDEX channel. Persists structural/audit history (INIT, "
            "CORP_ACTION, ADD_CONSTITUENT, DELIST) as JSONL; level/EOD ticks are "
            "recorded by pm-stats instead.",
        ),
        options=(
            Option(
                "--reset",
                "off",
                "Delete persisted state files and reinitialise all indices from config",
            ),
        ),
        has_common_log_options=True,
        ports="Binds 5558 (PUB, index.update), 5559 (PULL, operator commands); connects out to 5556",
        related=("pm-index-cli", "pm-index-admin-cli", "pm-stats-cli", "pm-md-gwy"),
        doc_anchor="pm-index-index-calculation-process",
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/070-market-index.md",
    ),
    CommandInfo(
        name="pm-index-cli",
        category="Index",
        title="Index Structural/Audit History Query Tool",
        summary="Read-only offline query of pm-index's structural/corporate-action JSONL history.",
        synopsis=(
            "pm-index-cli [--config engine_config.yaml] [--format table|json|csv] COMMAND [options]",
        ),
        description=(
            "Reads history files directly from disk -- no running process required. "
            "Does not expose level/EOD history; use `pm-stats-cli index-daily` / "
            "`index-snapshots` for that instead.",
        ),
        options=(
            Option(
                "--config, -c PATH",
                "unset",
                "Path to engine_config.yaml; auto-discovers history files and index IDs",
            ),
            Option(
                "--data-dir DIR",
                "data/indexes",
                "Directory containing history files, when --config is absent",
            ),
            Option("--format table|json|csv", "table", "Output format"),
            Option("--no-header", "off", "Suppress header row (CSV only)"),
        ),
        subcommands=(
            Subcommand(
                "events",
                purpose="Structural events: INIT, CORP_ACTION, ADD_CONSTITUENT, DELIST",
            ),
            Subcommand(
                "indices", purpose="List configured indices from engine_config.yaml"
            ),
        ),
        related=("pm-index", "pm-index-admin-cli", "pm-stats-cli"),
        doc_anchor="pm-index-cli-index-structuralaudit-history-query-tool",
        doc_page="../../../docs/books/operator-guide/part-3-run/020-admin-console-and-commands.md",
        examples=("pm-index-cli events --index MYIDX --days 30",),
    ),
    CommandInfo(
        name="pm-index-admin-cli",
        category="Index",
        title="Index Corporate Action / Constituent Change CLI",
        summary="One-shot write tool for splits, dividends, share changes, and constituent add/delist.",
        synopsis=(
            "pm-index-admin-cli --id <GW_ID> [--push ADDR] [--sub ADDR] [--timeout MS]",
            "                    [--dry-run] [-y] [--format table|json] COMMAND [options]",
        ),
        description=(
            "Talks directly to pm-index's live PUSH/PULL socket pair -- unlike "
            "pm-index-cli, it does not read JSONL files and does not require "
            "--config. Has no connect()/authentication step: pm-index's PULL socket "
            "accepts any non-empty gateway_id, used only as an ack-routing key.",
        ),
        options=(
            Option(
                "--id GW_ID",
                "required",
                "Ack-routing label -- not authenticated by pm-index",
            ),
            Option(
                "--push ADDR", "tcp://127.0.0.1:5559", "pm-index PULL socket address"
            ),
            Option("--sub ADDR", "tcp://127.0.0.1:5558", "pm-index PUB socket address"),
            Option("--timeout MS", "3000", "Ack timeout in milliseconds"),
            Option(
                "--dry-run", "off", "Print the outbound payload instead of sending it"
            ),
            Option("-y, --yes", "off", "Skip the confirmation prompt"),
            Option("--format table|json", "table", "Output format"),
        ),
        subcommands=(
            Subcommand("split", purpose="Apply a stock split or reverse split"),
            Subcommand("dividend", purpose="Apply a cash dividend adjustment"),
            Subcommand(
                "shares",
                purpose="Set shares outstanding -- covers issuances and buy-backs",
            ),
            Subcommand("add", purpose="Add a new constituent"),
            Subcommand("delist", purpose="Remove a constituent"),
            Subcommand(
                "history",
                purpose="Show recent structural/corp-action history for an index",
            ),
        ),
        related=("pm-index", "pm-index-cli"),
        doc_anchor="pm-index-admin-cli-index-corporate-action-constituent-change-cli",
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/080-index-administration.md",
        notes=(
            'Every mutating subcommand prompts "Continue? [y/N]" unless -y/--yes is given.',
        ),
    ),
)


# ---------------------------------------------------------------------------
# Query & Reporting CLIs -- read-only offline tools that query a SQLite/JSONL
# store directly, without connecting to any running process.
# ---------------------------------------------------------------------------

_QUERY_CLIS: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-audit-cli",
        category="Query & Reporting CLIs",
        title="Audit Log Query CLI",
        summary="Read-only offline query of pm-audit's rotating JSONL log files.",
        synopsis=(
            "pm-audit-cli [--log-file data/audit.log] [--log-dir PATH]",
            "             [--format table|json|csv] COMMAND [options]",
        ),
        options=(
            Option("--log-file PATH", "data/audit.log", "Primary audit log file"),
            Option(
                "--log-dir PATH",
                "directory of --log-file",
                "Directory containing rotated log backups",
            ),
            Option("--format table|json|csv", "table", "Output format"),
            Option("--no-header", "off", "Suppress header row in CSV output"),
            Option(
                "--use-index PATH",
                "auto-detected",
                "Path to the optional SQLite index file",
            ),
        ),
        subcommands=(
            Subcommand(
                "events",
                args="[options]",
                purpose="Search log entries by topic, gateway, symbol, and time range (default limit 100)",
            ),
            Subcommand(
                "orders",
                args="[options]",
                purpose="Order lifecycle events for specific order IDs or filters (default limit 100)",
            ),
            Subcommand(
                "trades",
                args="[options]",
                purpose="Trade executions (default limit 100)",
            ),
            Subcommand(
                "topics", purpose="List topics present in logs with event counts"
            ),
            Subcommand("gateways", purpose="Gateway activity summary"),
            Subcommand(
                "timeline",
                args="[options]",
                purpose="Raw chronological event stream for session replay (default limit 500)",
            ),
            Subcommand("stats", purpose="Summary statistics about audit log files"),
            Subcommand(
                "index",
                args="[--output PATH]",
                purpose="Build or update the optional SQLite index for faster queries",
            ),
            Subcommand(
                "archive",
                args="(--date D | --pending) [--level N] [--keep-days N]",
                purpose="Compress closed days' parts into one verified audit-D.log.zst",
            ),
        ),
        related=("pm-audit", "pm-stats-cli", "pm-clearing-cli"),
        doc_anchor="pm-audit-cli-audit-log-query-cli",
        examples=(
            "pm-audit-cli trades --symbol AAPL --from 2026-06-01 --to 2026-06-05",
        ),
    ),
    CommandInfo(
        name="pm-audit-replay",
        category="Query & Reporting CLIs",
        title="Audit Replay and Narration",
        summary=(
            "Reconstructs the causal structure of the audit trail and narrates "
            "it as business-level prose."
        ),
        synopsis=(
            "pm-audit-replay [--log-file data/audit.log] [--db data/audit_replay.db]",
            "                [--from ISO_TS] [--to ISO_TS] [-q|-v|-vv] COMMAND",
        ),
        description=(
            "pm-audit-cli answers 'which events match this filter?'. This "
            "answers 'what happened, in order, and why?' -- it reads causality "
            "from each message's envelope, groups events into episodes, and "
            "renders them.",
            "Read-only with respect to the audit trail, and a separate index "
            "(data/audit_replay.db) from pm-audit-cli's event index.",
            "Under construction: the global options below are settled, but no "
            "subcommand is registered yet.",
        ),
        options=(
            Option("--log-file PATH", "data/audit.log", "Audit log to read"),
            Option("--db PATH", "data/audit_replay.db", "Episode index"),
            Option("--no-index", "off", "Stream without building or reading an index"),
            Option("--rebuild", "off", "Rebuild the episode index before rendering"),
            Option("--from ISO_TS", "-", "Start of window"),
            Option("--to ISO_TS", "-", "End of window"),
            Option("--date YYYY-MM-DD", "-", "Shorthand for a whole UTC day"),
            Option("--last DURATION", "-", "Relative window, e.g. 15m, 2h, 1d"),
            Option("--symbol SYMBOL", "all", "Restrict to symbols (repeatable)"),
            Option("--gateway GW_ID", "all", "Restrict to gateways (repeatable)"),
            Option("--kind KIND", "all", "Restrict to episode kinds (repeatable)"),
            Option("-q, -v, -vv, -vvv", "-v", "Detail level"),
            Option("--format FORMAT", "text", "text, ndjson, json or markdown"),
            Option("--show-source", "off", "Append audit.log:LINE to every line"),
            Option("--show-units", "off", "Append unit provenance to every price"),
            Option("--explain", "off", "Show link evidence and confidence inline"),
            Option("--id-len N|full", "6", "Order-id abbreviation"),
            Option("--actor-style STYLE", "id", "Actor naming: id or descriptive"),
            Option("--tz TZ", "UTC", "Render timestamps in this zone"),
            Option("--reorder-window SPEC", "2000/5s", "Reorder buffer size"),
            Option("--no-color", "off", "Disable ANSI colour"),
        ),
        related=("pm-audit-cli", "pm-audit", "pm-stats-cli"),
        examples=("pm-audit-replay --date 2026-09-08 --symbol AAPL -v",),
        notes=("Design: docs-design/EduMatcher-Audit-Replay.md",),
    ),
    CommandInfo(
        name="pm-sim-forensics",
        category="Query & Reporting CLIs",
        title="Simulation Forensics",
        summary="Checks a finished simulation run's records against each other and writes a report.",
        synopsis=(
            "pm-sim-forensics [--data DIR] [--out DIR] [--check ID ...] [--slow]",
            "                 [--samples N] [--jobs N] [-q]",
            "pm-sim-forensics --list",
        ),
        description=(
            "Run it on a stopped sim's data directory, from the same build that "
            "produced the run: the re-run checks decode the config artifact the "
            "engine started on, and a build whose configuration schema has moved "
            "cannot. The report states both versions.",
            "Opens every store read-only and never talks to a running system.",
        ),
        options=(
            Option(
                "--data DIR",
                "resolved from $EDUMATCHER_DATA_DIR",
                "The run's data directory",
            ),
            Option(
                "--out DIR",
                "<data dir>/../forensics",
                "Where report.md and findings.json go",
            ),
            Option(
                "--check ID",
                "all",
                "Run only these checks (repeatable); slow ones included",
            ),
            Option(
                "--slow",
                "off",
                "Also run the slow checks (E5-E7: several engine re-runs)",
            ),
            Option("--samples N", "10", "Sample rows kept per check"),
            Option(
                "--jobs N", "CPU count", "Processes to run checks in; 1 = this process"
            ),
            Option("-q, --quiet", "off", "No progress output on stderr"),
            Option("--list", "off", "List the checks and exit"),
            Option("--version", "-", "Print the version and exit"),
        ),
        related=("pm-audit-replay", "pm-stats-cli", "pm-clearing-cli"),
        examples=("pm-sim-forensics --data ~/.edumatcher-sim/data --slow",),
        notes=(
            "Exit 0: every check PASSed or was SKIPPED. Exit 1: a check FAILed or hit an ERROR.",
            "Design: docs-design/EduMatcher-Sim-Forensics-Workplan.md",
        ),
    ),
    CommandInfo(
        name="pm-clearing-cli",
        category="Query & Reporting CLIs",
        title="Clearing Query CLI",
        summary="Command-line query interface for clearing.db, including a prune maintenance command.",
        synopsis=(
            "pm-clearing-cli [--datapath PATH] [--db-name clearing.db]",
            "                [--format table|json|csv] [--raw-output] COMMAND [options]",
        ),
        description=(
            "Unlike pm-clearing, this is a one-shot tool: runs one query, prints output, exits.",
        ),
        options=(
            Option(
                "--datapath PATH",
                "resolved from $EDUMATCHER_DATA_DIR",
                "Data directory or explicit .db file path",
            ),
            Option(
                "--db-name NAME",
                "clearing.db",
                "SQLite filename when --datapath is a directory",
            ),
            Option("--format table|json|csv", "table", "Output format"),
            Option("--no-header", "off", "Suppress header row in CSV output"),
            Option(
                "--raw-output",
                "off",
                "Disable tick-decimal normalization; emit raw tick-unit values",
            ),
        ),
        subcommands=(
            Subcommand(
                "gateways",
                purpose="Gateway-level realized/unrealized/total P&L totals (limit 1000)",
            ),
            Subcommand(
                "positions",
                purpose="Current open position state by gateway and symbol (limit 10000)",
            ),
            Subcommand(
                "pnl",
                purpose="Realized/unrealized/total P&L rows per gateway and symbol (limit 10000)",
            ),
            Subcommand("daily", purpose="Daily rollup summary rows (limit 1000)"),
            Subcommand("trades", purpose="Raw trade-event rows (limit 200)"),
            Subcommand(
                "exposure", purpose="Net/gross notional exposure and P&L (limit 1000)"
            ),
            Subcommand(
                "symbols",
                purpose="Symbol-level totals and open exposure snapshot (limit 1000)",
            ),
            Subcommand(
                "dates",
                purpose="Available trade dates, optionally with totals (limit 1000)",
            ),
            Subcommand("health", purpose="DB row counts, flush metadata, and WAL mode"),
            Subcommand(
                "reconcile",
                purpose="Compares raw trade_events vs daily summary for discrepancies",
            ),
            Subcommand(
                "sessions",
                purpose="Gateway connection/disconnection history (limit 500)",
            ),
            Subcommand(
                "snapshots",
                args="[--date D] [--gateway G] [--symbol S]",
                purpose="Position snapshots taken at each session close; the basis of pm-eod's settlement",
            ),
            Subcommand(
                "eod",
                purpose="End-of-day sentinel events written by pm-clearing (limit 100)",
            ),
            Subcommand(
                "gaps",
                args="[--from D] [--to D]",
                purpose="Trade-feed gaps: trades pm-clearing never received (limit 500)",
            ),
            Subcommand(
                "rebuild",
                args="--from-audit DATA_DIR --output PATH",
                purpose="Replay the audit trail into a new DB and list positions that differ (exit 3)",
            ),
            Subcommand(
                "prune",
                args="[--days N] [--dry-run]",
                purpose="Delete old trade_events rows by retention window",
            ),
        ),
        related=("pm-clearing", "pm-stats-cli", "pm-audit-cli", "pm-eod"),
        doc_anchor="pm-clearing-cli-clearing-query-cli",
        doc_page="../../../docs/books/participant-guide/part-5-positions-and-results/010-positions-and-pnl.md",
        examples=(
            "pm-clearing-cli gateways",
            "pm-clearing-cli --format json positions --gateway MM01",
            "pm-clearing-cli exposure --sort total_pnl",
            "pm-clearing-cli prune --days 90 --dry-run",
        ),
    ),
    CommandInfo(
        name="pm-stats-cli",
        category="Query & Reporting CLIs",
        title="Statistics Query CLI",
        summary="Read-only query interface for stats.db (OHLCV, trades, snapshots, index history).",
        synopsis=(
            "pm-stats-cli [--db data/stats.db] [--format table|json|csv] [--timezone TZ] COMMAND [options]",
        ),
        description=(
            "Runs one query, prints output, and exits -- not a subscriber process.",
        ),
        options=(
            Option("--db PATH", "data/stats.db", "SQLite database file path"),
            Option("--format table|json|csv", "table", "Output format"),
            Option("--no-header", "off", "Suppress header row in csv output"),
            Option(
                "--timezone TZ",
                "DB-recorded timezone",
                "Override the session timezone --date resolves in",
            ),
        ),
        subcommands=(
            Subcommand("daily", purpose="Daily OHLCV summary from daily_stats"),
            Subcommand(
                "snapshots",
                purpose="Intraday snapshots from price_snapshots (--symbol required)",
            ),
            Subcommand("trades", purpose="Trade history from trade_log"),
            Subcommand(
                "order-events",
                purpose="Private order lifecycle events (--gateway required)",
            ),
            Subcommand(
                "order-lifecycle",
                purpose="All events for a single order ID (--gateway, --order-id required)",
            ),
            Subcommand("symbols", purpose="Discover symbols available in stats data"),
            Subcommand(
                "dates", purpose="Discover trading dates available in daily_stats"
            ),
            Subcommand(
                "index-daily", purpose="Daily index OHLC rollup from index_daily_stats"
            ),
            Subcommand(
                "index-snapshots",
                purpose="Every recorded index level tick (--index-id required)",
            ),
            Subcommand("index-ids", purpose="Discover index IDs with recorded data"),
            Subcommand(
                "instruments",
                purpose="Instrument reference data (tick scale per symbol)",
            ),
            Subcommand(
                "gaps",
                purpose="Detected feed gaps -- trades the recorder never received",
            ),
            Subcommand(
                "health",
                purpose="Check the pm-stats process and stats DB read/write health",
            ),
        ),
        related=("pm-stats", "pm-clearing-cli", "pm-index-cli"),
        doc_anchor="pm-stats-cli-statistics-query-cli",
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/060-statistics-and-reporting.md",
        examples=(
            "pm-stats-cli daily --date 2026-06-14 --symbol AAPL",
            "pm-stats-cli snapshots --symbol MSFT --from 2026-06-14T09:00:00+00:00 --to 2026-06-14T16:30:00+00:00",
            "pm-stats-cli --format csv trades --symbol AAPL --date 2026-06-14",
        ),
        notes=(
            "--after CURSOR pages through results using the cursor from a previous call's last row.",
        ),
    ),
    CommandInfo(
        name="pm-monitor-cli",
        category="Query & Reporting CLIs",
        title="Health Query CLI",
        summary="Read-only health, exchange status and event log from pm-monitor.",
        synopsis=(
            "pm-monitor-cli [--host HOST] [--port 5611] [--db PATH] [--format table|json]",
            "               [--timeout SEC] COMMAND [options]",
        ),
        description=(
            "Subscribes to pm-monitor's snapshot port for the live view and reads "
            "metrics.db for the event log; never writes either.",
        ),
        options=(
            Option("--host HOST", "monitor.host", "Where pm-monitor publishes"),
            Option("--port PORT", "monitor.pub_port (5611)", "pm-monitor's PUB port"),
            Option(
                "--db PATH",
                "data/metrics.db",
                "metrics.db for events and health --extended",
            ),
            Option("--format table|json", "table", "Output format"),
            Option("--timeout SEC", "3", "Seconds to wait for a snapshot"),
        ),
        subcommands=(
            Subcommand(
                "health",
                purpose=(
                    "pm-monitor publishing snapshots; --extended checks metrics.db "
                    "integrity, schema, timezone and write access; -q exits 0/255"
                ),
            ),
            Subcommand(
                "status",
                purpose=(
                    "Exchange status, every process, active breaches; exit 0 "
                    "OPERATIONAL, 1 DEGRADED, 3 IMPAIRED, 4 DOWN, 5 unreachable"
                ),
            ),
            Subcommand(
                "events",
                purpose="Event log from metrics.db; --follow adds live events",
            ),
        ),
        related=("pm-monitor", "pm-opctl-cli", "pm-log-cli"),
        doc_anchor="pm-monitor-cli-health-query-cli",
        doc_page="../../../docs/books/operator-guide/part-6-observe-and-recover/060-health-monitor.md",
        examples=(
            "pm-monitor-cli status",
            "pm-monitor-cli health --extended -v",
            "pm-monitor-cli events --kind DISCONNECT --follow",
            "pm-monitor-cli --format json status",
        ),
        notes=(
            "The monitor entry of every built-in pm-opctl-cli profile uses "
            "'pm-monitor-cli health -q' as its healthcheck.",
        ),
    ),
    CommandInfo(
        name="pm-compdb-cli",
        category="Query & Reporting CLIs",
        title="Company Database CLI",
        summary="Company profiles of the simulated market: look up, list, filter, add.",
        synopsis=(
            "pm-compdb-cli [--db PATH] [--format table|json|csv] [--no-header] "
            "COMMAND [options]",
            "pm-compdb-cli list [-c COLS|all] [-w FILTER]... [-s COL [--desc]] [-n N]",
            "pm-compdb-cli add|update SYMBOL FIELD=VALUE...",
        ),
        description=(
            "A SQLite database of made-up company profiles for the 300 tickers of "
            "the s300 simulation and 100 Nordic ones: name, industry, purpose, founder story, CEO, "
            "financials (revenue, profit, P/E, margins, debt, rating) and more. "
            "Each ticker keeps its sector and industry from pm-market-sim; every "
            "name, person and number is invented. No running process is needed.",
            "A filter is COLUMN OP VALUE with OP one of = != < <= > >= or ~ "
            "(contains, any case); repeated filters must all match. "
            "`pm-compdb-cli columns` lists the columns.",
        ),
        options=(
            Option("--db PATH", "<DATA_DIR>/companies.db", "Database file"),
            Option(
                "--format table|json|csv", "table", "Output format of show and list"
            ),
            Option("--no-header", "off", "Leave out the table/CSV header"),
        ),
        subcommands=(
            Subcommand("init", purpose="Build the database of the bundled companies"),
            Subcommand("columns", purpose="List the columns and what each one holds"),
            Subcommand("show", "SYMBOL...", "Everything about one or more companies"),
            Subcommand(
                "list", purpose="List companies with chosen columns and filters"
            ),
            Subcommand("add", "SYMBOL FIELD=VALUE...", "Add a company"),
            Subcommand("import", "FILE...", "Add the companies of YAML files"),
            Subcommand("update", "SYMBOL FIELD=VALUE...", "Change a company's fields"),
            Subcommand("delete", "SYMBOL", "Remove a company"),
        ),
        related=("pm-market-sim", "pm-news"),
        doc_anchor="pm-compdb-cli-company-database-cli",
        examples=(
            "pm-compdb-cli show AAPL",
            "pm-compdb-cli list -c symbol,name,pe_ratio -w sector=TECH -w 'pe_ratio<25' -s pe_ratio",
            "pm-compdb-cli --format csv list -c all > companies.csv",
        ),
    ),
)


# ---------------------------------------------------------------------------
# Admin & Operations
# ---------------------------------------------------------------------------

_ADMIN_AND_OPS: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-eod",
        category="Admin & Operations",
        title="End-of-Day Settlement",
        summary="Settles a closed trading day, writes statements, and does the daily housekeeping.",
        synopsis=(
            "pm-eod [--datapath DIR] [--format table|json|csv] run (--date D | --pending)",
            "       [--only STEP] [--force] [--redo] [--dry-run]",
            "       [--log-keep-days 14] [--backup-keep-days 7] [--backup-skip NAME]",
            "pm-eod [--datapath DIR] [--format table|json|csv] status [-q]",
            "pm-eod [--datapath DIR] [--format table|json|csv] balances [--date D] [--gateway G] [--check]",
            "pm-eod [--datapath DIR] [--format table|json|csv] show --date D [--gateway G] [--steps]",
        ),
        description=(
            "A one-shot command, normally started by 'pm-scheduler --on-close' after the "
            "market closes. For each trading date it checks that the day really closed and "
            "that the books reconcile (gate), converts each trader's change in mark-to-market "
            "equity since the previous close into an amount the trader pays or receives "
            "against the exchange (settle), writes one statement per trader plus an exchange "
            "summary (report), and runs the housekeeping: audit-archive safety net, "
            "log compression and verified database backups.",
            "The currency is fictional and nothing is sent: statements are files under "
            "<data>/settlement/<date>/, with instructions.csv as the mail-merge input. "
            "Traders are identified by gateway; ref_data/roster.yaml adds names, emails and "
            "opening balances. The ledger is <data>/eod.db.",
            "Exit codes of 'run': 0 clean, 1 the gate, settlement or report failed, "
            "2 usage error, 3 settled and reported but a step warned (housekeeping, "
            "or a settled date's snapshot changed). "
            "'status -q' exits 0 when no closed date is waiting, 1 when one is "
            "or clearing.db is missing.",
        ),
        options=(
            Option(
                "--datapath DIR",
                "resolved from $EDUMATCHER_DATA_DIR",
                "Data directory (global option: put it before the subcommand)",
            ),
            Option(
                "--format table|json|csv",
                "table",
                "Output format for status and balances",
            ),
            Option("--no-header", "off", "Suppress the header row"),
            Option(
                "--date D", "", "run: the trading date to close (YYYY-MM-DD)", "run"
            ),
            Option(
                "--pending",
                "off",
                "run: every closed date without an ok run, oldest first; stops at the first failure",
                "run",
            ),
            Option(
                "--only STEP",
                "all steps",
                "run: re-run just report, audit, logs or backup for a settled date "
                "(not with --redo, --force or --dry-run)",
                "run",
            ),
            Option(
                "--force",
                "off",
                "run: skip the 'has the day closed?' test (exchanges without a "
                "scheduler); the snapshot and reconcile checks still apply",
                "run",
            ),
            Option(
                "--redo",
                "off",
                "run: recompute the date; drops its settlement and every later date's",
                "run",
            ),
            Option(
                "--dry-run",
                "off",
                "run: gate and settle into an in-memory copy of the ledger, print the "
                "amounts, write nothing (not with --only)",
                "run",
            ),
            Option(
                "--log-keep-days N",
                "14",
                "run: delete compressed fallback logs older than N days (N >= 0)",
                "run",
            ),
            Option(
                "--backup-keep-days N",
                "7",
                "run: delete backup folders older than N days (N >= 0)",
                "run",
            ),
            Option(
                "--backup-skip NAME",
                "none",
                "run: leave clearing.db, stats.db or eod.db out of the backup (repeatable)",
                "run",
            ),
            Option(
                "-q, --quiet",
                "off",
                "status: print nothing; exit 0 if no closed date waits, 1 if one does "
                "or clearing.db is missing",
                "status",
            ),
            Option("--limit N", "30", "status: number of runs shown", "status"),
            Option("--date D", "", "balances: balances as of this date", "balances"),
            Option("--gateway G", "", "balances, show: only this trader", "balances"),
            Option("--date D", "", "show: the settled trading date (required)", "show"),
            Option(
                "--steps",
                "off",
                "show: the run's steps with full messages instead of the amounts",
                "show",
            ),
            Option(
                "--check",
                "off",
                "balances: verify every settled date sums to zero",
                "balances",
            ),
        ),
        subcommands=(
            Subcommand(
                "run",
                args="(--date D | --pending)",
                purpose="Settle, report and tidy up trading date(s)",
            ),
            Subcommand("status", args="[-q]", purpose="Recent runs and pending dates"),
            Subcommand(
                "balances", args="[--check]", purpose="Running balance per account"
            ),
            Subcommand(
                "show",
                args="--date D [--steps]",
                purpose="One date's ledger rows, or its run steps",
            ),
        ),
        related=("pm-scheduler", "pm-clearing", "pm-clearing-cli", "pm-audit-cli"),
        doc_anchor="pm-eod-end-of-day-settlement",
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/100-closing-the-day.md",
        examples=(
            "pm-eod run --date 2026-11-02 --dry-run",
            "pm-eod run --pending",
            "pm-eod status",
            "pm-eod balances --check",
        ),
        notes=(
            "Design: docs-design/EduMatcher-EOD-Settlement.md",
            "Statements: <data>/settlement/<date>/statements/<gateway>.md",
        ),
    ),
    CommandInfo(
        name="pm-admin",
        category="Admin & Operations",
        title="Interactive Admin Console",
        summary="Interactive REPL for operator commands (halt, kill, kick) without a full gateway.",
        synopsis=("pm-admin --id <ADMIN_GW_ID> [-v|-vv] [--log-level LEVEL]",),
        description=(
            "The prompt is coloured red to distinguish it from pm-alf-console. Tab "
            "completion and arrow-key history work the same way. The --id must be "
            "an entry in engine_config.yaml with role: ADMIN.",
        ),
        options=(
            Option(
                "--id ADMIN_GW_ID",
                "required",
                "ADMIN gateway ID configured in engine_config.yaml",
            ),
        ),
        has_common_log_options=True,
        subcommands=(
            Subcommand(
                "HALT / RESUME", purpose="Exchange-wide circuit-breaker halt / lift it"
            ),
            Subcommand(
                "HALT_SYM / RESUME_SYM",
                args="SYM=<sym>",
                purpose="Halt / resume a single symbol",
            ),
            Subcommand(
                "CANCEL_SYM",
                args="SYM=<sym>",
                purpose="Cancel all resting orders for a symbol",
            ),
            Subcommand(
                "KILL",
                args="GW=<gw>[|SYM=<sym>]",
                purpose="Cancel all (or symbol-scoped) orders/quotes for a gateway",
            ),
            Subcommand(
                "KICK",
                args="GW=<gw>[|REASON=<text>]",
                purpose="Forcefully disconnect a gateway",
            ),
            Subcommand(
                "QCANCEL",
                args="GW=<gw>|SYM=<sym>",
                purpose="Cancel an MM's active quote on one symbol",
            ),
            Subcommand(
                "BOOK", args="SYM=<sym>", purpose="Print L1/L2 order-book snapshot"
            ),
            Subcommand(
                "ORDERS", args="GW=<gw>", purpose="List resting orders for a gateway"
            ),
            Subcommand(
                "LEVEL",
                args="SYM=<sym>[|PRICE=<p>]",
                purpose="Show orders making up a symbol or one price level",
            ),
            Subcommand(
                "SYMBOLS / GATEWAYS / VOLUME",
                purpose="List instruments / gateways / daily traded volume",
            ),
            Subcommand(
                "SESSION", args="STATE=<phase>", purpose="Advance session phase"
            ),
            Subcommand(
                "SESSION_STATUS / SCHEDULE",
                purpose="Show current session state / configured schedule",
            ),
            Subcommand(
                "HELP / EXIT / QUIT",
                purpose="Show command reference / disconnect and exit",
            ),
        ),
        related=("pm-admin-cli", "pm-opctl-cli", "pm-engine"),
        doc_anchor="pm-admin-interactive-admin-console",
        doc_page="../../../docs/books/operator-guide/part-3-run/020-admin-console-and-commands.md",
        examples=("pm-admin --id GW_ADMIN",),
        notes=(
            "Most commands require the ADMIN gateway role; see the full risk-control flow in Risk Controls.",
        ),
    ),
    CommandInfo(
        name="pm-admin-cli",
        category="Admin & Operations",
        title="CLI Admin Commands",
        summary="Non-interactive, one-shot alternative to pm-admin for scripting and CI.",
        synopsis=("pm-admin-cli --id <GW_ID> <command> [options]",),
        description=(
            "Sends one command to the engine, waits for an acknowledgement, prints the result, and exits.",
        ),
        options=(
            Option("--id GW_ID", "required", "ADMIN gateway ID"),
            Option("--push ADDR", "from config", "Engine PULL address"),
            Option("--sub ADDR", "from config", "Engine PUB address"),
            Option("--timeout MS", "3000", "Ack timeout in milliseconds"),
        ),
        subcommands=(
            Subcommand("halt / resume", purpose="Exchange-wide halt / resume"),
            Subcommand(
                "halt-sym / resume-sym",
                args="--sym SYMBOL",
                purpose="Halt / resume one symbol",
            ),
            Subcommand(
                "cancel-sym",
                args="--sym SYMBOL",
                purpose="Cancel all resting orders on one symbol",
            ),
            Subcommand(
                "kill",
                args="--gw GW_ID [--sym SYMBOL]",
                purpose="Cancel all (or symbol-scoped) orders/quotes for gateway",
            ),
            Subcommand(
                "kick",
                args="--gw GW_ID [--reason TEXT]",
                purpose="Disconnect a gateway",
            ),
            Subcommand(
                "qcancel",
                args="--gw GW_ID --sym SYMBOL",
                purpose="Cancel active quote for gateway on symbol",
            ),
            Subcommand("book", args="--sym SYMBOL", purpose="Fetch book snapshot"),
            Subcommand(
                "orders", args="--gw GW_ID", purpose="List resting orders for gateway"
            ),
            Subcommand(
                "symbols / gateways / volume",
                purpose="List instruments / gateway states / daily volume",
            ),
            Subcommand(
                "session", args="--state STATE", purpose="Request session transition"
            ),
            Subcommand(
                "session-status / schedule",
                purpose="Read current session state / configured schedule",
            ),
        ),
        related=("pm-admin", "pm-opctl-cli"),
        doc_anchor="pm-admin-cli-cli-admin-commands",
        doc_page="../../../docs/books/operator-guide/part-3-run/020-admin-console-and-commands.md",
        examples=("pm-admin-cli --id GW_ADMIN halt-sym --sym AAPL",),
    ),
    CommandInfo(
        name="pm-opctl-cli",
        category="Admin & Operations",
        title="Operational Process Control",
        summary="Start, stop, and monitor a named group of pm-* processes together (recommended stack launcher).",
        synopsis=(
            "pm-opctl-cli start|up [PROFILE]",
            "pm-opctl-cli list [-y|--no-restart] | health [-q] | stop|down | kill",
            "pm-opctl-cli init | show [--json] | clear (--state|--all) [--yes]",
        ),
        description=(
            "The recommended way to bring up or tear down a full EduMatcher stack, "
            "instead of launching each process by hand. A profile is a named list "
            "of processes defined in <DATA_DIR>/emo-config.yaml; three profiles "
            "(micro, mini, default) are built in until that file exists.",
        ),
        subcommands=(
            Subcommand(
                "start",
                args="[PROFILE]",
                aliases=("up",),
                purpose="Start a profile (default when omitted), skipping entries already running",
            ),
            Subcommand(
                "list",
                purpose="Status table for the active profile: uptime and memory per process; offers to restart dead entries",
            ),
            Subcommand(
                "health",
                args="[-q]",
                purpose="Same checks as list; exits 0 only when every process is running -- for monitoring scripts",
            ),
            Subcommand(
                "stop",
                aliases=("down",),
                purpose="Send SIGTERM to processes this tool started",
            ),
            Subcommand(
                "kill",
                purpose="Emergency stop: signals every process whose command line contains pm-, including ones this tool did not start",
            ),
            Subcommand(
                "init",
                purpose="Write the built-in profiles to emo-config.yaml for editing (refuses to overwrite)",
            ),
            Subcommand(
                "show",
                args="[--json]",
                purpose="Print version, data directory, and deployed config paths",
            ),
            Subcommand(
                "clear",
                args="(--state|--all) [--yes]",
                purpose="Delete persisted data; ref_data/ configuration is never touched",
            ),
        ),
        related=("pm-engine", "pm-config-deploy", "pm-setup", "pm-admin"),
        doc_anchor="pm-opctl-cli-operational-process-control",
        doc_page="../../../docs/books/operator-guide/part-3-run/010-running-the-exchange.md",
        examples=(
            "pm-opctl-cli init                # write editable emo-config.yaml",
            "pm-opctl-cli start                # start the default profile",
            "pm-opctl-cli list                 # status table, offers to restart dead entries",
            "pm-opctl-cli health -q && echo OK # scripting-friendly health check",
            "pm-opctl-cli stop                 # graceful shutdown",
        ),
        notes=(
            "Health is reported at three confidence levels: dead, not responding, "
            "or running. A restarted-outside-this-tool process is re-adopted by "
            "matching its command line, so a stale PID file is never treated as final.",
        ),
    ),
)


# ---------------------------------------------------------------------------
# Setup & Configuration
# ---------------------------------------------------------------------------

_SETUP_AND_CONFIG: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-setup",
        category="Setup & Configuration",
        title="Session Bootstrap Tool",
        summary="Bootstraps a runnable EduMatcher session directory with sensible defaults.",
        synopsis=("pm-setup [--data-dir PATH] [--force] [--no-config]",),
        description=(
            "Creates the data directory and deploys the bundled sample config to "
            "<DATA_DIR>/ref_data/engine_config.json. Use once per new environment "
            "before starting runtime processes.",
        ),
        options=(
            Option(
                "--data-dir PATH",
                "$EDUMATCHER_DATA_DIR or ~/.local/share/edumatcher",
                "Data directory for persistent files",
            ),
            Option("--force", "off", "Replace an already-deployed config"),
            Option("--no-config", "off", "Create the data dir only; deploy nothing"),
        ),
        related=("pm-config-gen", "pm-config-deploy", "pm-opctl-cli"),
        doc_anchor="pm-setup-session-bootstrap-tool",
        doc_page="../../../docs/books/reference-manual/part-1-command-line/010-processes-environment-and-ports.md",
        notes=(
            "Local bootstrap logic; does not participate in the ZeroMQ runtime message bus.",
        ),
    ),
    CommandInfo(
        name="pm-config-gen",
        category="Setup & Configuration",
        title="Engine Config Generator",
        summary="Generates engine_config.yaml from explicit CLI parameters instead of hand-editing YAML.",
        synopsis=(
            "pm-config-gen --symbols SYM [SYM ...] --participants GW_SPEC [...] [options]",
            "              --output engine_config.yaml",
        ),
        options=(
            Option(
                "--symbols SYM [SYM ...]",
                "required",
                "One or more symbols",
                group="Required",
            ),
            Option(
                "--participants GW_SPEC [...]",
                "required",
                "One or more ID[:ROLE[:DISCONNECT]] participant specs",
                group="Required",
            ),
            Option(
                "--sessions-enabled",
                "disabled",
                "Enable scheduler-driven sessions; without it the file says "
                "sessions_enabled: false (an absent key means enabled)",
                group="Session & engine",
            ),
            Option(
                "--static-band / --dynamic-band PCT",
                "unset",
                "Default collar bands",
                group="Collars & circuit breakers",
            ),
            Option(
                "--risk-level NAME:STATIC[:DYNAMIC]",
                "-",
                "Risk level definition; repeatable",
                group="Collars & circuit breakers",
            ),
            Option(
                "--cb-levels NAME:SHIFT[:HALT_MINS]",
                "-",
                "Circuit-breaker levels (HALT_MINS > 0; omit for rest of day); "
                "repeatable. Without it no circuit_breaker_defaults is written",
                group="Collars & circuit breakers",
            ),
            Option(
                "--mm-spread-ticks / --mm-min-qty",
                "20 / 100",
                "Global market-maker obligation defaults",
                group="Market-maker obligations",
            ),
            Option(
                "--post-trade-gateway",
                "-",
                "Emit post_trade_gateway: section for pm-ralf-gwy",
                group="Gateway sections",
            ),
            Option(
                "--market-data-gateway",
                "-",
                "Emit market_data_gateway: section for pm-md-gwy",
                group="Gateway sections",
            ),
            Option(
                "--balf-gateway",
                "-",
                "Emit balf_gateway: section for pm-balf-gwy",
                group="Gateway sections",
            ),
            Option(
                "--api-gateway",
                "-",
                "Emit api_gateways: section for pm-api-gwy",
                group="Gateway sections",
            ),
            Option(
                "--index INDEX_ID",
                "-",
                "Add an index to the config; repeatable",
                group="Index sections",
            ),
            Option(
                "--schedule / --no-schedule",
                "auto",
                "Write / leave out the schedule section (needs --sessions-enabled)",
                group="Schedule",
            ),
            Option(
                "--combo SPEC",
                "-",
                "Add a pre-configured combo definition; repeatable",
                group="Combos",
            ),
            Option("--output FILE", "stdout", "Output YAML file path", group="Output"),
            Option(
                "--dry-run",
                "off",
                "Print generated YAML; write nothing",
                group="Output",
            ),
        ),
        related=("pm-cverifier", "pm-config-deploy", "pm-config-show"),
        doc_anchor="pm-config-gen-engine-config-generator",
        doc_page="../../../docs/books/operator-guide/part-2-configure/010-the-configuration-workflow.md",
        examples=(
            "pm-config-gen --symbols AAPL MSFT --participants TRADER01 TRADER02 OPS01:ADMIN "
            "--sessions-enabled --output engine_config.yaml",
        ),
        notes=(
            "Full option reference (80+ flags across gateway/symbol overrides, "
            "seeding, and per-gateway sub-flags) is in the Configuration chapter's "
            "Option Reference -- this page shows the groups, not every flag.",
        ),
    ),
    CommandInfo(
        name="pm-cverifier",
        category="Setup & Configuration",
        title="Config Verifier",
        summary="Validates engine_config.yaml across YAML, schema, semantic, and completeness checks.",
        synopsis=(
            "pm-cverifier [--format text|json] [--level info|warn|error] [--strict] CONFIG_FILE",
        ),
        options=(
            Option("CONFIG_FILE", "required", "Path to engine_config.yaml"),
            Option("--format text|json", "text", "Output format"),
            Option("--level info|warn|error", "info", "Minimum severity to show"),
            Option("--no-color", "off", "Disable ANSI colour in text output"),
            Option(
                "--strict", "off", "Treat warnings as errors for CI exit-code purposes"
            ),
        ),
        related=("pm-config-gen", "pm-config-deploy", "pm-config-show"),
        doc_anchor="pm-cverifier-config-verifier",
        notes=(
            "Exit 0: no errors or warnings (advisories allowed). Exit 1: warnings, "
            "no errors. Exit 2: errors, warnings under --strict, or a file that "
            "could not be verified. --level only filters what is shown.",
        ),
    ),
    CommandInfo(
        name="pm-config-deploy",
        category="Setup & Configuration",
        title="Compile and Install a Configuration",
        summary="Validates, compiles, and installs engine_config.yaml as the file every process reads.",
        synopsis=(
            "pm-config-deploy SOURCE",
            "pm-config-deploy --check SOURCE",
            "pm-config-deploy --show",
        ),
        description=(
            "Runs all four pm-cverifier layers before installing; a failing "
            "configuration is never installed and the previous artifact is left "
            "untouched (staged write + rename). Compiling also resolves every "
            "default exactly once.",
        ),
        options=(
            Option(
                "SOURCE",
                "-",
                "Authored engine_config.yaml to validate, compile and install",
            ),
            Option(
                "--check", "off", "Validate and compile, but install nothing -- for CI"
            ),
            Option("--show", "off", "Print the deployed paths and exit"),
        ),
        related=("pm-cverifier", "pm-config-gen", "pm-config-show", "pm-opctl-cli"),
        doc_anchor="pm-config-deploy-compile-and-install-a-configuration",
        doc_page="../../../docs/books/operator-guide/part-2-configure/010-the-configuration-workflow.md",
        notes=(
            "Local bootstrap logic; does not participate in the ZeroMQ runtime message bus.",
        ),
    ),
    CommandInfo(
        name="pm-new-symbol",
        aliases=("pm-ipo",),
        category="Setup & Configuration",
        title="List a New Symbol (IPO)",
        summary="Add a symbol at its IPO price to the deployed configuration's source and redeploy it.",
        synopsis=(
            "pm-new-symbol --symbol NAME --ipo-price PRICE --outstanding-shares N",
            "pm-ipo --config PATH --symbol NAME --ipo-price PRICE --outstanding-shares N",
        ),
        options=(
            Option(
                "--config PATH",
                "deployed source",
                "Authored YAML to edit; redeployed only when it is the deployed source",
            ),
            Option("--symbol NAME", "required", "1-8 characters of A-Z 0-9 . _"),
            Option(
                "--ipo-price PRICE",
                "required",
                "Offer price; becomes both last prices and the collar/breaker reference",
            ),
            Option("--outstanding-shares N", "required", "Positive number of shares"),
            Option("--tick-decimals N", "2", "Price grid precision, 0..8"),
            Option(
                "--mm-gateway-id ID",
                "the only MM gateway",
                "MARKET_MAKER gateway that posts the seed quote",
            ),
            Option(
                "--mm-bid-price PRICE, --mm-ask-price PRICE",
                "max spread around the IPO price",
                "Explicit seed quote; must straddle the IPO price",
            ),
            Option("--mm-bid-qty N, --mm-ask-qty N", "1000", "Seed quote sizes"),
            Option("--mm-tif DAY|GTC", "DAY", "Seed quote time in force"),
            Option(
                "--[no-]mm-seed-once", "on", "Skip the seed when a quote was restored"
            ),
            Option(
                "--field KEY=YAML_VALUE",
                "none",
                "level, collar, order_limits or circuit_breaker; repeatable",
            ),
        ),
        related=("pm-config-deploy", "pm-cverifier", "pm-opctl-cli", "pm-valuation"),
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/010-new-symbols.md",
    ),
    CommandInfo(
        name="pm-valuation",
        category="Setup & Configuration",
        title="IPO Valuation Simulator",
        summary=(
            "Value a fictive company with a DCF, simulate its IPO book-build and "
            "find the offer price that pm-new-symbol lists."
        ),
        synopsis=(
            "pm-valuation [--market se|us] [--load FILE | --case NAME] [--level LEVEL]",
            "pm-valuation [--load FILE | --case NAME] --no-tui [--list [--config PATH]]",
        ),
        description=(
            "A terminal interview (twelve pages, every answer optional) feeds a "
            "two-stage DCF, comparables, a book-building model and an index "
            "rulebook. The report ends with the pm-new-symbol command for the "
            "priced IPO, or explains why the IPO is postponed.",
        ),
        options=(
            Option("--load FILE", "none", "Scenario file to start from"),
            Option("--case NAME", "none", "Classroom case to start from"),
            Option(
                "--market MARKET",
                "se",
                "se: Swedish IPO (SEK, prospectus, Nasdaq Stockholm); us: US IPO "
                "(USD, S-1)",
            ),
            Option("--no-tui", "off", "Print the report instead of interviewing"),
            Option(
                "--level LEVEL",
                "beginner",
                "Interview detail: beginner, intermediate, advanced or expert (F3)",
            ),
            Option(
                "--mode MODE",
                "both",
                "deterministic, montecarlo or both (overrides the scenario)",
            ),
            Option("--draws N, --seed S", "10000, 42", "Monte Carlo settings"),
            Option("--save FILE", "none", "Write the scenario (also F9 in the TUI)"),
            Option("--with-defaults", "off", "With --save: write every resolved value"),
            Option("--export FILE", "none", "Write the report as Markdown"),
            Option(
                "--pdf FILE", "none", "Write a printable PDF report (also p in the TUI)"
            ),
            Option("--paper SIZE", "a4", "PDF page size: a4 or letter"),
            Option("--presets FILE", "bundled", "Alternative sector presets"),
            Option(
                "--list", "off", "With --no-tui: list the priced IPO with pm-new-symbol"
            ),
            Option(
                "--config PATH",
                "deployed source",
                "With --list: the engine YAML pm-new-symbol edits",
            ),
        ),
        related=("pm-new-symbol", "pm-index-admin-cli", "pm-opctl-cli"),
        doc_page="../../../docs/books/operator-guide/part-4-run-a-market/020-valuation.md",
        examples=(
            "pm-valuation --case tornfalk                  # interview a classroom case",
            "pm-valuation --market us                      # a US IPO, in USD",
            "pm-valuation --case halvard --level expert    # show every field",
            "pm-valuation --load my.yaml --no-tui --list   # price and list in one go",
            "pm-valuation --case tornfalk --no-tui --pdf tornfalk.pdf   # print it",
        ),
    ),
    CommandInfo(
        name="pm-config-show",
        category="Setup & Configuration",
        title="Config Viewer",
        summary="Prints the effective configuration as a terminal dashboard, or renders it as a PDF.",
        synopsis=(
            "pm-config-show [-m 1|2] [--all] [-f FILE]",
            "pm-config-show --format pdf -o exchange.pdf",
        ),
        description=(
            'Where pm-cverifier answers "is this file correct", pm-config-show '
            'answers "what does this file say" -- including the resolved port map, '
            "which cannot be read off the YAML alone. Strictly read-only.",
        ),
        options=(
            Option(
                "-f, --file YAML",
                "<DATA_DIR>/ref_data/engine_config.yaml",
                "Config file to read",
            ),
            Option(
                "-m, --density [1|2]",
                "0",
                "1 adds risk/gateway detail, 2 adds every knob",
            ),
            Option(
                "-a, --all", "off", "Show everything: implies -m 2, unmasks API keys"
            ),
            Option("--format terminal|pdf", "terminal", "Output format"),
            Option(
                "-o, --output FILE",
                "engine-config-<stem>.pdf",
                "Destination file for --format pdf",
            ),
            Option("--no-color", "off", "Disable ANSI colour"),
            Option(
                "--ascii",
                "off",
                "ASCII box drawing; auto-enabled on non-UTF-8 terminals",
            ),
            Option(
                "--width N",
                "terminal width",
                "Force render width -- for scripted capture",
            ),
        ),
        related=("pm-cverifier", "pm-config-deploy", "pm-config-gen"),
        doc_anchor="pm-config-show-config-viewer",
        doc_page="../../../docs/books/operator-guide/part-2-configure/010-the-configuration-workflow.md",
        notes=(
            "Exit 2: config file missing/unreadable. Exit 3: not valid YAML "
            "(points at pm-cverifier). Local inspection logic; not on the ZeroMQ bus.",
        ),
    ),
)


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

_LOGGING: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-log-srv",
        category="Logging",
        title="Centralized Log Server",
        summary="Collects LALF log lines from every pm-* process into a queryable log.db.",
        synopsis=(
            "pm-log-srv [--host ADDR] [--port 5600] [--db PATH] [--retention-days N]",
            "           [--pub-port 5601] [--pull-port 5602] [--no-pubsub]",
        ),
        description=(
            "A dedicated collector process, unrelated to the ZeroMQ order-flow bus: "
            "accepts LALF TCP connections and appends every record to SQLite. Also "
            "runs a LALF-PS ZeroMQ PUB/PULL pair that pushes live rows to log "
            "viewers without polling log.db.",
        ),
        options=(
            Option("--host ADDR", "0.0.0.0 (from config)", "TCP bind address"),
            Option("--port PORT", "5600", "TCP listen port for LALF clients"),
            Option("--db PATH", "data/log.db", "SQLite database path"),
            Option(
                "--retention-days N",
                "30",
                "Prune log_events rows older than N days (0 = unbounded)",
            ),
            Option(
                "--max-message-bytes N", "65536", "Truncation ceiling per LOG payload"
            ),
            Option(
                "--pub-port PORT", "5601", "LALF-PS PUB bind port for log distribution"
            ),
            Option(
                "--pull-port PORT",
                "5602",
                "LALF-PS PULL bind port for subscriber control",
            ),
            Option("--no-pubsub", "off", "Disable the LALF-PS interface entirely"),
            Option(
                "--lease-sec N",
                "30",
                "Subscription lease TTL before an unrenewed subscriber is reaped",
            ),
            Option(
                "--log-level LEVEL",
                "WARNING",
                "Explicit level: CRITICAL, ERROR, WARNING, INFO, DEBUG",
            ),
            Option("-v, --verbose", "off", "Increase verbosity"),
            Option("-q, --quiet", "off", "Explicit WARNING log level (the default)"),
            Option(
                "--log-target stdout|file",
                "stdout",
                "Never server -- pm-log-srv must not depend on itself",
            ),
            Option(
                "--log-file PATH",
                "-",
                "Operational log file; required with --log-target file",
            ),
        ),
        ports="Listens on TCP 5600 (LALF collection), binds ZMQ 5601 (PUB) and 5602 (PULL) unless --no-pubsub",
        related=("pm-log-cli",),
        doc_anchor="pm-log-srv-centralized-log-server",
        doc_page="../../../docs/books/operator-guide/part-6-observe-and-recover/040-log-server.md",
        notes=(
            "Every other pm-* process probes for pm-log-srv at start-up and ships its log there when it answers (unless --log-target says otherwise); a process started while it is down logs to its console.",
        ),
    ),
    CommandInfo(
        name="pm-log-cli",
        category="Logging",
        title="Log Server Query/Troubleshooting CLI",
        summary="Read-only offline query and troubleshooting tool for log.db.",
        synopsis=("pm-log-cli [--db PATH] [--format human|json] COMMAND [options]",),
        description=(
            "Queries log.db directly from disk, never over the network, so a busy "
            "or even-stopped pm-log-srv never blocks troubleshooting.",
        ),
        options=(
            Option("--db PATH", "data/log.db", "SQLite database path"),
            Option("--format human|json", "human", "Output format"),
        ),
        subcommands=(
            Subcommand("tail", purpose="Follow recent log records"),
            Subcommand("query", purpose="Search log records by filter"),
            Subcommand("processes", purpose="Summarize which processes have logged"),
            Subcommand("stats", purpose="Summary statistics about the log database"),
            Subcommand(
                "diagnose",
                purpose="Rule-based troubleshooting heuristics with concrete recommendations",
            ),
            Subcommand("prune", purpose="Manual retention maintenance"),
            Subcommand(
                "explain",
                purpose="One row with its log-ledger explanation and suggested actions",
            ),
            Subcommand(
                "ledger",
                purpose="list/show/check/export the log ledger (needs no log.db)",
            ),
        ),
        related=("pm-log-srv",),
        doc_anchor="pm-log-cli-log-server-querytroubleshooting-cli",
        doc_page="../../../docs/books/operator-guide/part-6-observe-and-recover/040-log-server.md",
    ),
)


# ---------------------------------------------------------------------------
# Developer Tools
# ---------------------------------------------------------------------------

_DEVELOPER_TOOLS: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-msgen",
        category="Developer Tools",
        title="Message Binding Generator",
        summary="Generates Python/C message bindings and message-reference docs from spec/.",
        synopsis=(
            "pm-msgen generate [--spec DIR] [--out-python DIR] [--out-c DIR]",
            "pm-msgen check    [--spec DIR] [--out-python DIR] [--out-c DIR]",
            "pm-msgen lint     [--spec DIR]",
            "pm-msgen grep-literals [--spec DIR] [--src DIR]",
        ),
        description=(
            "Not part of the running exchange -- no pm-* runtime process invokes "
            "it. Keeps the spec in spec/ as the single source of truth for every "
            "topic name and payload shape. `check` is the CI gate: it re-renders "
            "from the spec and fails if committed output differs, run via "
            "`make msgen-check`.",
        ),
        subcommands=(
            Subcommand(
                "generate",
                purpose="Render Python bindings, C artifacts, and docs; write to disk",
            ),
            Subcommand(
                "check",
                purpose="Fail (exit 1) if committed output differs from the spec",
            ),
            Subcommand(
                "lint", purpose="Validate the spec only; prints a family/message count"
            ),
            Subcommand(
                "grep-literals",
                purpose="Scan a source tree for topic literals a generated constant should replace",
            ),
        ),
        options=(
            Option(
                "--spec DIR", "spec", "Spec root holding transports.yaml and messages/"
            ),
            Option(
                "--out-python DIR",
                "src/edumatcher/models/generated",
                "Python output directory (generate/check)",
            ),
            Option(
                "--out-c DIR",
                "docs/examples/generated",
                "C output directory (generate/check)",
            ),
            Option("--src DIR", "src", "Source tree to scan (grep-literals)"),
        ),
        related=(),
        doc_anchor="pm-msgen-message-binding-generator",
        examples=(
            "make msgen        # regenerate after editing a spec file",
            "make msgen-check  # CI drift gate",
        ),
        notes=(
            "Exit 2 on spec error or a missing --spec directory (usually the wrong "
            "working directory -- run from the repo root, or pass --spec).",
            "Local build tooling; does not participate in the ZeroMQ runtime message bus.",
        ),
    ),
)


# ---------------------------------------------------------------------------
# Help
# ---------------------------------------------------------------------------

_HELP: tuple[CommandInfo, ...] = (
    CommandInfo(
        name="pm-help",
        category="Help",
        title="Command Index and Man-Page Reference",
        summary="Lists every pm-* command, or prints a full man page for one of them.",
        synopsis=(
            "pm-help [--format table|text] [-v]",
            "pm-help [--format table|text] [-v] <pm-command>",
            "pm-help --completion bash|zsh",
        ),
        description=(
            "With no argument, prints the version, data directories, and a table "
            "of every pm-* command with a one-sentence description, grouped by "
            "category. With a command name, prints a full man page for that "
            "command: synopsis, description, options, subcommands, ports/message "
            "bus involvement, related commands, and examples.",
        ),
        options=(
            Option(
                "--format table|text",
                "table",
                "table uses UTF-8 box-drawing characters; text is plain-aligned columns",
            ),
            Option(
                "-v, --verbose",
                "off",
                "Show extra detail (and an example, where one exists) for each command",
            ),
            Option(
                "--completion bash|zsh",
                "",
                "Print the tab-completion script for every pm-* command and exit",
            ),
        ),
        aliases=("pm-man",),
        related=(),
        doc_anchor="",
        examples=(
            "pm-help                    # version, data dirs, and the full command table",
            "pm-help --format text -v   # plain-text table with per-command examples",
            "pm-help pm-viewer          # full man page for pm-viewer",
            "pm-man pm-alf-console      # pm-man is an alias for pm-help",
        ),
    ),
)


# ---------------------------------------------------------------------------
# Public assembly
# ---------------------------------------------------------------------------

ALL_COMMANDS: tuple[CommandInfo, ...] = (
    _CORE_RUNTIME
    + _EXTERNAL_GATEWAYS
    + _PROTOCOL_SPIES
    + _AI_AND_BOTS
    + _INDEX
    + _QUERY_CLIS
    + _ADMIN_AND_OPS
    + _SETUP_AND_CONFIG
    + _LOGGING
    + _DEVELOPER_TOOLS
    + _HELP
)


def _build_index(commands: tuple[CommandInfo, ...]) -> dict[str, CommandInfo]:
    """Map every command's name and aliases to its :class:`CommandInfo`."""
    by_name: dict[str, CommandInfo] = {cmd.name: cmd for cmd in commands}
    for cmd in commands:
        for alias in cmd.aliases:
            by_name.setdefault(alias, cmd)
    return by_name


_BY_NAME: dict[str, CommandInfo] = _build_index(ALL_COMMANDS)


def all_commands() -> tuple[CommandInfo, ...]:
    """Return every known command, in category-then-registration order."""
    return ALL_COMMANDS


def get_command(name: str) -> CommandInfo | None:
    """Look up a command by exact name or alias.

    Accepts the name with or without a leading ``pm-`` so ``viewer`` finds
    ``pm-viewer`` as a convenience for a mistyped invocation.
    """
    if name in _BY_NAME:
        return _BY_NAME[name]
    if not name.startswith("pm-") and f"pm-{name}" in _BY_NAME:
        return _BY_NAME[f"pm-{name}"]
    return None


def commands_by_category() -> tuple[tuple[str, tuple[CommandInfo, ...]], ...]:
    """Group commands by category, in ``CATEGORY_ORDER``."""
    grouped: dict[str, list[CommandInfo]] = {cat: [] for cat in CATEGORY_ORDER}
    for cmd in ALL_COMMANDS:
        grouped.setdefault(cmd.category, []).append(cmd)
    return tuple((cat, tuple(cmds)) for cat, cmds in grouped.items() if cmds)


def close_matches(name: str, limit: int = 3) -> tuple[str, ...]:
    """Suggest similar command names for an unknown-command error message."""
    import difflib

    candidates = list(_BY_NAME.keys())
    return tuple(difflib.get_close_matches(name, candidates, n=limit, cutoff=0.4))
