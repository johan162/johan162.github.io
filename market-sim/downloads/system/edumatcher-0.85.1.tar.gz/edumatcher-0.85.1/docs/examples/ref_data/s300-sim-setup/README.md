# 300-Symbol Simulation Setup

The long-running simulated market of the
[AI Traders and Market Simulation](../../../books/ai-traders/00-front/010-how-to-use-this-book.md)
book, and the default of the `edumatcher-ai-sim` container image.

- Symbols: 300 (the 150 `s150` tickers plus 150 more)
- Participants: `TRADER01`–`TRADER10` (people), `OPS01` (instructor), `MON01` (the admin monitor feed's own API gateway instance `monitor` on port 8082, logged in to with `OPS01`'s key), `MM01` (the market-maker bot), and AI traders `AI001`–`AI100`
- `swarm.yaml`: the 100 AI traders, each trading 30 symbols (about 10 agents per symbol), 120 order actions a second in total
- `market_sim.yaml`: the market model (hidden true values) with generated news and rumours on
- `companies.db`: made-up company profiles for all 300 tickers, matching their sectors and industries, plus 100 Swedish and Nordic companies whose tickers the simulation does not trade; query with `pm-compdb-cli --db companies.db list`, rebuild with `pm-compdb-cli --db companies.db init --force` (the source is `src/edumatcher/compdb/companies/*.yaml`)
- Sessions: enabled, the same 09:00–16:05 schedule on weekdays and weekends, Sweden's calendar and time zone; collars off; market-maker obligations enforced
- Seeded market-maker quotes on every symbol
- Outstanding shares: each symbol's `companies.db` market cap divided by its seeded price, so price × shares starts at the company's market cap
- Index `EDU50`: the 50 largest companies by `companies.db` market cap, cap-weighted, base value 1000 (`NVDA`, `AAPL`, `MSFT`, … `BX`); about 47% technology, the ten largest about 64%. TapeDeck shows it in the Index view (the container sets `INDEX_IDS=EDU50`)
- Market-data gateway: `max_symbols_per_client: 300`
- Run it: `pm-config-deploy --example s300-sim`, then `pm-opctl-cli start ai-sim`
- Regenerate: `./mkrefdata.sh [--seed INTEGER]` (this file was generated with `--seed 300100`)
