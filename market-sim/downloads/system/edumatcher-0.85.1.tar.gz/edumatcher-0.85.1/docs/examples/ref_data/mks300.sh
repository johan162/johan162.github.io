#!/usr/bin/env bash
# Generates the 300-symbol examples, chosen by SETUP_DIR's name:
#   s300-load-setup  the design-limit test bed for the AI traders: 500 AI
#                    participants, MM01 and MM02 (docs-design/EduMatcher-AI-Traders-v3-Plan.md, WP-A3)
#   s300-sim-setup   the long-running simulation: 100 AI participants, MM01
#                    (docs-design/EduMatcher-AI-Sim-Book-Plan.md, WP-B1)
set -euo pipefail

setup_dir="${1:?usage: mks300.sh SETUP_DIR [--seed INTEGER]}"
shift
cd "$setup_dir"

# s300-sim runs for weeks with ~100 orders a second: the API gateways keep
# finished orders 5 minutes instead of an hour, and the post-trade gateway's
# replay journal 15 minutes instead of a day, or both would hold gigabytes.
# The sim also gets an API gateway of its own for the admin monitor feed
# (instance 'monitor', admin id MON01): the feed's fan-out saturated the
# event loop of 'desk' at the open and dropped events. Empty = none.
# The sim's outstanding shares follow companies.db, and its 50 largest
# companies form the EDU50 index; the load test bed has neither.
case "$(basename "$(pwd)")" in
  s300-load-setup) ai_count=500; market_makers=(MM01 MM02); long_run=()
    risk=(--no-collars); monitor_admin=""; company_db="" ;;
  # The sim runs with collars and circuit breakers a news-driven move can
  # reach, so the forensics see band rejects, halts and reopening auctions
  # (sim forensics S27).
  s300-sim-setup) ai_count=100; market_makers=(MM01)
    long_run=(--api-gateway-order-retention-sec 300 --post-trade-gateway
              --post-trade-replay-retention-sec 900)
    risk=(--static-band 0.20 --dynamic-band 0.03
          --cb-levels L1:0.04:3 L2:0.08:10 L3:0.15 --cb-window-ns 300000000000)
    monitor_admin=MON01; company_db=companies.db ;;
  *) echo "Error: unknown setup directory $(pwd)" >&2; exit 1 ;;
esac

seed=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --seed) seed="${2:?Error: --seed requires an integer argument}"; shift 2 ;;
    --seed=*) seed="${1#*=}"; shift ;;
    -h|--help) echo "Usage: $0 SETUP_DIR [--seed INTEGER]"; exit 0 ;;
    *) echo "Error: unknown argument: $1" >&2; exit 1 ;;
  esac
done
if [[ -n "$seed" && ! "$seed" =~ ^-?[0-9]+$ ]]; then
  echo "Error: --seed must be an integer" >&2
  exit 1
fi
if [[ -z "$seed" ]]; then
  # Reuse the seed recorded in an existing engine_config.yaml's header
  # comment, if there is one, instead of drawing a new random seed -- a
  # re-run with no --seed should reproduce the same book.
  existing_seed=$(awk '/^#/{sub(/^#/,""); sub(/\\$/,""); printf "%s ", $0; next} {exit}' engine_config.yaml 2>/dev/null \
    | grep -oE -- '--seed +-?[0-9]+' | head -1 | awk '{print $2}')
  if [[ -n "$existing_seed" ]]; then
    seed="$existing_seed"
    echo "[INFO] Reusing seed $seed from existing engine_config.yaml -- pass --seed to override." >&2
  else
    seed=$(( RANDOM * 32768 + RANDOM ))
    echo "[INFO] Auto-generated seed $seed -- re-run with --seed $seed for identical output." >&2
  fi
fi

if command -v pm-config-gen >/dev/null 2>&1; then
  config_gen=(pm-config-gen)
elif command -v poetry >/dev/null 2>&1; then
  config_gen=(poetry run pm-config-gen)
else
  echo "Error: neither pm-config-gen nor poetry is available in PATH" >&2
  exit 1
fi

# The 150 s150 tickers followed by 150 more, so s150 sector data carries over.
symbols=(
  AAPL MSFT TSLA AMZN GOOGL META NVDA NFLX INTC ORCL IBM ADBE CRM QCOM AMD AVGO
  TXN NOW SHOP UBER PYPL SQ BABA SONY SAP ASML CSCO MU BKNG TSM JPM BAC WFC C
  GS MS V MA AXP BLK SCHW WMT COST TGT HD LOW NKE SBUX MCD KO PEP PG CL EL JNJ
  PFE MRK ABBV LLY BMY AMGN GILD CVS UNH CI HUM ISRG MDT XOM CVX COP SLB EOG OXY
  MPC VLO PSX KMI BA CAT DE GE HON LMT RTX NOC UPS FDX UNP CSX DIS CMCSA T VZ
  TMUS SPOT ROKU PANW CRWD SNOW PLTR DDOG NET MDB TEAM ZS FTNT INTU ADP PAYX FIS
  FI ABNB MAR HLT DAL UAL AAL RCL CCL F GM TM HMC RIVN LCID NEE DUK SO AEP EXC
  XEL SRE LIN APD SHW FCX NEM NUE PLD AMT CCI EQIX SPG O PSA REG DLR WELL CB ACN
  ADI ADSK AFL AIG AJG ALB ALL AMAT AME AMP ANET AON APH ARE ATO AVB AWK AZO BAX
  BBY BDX BIIB BK BKR BR BRO BSX BX CAH CARR CDNS CDW CEG CF CHD CHTR CINF CLX
  CMG CME CMI CMS CNC COF CPRT CSGP CTAS CTSH CTVA D DD DG DHI DHR DLTR DOV DOW
  DPZ DRI DTE DVN DXCM EA EBAY ECL ED EFX EIX EMR ENPH EPAM ES ETN ETR EW EXPD
  EXPE FANG FAST FICO FITB FSLR GD GEHC GIS GLW GPC GPN GRMN GWW HAL HAS HBAN
  HCA HES HIG HPE HPQ HSY HUBB IDXX IFF ILMN INCY IP IQV IR IRM IT ITW JBHT JCI
  K KDP KEY KHC KLAC KMB KR LEN LH LHX LRCX LULU LVS LYB MAA MCHP MCK MCO MDLZ
  MET MGM MKC MLM MMC MMM MNST MO MOS MRNA MSCI MSI MTB MTD NDAQ NOV NRG NSC
)

participants=()
trader_ids=()
# Descriptions go through --participant-desc, one quoted "ID:TEXT" each; the
# --participants specs themselves carry no free text.
desc_args=()
for n in $(seq 1 10); do
  trader_id=$(printf 'TRADER%02d' "$n")
  participants+=("${trader_id}:TRADER:CANCEL_ALL")
  desc_args+=(--participant-desc "${trader_id}:Student desk ${n}")
  trader_ids+=("$trader_id")
done
participants+=("OPS01:ADMIN:LEAVE_ALL")
desc_args+=(--participant-desc "OPS01:Instructor console")
monitor_args=()
if [[ -n "$monitor_admin" ]]; then
  participants+=("${monitor_admin}:ADMIN:LEAVE_ALL")
  desc_args+=(--participant-desc "${monitor_admin}:Instructor console, admin monitor feed")
  monitor_args=(--api-gateway-instance "monitor:${monitor_admin}:8082")
fi
for mm in "${market_makers[@]}"; do
  case "$mm" in
    MM01) mm_desc="Primary market maker" ;;
    MM02) mm_desc="Backup market maker" ;;
    *) echo "Error: unknown market maker $mm" >&2; exit 1 ;;
  esac
  participants+=("${mm}:MARKET_MAKER:CANCEL_QUOTES_ONLY")
  desc_args+=(--participant-desc "${mm}:${mm_desc}")
done
for n in $(seq 1 "$ai_count"); do
  ai_id=$(printf 'AI%03d' "$n")
  participants+=("${ai_id}:TRADER:CANCEL_ALL")
  desc_args+=(--participant-desc "${ai_id}:AI trader ${n}")
done
trader_list=$(IFS=,; echo "${trader_ids[*]}")
mm_list=$(IFS=,; echo "${market_makers[*]}")

# generate OUTPUT [EXTRA_ARG...]
generate() {
  local output="$1"
  shift
  "${config_gen[@]}" \
  --symbols "${symbols[@]}" \
  --participants "${participants[@]}" \
  "${desc_args[@]}" \
  --participant-default-smp CANCEL_AGGRESSOR \
  --output "$output" \
  --force \
  --comment-default-config-fields \
  --seed "$seed" \
  --api-gateway-instance "desk:${trader_list},${mm_list},OPS01:8080" \
  --api-gateway-instance dashboards::8081 \
  "${monitor_args[@]+"${monitor_args[@]}"}" \
  --api-gateway-readonly-key \
  --seed-mm-mid-range 20:300 --mm-seed-spread-ticks 10 --seed-last-prices-from-mm \
  --enforce-mm-obligations \
  "${risk[@]}" \
  --sessions-enabled \
  --pre-open 09:00 --opening-auction 09:25 --continuous 09:30 \
  --closing-auction 16:00 --closing-end 16:05 \
  --weekend \
  --weekend-pre-open 09:00 --weekend-opening-auction 09:25 --weekend-continuous 09:30 \
  --weekend-closing-auction 16:00 --weekend-closing-end 16:05 \
  --market-data-gateway --market-data-enabled --market-data-name md-gwy01 \
  --market-data-bind-address 0.0.0.0 --market-data-port 5570 \
  --market-data-heartbeat-interval-sec 1 --market-data-idle-timeout-sec 5 \
  --market-data-replay-window-sec 30 --market-data-max-symbols-per-client 300 \
  --market-data-max-client-queue 20000 \
  "${long_run[@]+"${long_run[@]}"}" \
  "$@"
}

outstanding_args=()
index_args=()
if [[ -z "$company_db" ]]; then
  for index in "${!symbols[@]}"; do
    outstanding_args+=(--outstanding-shares "${symbols[$index]}:$((500000000 + index * 10000000))")
  done
else
  # pm-index weights a constituent by price x outstanding shares, so each
  # symbol gets companies.db's market cap / its seeded price in shares. The
  # seeded prices depend only on --seed: a first pass into a scratch
  # directory reads them. The last line out is the 50 largest, for EDU50.
  scratch=$(mktemp -d)
  trap 'rm -rf "$scratch"' EXIT
  generate "$scratch/engine_config.yaml" >/dev/null
  python3 -I - "$scratch/engine_config.yaml" "$company_db" > "$scratch/shares.txt" <<'PY'
import re
import sqlite3
import sys

config, db = sys.argv[1], sys.argv[2]
text = open(config, encoding="utf-8").read()
prices = {
    symbol: float(price)
    for symbol, price in re.findall(
        r"^  ([A-Z][A-Z0-9.]*):\n    tick_decimals: \d+\n    last_buy_price: (\S+)$",
        text,
        re.MULTILINE,
    )
}
caps = dict(sqlite3.connect(db).execute("SELECT symbol, market_cap_musd FROM companies"))
missing = sorted(symbol for symbol in prices if not caps.get(symbol))
if missing:
    sys.exit(f"Error: no market cap in {db} for {', '.join(missing)}")
for symbol, price in prices.items():
    print(f"{symbol}:{round(caps[symbol] * 1e6 / price)}")
print(",".join(sorted(prices, key=lambda symbol: (-caps[symbol], symbol))[:50]))
PY
  mapfile -t shares < "$scratch/shares.txt"
  for spec in "${shares[@]:0:${#shares[@]}-1}"; do
    outstanding_args+=(--outstanding-shares "$spec")
  done
  index_args=(--index "EDU50:EduMatcher 50, the 50 largest companies by market cap"
              --index-constituents "EDU50:${shares[-1]}")
fi

generate engine_config.yaml "${outstanding_args[@]}" "${index_args[@]+"${index_args[@]}"}"

if [[ -n "$monitor_admin" ]]; then
  # The browser sends the one key it was given to every socket; 'desk' reads it
  # as OPS01 and 'monitor' as ${monitor_admin} (the engine refuses one id
  # connected twice). So the monitor's key is OPS01's. Rotate them together.
  python3 -I - "$monitor_admin" <<'PY'
import re
import sys

admin = sys.argv[1]
text = open("engine_config.yaml", encoding="utf-8").read()
ops_key = re.search(r"- api_key: (\S+)\n\s+gateway_id: OPS01\n", text)
monitor_key = re.search(rf"- api_key: (\S+)\n\s+gateway_id: {admin}\n", text)
if ops_key is None or monitor_key is None:
    sys.exit(f"Error: no OPS01 / {admin} credential in engine_config.yaml")
text = text.replace(monitor_key.group(1), ops_key.group(1))
open("engine_config.yaml", "w", encoding="utf-8").write(text)
PY
fi

echo "Generated $(pwd)/engine_config.yaml"
