"""Console display helpers and the Rich console instance for the gateway."""

from __future__ import annotations

import sys
from datetime import datetime
from typing import Any

from prompt_toolkit.styles import Style
from rich.console import Console
from rich.table import Table

from edumatcher.models.price import get_tick_decimals


class _SysStdoutProxy:
    """
    Write-through proxy that resolves sys.stdout at *call time*, not at
    construction time.  This is necessary because prompt_toolkit's
    patch_stdout=True replaces sys.stdout with a StdoutProxy during each
    session.prompt() call.  Rich's Console stores the file reference at
    construction; without this proxy it would bypass the patch and its output
    would overwrite (and be overwritten by) prompt_toolkit's prompt redraws,
    making background responses like SYMBOLS appear empty.
    """

    def write(self, s: str) -> int:
        return sys.stdout.write(s)

    def flush(self) -> None:
        sys.stdout.flush()

    def fileno(self) -> int:
        return sys.stdout.fileno()

    def isatty(self) -> bool:
        return getattr(sys.stdout, "isatty", lambda: False)()

    @property
    def encoding(self) -> str:
        return getattr(sys.stdout, "encoding", "utf-8")

    @property
    def errors(self) -> str:
        return getattr(sys.stdout, "errors", "replace")


# force_terminal=True so rich always emits ANSI even through the proxy.
console = Console(file=_SysStdoutProxy(), force_terminal=True)  # type: ignore[arg-type]

PROMPT_STYLE = Style.from_dict(
    {
        "prompt": "bold ansigreen",
    }
)

HELP_TEXT = """
[bold]FIX-like command reference[/bold]

    NEW|SYM=<sym>|SIDE=BUY|SELL|TYPE=<type>|QTY=<n>[|PRICE=<p>][|STOP=<p>][|TRAIL=<offset>][|TIF=<tif>][|VISIBLE=<n>][|SMP=<action>][|TAG=<order-tag>]

    AMEND|ID=<order-id>[|PRICE=<new-price>][|QTY=<new-qty>][|RTAG=<request-tag>]
    • Amend a resting LIMIT or ICEBERG order in-place (no cancel+resubmit needed)
    • At least one of PRICE= or QTY= must be specified
    • Quantity decrease only (same price): priority is PRESERVED
    • Price change or quantity increase: priority is LOST (back of queue)
    • New QTY must exceed already-filled quantity

  Types:
    MARKET        — execute immediately, discard unfilled remainder
    LIMIT         — rest at PRICE= until filled or cancelled
    IOC           — Immediate-Or-Cancel: fill what you can at PRICE=, cancel the rest
    FOK           — Fill-Or-Kill: fill entire QTY= at PRICE= or cancel whole order
    STOP          — trigger as MARKET when price crosses STOP=
    STOP_LIMIT    — trigger as LIMIT at PRICE= when price crosses STOP=
    ICEBERG       — show only VISIBLE= qty; hidden remainder auto-replenishes
    TRAILING_STOP — stop that trails market by TRAIL= offset; provide initial STOP= or
                    omit for automatic initialisation from last trade price

  TIF  : DAY (default)  GTC  ATO (opening auction)  ATC (closing auction)
  SMP  : NONE  CANCEL_AGGRESSOR  CANCEL_RESTING  CANCEL_BOTH
         (omitted: your participant's configured smp_action)

  [bold]OCO orders (One-Cancels-Other — two linked orders):[/bold]
  NEW|TYPE=OCO|OCO_ID=<label>|SYM=<sym>|QTY=<n>|TIF=DAY|GTC|LEG1_SIDE=BUY|SELL|LEG1_TYPE=<type>[|LEG1_PRICE=<p>][|LEG1_STOP=<p>][|LEG1_TRAIL=<offset>]|LEG2_SIDE=...[|TAG=<tag>]
    • Both legs on the same symbol, same quantity
    • When one leg fills or is cancelled, the other is auto-cancelled
    • Classic use: take-profit limit + stop-loss (sell side)
  CANCEL|OCO_ID=<label>   — cancel an OCO pair and both its legs

  [bold]Combo orders (multi-leg):[/bold]
  NEW|TYPE=COMBO|COMBO_ID=<label>|COMBO_TYPE=AON|TIF=DAY|GTC|LEG_COUNT=<n>|LEG0.SYM=<sym>|LEG0.SIDE=BUY|LEG0.QTY=<n>|LEG0.PRICE=<p>|LEG1.SYM=...[|SMP=<action>][|TAG=<tag>]
    • Per leg: LEG<i>.SYM= LEG<i>.SIDE= LEG<i>.QTY= [LEG<i>.TYPE=LIMIT (default)|MARKET|STOP|STOP_LIMIT|FOK|IOC]
      [LEG<i>.PRICE=<p>] [LEG<i>.STOP=<p>]
    • 2–10 legs, each on a different symbol
    • Child orders are posted to books and fill independently
    • If any leg is cancelled/expires, all remaining legs are cascade-cancelled

    CANCEL|ID=<order-id>[|RTAG=<request-tag>]
  CANCEL|COMBO_ID=<combo-label>   — cancel a combo and all its legs
    QUOTE|SYM=<sym>|BID=<p>|ASK=<p>|BID_QTY=<n>|ASK_QTY=<n>[|TIF=DAY|GTC][|QUOTE_ID=<label>]
    QUOTE_CANCEL|SYM=<sym>          — cancel active quote for a symbol
    QBOOT[|SYM=<sym>]               — request active quote bootstrap state from engine
        QLEGS[|SYM=<sym>][|SHOW=ACTIVE|RECENT|ALL]  — show MM quote legs and fill flags
    KILL[|SYM=<sym>]                — kill-switch cancel for this gateway
    DC|STATE=ON|OFF                 — toggle async drop-copy relay (own fills only)
    STATUS      — show gateway/session summary (identity, symbols, order counts)
    ORDERS      — inspect this gateway's order table with IDs, quantities, and status
  POS         — show positions (quantity and cost from the engine) with this session's P&L
  POS|GW=<gateway_id>  — query another gateway's (e.g. an MM bot's) position
  SYMBOLS     — list all active instruments in the engine
  SESSION     — query the engine's current trading session state
    INDEX       — show current cached index level
    INDEX|HISTORY|INDEX=<id>[|FROM=YYYY-MM-DD|TO=YYYY-MM-DD] — query index structural/
                  audit history (corp actions, constituent changes — not level ticks;
                  use pm-stats-cli for level/EOD history)
  HELP        — this message
  CLEAR       — clear the terminal screen (like the shell's `clear`)
  EXIT / QUIT — disconnect
"""


def format_price(
    value: object, symbol: str, *, extra_digits: int = 0, missing: str = "—"
) -> str:
    """A price at the symbol's tick size; *extra_digits* more for an average.

    *missing* stands in for anything that is not a number.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return missing
    return f"{value:.{get_tick_decimals(symbol) + extra_digits}f}"


def is_active_leg_status(status: str) -> bool:
    return status in {"NEW", "PARTIAL", "PENDING"}


def print_quote_legs(
    gateway_id: str,
    quote_leg_cache: dict[str, dict[str, Any]],
    symbol: str | None,
    show: str,
) -> None:
    rows = list(quote_leg_cache.values())
    if symbol:
        rows = [r for r in rows if str(r.get("symbol", "")).upper() == symbol]

    if show == "ACTIVE":
        rows = [
            r
            for r in rows
            if is_active_leg_status(str(r.get("status", "")))
            or int(r.get("remaining", 0)) > 0
        ]
    elif show == "RECENT":
        rows = [
            r
            for r in rows
            if not is_active_leg_status(str(r.get("status", "")))
            and int(r.get("remaining", 0)) <= 0
        ]

    if not rows:
        console.print("[dim]No quote legs match this filter.[/dim]")
        return

    rows.sort(key=lambda r: str(r.get("last_event_time", "")), reverse=True)

    title = f"Quote legs — {gateway_id}  (show={show}"
    if symbol:
        title += f", sym={symbol}"
    title += ")"
    t = Table(title=title, show_lines=True)
    t.add_column("Symbol", style="bold")
    t.add_column("Quote", style="cyan")
    t.add_column("Leg", style="magenta")
    t.add_column("Order", style="dim")
    t.add_column("Price", justify="right")
    t.add_column("Qty", justify="right")
    t.add_column("Rem", justify="right")
    t.add_column("Filled", justify="right")
    t.add_column("Filled?", justify="center")
    t.add_column("Leg status", style="bold")
    t.add_column("Quote status", style="dim")
    t.add_column("Time", style="dim")

    status_colour = {
        "NEW": "green",
        "PARTIAL": "yellow",
        "FILLED": "bright_green",
        "CANCELLED": "red",
        "EXPIRED": "dim",
        "PENDING": "dim",
    }

    for row in rows:
        leg_status = str(row.get("status", "?"))
        colour = status_colour.get(leg_status, "white")
        filled_qty = int(row.get("filled", 0))
        fill_flag = "YES" if filled_qty > 0 else "NO"
        price_text = format_price(row.get("price"), str(row.get("symbol", "")))
        t.add_row(
            str(row.get("symbol", "?")),
            str(row.get("quote_id", "?")),
            str(row.get("leg_side", "?")),
            str(row.get("order_id", "?")),
            price_text,
            str(row.get("qty", "?")),
            str(row.get("remaining", "?")),
            str(filled_qty),
            fill_flag,
            f"[{colour}]{leg_status}[/{colour}]",
            str(row.get("quote_status", "")) or "—",
            str(row.get("last_event_time", "")),
        )
    console.print(t)


def print_quote_bootstrap(gateway_id: str, quotes: list[dict[str, Any]]) -> None:
    if not quotes:
        console.print("[dim]No active quote bootstrap entries returned.[/dim]")
        return

    t = Table(
        title=f"Quote bootstrap - {gateway_id}",
        show_header=True,
        header_style="bold magenta",
    )
    t.add_column("Symbol", style="bold")
    t.add_column("Quote", style="cyan")
    t.add_column("State", style="white")
    t.add_column("Bid", style="green")
    t.add_column("Ask", style="red")
    t.add_column("BidRem", justify="right")
    t.add_column("AskRem", justify="right")

    for q in quotes:
        symbol = str(q.get("symbol", ""))
        bid_txt = format_price(q.get("bid_price"), symbol, missing="-")
        ask_txt = format_price(q.get("ask_price"), symbol, missing="-")
        t.add_row(
            str(q.get("symbol", "?")),
            str(q.get("quote_id", "?")),
            str(q.get("state", "?")),
            bid_txt,
            ask_txt,
            str(q.get("bid_remaining_qty", 0)),
            str(q.get("ask_remaining_qty", 0)),
        )

    console.print(t)


def print_symbols_table(symbols: list[dict[str, Any]]) -> None:
    t = Table(
        title="Active Instruments",
        show_header=True,
        header_style="bold magenta",
    )
    t.add_column("#", style="dim", width=4)
    t.add_column("Symbol", style="bold", min_width=10)
    t.add_column("Tick", justify="right")
    t.add_column("MM Enforced", justify="center")
    t.add_column("Max Spread", justify="right")
    t.add_column("Min Qty", justify="right")

    for i, meta in enumerate(symbols, 1):
        sym = str(meta.get("symbol", ""))
        tick_decimals = meta.get("tick_decimals")
        enforce_mm = meta.get("enforce_mm_obligation")
        mm_max_spread_ticks = meta.get("mm_max_spread_ticks")
        mm_min_qty = meta.get("mm_min_qty")

        # The engine sends the exponent; the column shows the tick itself,
        # which is what a trader reads a price against.
        tick_text = (
            f"{10 ** -int(tick_decimals):.{int(tick_decimals)}f}"
            if tick_decimals is not None
            else "—"
        )
        if isinstance(enforce_mm, bool):
            enforced_text = "YES" if enforce_mm else "NO"
        else:
            enforced_text = "—"

        t.add_row(
            str(i),
            sym,
            tick_text,
            enforced_text,
            str(mm_max_spread_ticks) if mm_max_spread_ticks is not None else "—",
            str(mm_min_qty) if mm_min_qty is not None else "—",
        )

    console.print(t)


def _signed_money(value: float) -> str:
    """A P&L to the cent, signed and coloured. Never "-0.00": a short at its
    cost is ``0.0 * -100``, which is ``-0.0``, and adding ``0.0`` to the
    rounded value turns that, or a residue under half a cent, into ``0.0``."""
    cents = round(value, 2) + 0.0
    colour = "green" if cents >= 0 else "red"
    return f"[{colour}]{cents:+.2f}[/{colour}]"


def print_positions(
    positions: dict[str, dict[str, Any]],
    last_prices: dict[str, float],
) -> None:
    # A copy: the listener thread adds symbols while this runs.
    items = list(positions.items())
    active = {s: p for s, p in items if p["net_qty"] != 0}
    flat = {s: p for s, p in items if p["net_qty"] == 0 and p["realized_pnl"] != 0.0}

    if not active and not flat:
        console.print("[dim]No positions.[/dim]")
        return

    # Net quantity and average cost come from the engine at connect; realised
    # P&L only counts fills this session has seen.
    t = Table(
        title="Positions (P&L since connect)",
        show_header=True,
        header_style="bold magenta",
    )
    t.add_column("Symbol", style="bold", min_width=8)
    t.add_column("Net Qty", justify="right", min_width=8)
    t.add_column("Avg Cost", justify="right", min_width=10)
    t.add_column("Last Px", justify="right", min_width=10)
    t.add_column("Unreal P&L", justify="right", min_width=12)
    t.add_column("Real P&L", justify="right", min_width=12)

    for symbol in sorted(active.keys()):
        pos = active[symbol]
        net = pos["net_qty"]
        avg = pos["avg_cost"]
        last = last_prices.get(symbol)
        unreal = ""
        if last is not None and avg > 0:
            unreal = _signed_money((last - avg) * net)
        last_str = format_price(last, symbol)
        t.add_row(
            symbol,
            f"{net:+d}",
            format_price(avg, symbol, extra_digits=1),
            last_str,
            unreal or "—",
            _signed_money(pos["realized_pnl"]),
        )

    for symbol in sorted(flat.keys()):
        pos = flat[symbol]
        t.add_row(
            f"[dim]{symbol}[/dim]",
            "0",
            "—",
            "—",
            "—",
            _signed_money(pos["realized_pnl"]),
        )

    console.print(t)


def print_remote_position(
    gateway_id: str, positions: list[dict[str, Any]], status: str = "OK"
) -> None:
    """Render a POS|GW=<gateway_id> reply -- system.position_snapshot's
    per-symbol net_qty/avg_cost for some *other* gateway (typically a
    running pm-mm-bot). Unlike ``print_positions`` this has no local
    fill history to compute unrealized/realized P&L from, so it only shows
    what the engine's ledger reports: symbol, net position, and average
    cost. *status* is the reply's: a logged-off participant is shown as
    such, and an id no participant has is not shown as flat.
    """
    if status == "UNKNOWN_GATEWAY":
        console.print(f"[yellow]{gateway_id}: no participant has this id.[/yellow]")
        return
    offline = " (not connected)" if status == "NOT_CONNECTED" else ""
    if not positions:
        console.print(f"[dim]{gateway_id}{offline}: flat (no open positions).[/dim]")
        return

    t = Table(
        title=f"Position — {gateway_id}{offline}",
        show_header=True,
        header_style="bold magenta",
    )
    t.add_column("Symbol", style="bold", min_width=8)
    t.add_column("Net Qty", justify="right", min_width=8)
    t.add_column("Avg Cost", justify="right", min_width=10)

    for pos in sorted(positions, key=lambda p: str(p.get("symbol", ""))):
        symbol = str(pos.get("symbol", "?"))
        net = int(pos.get("net_qty", 0))
        avg = float(pos.get("avg_cost", 0.0))
        t.add_row(symbol, f"{net:+d}", format_price(avg, symbol, extra_digits=1))

    console.print(t)


_SESSION_STATE_COLOUR = {
    "PRE_OPEN": "yellow",
    "OPENING_AUCTION": "yellow",
    "CONTINUOUS": "green",
    "CLOSING_AUCTION": "yellow",
    "CLOSED": "red",
}

_SESSION_STATE_DESCRIPTIONS = {
    "PRE_OPEN": "orders accepted, no matching",
    "OPENING_AUCTION": "orders accepted, no matching (uncross on exit)",
    "CONTINUOUS": "normal continuous matching",
    "CLOSING_AUCTION": "orders accepted, no matching (uncross on exit)",
    "CLOSED": "no new orders accepted",
}


def print_session_status(state: str, sessions_enabled: bool) -> None:
    colour = _SESSION_STATE_COLOUR.get(state, "white")
    description = _SESSION_STATE_DESCRIPTIONS.get(state, "")
    ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    msg = f"[{ts}] [bold {colour}]SESSION[/bold {colour}]  {state}"
    if description:
        msg += f"  [dim]({description})[/dim]"
    console.print(msg)
    if not sessions_enabled:
        console.print("[dim]  [sessions gating disabled][/dim]")


def print_status(
    gateway_id: str,
    authenticated: bool,
    known_symbols: list[str],
    order_cache: dict[str, dict[str, Any]],
    quote_leg_cache: dict[str, dict[str, Any]],
    positions: dict[str, dict[str, Any]],
) -> None:
    # Copies: the listener thread inserts into both caches while this runs.
    orders = list(order_cache.values())
    quote_legs = list(quote_leg_cache.values())
    status_counts: dict[str, int] = {}
    for order in orders:
        status = str(order.get("status", "UNKNOWN"))
        status_counts[status] = status_counts.get(status, 0) + 1

    active_orders = sum(
        count
        for status, count in status_counts.items()
        if status in {"NEW", "PARTIAL", "PENDING"}
    )
    active_quote_legs = sum(
        1 for leg in quote_legs if is_active_leg_status(str(leg.get("status", "")))
    )

    table = Table(title=f"Gateway status — {gateway_id}", show_lines=True)
    table.add_column("Field", style="bold")
    table.add_column("Value")
    table.add_row("Gateway ID", gateway_id)
    table.add_row("Authenticated", "yes" if authenticated else "no")
    table.add_row(
        "Known symbols",
        ", ".join(known_symbols) if known_symbols else "—",
    )
    table.add_row("Cached orders", str(len(orders)))
    table.add_row("Active/resting orders", str(active_orders))
    table.add_row("Cached quote legs", str(len(quote_legs)))
    table.add_row("Active quote legs", str(active_quote_legs))
    table.add_row(
        "Position symbols",
        ", ".join(sorted(positions)) if positions else "—",
    )
    if status_counts:
        counts = ", ".join(
            f"{status}={count}" for status, count in sorted(status_counts.items())
        )
    else:
        counts = "—"
    table.add_row("Order status counts", counts)
    console.print(table)
    console.print(
        "[dim]Use ORDERS for detailed order inspection and POS for P&L.[/dim]"
    )


def print_current_index(last_index_update: dict[str, Any] | None) -> None:
    payload = last_index_update
    if not payload:
        console.print("[dim]No index data received yet. Is pm-index running?[/dim]")
        return

    # AR-0.3 renamed index.update's wire field to ts_ns (epoch nanoseconds);
    # AR-0.3b caught this call site still reading the old "timestamp" key,
    # which the index family stopped sending.
    ts_raw = payload.get("ts_ns")
    if isinstance(ts_raw, (int, float)):
        ts = datetime.fromtimestamp(float(ts_raw) / 1_000_000_000).strftime(
            "%H:%M:%S.%f"
        )[:-3]
    else:
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]

    index_id = str(payload.get("index_id", "INDEX"))
    level = float(payload.get("level", 0.0))
    session_state = str(payload.get("session_state", "?"))

    # `day` is one nullable record where day_open/day_high/day_low were three
    # flat keys (design section 16.2). The three-way isinstance check below
    # collapses to one: the record either travelled whole or did not travel.
    day = payload.get("day") or {}
    day_open = day.get("open")
    day_high = day.get("high")
    day_low = day.get("low")

    change_txt = ""
    if isinstance(day_open, (int, float)) and day_open > 0.0:
        delta = level - float(day_open)
        pct = (delta / float(day_open)) * 100
        colour = "green" if delta >= 0 else "red"
        change_txt = f" [{colour}]{delta:+.2f} {pct:+.2f}%[/{colour}]"

    ohlc_txt = ""
    if (
        isinstance(day_open, (int, float))
        and isinstance(day_high, (int, float))
        and isinstance(day_low, (int, float))
    ):
        ohlc_txt = (
            f" [dim]O={float(day_open):.2f} H={float(day_high):.2f} "
            f"L={float(day_low):.2f}[/dim]"
        )

    console.print(
        f"[{ts}] [bold cyan]{index_id}[/bold cyan] [bold]{level:.2f}[/bold]"
        f"{change_txt}{ohlc_txt} [dim]{session_state}[/dim]"
    )


def print_index_history(records: list[dict[str, Any]]) -> None:
    """Render structural/audit index records (INIT, CORP_ACTION,
    ADD_CONSTITUENT, DELIST). This is not a level/EOD time series —
    query pm-stats-cli (index-daily / index-snapshots) for that.
    """
    if not records:
        console.print(
            "[dim]No structural index history records returned. "
            "For level/EOD time-series data, use pm-stats-cli instead.[/dim]"
        )
        return

    table = Table(
        title="Index structural history", show_header=True, header_style="bold magenta"
    )
    table.add_column("Type", style="bold")
    table.add_column("Time", style="dim")
    table.add_column("Symbol", style="dim")
    table.add_column("Detail")
    table.add_column("Level", justify="right")

    for rec in records:
        rec_type = str(rec.get("type", "?"))
        # AR-0.3 renamed HistoryRecord.timestamp to ts_ns (epoch nanoseconds);
        # AR-0.3b caught this call site still reading the old key.
        ts = rec.get("ts_ns")
        if isinstance(ts, (int, float)):
            ts_txt = datetime.fromtimestamp(float(ts) / 1_000_000_000).strftime(
                "%Y-%m-%d %H:%M:%S"
            )
        else:
            ts_txt = "?"
        symbol = str(rec.get("symbol", "-")) or "-"
        detail = _describe_structural_record(rec_type, rec)
        level = rec.get("level")
        level_txt = f"{float(level):.2f}" if isinstance(level, (int, float)) else "-"
        table.add_row(rec_type, ts_txt, symbol, detail, level_txt)

    console.print(table)


def _describe_structural_record(rec_type: str, rec: dict[str, Any]) -> str:
    if rec_type == "CORP_ACTION":
        action = rec.get("action", "")
        detail = rec.get("detail", "")
        return f"{action} {detail}".strip() or "-"
    if rec_type == "ADD_CONSTITUENT":
        return f"ref_price={rec.get('reference_price', '?')}"
    if rec_type == "DELIST":
        return "-"
    if rec_type == "INIT":
        constituents = rec.get("constituents", [])
        base = rec.get("base_value", "?")
        return f"base={base} n_constituents={len(constituents)}"
    return "-"


def print_orders(gateway_id: str, order_cache: dict[str, dict[str, Any]]) -> None:
    if not order_cache:
        console.print("[dim]No outstanding orders for this gateway.[/dim]")
        return
    t = Table(title=f"Orders — {gateway_id}", show_lines=True)
    t.add_column("ID", style="dim")
    t.add_column("Symbol", style="bold")
    t.add_column("Side", style="cyan")
    t.add_column("Type", style="magenta")
    t.add_column("TIF", style="dim")
    t.add_column("Qty", justify="right")
    t.add_column("Rem", justify="right")
    t.add_column("Price", justify="right")
    t.add_column("Status", style="bold")
    t.add_column("Time", style="dim")

    status_colour = {
        "NEW": "green",
        "PARTIAL": "yellow",
        "FILLED": "bright_green",
        "CANCELLED": "red",
        "REJECTED": "red",
        "EXPIRED": "dim",
        "PENDING": "dim",
    }

    for o in sorted(order_cache.values(), key=lambda x: x["time"], reverse=True):
        st = o["status"]
        colour = status_colour.get(st, "white")
        t.add_row(
            o["id"],
            o["symbol"],
            o["side"],
            o["type"],
            o["tif"],
            str(o["qty"]),
            str(o["remaining"]),
            format_price(o["price"], o["symbol"]) if o["price"] else "—",
            f"[{colour}]{st}[/{colour}]",
            o["time"],
        )
    console.print(t)
