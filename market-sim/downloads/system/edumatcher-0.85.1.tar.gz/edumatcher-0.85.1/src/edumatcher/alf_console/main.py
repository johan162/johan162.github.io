"""
pm-alf-console — the interactive trader console.

Usage:
  poetry run pm-alf-console --id GW01

Not a gateway: it talks to pm-engine directly over ZeroMQ as participant
``--id``, reads ALF-style commands at a prompt, sends them to the engine and
prints the engine's events for this participant. Exit status: 0 when the user
leaves, 1 when the logon fails or the engine connection is lost.

Commands
--------
  NEW|SYM=AAPL|SIDE=BUY|TYPE=LIMIT|QTY=100|PRICE=150.50|TAG=demo-1
  NEW|SYM=AAPL|SIDE=BUY|TYPE=LIMIT|QTY=100|PRICE=150.50|TIF=GTC
  NEW|SYM=MSFT|SIDE=SELL|TYPE=MARKET|QTY=50
  NEW|SYM=AAPL|SIDE=BUY|TYPE=STOP|QTY=100|STOP=148.00
  NEW|SYM=AAPL|SIDE=BUY|TYPE=STOP_LIMIT|QTY=100|STOP=148.00|PRICE=147.50
  NEW|SYM=AAPL|SIDE=BUY|TYPE=FOK|QTY=100|PRICE=150.00
  NEW|SYM=AAPL|SIDE=BUY|TYPE=IOC|QTY=100|PRICE=150.00
  NEW|SYM=AAPL|SIDE=BUY|TYPE=ICEBERG|QTY=1000|PRICE=150.00|VISIBLE=100
  NEW|SYM=AAPL|SIDE=BUY|TYPE=TRAILING_STOP|QTY=100|TRAIL=0.50
  NEW|TYPE=OCO|OCO_ID=<label>|SYM=AAPL|QTY=100|TIF=DAY|LEG1_SIDE=BUY|LEG1_TYPE=LIMIT|LEG1_PRICE=150.00|LEG2_SIDE=SELL|LEG2_TYPE=STOP|LEG2_STOP=148.00
  NEW|TYPE=COMBO|COMBO_ID=<label>|COMBO_TYPE=AON|TIF=DAY|LEG_COUNT=2|LEG0.SYM=AAPL|LEG0.SIDE=BUY|LEG0.QTY=100|LEG0.PRICE=150.00|LEG1.SYM=MSFT|LEG1.SIDE=SELL|LEG1.QTY=50|LEG1.PRICE=300.00
  AMEND|ID=ORD-xxxx|PRICE=151.00[|RTAG=req-1]
  AMEND|ID=ORD-xxxx|QTY=200[|RTAG=req-2]
  AMEND|ID=ORD-xxxx|PRICE=151.00|QTY=200[|RTAG=req-3]
  CANCEL|ID=ORD-xxxx[|RTAG=req-4]
  CANCEL|COMBO_ID=<label>
  CANCEL|OCO_ID=<label>
  QUOTE|SYM=AAPL|BID=150.00|ASK=150.10|BID_QTY=500|ASK_QTY=500
  QUOTE_CANCEL|SYM=AAPL
  QBOOT[|SYM=AAPL]         — request active quote bootstrap state from engine
  QLEGS[|SYM=AAPL][|SHOW=ACTIVE|RECENT|ALL]  — show MM quote legs
  KILL[|SYM=AAPL]          — kill-switch cancel for this gateway
  DC|STATE=ON              — enable async drop-copy relay for this gateway's own fills
  DC|STATE=OFF             — disable drop-copy relay
  STATUS                   — print gateway/session summary
  ORDERS                   — print table of this session's orders
  POS                      — print current positions with P&L
  POS|GW=<gateway_id>      — query another gateway's (e.g. an MM bot's) position
  SYMBOLS                  — list all active instruments in the engine
  SESSION                  — query the engine's current trading session state
  INDEX                    — show current index level
  INDEX|HISTORY|INDEX=<id>[|FROM=YYYY-MM-DD|TO=YYYY-MM-DD] — query index structural/audit history
                             (corporate actions, constituent changes — not level ticks;
                              use pm-stats-cli for level/EOD history)
  HELP                     — show command reference
  CLEAR                    — clear the screen
  EXIT / QUIT              — disconnect
"""

from __future__ import annotations

import argparse
from collections import OrderedDict, defaultdict, deque
import logging
import math
import threading
import time
from datetime import datetime, timedelta
from typing import Any

import zmq
from zmq.utils.monitor import recv_monitor_message
from prompt_toolkit import PromptSession
from prompt_toolkit.filters import completion_is_selected
from prompt_toolkit.history import InMemoryHistory
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.patch_stdout import patch_stdout as pt_patch_stdout

from edumatcher.config_artifact import exit_on_config_error
from edumatcher.cli_signals import logout_on_hangup
from edumatcher.cli_version import add_version_argument
from edumatcher.config import (
    DROP_COPY_PUB_ADDR,
    ENGINE_PULL_ADDR,
    ENGINE_PUB_ADDR,
    INDEX_PUB_CONNECT_ADDR,
    INDEX_PULL_CONNECT_ADDR,
)
from edumatcher.log_srv.config import (
    load_default_log_client_config,
    load_default_log_server_config,
    resolve_host_default,
)
from edumatcher.logclient.discovery import resolve_handler
from edumatcher.messaging.bus import PushSocket, make_pusher, make_subscriber
from edumatcher.models.envelope import new_ulid
from edumatcher.models.combo import ComboLeg, ComboOrder, ComboType
from edumatcher.models.message import (
    decode,
    decode_sequence,
    make_combo_cancel_msg,
    make_combo_order_msg,
    make_gateway_connect_msg,
    INTERACTIVE_HEARTBEAT_INTERVAL_SEC,
    make_gateway_disconnect_msg,
    make_gateway_heartbeat_msg,
    make_kill_switch_msg,
    make_order_amend_msg,
    make_order_cancel_msg,
    make_order_new_msg,
    make_orders_request_msg,
    make_position_request_msg,
    make_quote_bootstrap_request_msg,
    make_quote_cancel_msg,
    make_quote_new_msg,
    make_session_state_request_msg,
    make_symbols_request_msg,
    make_index_history_request_msg,
    make_oco_order_msg,
    make_oco_cancel_msg,
)
from edumatcher.models.order import (
    Order,
    OrderType,
    Side,
    SmpAction,
    TIF,
)
from edumatcher.models.price import (
    get_tick_decimals,
    register_tick_decimals,
    to_ticks_exact,
)

# Extracted submodules — re-exported here so that existing
# ``from edumatcher.alf_console.main import ...`` imports keep working.
from .completer import GatewayCompleter as GatewayCompleter  # noqa: F401
from .display import _SysStdoutProxy as _SysStdoutProxy  # noqa: F401  # type: ignore
from .display import (
    HELP_TEXT,
    PROMPT_STYLE,
    console,
    format_price,
    is_active_leg_status,
    print_current_index,
    print_index_history,
    print_orders,
    print_positions,
    print_quote_bootstrap,
    print_quote_legs,
    print_remote_position,
    print_session_status,
    print_status,
    print_symbols_table,
)
from edumatcher.models.generated.trade import TOPIC_TRADE_EXECUTED
from edumatcher.models.generated.index import (
    TOPIC_INDEX_UPDATE,
    topic_index_error,
    topic_index_history,
)
from edumatcher.models.generated.drop_copy import topic_drop_copy_event
from edumatcher.models.generated.risk import topic_kill_switch_ack
from edumatcher.models.generated.order import (
    PREFIX_ORDER_ACK,
    PREFIX_ORDER_AMENDED,
    PREFIX_ORDER_CANCELLED,
    PREFIX_ORDER_EXPIRED,
    PREFIX_ORDER_FILL,
    PREFIX_ORDER_TRIGGERED,
    PREFIX_ORDERS,
    topic_order_ack,
    topic_order_amended,
    topic_order_cancelled,
    topic_order_expired,
    topic_order_fill,
    topic_order_triggered,
    topic_orders,
)
from edumatcher.models.generated.structure import (
    topic_combo_ack,
    topic_combo_cancel_ack,
    topic_combo_status,
    topic_oco_ack,
    topic_oco_cancel_ack,
    topic_oco_cancelled,
)
from edumatcher.models.generated.quote import (
    topic_quote_ack,
    topic_quote_cancel_ack,
    topic_quote_status,
)
from edumatcher.models.generated.system import (
    PREFIX_POSITION_SNAPSHOT,
    topic_gateway_auth,
    topic_position_snapshot,
    topic_quote_bootstrap,
    topic_session_status,
    topic_symbols,
)

_DEBUG_SUMMARY_INTERVAL_SEC = 5.0
# Receive buffer of the engine and drop-copy SUB sockets, in messages. The
# engine socket also carries every trade on the exchange; with ZeroMQ's
# default of 1000 a busy market evicted this console's own fills (review C1).
# The same depth as pm-alf-gwy.
_SUB_RCVHWM = 200_000
_CLIENT_NAME = "pm-alf-console"
_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s - %(message)s"

log = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="EduMatcher gateway")
    add_version_argument(parser, "pm-alf-console")
    parser.add_argument(
        "--id",
        required=True,
        metavar="GW_ID",
        help="Unique gateway identifier, e.g. GW01",
    )
    parser.add_argument(
        "--drop-copy",
        action="store_true",
        help="Enable drop-copy relay on startup (equivalent to sending "
        "DC|STATE=ON immediately after connecting). Default: off. Can also "
        "be toggled at runtime with the DC|STATE=ON / DC|STATE=OFF command. "
        "See the Drop copy chapter of the Protocols and Clients book.",
    )
    parser.add_argument(
        "--log-level",
        choices=["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"],
        help="Logging level override (default: WARNING)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase log verbosity (-v: INFO, -vv: DEBUG)",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Explicit WARNING log level (the default)",
    )
    parser.add_argument(
        "--log-target",
        choices=["server", "stdout", "file"],
        default=None,
        help=(
            "Where this process's own operational log records go: "
            "server (default, auto-detected pm-log-srv), stdout, or file"
        ),
    )
    parser.add_argument(
        "--log-file",
        default=None,
        metavar="PATH",
        help="Operational log file path — required when --log-target file",
    )
    parser.add_argument(
        "--log-failover-timeout",
        type=float,
        default=None,
        metavar="SECONDS",
        help=(
            "Grace window before falling back to a local log file once "
            "pm-log-srv becomes unreachable (default: 30, from config)"
        ),
    )
    return parser


def _configure_logging(args: argparse.Namespace) -> int:
    log_level = getattr(args, "log_level", None)
    verbose = getattr(args, "verbose", 0)
    quiet = getattr(args, "quiet", False)

    if log_level:
        level_name = str(log_level).upper()
        level = getattr(logging, level_name, logging.WARNING)
    elif verbose >= 2:
        level = logging.DEBUG
    elif verbose == 1:
        level = logging.INFO
    elif quiet:
        level = logging.WARNING
    else:
        level = logging.WARNING

    client_config = load_default_log_client_config()
    server_config = load_default_log_server_config()
    failover_timeout = getattr(args, "log_failover_timeout", None)
    handler = resolve_handler(
        log_target=getattr(args, "log_target", None),
        log_file=getattr(args, "log_file", None),
        client_name=_CLIENT_NAME,
        instance=None,
        host=resolve_host_default(),
        port=server_config.port,
        connect_timeout_sec=client_config.connect_timeout_sec,
        failover_timeout_sec=(
            failover_timeout
            if failover_timeout is not None
            else client_config.failover_timeout_sec
        ),
        failover_dir=client_config.failover_dir,
    )
    logging.basicConfig(level=level, format=_LOG_FORMAT, handlers=[handler])
    return int(level)


def _to_float(key: str, raw: str) -> float:
    """The price or offset typed as ``KEY=<raw>``.

    The ValueError names the field, so a parse error says which value was
    wrong instead of "could not convert string to float". NaN and infinity
    are refused, and so is a value too large to scale to ticks at the
    finest grid a symbol can have (10**-9).
    """
    try:
        value = float(raw)
    except ValueError:
        raise ValueError(f"{key}= is not a number: {raw!r}") from None
    if not math.isfinite(value * 10**9):
        raise ValueError(f"{key}= must be a finite number: {raw!r}")
    return value


def _to_int(key: str, raw: str) -> int:
    """The whole number typed as ``KEY=<raw>``; the ValueError names the field."""
    try:
        return int(raw)
    except ValueError:
        raise ValueError(f"{key}= is not a whole number: {raw!r}") from None


def _completion_key_bindings() -> KeyBindings:
    """Make Enter accept a highlighted completion instead of submitting.

    prompt_toolkit's default Enter binding does both at once when a
    completion menu is open: it applies the highlighted completion *and*
    accepts the whole line, in the same keypress. For a command line built
    up across several Tab-completions (SYM=, then SIDE=, then TYPE=, ...)
    that means one Enter can fire an order before the line is finished.
    This overrides Enter, while a completion is selected, to only close the
    menu and insert the choice — a second, separate Enter is then needed to
    submit, matching the behaviour of a normal shell completion menu.
    """
    bindings = KeyBindings()

    # pyright can't see that @bindings.add registers this handler by side
    # effect (the KeyBindings registry, not the name _accept_completion_not_line,
    # is what's read afterward) — it's genuinely wired up at runtime, so this
    # is a false positive rather than actually-dead code.
    @bindings.add("enter", filter=completion_is_selected)
    def _accept_completion_not_line(  # pyright: ignore[reportUnusedFunction]
        event: Any,
    ) -> None:
        buf = event.current_buffer
        state = buf.complete_state
        if state is not None and state.current_completion is not None:
            buf.apply_completion(state.current_completion)
        else:
            buf.cancel_completion()

    return bindings


class Gateway:
    def __init__(self, gateway_id: str, drop_copy: bool = False) -> None:
        self.gateway_id = gateway_id.upper()
        self._dc_enabled = False
        self._dc_requested_on_startup = drop_copy
        # POS|GW=<gateway_id>: which other gateway's position was last
        # queried, and the topic of its reply -- set between issuing the
        # request and receiving the matching
        # system.position_snapshot.<gateway_id>. None when no query is
        # outstanding.
        self._pos_query_gateway_id: str | None = None
        self._pos_query_topic: bytes | None = None
        self.order_cache: dict[str, dict[str, Any]] = {}  # order_id → state dict
        self.quote_leg_cache: dict[str, dict[str, Any]] = (
            {}
        )  # order_id → quote leg state
        self._quote_id_by_order_id: dict[str, str] = {}  # order_id → quote_id
        # quote.ack carries no symbol/qty — only quote_id/bid_order_id/
        # ask_order_id — so the submitted symbol, prices and sizes have to be
        # remembered locally and re-attached when the ack arrives. Keyed by the
        # quote_id we send (minted in _send_quote when the operator does not
        # supply QUOTE_ID=), because the engine echoes it on the ack.
        #
        # Bounded: one entry per quote sent, and only the recent ones can still
        # attract an ack, so older entries are evicted in insertion order.
        self._pending_quote_by_id: OrderedDict[str, dict[str, Any]] = OrderedDict()
        self._pending_quote_cap = 64
        # Fallback only, for an ack carrying no id. Send order is weaker: it
        # assumes one ack per quote.new, in order, so a single dropped ack
        # leaves it permanently off by one — and this console *prints* the
        # cached symbol and prices, so a desync shows a human confident,
        # wrong detail.
        self._pending_quote_requests: deque[dict[str, Any]] = deque()
        self._known_symbols: list[str] = []
        # Set by the first system.symbols reply, which registers the tick
        # sizes every typed price is converted with; run() opens the prompt
        # only after it (review H3).
        self._symbols_received = threading.Event()
        self._symbols_timeout_sec = 3.0
        # The reply is printed only when the user typed SYMBOLS.
        self._symbols_requested = False
        self._positions: dict[str, dict[str, Any]] = (
            {}
        )  # symbol → {net_qty, avg_cost, realized_pnl}
        self._last_prices: dict[str, float] = {}  # symbol → last trade price
        self._last_index_update: dict[str, Any] | None = None
        self._default_index_id: str | None = None
        self._running = True
        # Set when the session ends because the engine went away; run()
        # then exits 1 instead of 0.
        self._connection_lost = False
        self._heartbeat_stop = threading.Event()
        self._authenticated: bool = False
        self._prompt_session: PromptSession[str] | None = None

        self.push_sock = make_pusher(ENGINE_PULL_ADDR)
        self._index_push_sock = make_pusher(INDEX_PULL_CONNECT_ADDR)
        engine_topics = (
            topic_order_ack(self.gateway_id),
            topic_order_fill(self.gateway_id),
            topic_order_amended(self.gateway_id),
            topic_order_cancelled(self.gateway_id),
            topic_order_expired(self.gateway_id),
            topic_order_triggered(self.gateway_id),
            topic_orders(self.gateway_id),
            topic_combo_ack(self.gateway_id),
            topic_combo_cancel_ack(self.gateway_id),
            topic_combo_status(self.gateway_id),
            topic_oco_ack(self.gateway_id),
            topic_oco_cancel_ack(self.gateway_id),
            topic_oco_cancelled(self.gateway_id),
            topic_quote_ack(self.gateway_id),
            topic_quote_cancel_ack(self.gateway_id),
            topic_quote_status(self.gateway_id),
            topic_kill_switch_ack(self.gateway_id),
            topic_symbols(self.gateway_id),
            topic_quote_bootstrap(self.gateway_id),
            topic_session_status(self.gateway_id),
            topic_gateway_auth(self.gateway_id),
        )
        index_topics = (
            topic_index_history(self.gateway_id),
            topic_index_error(self.gateway_id),
        )
        # The engine's answer to this console's own position request
        # (_seed_positions); received through the PREFIX_POSITION_SNAPSHOT
        # subscription below.
        self._own_position_topic = topic_position_snapshot(self.gateway_id)
        # A SUBSCRIBE is a byte prefix, so order.fill.GW1 also delivers
        # order.fill.GW10: _handle_event handles a gateway-scoped topic only
        # when it is exactly one of these.
        self._own_topics = frozenset(
            engine_topics + index_topics + (self._own_position_topic,)
        )
        # Last per-topic sequence seen on each own topic (_check_sequence).
        self._topic_seq: dict[str, int] = {}
        # Subscribe to all order events for this gateway, the trade feed for
        # last prices, and every gateway's position snapshot for POS|GW=:
        # subscribed once here because only the listener thread may touch
        # this socket, and so a reply can never overtake its subscription.
        self.sub_sock = make_subscriber(
            ENGINE_PUB_ADDR,
            *engine_topics,
            TOPIC_TRADE_EXECUTED,
            PREFIX_POSITION_SNAPSHOT,
            rcvhwm=_SUB_RCVHWM,
        )
        self._index_sub_sock = make_subscriber(
            INDEX_PUB_CONNECT_ADDR, TOPIC_INDEX_UPDATE, *index_topics
        )
        # Separate SUB socket for the engine's drop-copy feed (:5557),
        # distinct from sub_sock (:5556) -- a different ZMQ PUB address, not
        # just a different topic namespace. The own topic is subscribed for
        # the whole session and shown only while DC is on (_set_drop_copy).
        dc_topic = topic_drop_copy_event(self.gateway_id)
        self._dc_sub_sock = make_subscriber(
            DROP_COPY_PUB_ADDR, dc_topic, rcvhwm=_SUB_RCVHWM
        )
        self._dc_topic = dc_topic.encode()
        self._resync_push_sock: PushSocket | None = None
        self._auth_reason: str = ""
        self._auth_description: str = ""
        self._debug_counts: defaultdict[str, int] = defaultdict(int)
        self._debug_last_summary = time.monotonic()

    def _dbg_count(self, key: str, amount: int = 1) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        self._debug_counts[key] += amount
        self._flush_debug_summary()

    def _flush_debug_summary(self, force: bool = False) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        now = time.monotonic()
        if not force and now - self._debug_last_summary < _DEBUG_SUMMARY_INTERVAL_SEC:
            return
        if not self._debug_counts:
            self._debug_last_summary = now
            return
        summary = ", ".join(
            f"{key}={value}" for key, value in sorted(self._debug_counts.items())
        )
        log.debug("alf_console flow summary: %s", summary)
        self._debug_counts.clear()
        self._debug_last_summary = now

    def _set_drop_copy(self, enabled: bool) -> None:
        """Toggle the drop-copy relay (DC|ON / DC|OFF / --drop-copy).

        Only flips the flag ``_handle_dc_event`` reads: the own
        ``drop_copy.event.<gateway_id>`` topic is subscribed for the whole
        session, because a ZeroMQ socket must not be touched by the prompt
        thread while the listener thread polls it.
        """
        self._dc_enabled = enabled

    def _query_position(self, target_gateway_id: str) -> None:
        """Send POS|GW=<target_gateway_id>: ask the engine what that
        gateway (e.g. a running pm-mm-bot) is holding.

        ``system.position_request`` is a shared, non-gateway-scoped topic
        -- any gateway may ask about any ``gateway_id`` (see
        ``engine/main.py::_handle_position_request``, which looks the id up
        directly with no sender-identity check). The reply comes back on
        ``system.position_snapshot.<target_gateway_id>``; ``sub_sock``
        receives every gateway's snapshot, and the listener shows only the
        one for the outstanding query.

        A second POS|GW= before the first replied replaces the query.
        """
        self._pos_query_gateway_id = target_gateway_id
        self._pos_query_topic = topic_position_snapshot(target_gateway_id).encode()
        self._send(self.push_sock, make_position_request_msg(target_gateway_id))

    def _handle_position_snapshot_reply(
        self, topic: str, payload: dict[str, Any]
    ) -> None:
        """Handle a system.position_snapshot.<gw> reply to POS|GW=.

        Ignores a reply that does not match the currently outstanding query
        (e.g. arriving after a timeout already cleared it, or for a
        gateway_id that isn't the one last asked about) rather than
        clobbering unrelated state.
        """
        if self._pos_query_topic is None or topic.encode() != self._pos_query_topic:
            return
        gateway_id = self._pos_query_gateway_id
        self._pos_query_gateway_id = None
        self._pos_query_topic = None
        assert gateway_id is not None
        print_remote_position(
            gateway_id, payload.get("positions", []), payload.get("status", "OK")
        )

    @staticmethod
    def _topic_family(topic: str) -> str:
        if topic.startswith("order."):
            return "order"
        if topic.startswith("combo."):
            return "combo"
        if topic.startswith("oco."):
            return "oco"
        if topic.startswith("quote."):
            return "quote"
        if topic.startswith("risk."):
            return "risk"
        if topic.startswith("system."):
            return "system"
        if topic.startswith("trade."):
            return "trade"
        if topic.startswith("index."):
            return "index"
        return "other"

    # ------------------------------------------------------------------
    # Quote-leg tracking
    # ------------------------------------------------------------------

    def _upsert_quote_leg(
        self,
        *,
        order_id: str,
        quote_id: str,
        symbol: str,
        leg_side: str,
        quantity: int,
        remaining_qty: int,
        status: str,
        event_time: str,
        price: float | None = None,
        quote_status: str = "",
    ) -> None:
        existing = self.quote_leg_cache.get(order_id, {})
        filled_qty = max(0, quantity - remaining_qty)
        self.quote_leg_cache[order_id] = {
            "order_id": order_id,
            "quote_id": quote_id,
            "symbol": symbol,
            "leg_side": leg_side,
            "price": price if price is not None else existing.get("price"),
            "qty": quantity,
            "remaining": remaining_qty,
            "filled": filled_qty,
            "status": status,
            "quote_status": quote_status or str(existing.get("quote_status", "")),
            "last_event_time": event_time,
        }
        self._quote_id_by_order_id[order_id] = quote_id

    def _mark_quote_status(
        self, quote_id: str, quote_status: str, event_time: str
    ) -> None:
        for row in self.quote_leg_cache.values():
            if row.get("quote_id") != quote_id:
                continue
            row["quote_status"] = quote_status
            row["last_event_time"] = event_time
            if quote_status == "CANCELLED" and is_active_leg_status(
                str(row.get("status", ""))
            ):
                row["status"] = "CANCELLED"
                row["remaining"] = 0

    def _record_fill_for_quote_leg(
        self,
        *,
        order_id: str,
        fill_qty: int,
        remaining_qty: int,
        status: str,
        symbol: str,
        side: str,
        qty: int | None,
        event_time: str,
        price: float | None = None,
    ) -> None:
        if order_id not in self._quote_id_by_order_id:
            return

        if order_id in self.quote_leg_cache:
            row = self.quote_leg_cache[order_id]
            row["remaining"] = remaining_qty
            row["status"] = status
            row["filled"] = int(row.get("filled", 0)) + fill_qty
            if qty is not None and int(row.get("qty", 0)) <= 0:
                row["qty"] = qty
            if price is not None and not row.get("price"):
                row["price"] = price
            row["last_event_time"] = event_time
            return

        quote_id = self._quote_id_by_order_id.get(order_id, "?")
        base_qty = qty if qty is not None else fill_qty + max(0, remaining_qty)
        self._upsert_quote_leg(
            order_id=order_id,
            quote_id=quote_id,
            symbol=symbol,
            leg_side=side,
            quantity=base_qty,
            remaining_qty=remaining_qty,
            status=status,
            event_time=event_time,
            price=price,
        )
        self.quote_leg_cache[order_id]["filled"] = fill_qty

    def _authenticate(self, timeout_sec: float = 3.0) -> bool:
        # Give sockets time to connect and SUB filters to propagate.
        log.info("starting gateway authentication gateway_id=%s", self.gateway_id)
        time.sleep(0.1)
        # push_sock is IMMEDIATE + non-blocking (see make_pusher): a ZMQ
        # connect() is asynchronous, and this send can fire before the
        # ZMTP handshake with the engine has completed, raising Again. The
        # fixed sleep above covers same-host loopback but not a host that
        # reaches the engine over a slower hop (e.g. connecting into a
        # container from outside it), so retry a few times rather than
        # failing on the first race.
        connect_msg = make_gateway_connect_msg(self.gateway_id)
        handshake_deadline = time.monotonic() + timeout_sec
        while True:
            try:
                self.push_sock.send_multipart(connect_msg)
                break
            except zmq.Again:
                if time.monotonic() >= handshake_deadline:
                    log.error(
                        "gateway authentication failed to reach engine "
                        "gateway_id=%s (connection not established)",
                        self.gateway_id,
                    )
                    self._auth_reason = (
                        f"Engine not reachable at {ENGINE_PULL_ADDR} "
                        "(is pm-engine running?)"
                    )
                    return False
                time.sleep(0.1)

        poller = zmq.Poller()
        poller.register(self.sub_sock, zmq.POLLIN)
        deadline = time.monotonic() + timeout_sec
        while time.monotonic() < deadline:
            remaining_ms = max(1, int((deadline - time.monotonic()) * 1000))
            socks = dict(poller.poll(timeout=min(remaining_ms, 200)))
            if self.sub_sock not in socks:
                continue
            frames = self.sub_sock.recv_multipart()
            topic, payload = decode(frames)
            if topic == topic_gateway_auth(self.gateway_id):
                accepted = bool(payload.get("accepted", False))
                self._auth_reason = str(payload.get("reason", ""))
                self._auth_description = str(payload.get("description", ""))
                if accepted:
                    log.info(
                        "gateway authentication accepted gateway_id=%s", self.gateway_id
                    )
                else:
                    log.warning(
                        "gateway authentication rejected gateway_id=%s reason=%s",
                        self.gateway_id,
                        self._auth_reason,
                    )
                return accepted
            # Ignore unrelated early messages during handshake window.
        self._auth_reason = "Gateway authentication timed out"
        log.warning("gateway authentication timed out gateway_id=%s", self.gateway_id)
        return False

    def _heartbeat_loop(self) -> None:
        """Tell the engine this console is alive, so a killed console frees its
        ID instead of locking it. Own socket: a ZMQ socket must not be shared
        across threads, and push_sock belongs to the prompt thread."""
        push_sock = make_pusher(ENGINE_PULL_ADDR)
        try:
            handshake_deadline = time.monotonic() + 3.0
            while True:
                try:
                    push_sock.send_multipart(
                        make_gateway_heartbeat_msg(
                            self.gateway_id, INTERACTIVE_HEARTBEAT_INTERVAL_SEC
                        )
                    )
                    break
                except zmq.Again:
                    if time.monotonic() >= handshake_deadline:
                        self._engine_connection_lost()
                        return
                    if self._heartbeat_stop.wait(0.1):
                        return

            while True:
                if self._heartbeat_stop.wait(INTERACTIVE_HEARTBEAT_INTERVAL_SEC):
                    return
                try:
                    push_sock.send_multipart(
                        make_gateway_heartbeat_msg(
                            self.gateway_id, INTERACTIVE_HEARTBEAT_INTERVAL_SEC
                        )
                    )
                except zmq.Again:
                    log.debug(
                        "gateway_id=%s heartbeat dropped: engine unreachable",
                        self.gateway_id,
                    )
                    self._engine_connection_lost()
                    return
                log.debug("engine heartbeat sent gateway_id=%s", self.gateway_id)
        finally:
            push_sock.close()

    def _engine_connection_lost(self) -> None:
        if not self._running:
            return
        self._running = False
        self._connection_lost = True
        log.error("engine connection lost gateway_id=%s", self.gateway_id)
        console.print("[red]Engine connection was lost; logging out.[/red]")
        self._exit_prompt()

    def _request_exit(self) -> None:
        """SIGHUP or SIGTERM: leave the prompt loop as EXIT does, so the
        session logs out instead of the process just ending."""
        log.info("terminal closed or terminated gateway_id=%s", self.gateway_id)
        self._running = False
        self._exit_prompt()

    def _exit_prompt(self) -> None:
        """End a prompt that is waiting for input; safe from any thread."""
        session = self._prompt_session
        if session is None:
            return
        app = session.app
        loop = app.loop
        if loop is not None and loop.is_running():

            def _exit_prompt() -> None:
                if app.is_running:
                    app.exit(exception=KeyboardInterrupt)

            loop.call_soon_threadsafe(_exit_prompt)

    def _send(self, sock: PushSocket, frames: list[bytes]) -> bool:
        """Send on a PUSH socket, reporting a clean error instead of
        crashing the console. An unavailable engine ends this session.

        Every PUSH socket from ``make_pusher()`` is IMMEDIATE + non-
        blocking (see ``bus.py``), so a send raises ``zmq.Again`` whenever
        the peer connection isn't currently established — e.g. the engine
        restarted or the network dropped mid-session. The command cannot be
        retried safely after the session is lost, so log out.
        Returns True on success, False if the send was dropped.
        """
        try:
            sock.send_multipart(frames)
            return True
        except zmq.Again:
            log.debug("gateway_id=%s send dropped: engine unreachable", self.gateway_id)
            self._engine_connection_lost()
            return False

    # ------------------------------------------------------------------
    # Background SUB listener
    # ------------------------------------------------------------------

    def _check_sequence(self, topic: str, frames: list[bytes]) -> None:
        """Report own events the engine's PUB dropped, and re-sync.

        Every message from ``make_publisher`` carries a per-topic sequence;
        a jump on one of this gateway's own topics means fills, acks or
        cancels were lost at a high-water mark. The user is told, and the
        console asks the engine for its resting orders and position again.
        """
        if topic not in self._own_topics:
            return
        seq = decode_sequence(frames)
        if seq is None:
            return
        last = self._topic_seq.get(topic)
        self._topic_seq[topic] = seq
        # First sight of the topic, or a lower number: the engine restarted.
        if last is None or seq <= last + 1:
            return
        missed = seq - last - 1
        family = topic.rpartition(".")[0]
        log.warning(
            "engine events lost gateway_id=%s topic=%s count=%d",
            self.gateway_id,
            topic,
            missed,
        )
        console.print(
            f"[bold red]WARNING: {missed} event(s) lost on {family} "
            f"— ORDERS and POS re-synced from the engine[/bold red]"
        )
        if self._resync_push_sock is not None:
            self._send(self._resync_push_sock, make_orders_request_msg(self.gateway_id))
            self._send(
                self._resync_push_sock, make_position_request_msg(self.gateway_id)
            )

    def _listen(self) -> None:
        # The listener's own PUSH socket for re-sync requests: push_sock
        # belongs to the prompt thread.
        self._resync_push_sock = make_pusher(ENGINE_PULL_ADDR)
        monitor_sock = self.sub_sock.get_monitor_socket(events=zmq.EVENT_DISCONNECTED)
        poller = zmq.Poller()
        poller.register(self.sub_sock, zmq.POLLIN)
        poller.register(self._index_sub_sock, zmq.POLLIN)
        poller.register(self._dc_sub_sock, zmq.POLLIN)
        poller.register(monitor_sock, zmq.POLLIN)
        log.info("gateway listeners started gateway_id=%s", self.gateway_id)
        while self._running:
            try:
                socks = dict(poller.poll(timeout=200))
            except zmq.ZMQError:
                log.warning("listener poll interrupted gateway_id=%s", self.gateway_id)
                break
            if monitor_sock in socks:
                event = recv_monitor_message(monitor_sock)
                if event["event"] == zmq.EVENT_DISCONNECTED:
                    self._engine_connection_lost()
                    break
            if self.sub_sock in socks:
                try:
                    frames = self.sub_sock.recv_multipart()
                    topic, payload = decode(frames)
                    self._dbg_count("events_main_socket")
                    self._check_sequence(topic, frames)
                    self._handle_event(topic, payload)
                except Exception as exc:
                    if self._running:
                        self._dbg_count("listener_errors")
                        log.warning(
                            "listener error gateway_id=%s: %s", self.gateway_id, exc
                        )
                        console.print(f"[dim][WARN] listener error: {exc}[/dim]")
            if self._index_sub_sock in socks:
                try:
                    frames = self._index_sub_sock.recv_multipart()
                    topic, payload = decode(frames)
                    self._dbg_count("events_index_socket")
                    self._handle_event(topic, payload)
                except Exception as exc:
                    if self._running:
                        self._dbg_count("index_listener_errors")
                        log.warning(
                            "index listener error gateway_id=%s: %s",
                            self.gateway_id,
                            exc,
                        )
                        console.print(f"[dim][WARN] index listener error: {exc}[/dim]")
            if self._dc_sub_sock in socks:
                try:
                    frames = self._dc_sub_sock.recv_multipart()
                    topic, payload = decode(frames)
                    self._dbg_count("events_dc_socket")
                    self._handle_dc_event(topic, payload)
                except Exception as exc:
                    if self._running:
                        self._dbg_count("dc_listener_errors")
                        log.warning(
                            "drop-copy listener error gateway_id=%s: %s",
                            self.gateway_id,
                            exc,
                        )
                        console.print(
                            f"[dim][WARN] drop-copy listener error: {exc}[/dim]"
                        )
        # Detach the monitor before closing its reading end. libzmq's I/O
        # thread sends monitor events with a *blocking* send: left attached,
        # the next disconnect on sub_sock blocks that thread forever on a
        # pipe nobody reads, and with it every socket of the shared context.
        try:
            self.sub_sock.disable_monitor()
        except zmq.ZMQError:
            pass  # sub_sock already closed
        monitor_sock.close(linger=0)
        self._resync_push_sock.close(linger=0)
        self._resync_push_sock = None
        self._flush_debug_summary(force=True)
        log.info("gateway listeners stopped gateway_id=%s", self.gateway_id)

    def _handle_dc_event(self, topic: str, payload: dict[str, Any]) -> None:
        """Render one drop-copy event received on the :5557 relay.

        Shown only while DC is enabled -- see ``_set_drop_copy``. Printed as a
        ``DC_FILL``-style line for consistency with the wire message
        pm-alf-gwy sends its own TCP clients for the same event (see
        ../../../docs/books/protocols-and-clients/part-5-message-reference/010-message-reference.md).
        """
        # SUBSCRIBE matches by prefix: GW1 also receives GW10's events, which
        # are another gateway's fills with their own seq stream.
        if not self._dc_enabled or topic.encode() != self._dc_topic:
            return
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        seq = payload.get("seq", "?")
        symbol = payload.get("symbol", "?")
        qty = payload.get("fill_qty", "?")
        price = payload.get("fill_price", "?")
        price = format_price(price, str(symbol), missing=str(price))
        liquidity = payload.get("liquidity_flag", "?")
        order_id = str(payload.get("order_id", "?"))
        console.print(
            f"[{ts}] [bold cyan]DC_FILL[/bold cyan]   {order_id}  {symbol}  "
            f"qty={qty} @{price}  [{liquidity}]  #{seq}  [dim]({topic})[/dim]"
        )

    def _handle_event(self, topic: str, payload: dict[str, Any]) -> None:
        if (
            topic not in self._own_topics
            and topic not in (TOPIC_TRADE_EXECUTED, TOPIC_INDEX_UPDATE)
            and topic.encode() != self._pos_query_topic
        ):
            # Another gateway's event that shares this one's id as a prefix.
            return
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        oid = payload.get("order_id", "?")
        self._dbg_count("events_total")
        self._dbg_count(f"topic_family_{self._topic_family(topic)}")

        if PREFIX_ORDER_ACK in topic:
            if payload.get("accepted"):
                console.print(f"[{ts}] [green]ACK[/green]       {oid}  order accepted")
                log.debug("order ack order_id=%s accepted=True", oid)
                # Register in cache
                full_id = payload.get("order_id", "?")
                if full_id in self.order_cache:
                    self.order_cache[full_id]["status"] = "NEW"
                elif payload.get("symbol") and not payload.get("quote_id"):
                    # A child of a combo or OCO: this gateway sent the parent
                    # and learns of the child orders only from their acks.
                    self.order_cache[full_id] = {
                        "id": full_id,
                        "symbol": payload.get("symbol"),
                        "side": payload.get("side", "?"),
                        "type": payload.get("order_type", "?"),
                        "tif": payload.get("tif", "?"),
                        "qty": payload.get("qty", 0),
                        "remaining": payload.get("qty", 0),
                        "price": payload.get("price"),
                        "stop_price": payload.get("stop_price"),
                        "status": "NEW",
                        "client_tag": payload.get("client_tag"),
                        "time": ts[:8],
                    }
            else:
                reason = payload.get("reason", "")
                code = payload.get("reject_code")
                code_text = f" code={code}" if code else ""
                rtag = payload.get("request_tag")
                rtag_text = f" rtag={rtag}" if rtag else ""
                console.print(
                    f"[{ts}] [red]REJECTED[/red]  {oid}{code_text}{rtag_text}  {reason}"
                )
                log.debug(
                    "order rejected order_id=%s code=%s reason=%s", oid, code, reason
                )
                # Only a refused submission rejects the order. A refused AMEND
                # or CANCEL leaves the resting order exactly as it was.
                full_id = payload.get("order_id", "?")
                cached = self.order_cache.get(full_id)
                if cached is not None and cached.get("status") == "PENDING":
                    cached["status"] = "REJECTED"

        elif PREFIX_ORDER_FILL in topic:
            qty = payload.get("fill_qty")
            price = payload.get("fill_price")
            rem = payload.get("remaining_qty")
            status = payload.get("status")
            order_price = payload.get(
                "price"
            )  # resting leg's own limit price, not fill_price
            fill_symbol = str(payload.get("symbol") or "")
            console.print(
                f"[{ts}] [cyan]FILL[/cyan]      {oid}  qty={qty} "
                f"@{format_price(price, fill_symbol, missing=str(price))}  "
                f"remaining={rem}  [{status}]"
            )
            log.debug(
                "order fill order_id=%s qty=%s price=%s remaining=%s status=%s",
                oid,
                qty,
                price,
                rem,
                status,
            )
            full_id = payload.get("order_id", "?")
            if full_id in self.order_cache:
                self.order_cache[full_id]["status"] = status
                self.order_cache[full_id]["remaining"] = rem
            # Update position tracker
            symbol = payload.get("symbol")
            side = payload.get("side")
            if symbol and side and qty and price:
                self._update_position(symbol, side, qty, price)

            if (
                isinstance(qty, int)
                and isinstance(rem, int)
                and isinstance(status, str)
                and isinstance(symbol, str)
                and isinstance(side, str)
            ):
                qty_total = payload.get("qty")
                self._record_fill_for_quote_leg(
                    order_id=payload.get("order_id", "?"),
                    fill_qty=qty,
                    remaining_qty=rem,
                    status=status,
                    symbol=symbol,
                    side=side,
                    qty=qty_total if isinstance(qty_total, int) else None,
                    event_time=ts,
                    price=(
                        order_price if isinstance(order_price, (int, float)) else None
                    ),
                )

        elif PREFIX_ORDER_CANCELLED in topic:
            rtag = payload.get("request_tag")
            rtag_text = f" rtag={rtag}" if rtag else ""
            reason = payload.get("cancel_reason")
            reason_text = f" reason={reason}" if reason else ""
            console.print(
                f"[{ts}] [yellow]CANCELLED[/yellow] {oid}{rtag_text}{reason_text}"
            )
            log.debug("order cancelled order_id=%s reason=%s", oid, reason)
            full_id = payload.get("order_id", "?")
            if full_id in self.order_cache:
                self.order_cache[full_id]["status"] = "CANCELLED"
            if full_id in self.quote_leg_cache:
                self.quote_leg_cache[full_id]["status"] = "CANCELLED"
                self.quote_leg_cache[full_id]["remaining"] = 0
                self.quote_leg_cache[full_id]["last_event_time"] = ts

        elif PREFIX_ORDER_AMENDED in topic:
            new_price = payload.get("price")
            new_qty = payload.get("qty")
            rem = payload.get("remaining_qty")
            prio = (
                " [dim](priority reset)[/dim]" if payload.get("priority_reset") else ""
            )
            amend_symbol = str(
                payload.get("symbol")
                or self.order_cache.get(str(oid), {}).get("symbol")
                or ""
            )
            console.print(
                f"[{ts}] [magenta]AMENDED[/magenta]   {oid}  "
                f"price={format_price(new_price, amend_symbol, missing=str(new_price))}"
                f" qty={new_qty} remaining={rem}{prio}"
                f"{f' rtag={payload.get('request_tag')}' if payload.get('request_tag') else ''}"
            )
            log.debug(
                "order amended order_id=%s price=%s qty=%s remaining=%s priority_reset=%s",
                oid,
                new_price,
                new_qty,
                rem,
                payload.get("priority_reset"),
            )
            full_id = payload.get("order_id", "?")
            if full_id in self.order_cache:
                if new_price is not None:
                    self.order_cache[full_id]["price"] = new_price
                if new_qty is not None:
                    self.order_cache[full_id]["qty"] = new_qty
                if rem is not None:
                    self.order_cache[full_id]["remaining"] = rem

        elif PREFIX_ORDER_TRIGGERED in topic:
            full_id = str(payload.get("order_id", "?"))
            symbol = str(payload.get("symbol", ""))
            decimals = payload.get("tick_decimals")
            if not isinstance(decimals, int):
                decimals = get_tick_decimals(symbol)
            becomes = str(payload.get("becomes", "?"))
            stop_ticks = payload.get("stop_price_ticks")
            stop_text = (
                f"{stop_ticks / 10**decimals:.{decimals}f}"
                if isinstance(stop_ticks, int)
                else "?"
            )
            console.print(
                f"[{ts}] [yellow]TRIGGERED[/yellow] {full_id}  @{stop_text}  "
                f"→ {becomes}"
            )
            # A STOP_LIMIT now rests as a LIMIT; a STOP or TRAILING_STOP
            # is now a MARKET order.
            if full_id in self.order_cache:
                self.order_cache[full_id]["type"] = becomes

        elif PREFIX_ORDER_EXPIRED in topic:
            full_id = str(payload.get("order_id", "?"))
            reason = payload.get("reason")
            if not isinstance(reason, str) or not reason:
                cached = self.order_cache.get(full_id, {})
                cached_tif = cached.get("tif")
                reason = {
                    "ATO": "Opening auction ended",
                    "ATC": "Closing auction ended",
                    "DAY": "Trading day ended",
                }.get(
                    cached_tif if isinstance(cached_tif, str) else "", "Order expired"
                )
            console.print(f"[{ts}] [dim]EXPIRED[/dim]   {oid}  ({reason})")
            log.debug("order expired order_id=%s", oid)
            if full_id in self.order_cache:
                self.order_cache[full_id]["status"] = "EXPIRED"

        elif "system.symbols" in topic:
            entries = payload.get("symbols", [])
            symbols = [str(e.get("symbol", "")) for e in entries]
            for entry in entries:
                tick_decimals = entry.get("tick_decimals")
                if isinstance(tick_decimals, int):
                    register_tick_decimals(str(entry.get("symbol", "")), tick_decimals)
            self._symbols_received.set()
            # Update completer's known symbols list
            self._known_symbols.clear()
            self._known_symbols.extend(symbols)
            if not self._symbols_requested:
                return
            self._symbols_requested = False
            if symbols:
                print_symbols_table(entries)
            else:
                console.print(
                    "[dim]No active instruments yet — submit an order to create a book.[/dim]"
                )

        elif "system.session_status" in topic:
            state = str(payload.get("state", "?"))
            sessions_enabled = bool(payload.get("sessions_enabled", True))
            print_session_status(state, sessions_enabled)

        elif "system.quote_bootstrap" in topic:
            quotes = payload.get("quotes", [])
            if isinstance(quotes, list):
                print_quote_bootstrap(self.gateway_id, quotes)
            else:
                console.print("[red]Malformed quote bootstrap response.[/red]")

        elif topic.startswith(PREFIX_ORDERS):
            orders = payload.get("orders", [])
            # The reply lists every resting order. A cached NEW/PARTIAL order
            # missing from it ended while its last event was lost
            # (_check_sequence); how it ended is not known.
            resting = {str(od.get("id") or "") for od in orders}
            for cached_id, cached in list(self.order_cache.items()):
                if cached_id not in resting and cached.get("status") in (
                    "NEW",
                    "PARTIAL",
                ):
                    cached["status"] = "CLOSED"
            for od in orders:
                oid = str(od.get("id") or "")
                if not oid:
                    continue
                # AR-0.3b: order.orders' OrderDisplay carries ts_ns (epoch
                # nanoseconds) now, not a "timestamp" float in seconds.
                raw_ts_ns = od.get("ts_ns") or 0
                try:
                    ts_str = datetime.fromtimestamp(
                        float(raw_ts_ns) / 1_000_000_000
                    ).strftime("%H:%M:%S")
                except ValueError, OSError:
                    ts_str = "?"
                if oid in self.order_cache:
                    # Sync mutable fields from the engine's authoritative snapshot
                    self.order_cache[oid].update(
                        {
                            "qty": od.get(
                                "quantity", self.order_cache[oid].get("qty", 0)
                            ),
                            "remaining": od.get(
                                "remaining_qty",
                                self.order_cache[oid].get("remaining", 0),
                            ),
                            "price": od.get(
                                "price", self.order_cache[oid].get("price")
                            ),
                            "status": od.get(
                                "status", self.order_cache[oid].get("status", "?")
                            ),
                        }
                    )
                else:
                    self.order_cache[oid] = {
                        "id": oid,
                        "symbol": od.get("symbol", "?"),
                        "side": od.get("side", "?"),
                        "type": od.get("order_type", "?"),
                        "tif": od.get("tif", "?"),
                        "qty": od.get("quantity", 0),
                        "remaining": od.get("remaining_qty", 0),
                        "price": od.get("price"),
                        "status": od.get("status", "?"),
                        "time": ts_str,
                    }

                if od.get("origin") == "QUOTE":
                    quote_id = str(od.get("quote_id") or "?")
                    symbol = str(od.get("symbol") or "?")
                    leg_side = str(od.get("side") or "?")
                    quantity = int(od.get("quantity") or 0)
                    remaining = int(od.get("remaining_qty") or 0)
                    status = str(od.get("status") or "NEW")
                    leg_price = od.get("price")
                    self._upsert_quote_leg(
                        order_id=oid,
                        quote_id=quote_id,
                        symbol=symbol,
                        leg_side=leg_side,
                        quantity=quantity,
                        remaining_qty=remaining,
                        status=status,
                        event_time=ts,
                        price=(
                            leg_price if isinstance(leg_price, (int, float)) else None
                        ),
                    )

        elif ".cancel_ack." in topic:
            # The outcome of one OCO/combo/quote cancel (WP-API17).
            kind = topic.split(".", 1)[0].upper()
            target = (
                payload.get("oco_id")
                or payload.get("combo_id")
                or payload.get("symbol")
                or "?"
            )
            if payload.get("accepted"):
                legs = len(payload.get("cancelled_order_ids") or [])
                console.print(
                    f"[{ts}] [yellow]{kind} CXL OK[/yellow] {target}  legs cancelled={legs}"
                )
            else:
                reason = payload.get("reason", "")
                code = payload.get("reject_code", "")
                console.print(
                    f"[{ts}] [red]{kind} CXL REJ[/red] {target}  {code} {reason}"
                )

        elif "combo.ack" in topic:
            cid = payload.get("combo_id", "?")
            if payload.get("accepted"):
                console.print(f"[{ts}] [green]COMBO ACK[/green]  {cid}  combo accepted")
            else:
                reason = payload.get("reason", "")
                console.print(f"[{ts}] [red]COMBO REJ[/red]  {cid}  {reason}")

        elif "combo.status" in topic:
            cid = payload.get("combo_id", "?")
            status = payload.get("status", "?")
            reason = payload.get("reason", "")
            colour_map = {
                "MATCHED": "bright_green",
                "PARTIALLY_MATCHED": "yellow",
                "FAILED": "red",
                "CANCELLED": "red",
            }
            colour = colour_map.get(status, "white")
            msg = f"[{ts}] [{colour}]COMBO {status}[/{colour}]  {cid}"
            if reason:
                msg += f"  {reason}"
            console.print(msg)

        elif "oco.ack" in topic:
            oco_id = payload.get("oco_id", "?")
            if payload.get("accepted"):
                id1 = payload.get("order_id_1", "")
                id2 = payload.get("order_id_2", "")
                console.print(
                    f"[{ts}] [green]OCO ACK[/green]    {oco_id}  legs={id1}/{id2}"
                )
            else:
                reason = payload.get("reason", "")
                console.print(f"[{ts}] [red]OCO REJ[/red]    {oco_id}  {reason}")

        elif "oco.cancelled" in topic:
            oco_id = payload.get("oco_id", "?")
            sibling = payload.get("cancelled_order_id", "?")
            reason = payload.get("reason", "")
            console.print(
                f"[{ts}] [yellow]OCO CANCEL[/yellow] {oco_id}  sibling={sibling}  {reason}"
            )
            if sibling in self.order_cache:
                self.order_cache[sibling]["status"] = "CANCELLED"

        elif "quote.ack" in topic:
            quote_id = payload.get("quote_id", "?")
            pending_req = self._pending_quote_by_id.pop(str(quote_id), None)
            if pending_req is not None:
                # Keep the fallback queue aligned so a later ack with no id
                # is not paired against an entry already consumed here.
                try:
                    self._pending_quote_requests.remove(pending_req)
                except ValueError:
                    pass
            else:
                self._dbg_count("quote_ack_unmatched_id")
                pending_req = (
                    self._pending_quote_requests.popleft()
                    if self._pending_quote_requests
                    else {}
                )
            if payload.get("accepted"):
                bid_id = payload.get("bid_order_id", "")
                ask_id = payload.get("ask_order_id", "")
                console.print(
                    f"[{ts}] [green]QUOTE ACK[/green]  {quote_id}  bid={bid_id} ask={ask_id}"
                )

                req_symbol = str(pending_req.get("symbol", "?"))
                bid_qty = int(pending_req.get("bid_qty", 0))
                ask_qty = int(pending_req.get("ask_qty", 0))
                req_bid_price = pending_req.get("bid_px")
                req_ask_price = pending_req.get("ask_px")

                full_bid = payload.get("bid_order_id", "")
                full_ask = payload.get("ask_order_id", "")
                if isinstance(full_bid, str) and full_bid:
                    self._quote_id_by_order_id[full_bid] = str(quote_id)
                    if full_bid in self.quote_leg_cache:
                        self.quote_leg_cache[full_bid]["quote_id"] = str(quote_id)
                        self.quote_leg_cache[full_bid]["leg_side"] = "BUY"
                    else:
                        self._upsert_quote_leg(
                            order_id=full_bid,
                            quote_id=str(quote_id),
                            symbol=req_symbol,
                            leg_side="BUY",
                            quantity=bid_qty,
                            remaining_qty=bid_qty,
                            status="NEW",
                            event_time=ts,
                            price=req_bid_price,
                        )

                if isinstance(full_ask, str) and full_ask:
                    self._quote_id_by_order_id[full_ask] = str(quote_id)
                    if full_ask in self.quote_leg_cache:
                        self.quote_leg_cache[full_ask]["quote_id"] = str(quote_id)
                        self.quote_leg_cache[full_ask]["leg_side"] = "SELL"
                    else:
                        self._upsert_quote_leg(
                            order_id=full_ask,
                            quote_id=str(quote_id),
                            symbol=req_symbol,
                            leg_side="SELL",
                            quantity=ask_qty,
                            remaining_qty=ask_qty,
                            status="NEW",
                            event_time=ts,
                            price=req_ask_price,
                        )
            else:
                console.print(
                    f"[{ts}] [red]QUOTE REJ[/red]  {quote_id}  {payload.get('reason', '')}"
                )

        elif "quote.status" in topic:
            quote_id = payload.get("quote_id", "?")
            status = payload.get("status", "?")
            reason = payload.get("reason", "")
            msg = f"[{ts}] [cyan]QUOTE {status}[/cyan]  {quote_id}"
            if reason:
                msg += f"  {reason}"
            console.print(msg)
            self._mark_quote_status(str(quote_id), str(status), ts)

        elif "risk.kill_switch_ack" in topic:
            if payload.get("accepted"):
                console.print(
                    f"[{ts}] [yellow]KILL ACK[/yellow]  orders={payload.get('cancelled_orders', 0)} "
                    f"quote_legs={payload.get('cancelled_quotes', 0)}"
                )
            else:
                console.print(
                    f"[{ts}] [red]KILL REJ[/red]  {payload.get('reason', '')}"
                )

        elif TOPIC_TRADE_EXECUTED in topic:
            # Track last price per symbol for unrealized P&L
            symbol = payload.get("symbol")
            price = payload.get("price")
            if symbol and price:
                self._last_prices[symbol] = price

        elif topic == TOPIC_INDEX_UPDATE:
            self._last_index_update = payload
            index_id = payload.get("index_id")
            if isinstance(index_id, str) and index_id:
                self._default_index_id = index_id.upper()

        elif topic == topic_index_history(self.gateway_id):
            records = payload.get("records", [])
            if isinstance(records, list):
                print_index_history(records)
            else:
                console.print("[red]Malformed index history response.[/red]")

        elif topic == topic_index_error(self.gateway_id):
            reason = payload.get("reason", "")
            console.print(f"[{ts}] [red]INDEX ERROR[/red] {reason}")

        elif (
            self._pos_query_topic is not None
            and topic.encode() == self._pos_query_topic
        ):
            self._handle_position_snapshot_reply(topic, payload)

        elif topic == self._own_position_topic:
            self._seed_positions(payload.get("positions", []))

    # ------------------------------------------------------------------
    # Position tracking
    # ------------------------------------------------------------------

    def _seed_positions(self, positions: list[dict[str, Any]]) -> None:
        """Take net quantity and average cost from the engine's snapshot.

        Asked for at connect and after lost events, so POS shows what the
        engine holds rather than only the fills this process has seen. A
        symbol the snapshot leaves out is flat. Realised P&L is this
        session's own: the engine does not report it.
        """
        held = {str(p.get("symbol", "")): p for p in positions}
        for symbol in held.keys() | self._positions.keys():
            pos = self._positions.setdefault(
                symbol, {"net_qty": 0, "avg_cost": 0.0, "realized_pnl": 0.0}
            )
            engine = held.get(symbol, {})
            pos["net_qty"] = int(engine.get("net_qty", 0))
            pos["avg_cost"] = float(engine.get("avg_cost", 0.0))

    def _update_position(
        self, symbol: str, side: str, fill_qty: int, fill_price: float
    ) -> None:
        """Update position after a fill. Uses average cost accounting."""
        pos = self._positions.setdefault(
            symbol, {"net_qty": 0, "avg_cost": 0.0, "realized_pnl": 0.0}
        )
        signed_qty = fill_qty if side == "BUY" else -fill_qty
        old_qty = pos["net_qty"]
        new_qty = old_qty + signed_qty

        # Realize P&L when reducing or flipping position
        if old_qty != 0 and (
            (old_qty > 0 and signed_qty < 0) or (old_qty < 0 and signed_qty > 0)
        ):
            close_qty = min(abs(signed_qty), abs(old_qty))
            pnl_per_unit = (
                (fill_price - pos["avg_cost"])
                if old_qty > 0
                else (pos["avg_cost"] - fill_price)
            )
            pos["realized_pnl"] += pnl_per_unit * close_qty

        # Update average cost
        if new_qty == 0:
            pos["avg_cost"] = 0.0
        elif (old_qty >= 0 and signed_qty > 0) or (old_qty <= 0 and signed_qty < 0):
            # Adding to position — weighted average
            total_cost = pos["avg_cost"] * abs(old_qty) + fill_price * abs(signed_qty)
            pos["avg_cost"] = total_cost / abs(new_qty)
        elif abs(new_qty) > abs(old_qty):
            # Flipped through zero — new avg cost is the fill price
            pos["avg_cost"] = fill_price

        pos["net_qty"] = new_qty

    # ------------------------------------------------------------------
    # Command parser
    # ------------------------------------------------------------------

    def _parse_and_send(self, line: str) -> None:
        parts = line.strip().split("|")
        cmd = parts[0].upper()
        self._dbg_count("commands_total")
        self._dbg_count(f"command_{cmd.lower()}")

        if cmd == "HELP":
            console.print(HELP_TEXT)
            return

        if cmd == "CLEAR":
            # Same effect as the shell's `clear`: wipe the screen and put the
            # cursor back at the top, so the next prompt starts on a blank
            # terminal instead of scrolling below whatever was there before.
            console.clear()
            return

        if cmd in ("EXIT", "QUIT"):
            self._running = False
            return

        if cmd == "STATUS":
            print_status(
                self.gateway_id,
                self._authenticated,
                self._known_symbols,
                self.order_cache,
                self.quote_leg_cache,
                self._positions,
            )
            return

        if cmd == "ORDERS":
            print_orders(self.gateway_id, self.order_cache)
            return

        if cmd == "QLEGS":
            kv = self._kv(parts[1:])
            symbol = kv.get("SYM")
            show = kv.get("SHOW", "ACTIVE").upper()
            if show not in {"ACTIVE", "RECENT", "ALL"}:
                console.print("[red]QLEGS SHOW must be ACTIVE, RECENT, or ALL[/red]")
                log.debug(
                    "command rejected cmd=%s reason=%s",
                    cmd,
                    "QLEGS SHOW must be ACTIVE, RECENT, or ALL",
                )
                return
            print_quote_legs(self.gateway_id, self.quote_leg_cache, symbol, show)
            return

        if cmd == "QBOOT":
            kv = self._kv(parts[1:])
            symbol = kv.get("SYM", "")
            self._send(
                self.push_sock,
                make_quote_bootstrap_request_msg(self.gateway_id, symbol),
            )
            return

        if cmd == "POS":
            kv = self._kv(parts[1:])
            target_gw = kv.get("GW")
            if target_gw:
                self._query_position(target_gw)
            else:
                print_positions(self._positions, self._last_prices)
            return

        if cmd == "SYMBOLS":
            self._symbols_requested = True
            self._send(self.push_sock, make_symbols_request_msg(self.gateway_id))
            return

        if cmd == "SESSION":
            self._send(self.push_sock, make_session_state_request_msg(self.gateway_id))
            return

        if cmd == "INDEX":
            kv = self._kv(parts[1:])
            if len(parts) > 1 and parts[1].upper() == "HISTORY":
                index_id = kv.get("INDEX") or self._default_index_id or ""
                if not index_id:
                    console.print(
                        "[red]INDEX|HISTORY requires INDEX=<id> or prior index.update.[/red]"
                    )
                    return
                try:
                    from_dt = self._parse_date("FROM", kv.get("FROM"))
                    to_dt = self._parse_date("TO", kv.get("TO"))
                except ValueError as exc:
                    console.print(f"[red]{exc}[/red]")
                    return
                if from_dt is not None and to_dt is not None and from_dt > to_dt:
                    console.print("[red]FROM= is after TO=[/red]")
                    return
                now_ns = time.time_ns()
                from_ts_ns = (
                    int(from_dt.timestamp()) * 1_000_000_000
                    if from_dt is not None
                    else now_ns - 30 * 86400 * 1_000_000_000
                )
                to_ts_ns = (
                    int((to_dt + timedelta(days=1)).timestamp()) * 1_000_000_000 - 1
                    if to_dt is not None
                    else now_ns
                )
                # Date filters are converted directly to epoch nanoseconds;
                # subtract one nanosecond from the next local midnight so
                # the inclusive wire bound covers the full TO date.
                self._send(
                    self._index_push_sock,
                    make_index_history_request_msg(
                        gateway_id=self.gateway_id,
                        index_id=index_id,
                        from_ts_ns=from_ts_ns,
                        to_ts_ns=to_ts_ns,
                    ),
                )
                return
            print_current_index(self._last_index_update)
            return

        if cmd == "QUOTE":
            kv = self._kv(parts[1:])
            self._send_quote(kv)
            return

        if cmd == "QUOTE_CANCEL":
            kv = self._kv(parts[1:])
            symbol = kv.get("SYM")
            if not symbol:
                console.print("[red]QUOTE_CANCEL requires SYM=<symbol>[/red]")
                log.debug(
                    "command rejected cmd=%s reason=%s",
                    cmd,
                    "QUOTE_CANCEL requires SYM=<symbol>",
                )
                return
            self._send(self.push_sock, make_quote_cancel_msg(self.gateway_id, symbol))
            return

        if cmd == "KILL":
            kv = self._kv(parts[1:])
            self._send(
                self.push_sock, make_kill_switch_msg(self.gateway_id, kv.get("SYM", ""))
            )
            return

        if cmd == "DC":
            kv = self._kv(parts[1:])
            state = kv.get("STATE", "")
            if state in ("ON", "OFF"):
                self._set_drop_copy(state == "ON")
                console.print(f"[dim]DC {state}[/dim]")
            else:
                console.print("[red]DC requires STATE=ON or STATE=OFF[/red]")
                log.debug(
                    "command rejected cmd=%s reason=%s",
                    cmd,
                    "DC requires STATE=ON or STATE=OFF",
                )
            return

        if cmd == "CANCEL":
            kv = self._kv(parts[1:])
            combo_id = kv.get("COMBO_ID")
            if combo_id:
                self._send(
                    self.push_sock, make_combo_cancel_msg(combo_id, self.gateway_id)
                )
                return
            oco_id = kv.get("OCO_ID")
            if oco_id:
                self._send(self.push_sock, make_oco_cancel_msg(oco_id, self.gateway_id))
                return
            order_id = kv.get("ID")
            if not order_id:
                console.print("[red]CANCEL requires ID=, COMBO_ID=, or OCO_ID=[/red]")
                log.debug(
                    "command rejected cmd=%s reason=%s",
                    cmd,
                    "CANCEL requires ID=, COMBO_ID=, or OCO_ID=",
                )
                return
            self._send(
                self.push_sock,
                make_order_cancel_msg(
                    order_id,
                    self.gateway_id,
                    request_tag=kv.get("RTAG"),
                ),
            )
            return

        if cmd == "AMEND":
            kv = self._kv(parts[1:])
            order_id = kv.get("ID")
            if not order_id:
                console.print("[red]AMEND requires ID=<order-id>[/red]")
                log.debug(
                    "command rejected cmd=%s reason=%s",
                    cmd,
                    "AMEND requires ID=<order-id>",
                )
                return
            if "PRICE" not in kv and "QTY" not in kv:
                console.print("[red]AMEND requires at least PRICE= or QTY=[/red]")
                log.debug(
                    "command rejected cmd=%s reason=%s",
                    cmd,
                    "AMEND requires at least PRICE= or QTY=",
                )
                return
            try:
                frames = make_order_amend_msg(
                    order_id,
                    self.gateway_id,
                    price=(_to_float("PRICE", kv["PRICE"]) if "PRICE" in kv else None),
                    qty=_to_int("QTY", kv["QTY"]) if "QTY" in kv else None,
                    request_tag=kv.get("RTAG"),
                )
            except ValueError as exc:
                log.info(
                    "AMEND parse error gateway_id=%s error=%s", self.gateway_id, exc
                )
                console.print(f"[red]Parse error: {exc}[/red]")
                return
            self._send(self.push_sock, frames)
            return

        if cmd == "NEW":
            kv = self._kv(parts[1:])
            if kv.get("TYPE") == "COMBO":
                self._send_combo(kv)
            elif kv.get("TYPE") == "OCO":
                self._send_oco(kv)
            else:
                self._send_new(parts[1:])
            return

        log.info("unknown command gateway_id=%s command=%s", self.gateway_id, cmd)
        console.print(f"[red]Unknown command: {cmd}[/red]  (type HELP)")

    # Keys whose values are opaque, case-sensitive identifiers or free-text
    # labels rather than canonical-uppercase enum tokens (SIDE, TYPE, TIF,
    # ...) or the symbol/gateway-id convention this console otherwise
    # upper-cases. Order ids in particular are engine-minted lowercase hex
    # (see models/ids.py's new_order_id) -- uppercasing one typed back from
    # an order.ack or `pm-audit-cli` into a later CANCEL|ID= silently turns
    # it into an id that will never match anything in the book, and the
    # engine rejects it as ORDER_NOT_FOUND with no hint that case was the
    # problem. client_tag/request_tag are likewise whatever the caller
    # chose to record and must round-trip unchanged, and combo/OCO/quote
    # ids are free-text labels the user picks, not enum tokens.
    _CASE_SENSITIVE_KEYS = frozenset(
        {"ID", "TAG", "RTAG", "COMBO_ID", "OCO_ID", "QUOTE_ID"}
    )

    @classmethod
    def _kv(cls, parts: list[str]) -> dict[str, str]:
        kv: dict[str, str] = {}
        for p in parts:
            if "=" in p:
                k, v = p.split("=", 1)
                k = k.upper()
                kv[k] = v if k in cls._CASE_SENSITIVE_KEYS else v.upper()
        return kv

    def _send_new(self, parts: list[str]) -> None:
        kv = self._kv(parts)
        try:
            symbol = kv["SYM"]
            side = Side(kv["SIDE"])
            order_type = OrderType(kv["TYPE"])
            quantity = _to_int("QTY", kv["QTY"])
            if quantity < 1:
                raise ValueError(f"QTY= must be a positive whole number: {quantity}")
            tif = TIF(kv.get("TIF", "DAY"))
            price = _to_float("PRICE", kv["PRICE"]) if "PRICE" in kv else None
            stop_price = _to_float("STOP", kv["STOP"]) if "STOP" in kv else None
            trail = _to_float("TRAIL", kv["TRAIL"]) if "TRAIL" in kv else None
            visible = _to_int("VISIBLE", kv["VISIBLE"]) if "VISIBLE" in kv else None
            # SMP omitted entirely means "let the engine apply this
            # gateway's configured smp_action default" -- distinct from an
            # explicit SMP=NONE. See SmpAction's docstring in
            # models/order.py.
            smp_action = SmpAction(kv["SMP"]) if "SMP" in kv else None
            client_tag = kv.get("TAG")
        except (KeyError, ValueError) as exc:
            log.info(
                "NEW parse error gateway_id=%s input=%s error=%s",
                self.gateway_id,
                "|".join(parts),
                exc,
            )
            console.print(f"[red]Parse error: {exc}[/red]")
            return

        # Validation
        if (
            order_type
            in (OrderType.LIMIT, OrderType.FOK, OrderType.ICEBERG, OrderType.IOC)
            and price is None
        ):
            log.info(
                "order rejected gateway_id=%s reason=missing_price order_type=%s",
                self.gateway_id,
                order_type.value,
            )
            console.print("[red]LIMIT / FOK / ICEBERG / IOC require PRICE=[/red]")
            return
        if order_type in (OrderType.STOP, OrderType.STOP_LIMIT) and stop_price is None:
            log.info(
                "order rejected gateway_id=%s reason=missing_stop_price order_type=%s",
                self.gateway_id,
                order_type.value,
            )
            console.print("[red]STOP / STOP_LIMIT require STOP=[/red]")
            return
        if order_type == OrderType.STOP_LIMIT and price is None:
            log.info(
                "order rejected gateway_id=%s reason=missing_price order_type=STOP_LIMIT",
                self.gateway_id,
            )
            console.print(
                "[red]STOP_LIMIT requires PRICE= (limit price after trigger)[/red]"
            )
            return
        if order_type == OrderType.ICEBERG and visible is None:
            log.info(
                "order rejected gateway_id=%s reason=missing_visible_qty order_type=ICEBERG",
                self.gateway_id,
            )
            console.print("[red]ICEBERG requires VISIBLE=<peak size>[/red]")
            return
        if (
            order_type == OrderType.ICEBERG
            and visible is not None
            and visible >= quantity
        ):
            log.info(
                "order rejected gateway_id=%s reason=visible_not_less_than_qty visible=%s qty=%s",
                self.gateway_id,
                visible,
                quantity,
            )
            console.print("[red]ICEBERG VISIBLE must be less than total QTY[/red]")
            return
        if order_type == OrderType.TRAILING_STOP:
            if trail is None:
                log.info(
                    "order rejected gateway_id=%s reason=missing_trail_offset order_type=TRAILING_STOP",
                    self.gateway_id,
                )
                console.print("[red]TRAILING_STOP requires TRAIL=<offset>[/red]")
                return

        # Catch an off-grid price here rather than letting the engine round
        # it: the console user typed a price and would otherwise watch an
        # order rest at a different one with no explanation.
        try:
            order = Order.create(
                symbol=symbol,
                side=side,
                order_type=order_type,
                quantity=quantity,
                gateway_id=self.gateway_id,
                tif=tif,
                price_ticks=(
                    to_ticks_exact(price, symbol) if price is not None else None
                ),
                stop_price_ticks=(
                    to_ticks_exact(stop_price, symbol)
                    if stop_price is not None
                    else None
                ),
                visible_qty=visible,
                smp_action=smp_action,
                trail_offset_ticks=(
                    to_ticks_exact(trail, symbol) if trail is not None else None
                ),
                client_tag=client_tag,
            )
            # Built before the order is cached: a value the message refuses
            # (a 65-character TAG) must not leave a PENDING row behind.
            frames = make_order_new_msg(order.to_dict())
        except ValueError as exc:
            # TickViolation and MessageValidationError are ValueErrors.
            console.print(f"[red]{exc}[/red]")
            return

        # Pre-register in cache before ACK arrives
        self.order_cache[order.id] = {
            "id": order.id,
            "symbol": symbol,
            "side": side.value,
            "type": order_type.value,
            "tif": tif.value,
            "qty": quantity,
            "remaining": quantity,
            "price": price,
            "stop_price": stop_price,
            "status": "PENDING",
            "client_tag": client_tag,
            "time": datetime.now().strftime("%H:%M:%S"),
        }

        self._send(self.push_sock, frames)
        self._dbg_count("orders_submitted")

    def _send_quote(self, kv: dict[str, str]) -> None:
        try:
            symbol = kv["SYM"]
            bid_price = _to_float("BID", kv["BID"])
            ask_price = _to_float("ASK", kv["ASK"])
            bid_qty = _to_int("BID_QTY", kv["BID_QTY"])
            ask_qty = _to_int("ASK_QTY", kv["ASK_QTY"])
            tif = TIF(kv.get("TIF", "DAY"))
        except (KeyError, ValueError) as exc:
            log.info("QUOTE parse error gateway_id=%s error=%s", self.gateway_id, exc)
            console.print(f"[red]QUOTE parse error: {exc}[/red]")
            return

        if bid_qty <= 0 or ask_qty <= 0:
            log.info(
                "QUOTE rejected gateway_id=%s reason=non_positive_qty bid_qty=%s ask_qty=%s",
                self.gateway_id,
                bid_qty,
                ask_qty,
            )
            console.print("[red]QUOTE requires positive BID_QTY and ASK_QTY[/red]")
            return
        if bid_price >= ask_price:
            log.info(
                "QUOTE rejected gateway_id=%s reason=bid_not_less_than_ask bid=%s ask=%s",
                self.gateway_id,
                bid_price,
                ask_price,
            )
            console.print("[red]QUOTE requires BID < ASK[/red]")
            return

        try:
            payload: dict[str, Any] = {
                "gateway_id": self.gateway_id,
                "symbol": symbol,
                # Ticks on the wire: converting is the submitting gateway's
                # job (design section 15.2, extended to quotes in 6.1b).
                "tick_decimals": get_tick_decimals(symbol),
                "bid_price_ticks": to_ticks_exact(bid_price, symbol),
                "bid_qty": bid_qty,
                "ask_price_ticks": to_ticks_exact(ask_price, symbol),
                "ask_qty": ask_qty,
                "tif": tif.value,
            }
            # The operator may name the quote (QUOTE_ID=...); otherwise mint
            # one. Either way the request goes out *with* an id, so the ack
            # can be matched to it exactly rather than by arrival order.
            quote_id = kv.get("QUOTE_ID") or f"{self.gateway_id}-{symbol}-{new_ulid()}"
            payload["quote_id"] = quote_id
            frames = make_quote_new_msg(payload)
        except ValueError as exc:
            console.print(f"[red]{exc}[/red]")
            return

        pending = {
            "symbol": symbol,
            "bid_px": bid_price,
            "ask_px": ask_price,
            "bid_qty": bid_qty,
            "ask_qty": ask_qty,
        }
        self._pending_quote_by_id[quote_id] = pending
        while len(self._pending_quote_by_id) > self._pending_quote_cap:
            self._pending_quote_by_id.popitem(last=False)
        self._pending_quote_requests.append(pending)
        self._send(self.push_sock, frames)
        self._dbg_count("quotes_submitted")

    def _send_oco(self, kv: dict[str, str]) -> None:
        """Parse and send an OCO pair from TYPE=OCO format."""
        oco_id = kv.get("OCO_ID", "")
        symbol = kv.get("SYM", "")
        tif_str = kv.get("TIF", "DAY")

        if not oco_id:
            log.info(
                "OCO rejected gateway_id=%s reason=missing_oco_id", self.gateway_id
            )
            console.print("[red]OCO requires OCO_ID=<label>[/red]")
            return
        if not symbol:
            log.info(
                "OCO rejected gateway_id=%s reason=missing_symbol", self.gateway_id
            )
            console.print("[red]OCO requires SYM=<symbol>[/red]")
            return

        try:
            quantity = _to_int("QTY", kv["QTY"])
            tif_val = TIF(tif_str)
        except (KeyError, ValueError) as exc:
            log.info("OCO parse error gateway_id=%s error=%s", self.gateway_id, exc)
            console.print(f"[red]Parse error: {exc}[/red]")
            return

        def _parse_leg(prefix: str) -> dict[str, Any] | None:
            side_key = f"{prefix}SIDE"
            type_key = f"{prefix}TYPE"
            price_key = f"{prefix}PRICE"
            stop_key = f"{prefix}STOP"
            trail_key = f"{prefix}TRAIL"
            if side_key not in kv or type_key not in kv:
                return None
            leg: dict[str, Any] = {
                "side": kv[side_key],
                "order_type": kv[type_key],
            }
            for key, field in (
                (price_key, "price_ticks"),
                (stop_key, "stop_price_ticks"),
                (trail_key, "trail_offset_ticks"),
            ):
                if key in kv:
                    leg[field] = to_ticks_exact(_to_float(key, kv[key]), symbol)
            return leg

        try:
            leg1 = _parse_leg("LEG1_")
            leg2 = _parse_leg("LEG2_")
        except ValueError as exc:
            console.print(f"[red]{exc}[/red]")
            return

        if leg1 is None or leg2 is None:
            log.info(
                "OCO rejected gateway_id=%s reason=missing_required_legs",
                self.gateway_id,
            )
            console.print(
                "[red]OCO requires LEG1_SIDE= LEG1_TYPE= LEG2_SIDE= LEG2_TYPE=[/red]"
            )
            return

        payload = {
            "oco_id": oco_id,
            "gateway_id": self.gateway_id,
            "symbol": symbol,
            # The scale of the legs' ticks; the engine refuses any other (L032).
            "tick_decimals": get_tick_decimals(symbol),
            "quantity": quantity,
            "tif": tif_val.value,
            "leg1": leg1,
            "leg2": leg2,
        }
        if kv.get("TAG"):
            payload["client_tag"] = kv["TAG"]
        try:
            frames = make_oco_order_msg(payload)
        except ValueError as exc:
            console.print(f"[red]{exc}[/red]")
            return
        self._send(self.push_sock, frames)
        self._dbg_count("oco_submitted")

    def _send_combo(self, kv: dict[str, str]) -> None:
        """Parse and send a combo order from TYPE=COMBO format."""

        combo_id = kv.get("COMBO_ID", "")
        combo_type = kv.get("COMBO_TYPE", "AON")
        tif_str = kv.get("TIF", "DAY")
        # SMP omitted entirely means "let the engine apply this gateway's
        # configured smp_action default" to every leg -- distinct from an
        # explicit SMP=NONE. See SmpAction's docstring in models/order.py.
        smp_str = kv.get("SMP")

        if not combo_id:
            log.info(
                "COMBO rejected gateway_id=%s reason=missing_combo_id", self.gateway_id
            )
            console.print("[red]COMBO requires COMBO_ID=<label>[/red]")
            return

        try:
            combo_type_val = ComboType(combo_type)
            tif_val = TIF(tif_str)
        except ValueError as exc:
            log.info("COMBO parse error gateway_id=%s error=%s", self.gateway_id, exc)
            console.print(f"[red]Parse error: {exc}[/red]")
            return

        leg_count_str = kv.get("LEG_COUNT", "0")
        try:
            leg_count = int(leg_count_str)
        except ValueError:
            log.info(
                "COMBO rejected gateway_id=%s reason=invalid_leg_count value=%s",
                self.gateway_id,
                leg_count_str,
            )
            console.print(
                f"[red]LEG_COUNT must be an integer, got '{leg_count_str}'[/red]"
            )
            return

        if leg_count < 2 or leg_count > 10:
            log.info(
                "COMBO rejected gateway_id=%s reason=leg_count_out_of_range count=%d",
                self.gateway_id,
                leg_count,
            )
            console.print("[red]LEG_COUNT must be between 2 and 10[/red]")
            return

        legs: list[ComboLeg] = []
        for i in range(leg_count):
            prefix = f"LEG{i}"
            sym = kv.get(f"{prefix}.SYM")
            side = kv.get(f"{prefix}.SIDE")
            qty = kv.get(f"{prefix}.QTY")
            price = kv.get(f"{prefix}.PRICE")
            stop = kv.get(f"{prefix}.STOP")
            leg_type = kv.get(f"{prefix}.TYPE", "LIMIT")

            if not sym or not side or not qty:
                log.info(
                    "COMBO rejected gateway_id=%s reason=missing_leg_fields leg=%d",
                    self.gateway_id,
                    i,
                )
                console.print(f"[red]Leg {i} missing SYM, SIDE, or QTY[/red]")
                return
            try:
                if int(qty) < 1:
                    raise ValueError(f"QTY must be a positive integer, got {qty}")
                leg = ComboLeg(
                    symbol=sym,
                    side=Side(side),
                    order_type=OrderType(leg_type),
                    quantity=int(qty),
                    tick_decimals=get_tick_decimals(sym),
                    # TickViolation subclasses ValueError, so the except below
                    # already reports an off-grid leg price as a parse error.
                    price_ticks=(
                        to_ticks_exact(_to_float(f"{prefix}.PRICE", price), sym)
                        if price
                        else None
                    ),
                    stop_price_ticks=(
                        to_ticks_exact(_to_float(f"{prefix}.STOP", stop), sym)
                        if stop
                        else None
                    ),
                    smp_action=SmpAction(smp_str) if smp_str is not None else None,
                )
            except (ValueError, KeyError) as exc:
                log.info(
                    "COMBO leg parse error gateway_id=%s leg=%d error=%s",
                    self.gateway_id,
                    i,
                    exc,
                )
                console.print(f"[red]Leg {i} parse error: {exc}[/red]")
                return
            legs.append(leg)

        combo = ComboOrder.create(
            combo_id=combo_id,
            gateway_id=self.gateway_id,
            combo_type=combo_type_val,
            tif=tif_val,
            legs=legs,
        )

        payload = combo.to_submission_dict()
        if kv.get("TAG"):
            payload["client_tag"] = kv["TAG"]
        try:
            frames = make_combo_order_msg(payload)
        except ValueError as exc:
            console.print(f"[red]{exc}[/red]")
            return
        self._send(self.push_sock, frames)
        self._dbg_count("combo_submitted")

    @staticmethod
    def _parse_date(key: str, raw: str | None) -> datetime | None:
        """The date typed as ``KEY=YYYY-MM-DD``; None when not given."""
        if not raw:
            return None
        try:
            return datetime.strptime(raw, "%Y-%m-%d")
        except ValueError:
            raise ValueError(f"{key}= is not a date (YYYY-MM-DD): {raw!r}") from None

    # ------------------------------------------------------------------
    # Run
    # ------------------------------------------------------------------

    def run(self) -> int:
        """Log on and run the prompt; the process exit status.

        1 when the logon is refused or the engine cannot be reached, and
        when the engine connection is lost during the session; 0 when the
        user leaves (EXIT, QUIT, Ctrl-D, Ctrl-C).
        """
        if not self._authenticate():
            reason = self._auth_reason or f"Gateway not allowed: {self.gateway_id}"
            log.error(
                "gateway startup refused gateway_id=%s reason=%s",
                self.gateway_id,
                reason,
            )
            console.print(f"[red]Logon failed:[/red] {reason}")
            self._running = False
            self.push_sock.close()
            self.sub_sock.close()
            self._index_sub_sock.close()
            self._dc_sub_sock.close()
            return 1

        self._authenticated = True
        # The symbol list first: its tick sizes convert every typed price.
        self._send(self.push_sock, make_symbols_request_msg(self.gateway_id))
        # Request outstanding resting orders and the position, so a restarted
        # console shows what the engine holds.
        self._send(self.push_sock, make_orders_request_msg(self.gateway_id))
        self._send(self.push_sock, make_position_request_msg(self.gateway_id))

        if self._dc_requested_on_startup:
            self._set_drop_copy(True)

        listener = threading.Thread(target=self._listen, daemon=True)
        listener.start()
        threading.Thread(target=self._heartbeat_loop, daemon=True).start()

        if not self._symbols_received.wait(self._symbols_timeout_sec):
            if not self._connection_lost:
                log.error("engine sent no symbol list gateway_id=%s", self.gateway_id)
                console.print(
                    "[red]Logon failed:[/red] the engine did not send its symbol "
                    "list, so prices cannot be converted to its tick sizes"
                )
            self._shutdown()
            return 1
        log.info("gateway command loop started gateway_id=%s", self.gateway_id)

        desc = f" — {self._auth_description}" if self._auth_description else ""
        console.print(
            f"\n[bold green]Gateway {self.gateway_id} connected.[/bold green]  "
            f"{desc} "
            f"Type [bold]HELP[/bold] for commands.  "
            f"[dim]Tab=complete  ↑↓=history  Ctrl-A/E=line start/end[/dim]\n"
        )

        completer = GatewayCompleter(self._known_symbols)
        session: PromptSession[str] = PromptSession(
            history=InMemoryHistory(),
            completer=completer,
            complete_while_typing=False,  # only complete on Tab
            style=PROMPT_STYLE,
            mouse_support=False,
            key_bindings=_completion_key_bindings(),
        )
        self._prompt_session = session
        prompt_str = [("class:prompt", f"[{self.gateway_id}]> ")]

        try:
            with logout_on_hangup(self._request_exit), pt_patch_stdout(raw=True):
                while self._running:
                    try:
                        line = session.prompt(prompt_str)  # type: ignore[arg-type]
                    except EOFError, KeyboardInterrupt:
                        break
                    if not line.strip():
                        continue
                    try:
                        self._parse_and_send(line)
                    except Exception as exc:
                        # Leaving the loop would log the participant out, and
                        # the engine would apply their disconnect_behaviour.
                        log.exception(
                            "command failed gateway_id=%s line=%r",
                            self.gateway_id,
                            line,
                        )
                        console.print(f"[red]Command failed: {exc}[/red]")
        finally:
            self._shutdown()
        return 1 if self._connection_lost else 0

    def _shutdown(self) -> None:
        """Log out of the engine and close every socket."""
        self._prompt_session = None
        self._running = False
        self._heartbeat_stop.set()
        try:
            self.push_sock.send_multipart(
                make_gateway_disconnect_msg(self.gateway_id, reason="client_exit")
            )
        except Exception:
            pass
        self._flush_debug_summary(force=True)
        self._index_push_sock.close()
        self.push_sock.close()
        self.sub_sock.close()
        self._index_sub_sock.close()
        self._dc_sub_sock.close()
        log.info("gateway shutdown complete gateway_id=%s", self.gateway_id)
        console.print(f"\n[bold]Gateway {self.gateway_id} disconnected.[/bold]")


@exit_on_config_error
def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    log_level = _configure_logging(args)
    log.info(
        "starting pm-alf-console with log level %s",
        logging.getLevelName(log_level),
    )
    log.debug("resolved gateway args: id=%s drop_copy=%s", args.id, args.drop_copy)
    return Gateway(args.id, drop_copy=args.drop_copy).run()


if __name__ == "__main__":
    raise SystemExit(main())
