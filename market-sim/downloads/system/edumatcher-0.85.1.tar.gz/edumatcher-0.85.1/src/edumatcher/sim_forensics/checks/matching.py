"""D — matching correctness, and C7, from a replay of the audit trail.

The audit holds every engine message in publish order (see ``audit.py``),
and every message the engine sends for one inbound command carries that
command's ``chain``. One pass replays the run: each chain is one *dispatch*,
and a per-symbol book is rebuilt order by order from what the dispatch says
happened -- acks put orders in, trades take quantity out, cancels and
expiries remove them. The replay does not match; it re-derives, from its own
model of the matching rules, what each trade had to be, and flags a trade
the model would not have made:

- the aggressor of each trade is the command's order, or a stop the model's
  cascade triggered (checkpoints after each matching step, as the engine's
  ``OrderBook.process`` runs them; trailing stops ratchet at each one);
- its counterparty is the first order, in price-time priority, at the best
  opposite price -- an iceberg showing only its slice and refilling at the
  back of its level;
- an uncross prints at the volume-maximising price (ties: least surplus,
  then lowest price) and fills both sides in priority.

Orders cancelled anywhere in a dispatch (SMP, a pulled quote leg, an OCO
sibling) are left out of "who should have traded first": the stream does
not say whether the cancel came before or after a given trade.

The engine's own full-book snapshots (``book.<SYM>``) are the oracle for the
replay itself (D9): wherever replay and engine disagree, one of them is
wrong, and the first snapshot after the divergence names the place.

In a call phase the engine publishes each symbol's indicative uncross
(``auction.indicative.<SYM>``) on a timer, between dispatches; D10 compares
it with the uncross the replayed book would make at that point.
"""

from __future__ import annotations

import heapq
import json
from collections import Counter, defaultdict, deque
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Any

from edumatcher.sim_forensics.audit import Line, audit_files, lines, run_config_text
from edumatcher.sim_forensics.checks import refusals
from edumatcher.sim_forensics.dataset import Dataset
from edumatcher.sim_forensics.registry import Outcome, Sample, Skipped, check

BUY, SELL = "BUY", "SELL"
_STOP_TYPES = ("STOP", "STOP_LIMIT", "TRAILING_STOP")
#: The removal reasons that mean the engine triggered a stop (a MARKET that
#: found no liquidity, or one that met its owner's own order).
_TRIGGERED_REASONS = ("INSUFFICIENT_LIQUIDITY", "SELF_MATCH_PREVENTED")
#: Samples kept per check; the report shows fewer.
_KEEP = 50

#: Topics the replay reads, by exact topic and by prefix up to the last dot.
_EXACT = {
    "order.new": "new",
    "quote.new": "quote",
    "order.oco": "oco",
    "order.combo": "combo",
    "trade.executed": "trade",
    "session.state": "phase",
    "system.startup": "startup",
}
_PREFIX = {
    "order.ack.": "ack",
    "quote.ack.": "quote_ack",
    "oco.ack.": "oco_ack",
    "order.fill.": "fill",
    "order.cancelled.": "cancelled",
    "order.expired.": "expired",
    "oco.cancelled.": "oco_cancelled",
    "auction.result.": "auction",
    "book.": "book",
    "auction.indicative.": "indicative",
    "system.book_checkpoint.": "checkpoint",
    "order.amended.": "amended",
    "circuit_breaker.halt.": "halt",
    "circuit_breaker.resume.": "resume",
    "risk.band.": "band",
    "order.triggered.": "triggered",
    "engine.trace.": "trace",
}


@dataclass(slots=True)
class _Order:
    """An order as the replay holds it: resting, armed, or being matched."""

    id: str
    side: str
    kind: str  # order type; a triggered stop becomes MARKET or LIMIT
    price: int | None  # limit, in ticks
    remaining: int
    gw: str
    smp: str
    peak: int | None = None  # an iceberg's visible slice
    shown: int = 0  # what rests visibly
    stop: int | None = None
    offset: int | None = None
    seq: int = 0  # time priority
    triggered: bool = False
    armed_as: str = ""  # the stop type a triggered stop was
    traded: bool = False
    oco: str | None = None  # the OCO pair it is a leg of


class _Book:
    def __init__(self, symbol: str, td: int) -> None:
        self.symbol = symbol
        self.td = td
        #: Side → price → orders in priority order.
        self.levels: dict[str, dict[int, dict[str, _Order]]] = {BUY: {}, SELL: {}}
        #: Best-first heaps of level prices (bids negated), pruned lazily.
        self._heaps: dict[str, list[int]] = {BUY: [], SELL: []}
        self.orders: dict[str, _Order] = {}
        #: Armed STOP / STOP_LIMIT, and TRAILING_STOP in arming order (the
        #: engine's list order).
        self.stops: dict[str, _Order] = {}
        self.trailing: dict[str, _Order] = {}
        self.last: int | None = None
        self.qty = {BUY: 0, SELL: 0}
        self.count = {BUY: 0, SELL: 0}
        #: Bumped by every change to the resting orders.
        self.version = 0

    def best(self, side: str) -> int | None:
        heap, levels = self._heaps[side], self.levels[side]
        while heap:
            price = -heap[0] if side == BUY else heap[0]
            if price in levels:
                return price
            heapq.heappop(heap)
        return None

    def top(self, side: str, skip: set[str], keep: _Order) -> _Order | None:
        """First order in priority on *side*, passing over orders in *skip*
        other than *keep*."""
        best = self.best(side)
        if best is None:
            return None
        for o in self.levels[side][best].values():
            if o is keep or o.id not in skip:
                return o
        for price in sorted(self.levels[side], reverse=side == BUY):
            for o in self.levels[side][price].values():
                if o is keep or o.id not in skip:
                    return o
        return None

    def rest(self, o: _Order, seq: int) -> None:
        assert o.price is not None
        self.version += 1
        o.seq = seq
        o.shown = min(o.peak, o.remaining) if o.peak else o.remaining
        levels = self.levels[o.side]
        if o.price not in levels:
            levels[o.price] = {}
            heapq.heappush(self._heaps[o.side], -o.price if o.side == BUY else o.price)
        levels[o.price][o.id] = o
        self.orders[o.id] = o
        self.qty[o.side] += o.shown
        self.count[o.side] += 1

    def arm(self, o: _Order, seq: int) -> None:
        o.seq = seq
        (self.trailing if o.kind == "TRAILING_STOP" else self.stops)[o.id] = o

    def remove(self, order_id: str) -> _Order | None:
        o = self.orders.pop(order_id, None)
        if o is None:
            return self.stops.pop(order_id, None) or self.trailing.pop(order_id, None)
        self.version += 1
        assert o.price is not None
        level = self.levels[o.side][o.price]
        del level[order_id]
        if not level:
            del self.levels[o.side][o.price]
        self.qty[o.side] -= o.shown
        self.count[o.side] -= 1
        return o

    def fill(self, o: _Order, qty: int, seq: int) -> None:
        """A resting order trades *qty*; a used-up iceberg slice refills at
        the back of its level."""
        assert o.price is not None
        self.version += 1
        o.remaining -= qty
        o.shown -= qty
        self.qty[o.side] -= qty
        if o.remaining <= 0:
            self.remove(o.id)
        elif o.shown <= 0:
            self.qty[o.side] -= o.shown  # an over-fill (flagged by the caller)
            o.shown = min(o.peak or o.remaining, o.remaining)
            self.qty[o.side] += o.shown
            level = self.levels[o.side][o.price]
            del level[o.id]
            level[o.id] = o
            o.seq = seq

    def fillable(self, side: str, limit: int | None, gw: str, smp: str) -> int:
        """What an order on *side* from *gw* could execute against the book
        now, as a FOK or an all-or-none combo's pre-check counts it: the
        other side in priority up to *limit*; an iceberg's hidden rest
        behind everything at its price; the gateway's own orders left out
        under SMP -- under CANCEL_AGGRESSOR / CANCEL_BOTH the sweep stops at
        the first, so nothing behind it counts; of an OCO pair only the leg
        met first (the other goes with it)."""
        other = SELL if side == BUY else BUY
        total = 0
        pairs: set[tuple[str, str]] = set()
        for price in sorted(self.levels[other], reverse=other == BUY):
            if limit is not None and (price > limit if side == BUY else price < limit):  # fmt: skip
                break
            hidden = 0
            for o in self.levels[other][price].values():
                if smp != "NONE" and o.gw == gw:
                    if smp in ("CANCEL_AGGRESSOR", "CANCEL_BOTH"):
                        return total
                    continue
                if o.oco is not None:
                    if (o.gw, o.oco) in pairs:
                        continue
                    pairs.add((o.gw, o.oco))
                total += o.shown
                hidden += o.remaining - o.shown
            total += hidden
        return total

    def view(self, side: str) -> dict[int, tuple[int, int]]:
        return {
            price: (sum(o.shown for o in level.values()), len(level))
            for price, level in self.levels[side].items()
        }


@dataclass
class _Dispatch:
    chain: str
    new: dict[str, Any] | None = None
    quote: dict[str, Any] | None = None
    oco: dict[str, Any] | None = None
    acks: list[tuple[str, dict[str, Any]]] = field(default_factory=list)
    quote_ack: dict[str, Any] | None = None
    oco_ack: dict[str, Any] | None = None
    trades: list[dict[str, Any]] = field(default_factory=list)
    fills: list[dict[str, Any]] = field(default_factory=list)
    #: Order id → reason, for every order this dispatch cancelled or expired.
    dead: dict[str, str] = field(default_factory=dict)
    #: Symbol of each dead order the payload names.
    dead_symbol: dict[str, str] = field(default_factory=dict)
    auctions: dict[str, dict[str, Any]] = field(default_factory=dict)
    phase: str | None = None
    startup: bool = False
    combo: dict[str, Any] | None = None
    amends: list[dict[str, Any]] = field(default_factory=list)
    #: (symbol, halted) for each halt and resume, in order (in effect after
    #: the dispatch: a reopen's prints come before its resume).
    halts: list[tuple[str, bool]] = field(default_factory=list)
    #: order.triggered and engine.trace payloads, in publish order.
    triggered: list[dict[str, Any]] = field(default_factory=list)
    traces: list[dict[str, Any]] = field(default_factory=list)


class _Replay:
    def __init__(self, symbols: dict[str, dict[str, Any]], smp: dict[str, str]):
        self.td = {s: int(c.get("tick_decimals", 2)) for s, c in symbols.items()}
        self.smp = smp
        self.books: dict[str, _Book] = {}
        self.counts: Counter[str] = Counter()
        self.samples: dict[str, list[Sample]] = defaultdict(list)
        self.phase: str | None = None
        self.started = False
        #: Symbols whose replayed book is known to be the engine's (D9 then
        #: compares it with a checkpoint); every symbol when the replay began
        #: at the engine's start, none right after a restart.
        self.synced: set[str] = set()
        self.synced_all = False
        self.checkpoints = 0
        self.restarts = 0
        self.skipped_lines = 0
        self.seq = 0
        self.dispatches = 0
        self.snapshots = 0
        self.snapshots_differing = 0
        self.diverged: set[str] = set()
        self.auction_self_trades = 0
        self.trades_replayed = 0
        self.stops_triggered = 0
        self.uncrosses = 0
        #: Uncross price decisions (engine.trace UNCROSS_PRICE) compared.
        self.decisions = 0
        self.amends = 0
        self.combo_legs = 0
        #: C12's refusals judged on the books, and what failed.
        self.c12_judged = 0
        self.c12_errors: Counter[str] = Counter()
        #: Whether the audit carries S24's explicit events (engine.trace on
        #: every resting order, so any run has them): C7 then compares the
        #: replay's triggers with the engine's order.triggered, per dispatch.
        self.explicit = False
        self.halts = 0
        self.entries_banded = 0
        #: Symbols halted now (circuit breaker or administrator).
        self.halted: set[str] = set()
        #: Symbol → (static low, static high, dynamic band fraction), from risk.band.
        self.bands: dict[str, tuple[int, int, float]] = {}
        #: Order id → the engine's own priority_seq (engine.trace, amends,
        #: checkpoints), against which the replay's queue order is checked.
        self.engine_seq: dict[str, int] = {}
        self.symbol_of: dict[str, str] = {}
        self.indicatives = 0
        self.indicatives_skipped = 0
        #: Symbol → (book version, the uncross it makes).
        self._uncross_at: dict[str, tuple[int, _Uncross | None]] = {}
        # Per dispatch:
        self.chain = ""
        self.trades: list[dict[str, Any]] = []
        self.ti = 0
        self.dead: dict[str, str] = {}
        self.dead_symbol: dict[str, str] = {}
        self.triggered: list[_Order] = []
        self.remaining_after: dict[tuple[str, str], int] = {}

    # --- driving ---------------------------------------------------------

    def run(self, stream: Iterable[Line]) -> None:
        pending: list[tuple[str, str, dict[str, Any]]] = []
        chain = ""
        for topic, line_chain, body, *_ in stream:
            kind = _EXACT.get(topic) or _PREFIX.get(topic[: topic.rfind(".") + 1])
            if kind is None:
                continue
            if not self.started and not pending:
                # Until the engine's start or a checkpoint, no book is known.
                if kind == "checkpoint":
                    self.started = True
                elif kind != "startup":
                    self.skipped_lines += 1
                    continue
            if kind in ("book", "indicative", "checkpoint"):
                self._flush(chain, pending)
                pending = []
                if kind == "book":
                    self._snapshot(json.loads(body))
                elif kind == "indicative":
                    self._indicative(json.loads(body))
                else:
                    self._adopt(json.loads(body))
                continue
            if line_chain != chain:
                self._flush(chain, pending)
                pending, chain = [], line_chain
            pending.append((kind, topic, json.loads(body)))
        self._flush(chain, pending)
        if not self.started:
            raise Skipped(
                "the audit holds neither the engine's start nor a book checkpoint"
            )

    def _flush(self, chain: str, msgs: list[tuple[str, str, dict[str, Any]]]) -> None:
        if not msgs:
            return
        d = _Dispatch(chain)
        for kind, topic, p in msgs:
            if kind == "new":
                d.new = p
            elif kind == "quote":
                d.quote = p
            elif kind == "oco":
                d.oco = p
            elif kind == "ack":
                d.acks.append((topic.rsplit(".", 1)[1], p))
            elif kind == "quote_ack":
                d.quote_ack = p
            elif kind == "oco_ack":
                d.oco_ack = p
            elif kind == "trade":
                d.trades.append(p)
            elif kind == "fill":
                d.fills.append(p)
            elif kind in ("cancelled", "expired"):
                if kind == "expired":
                    d.dead[p["order_id"]] = "EXPIRED"
                else:
                    d.dead[p["order_id"]] = p.get("cancel_reason") or ""
                if p.get("symbol"):
                    d.dead_symbol[p["order_id"]] = p["symbol"]
            elif kind == "oco_cancelled":
                d.dead[p["cancelled_order_id"]] = "OCO_SIBLING"
            elif kind == "auction":
                d.auctions[p["symbol"]] = p
            elif kind == "phase":
                d.phase = p["state"]
            elif kind == "startup":
                d.startup = True
            elif kind == "combo":
                d.combo = p
            elif kind == "amended":
                d.amends.append(p)
            elif kind in ("halt", "resume"):
                d.halts.append((p["symbol"], kind == "halt"))
            elif kind == "band":
                self.bands[p["symbol"]] = (int(p["static_low_ticks"]), int(p["static_high_ticks"]), float(p["dynamic_band_pct"]))  # fmt: skip
            elif kind == "triggered":
                d.triggered.append(p)
            elif kind == "trace":
                d.traces.append(p)
                self.explicit = True
        if d.startup:
            if self.started:
                # A restart: the books come back from what the engine
                # restored, which its STARTUP checkpoints will say.
                self.restarts += 1
                self.books.clear()
                self.symbol_of.clear()
                self.diverged.clear()
                self._uncross_at.clear()
                self.halted.clear()
                self.engine_seq.clear()
                self.phase = None
            self.started = True
            self.synced_all = self.restarts == 0
            self.synced.clear()
        self.dispatches += 1
        self._dispatch(d)
        if d.phase is not None:
            self.phase = d.phase
        for symbol, halted in d.halts:
            if halted and symbol not in self.halted:
                self.halts += 1
            (self.halted.add if halted else self.halted.discard)(symbol)

    def _dispatch(self, d: _Dispatch) -> None:
        self.chain = d.chain
        self.dead = d.dead
        self.dead_symbol = d.dead_symbol
        self._refusals(d)
        commands = self._commands(d)
        by_symbol: dict[str, list[_Order]] = defaultdict(list)
        for symbol, o in commands:
            by_symbol[symbol].append(o)
        trades: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for t in d.trades:
            trades[t["symbol"]].append(t)
        symbols = set(by_symbol) | set(trades) | set(d.auctions)
        for oid in d.dead:
            sym = self.symbol_of.get(oid) or d.dead_symbol.get(oid)
            if sym is not None:
                symbols.add(sym)
        fills: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for f in d.fills:
            fills[f["symbol"]].append(f)
        amends: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for a in d.amends:
            amends[a["symbol"]].append(a)
        fired: dict[str, list[str]] = defaultdict(list)
        for t in d.triggered:
            fired[t["symbol"]].append(t["order_id"])
        traces: dict[str, list[dict[str, Any]]] = defaultdict(list)
        for t in d.traces:
            traces[t["symbol"]].append(t)
        # A halt or resume touches no order, but the book it leaves must be
        # checked (D2) like any other.
        symbols |= set(amends) | set(fired) | {s for s, _ in d.halts}
        halted_after = set(self.halted)
        for symbol, halted in d.halts:
            (halted_after.add if halted else halted_after.discard)(symbol)
        after = d.phase or self.phase
        for symbol in sorted(symbols):
            book = self._book(symbol)
            self._symbol_step(
                book,
                by_symbol.get(symbol, []),
                sorted(trades.get(symbol, []), key=lambda t: t["id"]),
                d.auctions.get(symbol),
                fills.get(symbol, []),
                after if symbol not in halted_after else "HALTED",
                amends.get(symbol, []),
                fired.get(symbol),
                next((t for t in traces.get(symbol, []) if t["kind"] == "UNCROSS_PRICE"), None),  # fmt: skip
            )
        for symbol, rows in traces.items():
            self._queue_order(symbol, rows)

    def _book(self, symbol: str) -> _Book:
        book = self.books.get(symbol)
        if book is None:
            book = self.books[symbol] = _Book(symbol, self.td.get(symbol, 2))
        return book

    def _next_seq(self) -> int:
        self.seq += 1
        return self.seq

    def _flag(self, cid: str, **sample: object) -> None:
        self.counts[cid] += 1
        if len(self.samples[cid]) < _KEEP:
            self.samples[cid].append({**sample, "chain": self.chain})

    # --- C12: the refusals only a book can judge -------------------------

    def _c12(self, error: str, **sample: object) -> None:
        self.c12_errors[error] += 1
        self._flag("C12", error=error, **sample)

    def _refusals(self, d: _Dispatch) -> None:
        """C12 on the book before the dispatch: a FOK refused for liquidity
        had less than its quantity to execute; an all-or-none combo was
        refused (its first leg, INSUFFICIENT_LIQUIDITY) exactly when a leg
        was short and a leg would trade now (X28), and its AON_PREFLIGHT
        (S36, where the audit has it) says what the book held."""
        refused = {a["order_id"] for _, a in d.acks if a.get("reject_code") == "INSUFFICIENT_LIQUIDITY"}  # fmt: skip
        if d.new is not None and d.new.get("order_type") == "FOK" and d.new["id"] in refused:  # fmt: skip
            p = d.new
            if p["symbol"] not in self.diverged:
                self.c12_judged += 1
                gw = p["gateway_id"]
                held = self._book(p["symbol"]).fillable(p["side"], p.get("price_ticks"), gw, p.get("smp_action") or self.smp.get(gw, "NONE"))  # fmt: skip
                if held >= int(p["quantity"]):
                    self._c12("FOK refused for liquidity the book held", order_id=p["id"], symbol=p["symbol"], qty=p["quantity"], fillable=held)  # fmt: skip
        if d.combo is not None and (d.combo.get("combo_type") or "AON") == "AON":
            self._aon(d, d.combo, bool(refused))

    def _aon(self, d: _Dispatch, c: dict[str, Any], refused: bool) -> None:
        legs = c.get("legs") or []
        traces = {int(t["leg_index"]): t for t in d.traces if t.get("kind") == "AON_PREFLIGHT"}  # fmt: skip
        posted = refused or traces or any(a.get("accepted") for _, a in d.acks)
        if not posted or any(leg["symbol"] in self.diverged for leg in legs):
            return  # refused before the pre-check (gateway, session, collar)
        self.c12_judged += 1
        gw = str(c["gateway_id"]).upper()
        mine = []
        for leg in legs:
            book = self._book(leg["symbol"])
            smp = leg.get("smp_action") or self.smp.get(gw, "NONE")
            price = leg.get("price_ticks")
            mine.append((book.fillable(leg["side"], price, gw, smp), book.fillable(leg["side"], price, gw, "NONE")))  # fmt: skip
        short = any(f < int(leg["quantity"]) for (f, _), leg in zip(mine, legs))
        matching = self.phase in ("CONTINUOUS", None)
        trades_now = any(n > 0 and leg["symbol"] not in self.halted for (_, n), leg in zip(mine, legs))  # fmt: skip
        outcome = "REJECT" if short and matching and trades_now else "REST" if short else "MATCH"  # fmt: skip
        if refused != (outcome == "REJECT"):
            self._c12("AON combo refused for liquidity, but the book did not call for it" if refused else "AON combo accepted, but a leg was short and one would trade now", combo_id=c.get("combo_id"), fillable=mine, outcome=outcome)  # fmt: skip
        for i, t in traces.items():
            theirs = (
                t.get("fillable_qty"),
                t.get("fillable_no_smp_qty"),
                t.get("outcome"),
            )
            if i < len(mine) and theirs != (*mine[i], outcome):
                self._c12("AON_PREFLIGHT differs from the replay's", combo_id=c.get("combo_id"), leg_index=i, engine=theirs, replay=(*mine[i], outcome))  # fmt: skip

    # --- commands --------------------------------------------------------

    def _commands(self, d: _Dispatch) -> list[tuple[str, _Order]]:
        """The orders the dispatch's command put into its book, in order."""
        out: list[tuple[str, _Order]] = []
        if d.new is not None:
            p = d.new
            ack = next((a for _, a in d.acks if a.get("order_id") == p["id"]), None)
            if ack is not None and p.get("price_ticks") is not None:
                self._band(
                    p["symbol"], int(p["price_ticks"]), "order.new", p["id"], ack
                )
            if ack is not None and ack.get("accepted"):
                td = int(p.get("tick_decimals") or self.td.get(p["symbol"], 2))
                stop = p.get("stop_price_ticks")
                if stop is None and ack.get("stop_price") is not None:
                    stop = _ticks(ack["stop_price"], td)
                o = _Order(
                    id=p["id"],
                    side=p["side"],
                    kind=p["order_type"],
                    price=p.get("price_ticks"),
                    remaining=int(p["quantity"]),
                    gw=p["gateway_id"],
                    smp=ack.get("smp_action") or self.smp.get(p["gateway_id"], "NONE"),
                    peak=p.get("visible_qty"),
                    stop=stop,
                    offset=p.get("trail_offset_ticks"),
                )
                out.append((p["symbol"], o))
                # An order accepted and then rejected in the same breath (X5)
                # is gone again.
                if any(
                    a.get("order_id") == o.id and not a.get("accepted")
                    for _, a in d.acks
                ):
                    self.dead.setdefault(o.id, "REJECTED")
        for gw, ack in d.acks:
            # Seed quote legs: acked at startup with no order.new.
            if ack.get("is_seed") and ack.get("accepted"):
                sym = ack["symbol"]
                o = _Order(
                    id=ack["order_id"],
                    side=ack["side"],
                    kind="LIMIT",
                    price=_ticks(ack["price"], self.td.get(sym, 2)),
                    remaining=int(ack["qty"]),
                    gw=gw,
                    smp="NONE",  # the engine never resolves a seed's SMP
                )
                out.append((sym, o))
        if (
            d.quote is not None
            and d.quote_ack is not None
            and d.quote_ack.get("accepted")
        ):
            q, a = d.quote, d.quote_ack
            smp = self.smp.get(q["gateway_id"], "NONE")
            for side, oid, price, qty in (
                (BUY, a["bid_order_id"], q["bid_price_ticks"], q["bid_qty"]),
                (SELL, a["ask_order_id"], q["ask_price_ticks"], q["ask_qty"]),
            ):
                o = _Order(oid, side, "LIMIT", price, int(qty), q["gateway_id"], smp)
                out.append((q["symbol"], o))
        if d.combo is not None:
            # Each leg is acked with its whole record, in posting order.
            known = {o.id for _, o in out}
            for gw, ack in d.acks:
                if ack.get("accepted") and ack.get("order_type") and ack["order_id"] not in known:  # fmt: skip
                    out.append((ack["symbol"], self._from_ack(gw, ack)))
                    self.combo_legs += 1
        if d.oco is not None and d.oco_ack is not None and d.oco_ack.get("accepted"):
            p, a = d.oco, d.oco_ack
            smp = self.smp.get(p["gateway_id"], "NONE")
            for leg, oid in (
                (p["leg1"], a["order_id_1"]),
                (p["leg2"], a["order_id_2"]),
            ):
                o = _Order(
                    id=oid,
                    side=leg["side"],
                    kind=leg["order_type"],
                    price=leg.get("price_ticks"),
                    remaining=int(p["quantity"]),
                    gw=p["gateway_id"],
                    smp=smp,
                    stop=leg.get("stop_price_ticks"),
                    offset=leg.get("trail_offset_ticks"),
                    oco=p["oco_id"],
                )
                out.append((p["symbol"], o))
        for symbol, o in out:
            self.symbol_of[o.id] = symbol
            if o.price is not None and d.new is None:
                # OCO and combo legs: the collar applies to every priced
                # order, whichever way it entered -- but a market maker's
                # quote and a seed (X30, decided 2026-10-29).
                entry = "quote" if d.quote else "order.oco" if d.oco else "order.combo" if d.combo else "seed"  # fmt: skip
                self._band(symbol, o.price, entry, o.id, None)
        return out

    def _band(self, symbol: str, price: int, entry: str, order_id: str, ack: dict[str, Any] | None) -> None:  # fmt: skip
        """D8: an accepted priced order lies inside its symbol's collar
        (risk.band's static band, ``dynamic_band_pct`` around the last
        trade, each edge truncated to a tick); one refused with
        COLLAR_BREACH lies outside it."""
        band = self.bands.get(symbol)
        if band is None or entry in ("seed", "quote"):
            return
        low, high, pct = band
        last = self._book(symbol).last
        inside = low <= price <= high and (
            last is None or int(last * (1 - pct)) <= price <= int(last * (1 + pct))
        )
        refused = ack is not None and ack.get("reject_code") == "COLLAR_BREACH"
        if ack is None or ack.get("accepted") or refused:
            self.entries_banded += 1
        if refused and inside:
            self._flag("D8", error="refused as a collar breach inside the collar", order_id=order_id, symbol=symbol, price=price, static=(low, high), last=last)  # fmt: skip
        elif not inside and not refused and (ack is None or ack.get("accepted")):
            self._flag("D8", error="accepted outside the collar", entry=entry, order_id=order_id, symbol=symbol, price=price, static=(low, high), last=last)  # fmt: skip

    # --- one symbol's part of a dispatch ---------------------------------

    def _symbol_step(
        self,
        book: _Book,
        commands: list[_Order],
        trades: list[dict[str, Any]],
        auction: dict[str, Any] | None,
        fills: list[dict[str, Any]],
        after: str | None,
        amends: list[dict[str, Any]],
        fired: list[str] | None,
        decision: dict[str, Any] | None,
    ) -> None:
        self.trades, self.ti = trades, 0
        self.triggered = []
        self.remaining_after = {}
        dying = set(self.dead)
        halted = book.symbol in self.halted
        matching = self.phase in ("CONTINUOUS", None) and not halted
        if halted:
            for t in trades:
                if t["aggressor_side"] != "AUCTION":
                    self._flag("D11", trade_id=t["id"], symbol=book.symbol, aggressor=_aggressor(t))  # fmt: skip
        if auction is not None or (trades and trades[0]["aggressor_side"] == "AUCTION"):
            self._uncross(book, auction, dying, decision)
        queue = list(commands)
        for amended in amends:
            self._amend(book, amended, queue)
        while queue:
            self._process(book, self._pick(queue), matching, dying, cascade=True)
        while self.ti < len(self.trades):
            self._stray(book, dying)

        for o in self.triggered:
            if o.kind == "MARKET" and o.remaining > 0 and o.id not in self.dead:
                if not o.traded:
                    self._flag(
                        "C7",
                        error="replay triggered the stop; the engine reported nothing",
                        order_id=o.id,
                        symbol=book.symbol,
                        stop=o.stop,
                        last=book.last,
                    )
                    # The engine still holds it armed; so does the replay.
                    o.kind, o.triggered = o.armed_as, False
                    book.arm(o, o.seq)
                else:
                    self._flag(
                        "D9",
                        error="triggered stop traded part and its rest was not cancelled",
                        order_id=o.id,
                        symbol=book.symbol,
                    )
        for oid, reason in self.dead.items():
            if self.symbol_of.get(oid, self.dead_symbol.get(oid)) != book.symbol:
                continue
            armed = book.stops.get(oid) or book.trailing.get(oid)
            if armed is not None and reason in _TRIGGERED_REASONS:
                self._flag(
                    "C7",
                    error="the engine triggered the stop; the replay did not",
                    order_id=oid,
                    symbol=book.symbol,
                    stop=armed.stop,
                    last=book.last,
                    reason=reason,
                )
            book.remove(oid)
            self.symbol_of.pop(oid, None)

        for f in fills:
            tids = f.get("trade_ids") or []
            if not tids:
                continue
            mine = self.remaining_after.get((f["order_id"], tids[-1]))
            if mine is not None and mine != f["remaining_qty"]:
                self._flag(
                    "D9",
                    error="fill's remaining_qty differs from the replay's",
                    order_id=f["order_id"],
                    trade_id=tids[-1],
                    engine=f["remaining_qty"],
                    replay=mine,
                )
        replayed = [o.id for o in self.triggered]
        if (self.explicit or fired is not None) and replayed != (fired or []):
            self._flag(
                "C7",
                error="the replay's triggered stops are not the engine's order.triggered",
                symbol=book.symbol,
                engine=fired or [],
                replay=replayed,
            )
        for o in self.triggered:
            if o.remaining <= 0 or o.id in self.dead or o.kind == "MARKET":
                if not (o.kind in _STOP_TYPES and not o.triggered):
                    self.symbol_of.pop(o.id, None)

        if after == "CONTINUOUS":
            bid, ask = book.best(BUY), book.best(SELL)
            if bid is not None and ask is not None and bid >= ask:
                b = book.top(BUY, set(), _NOBODY)
                a = book.top(SELL, set(), _NOBODY)
                newest = max((b, a), key=lambda o: o.seq if o else 0)
                self._flag(
                    "D2",
                    symbol=book.symbol,
                    bid=bid,
                    ask=ask,
                    bid_order=b.id if b else None,
                    ask_order=a.id if a else None,
                    rested_last=newest.id if newest else None,
                )

    def _amend(self, book: _Book, a: dict[str, Any], queue: list[_Order]) -> None:
        """``order.amended``: a price change or a bigger quantity goes to the
        back of the queue (an iceberg refilling its slice), a smaller
        quantity keeps its place (and can only shrink the slice). A
        marketable amend is pulled and matched as an aggressor."""
        self.amends += 1
        o = book.orders.get(a["order_id"])
        if o is None:
            self._flag("D9", error="amend of an order the replayed book does not hold", order_id=a["order_id"], symbol=book.symbol)  # fmt: skip
            return
        price = a.get("price_ticks", o.price)
        if price != o.price and price is not None:
            self._band(book.symbol, int(price), "order.amend", o.id, None)
        rule = price != o.price or int(a["qty"]) > int(a.get("old_qty") or a["qty"])
        if bool(a["priority_reset"]) != rule:
            self._flag("D5", error="amend's priority_reset is not the rule's", order_id=o.id, priority_reset=a["priority_reset"], old_price=o.price, price=price, old_qty=a.get("old_qty"), qty=a["qty"])  # fmt: skip
        if a.get("priority_seq") is not None:
            self.engine_seq[o.id] = int(a["priority_seq"])
        left = int(a["remaining_qty"])
        if a["priority_reset"]:
            book.remove(o.id)
            o.price, o.remaining = price, left
            book.rest(o, self._next_seq())
        else:
            book.version += 1
            shown = min(o.shown, left) if o.peak else left
            book.qty[o.side] += shown - o.shown
            o.remaining, o.shown = left, shown
        if any(_aggressor(t) == o.id for t in self.trades[self.ti :]):
            book.remove(o.id)
            queue.append(o)

    def _queue_order(self, symbol: str, traces: list[dict[str, Any]]) -> None:
        """D5 against the engine's own word: where an order rested or an
        iceberg refilled, the replayed level must queue its orders in the
        engine's priority_seq order."""
        book = self.books.get(symbol)
        if book is None or symbol in self.diverged:
            return
        levels = set()
        for t in traces:
            if t["kind"] in ("RESTED", "ICEBERG_REFILL") and t.get("priority_seq") is not None:  # fmt: skip
                self.engine_seq[t["order_id"]] = int(t["priority_seq"])
                o = book.orders.get(t["order_id"])
                if o is not None and o.price is not None:
                    levels.add((o.side, o.price))
        for side, price in levels:
            seqs = [(self.engine_seq.get(oid), oid) for oid in book.levels[side].get(price, {})]  # fmt: skip
            known = [q for q in seqs if q[0] is not None]
            if known != sorted(known):
                self._flag("D5", error="replayed queue differs from the engine's priority_seq", symbol=symbol, side=side, price=price, queue=[oid[:8] for _, oid in known])  # fmt: skip

    def _pick(self, queue: list[_Order]) -> _Order:
        """The next order the engine matched: the next trade's aggressor if
        it is queued, else the first in the queue."""
        if self.ti < len(self.trades):
            aid = _aggressor(self.trades[self.ti])
            for i, o in enumerate(queue):
                if o.id == aid:
                    return queue.pop(i)
        return queue.pop(0)

    def _process(
        self, book: _Book, o: _Order, matching: bool, dying: set[str], cascade: bool
    ) -> bool:
        """``OrderBook.process`` as the replay models it; True if it traded."""
        if not matching:
            if o.kind in _STOP_TYPES:
                book.arm(o, self._next_seq())
            elif o.kind in ("LIMIT", "ICEBERG") and o.id not in dying:
                book.rest(o, self._next_seq())
            return False
        if o.kind in _STOP_TYPES and not o.triggered:
            if book.last is None:
                # No trade yet in this replay: trust what the engine did.
                breached = (
                    self.ti < len(self.trades)
                    and _aggressor(self.trades[self.ti]) == o.id
                ) or self.dead.get(o.id) in _TRIGGERED_REASONS
            else:
                breached = _breached(o, book.last)
            if not breached:
                book.arm(o, self._next_seq())
                return False
            self._convert(book, o)
        traded = self._sweep(book, o, dying)
        if o.remaining > 0 and o.kind in ("LIMIT", "ICEBERG") and o.id not in dying:
            book.rest(o, self._next_seq())
        if traded and cascade:
            # First in, first out, as the engine runs them: a stop-limit
            # that trades nothing still rests before the next stop runs.
            pending = self._checkpoint(book)
            while pending:
                nxt = pending.pop(0)
                if self._process(book, nxt, True, dying, cascade=False):
                    pending += self._checkpoint(book)
        return traded

    def _convert(self, book: _Book, o: _Order) -> None:
        book.stops.pop(o.id, None)
        book.trailing.pop(o.id, None)
        o.triggered = True
        o.armed_as = o.kind
        self.stops_triggered += 1
        if o.kind == "STOP_LIMIT":
            o.kind = "LIMIT"
        else:
            o.kind, o.price = "MARKET", None
        self.triggered.append(o)

    def _checkpoint(self, book: _Book) -> list[_Order]:
        """The stops the engine's ``_check_stops`` + ``_check_trailing_stops``
        trigger at the book's last trade price, in the engine's order."""
        last = book.last
        if last is None:
            return []
        plain = list(book.stops.values())
        buys = sorted(
            (
                s
                for s in plain
                if s.side == BUY and s.stop is not None and last >= s.stop
            ),
            key=lambda s: (s.stop, s.seq),
        )
        sells = sorted(
            (
                s
                for s in plain
                if s.side == SELL and s.stop is not None and last <= s.stop
            ),
            key=lambda s: (-(s.stop or 0), s.seq),
        )
        trailing = []
        for s in book.trailing.values():
            if s.stop is None or s.offset is None:
                continue
            if s.side == SELL:
                s.stop = max(s.stop, last - s.offset)
                hit = last <= s.stop
            else:
                s.stop = min(s.stop, last + s.offset)
                hit = last >= s.stop
            if hit:
                trailing.append(s)
        fired = buys + sells + trailing
        for s in fired:
            self._convert(book, s)
        return fired

    def _sweep(self, book: _Book, o: _Order, dying: set[str]) -> bool:
        traded = False
        while self.ti < len(self.trades) and _aggressor(self.trades[self.ti]) == o.id:
            t = self.trades[self.ti]
            self.ti += 1
            traded = o.traded = True
            self._continuous_trade(book, t, o, dying)
        return traded

    def _continuous_trade(
        self, book: _Book, t: dict[str, Any], agg: _Order, dying: set[str]
    ) -> None:
        self.trades_replayed += 1
        if t.get("match_type") not in (None, "CONTINUOUS"):
            self._flag("D6", error="continuous match not marked CONTINUOUS", trade_id=t["id"], match_type=t["match_type"])  # fmt: skip
        price = self._price(book, t)
        qty = int(t["quantity"])
        passive_id = t["sell_order_id"] if agg.side == BUY else t["buy_order_id"]
        if t["buy_gateway_id"] == t["sell_gateway_id"] and agg.smp != "NONE":
            self._flag(
                "D7", trade_id=t["id"], gateway_id=t["buy_gateway_id"], smp=agg.smp
            )
        if agg.price is not None and (
            price > agg.price if agg.side == BUY else price < agg.price
        ):
            self._flag(
                "D3",
                trade_id=t["id"],
                order_id=agg.id,
                side=agg.side,
                limit=agg.price,
                price=price,
            )
        p = book.orders.get(passive_id)
        if p is None:
            self._flag(
                "D9",
                error="trade against an order the replayed book does not hold",
                trade_id=t["id"],
                order_id=passive_id,
                armed_stop=passive_id in book.stops or passive_id in book.trailing,
            )
        else:
            if price != p.price:
                self._flag(
                    "D4",
                    error="trade not at the resting order's price",
                    trade_id=t["id"],
                    order_id=p.id,
                    resting_price=p.price,
                    price=price,
                )
            self._priority(book, t, p, dying)
            want = min(agg.remaining, p.shown)
            if qty != want:
                self._flag(
                    "D5",
                    error="fill size is not min(aggressor left, resting shown)",
                    trade_id=t["id"],
                    order_id=p.id,
                    qty=qty,
                    expected=want,
                )
            book.fill(p, qty, self._next_seq())
            self.remaining_after[(p.id, t["id"])] = p.remaining
        agg.remaining -= qty
        self.remaining_after[(agg.id, t["id"])] = agg.remaining
        book.last = price

    def _priority(
        self, book: _Book, t: dict[str, Any], p: _Order, dying: set[str]
    ) -> None:
        first = book.top(p.side, dying, p)
        if first is None or first is p:
            return
        assert first.price is not None and p.price is not None
        better = first.price > p.price if p.side == BUY else first.price < p.price
        if better:
            self._flag(
                "D4",
                error="a better price was resting",
                trade_id=t["id"],
                order_id=p.id,
                price=p.price,
                better_order=first.id,
                better_price=first.price,
            )
        elif first.price == p.price:
            self._flag(
                "D5",
                error="an earlier order at the same price was passed over",
                trade_id=t["id"],
                order_id=p.id,
                ahead=first.id,
                price=p.price,
            )

    def _stray(self, book: _Book, dying: set[str]) -> None:
        """A trade whose aggressor the replay was not matching."""
        t = self.trades[self.ti]
        aid = _aggressor(t)
        armed = book.stops.get(aid) or book.trailing.get(aid)
        if armed is not None:
            self._flag(
                "C7",
                error="the engine traded a stop the replay had not triggered",
                order_id=aid,
                trade_id=t["id"],
                symbol=book.symbol,
                stop=armed.stop,
                last=book.last,
            )
            self._convert(book, armed)
            self._process(book, armed, True, dying, cascade=True)
            return
        self._flag(
            "D9",
            error="trade by an order the replay was not matching",
            trade_id=t["id"],
            order_id=aid,
            symbol=book.symbol,
        )
        self.ti += 1
        passive_id = (
            t["sell_order_id"] if t["aggressor_side"] == BUY else t["buy_order_id"]
        )
        p = book.orders.get(passive_id)
        if p is not None:
            book.fill(p, int(t["quantity"]), self._next_seq())
        book.last = self._price(book, t)

    # --- auctions --------------------------------------------------------

    def _decision(
        self,
        book: _Book,
        decision: dict[str, Any],
        decided: tuple[_Uncross, int, str, list[int]] | None,
        auction: dict[str, Any] | None,
    ) -> None:
        """D6: the engine's UNCROSS_PRICE (S36) is the replay's, step by
        step -- the differing fields name the step that went another way."""
        self.decisions += 1
        keys = ("eq_price_ticks", "eq_qty", "surplus", "rule", "tied_prices_ticks")
        theirs = [decision.get(k, [] if k == "tied_prices_ticks" else None) for k in keys]  # fmt: skip
        mine: list[Any] = [None] * len(keys)
        if decided is not None:
            (_, qty, surplus, _), price, rule, tied = decided
            mine = [price, qty, surplus, rule, tied]
        differs = {k: (t, m) for k, t, m in zip(keys, theirs, mine) if t != m}
        if differs:
            self._flag("D6", error="uncross decision differs from the replay's", symbol=book.symbol, auction_id=decision.get("auction_id"), engine_replay=differs)  # fmt: skip
        if auction is not None and auction.get("auction_id") != decision.get("auction_id"):  # fmt: skip
            self._flag("D6", error="UNCROSS_PRICE's auction_id is not its auction.result's", symbol=book.symbol, trace=decision.get("auction_id"), result=auction.get("auction_id"))  # fmt: skip

    def _uncross(
        self,
        book: _Book,
        auction: dict[str, Any] | None,
        dying: set[str],
        decision: dict[str, Any] | None,
    ) -> None:
        decided = _decided(book)
        eq = None if decided is None or decided[0][0] is None else decided[0][:2]
        if decision is not None and decision.get("rule") != "OVERRIDE":
            self._decision(book, decision, decided, auction)
        prints: list[dict[str, Any]] = []
        while (
            self.ti < len(self.trades)
            and self.trades[self.ti]["aggressor_side"] == "AUCTION"
        ):
            prints.append(self.trades[self.ti])
            self.ti += 1
        sym = book.symbol
        if prints:
            self.uncrosses += 1
            self.trades_replayed += len(prints)
        prices = {self._price(book, t) for t in prints}
        total = sum(int(t["quantity"]) for t in prints)
        if len(prices) > 1:
            self._flag(
                "D6",
                error="uncross printed more than one price",
                symbol=sym,
                prices=sorted(prices),
            )
        price = min(prices) if prices else None
        if (price, total) != ((eq[0], eq[1]) if eq else (None, 0)):
            self._flag(
                "D6",
                error="print differs from the replay's equilibrium",
                symbol=sym,
                printed=price,
                qty=total,
                replay=eq,
            )
        for t in prints:
            kind = t.get("match_type")
            if kind == "CONTINUOUS":
                self._flag("D6", error="uncross print marked CONTINUOUS", trade_id=t["id"])  # fmt: skip
            if auction is not None and auction.get("auction_id") and t.get("auction_id") != auction["auction_id"]:  # fmt: skip
                self._flag("D6", error="print's auction_id is not its auction.result's", trade_id=t["id"], print=t.get("auction_id"), result=auction["auction_id"])  # fmt: skip
        if auction is not None:
            stated = auction.get("eq_price")
            stated_ticks = _ticks(stated, book.td) if stated is not None else None
            if prints and (stated_ticks, auction.get("eq_qty")) != (price, total):
                self._flag(
                    "D6",
                    error="auction.result differs from the prints",
                    symbol=sym,
                    result=(stated_ticks, auction.get("eq_qty")),
                    printed=(price, total),
                )
        for t in prints:
            buyer = book.orders.get(t["buy_order_id"])
            seller = book.orders.get(t["sell_order_id"])
            if buyer is None or seller is None:
                self._flag(
                    "D9",
                    error="uncross print of an order the replay does not hold",
                    trade_id=t["id"],
                    buy=t["buy_order_id"],
                    sell=t["sell_order_id"],
                )
                continue
            if (
                book.top(BUY, dying, buyer) is not buyer
                or book.top(SELL, dying, seller) is not seller
            ):
                self._flag(
                    "D6", error="uncross filled out of priority", trade_id=t["id"]
                )
            qty = int(t["quantity"])
            if qty != min(buyer.shown, seller.shown):
                self._flag(
                    "D6",
                    error="uncross fill is not the smaller shown quantity",
                    trade_id=t["id"],
                    qty=qty,
                    expected=min(buyer.shown, seller.shown),
                )
            if t["buy_gateway_id"] == t["sell_gateway_id"]:
                self.auction_self_trades += 1
            book.fill(buyer, qty, self._next_seq())
            self.remaining_after[(buyer.id, t["id"])] = buyer.remaining
            book.fill(seller, qty, self._next_seq())
            self.remaining_after[(seller.id, t["id"])] = seller.remaining
        if not prints:
            return
        book.last = price
        # Orders the dispatch cancels (SMP resolves the pairs the walk left
        # crossed) are not part of the book that remains.
        top_bid, top_ask = book.top(BUY, dying, _NOBODY), book.top(SELL, dying, _NOBODY)
        bid = top_bid.price if top_bid is not None else None
        ask = top_ask.price if top_ask is not None else None
        if bid is not None and ask is not None and bid >= ask:
            self._flag(
                "D6",
                error="book still crossed after the uncross",
                symbol=sym,
                bid=bid,
                ask=ask,
            )
        # Each stop the print triggers is processed with its own cascade
        # (Engine._run_uncross calls book.process for each).
        queue = self._checkpoint(book)
        while queue:
            self._process(book, self._pick(queue), True, dying, cascade=True)

    # --- snapshots -------------------------------------------------------

    def _snapshot(self, p: dict[str, Any]) -> None:
        sym = p["symbol"]
        if not (self.synced_all or sym in self.synced):
            return  # after a restart, before its checkpoint: no book to compare
        td = int(p.get("tick_decimals", self.td.get(sym, 2)))
        book = self._book(sym)
        bids, asks = p["bids"], p["asks"]
        self.snapshots += 1
        if (
            self.phase == "CONTINUOUS"
            and sym not in self.halted
            and bids
            and asks
            and bids[0]["price"] >= asks[0]["price"]
        ):
            self._flag(
                "D1",
                symbol=sym,
                bid=bids[0]["price"],
                ask=asks[0]["price"],
                ts_ns=p.get("ts_ns"),
            )
        engine = {
            BUY: {_ticks(lv["price"], td): (lv["qty"], lv["count"]) for lv in bids},
            SELL: {_ticks(lv["price"], td): (lv["qty"], lv["count"]) for lv in asks},
        }
        same = all(
            _fingerprint(engine[s], s) == (book.best(s), book.qty[s], book.count[s])
            for s in (BUY, SELL)
        )
        if same:
            self.diverged.discard(sym)
            return
        self.snapshots_differing += 1
        if sym in self.diverged:
            return
        self.diverged.add(sym)
        diff = []
        for s in (BUY, SELL):
            mine = book.view(s)
            for price in sorted(set(mine) | set(engine[s]), reverse=s == BUY):
                if mine.get(price) != engine[s].get(price):
                    diff.append((s, price, engine[s].get(price), mine.get(price)))
        self._flag(
            "D9",
            error="replayed book differs from the engine's snapshot",
            symbol=sym,
            ts_ns=p.get("ts_ns"),
            levels="; ".join(
                f"{s} {price}: engine {e} replay {m}" for s, price, e, m in diff[:4]
            ),
        )

    def _adopt(self, p: dict[str, Any]) -> None:
        """A book checkpoint: compare it with the replayed book where that is
        in sync (D9, order by order), then take it as the book."""
        sym = p["symbol"]
        self.checkpoints += 1
        if self.phase is None and p.get("phase"):
            self.phase = p["phase"]
        mine = self.books.get(sym)
        if mine is not None and (self.synced_all or sym in self.synced) and sym not in self.diverged:  # fmt: skip
            theirs = _checkpoint_view(p)
            ours = _book_view(mine)
            for key in theirs:
                if ours[key] != theirs[key]:
                    self._flag("D9", error=f"replayed {key} differ from the engine's checkpoint", symbol=sym, reason=p.get("reason"), engine=str(theirs[key])[:300], replay=str(ours[key])[:300])  # fmt: skip
                    break
        book = self.books[sym] = _Book(sym, self.td.get(sym, 2))
        self._uncross_at.pop(sym, None)  # a new book restarts its version
        top = self.seq
        for side, key in ((BUY, "bids"), (SELL, "asks")):
            for r in p.get(key) or []:
                o = self._from_record(r)
                book.rest(o, int(r.get("priority_seq") or 0))
                if r.get("priority_seq") is not None:
                    self.engine_seq[o.id] = int(r["priority_seq"])
                shown = r.get("displayed_qty")
                if shown is not None and o.peak:
                    book.qty[side] += int(shown) - o.shown
                    o.shown = int(shown)
                top = max(top, o.seq)
        for key in ("buy_stops", "sell_stops", "trailing_stops"):
            for r in p.get(key) or []:
                o = self._from_record(r)
                book.arm(o, int(r.get("priority_seq") or 0))
                top = max(top, o.seq)
        book.last = p.get("last_trade_price_ticks")
        # New orders must queue behind every adopted one.
        self.seq = top
        self.diverged.discard(sym)
        self.synced.add(sym)

    def _from_ack(self, gw: str, a: dict[str, Any]) -> _Order:
        return _Order(
            id=a["order_id"],
            side=a["side"],
            kind=a["order_type"],
            price=a.get("price_ticks"),
            remaining=int(a["qty"]),
            gw=gw,
            smp=a.get("smp_action") or self.smp.get(gw, "NONE"),
            peak=a.get("visible_qty"),
            stop=a.get("stop_price_ticks"),
            offset=a.get("trail_offset_ticks"),
            oco=a.get("oco_group_id"),
        )

    def _from_record(self, r: dict[str, Any]) -> _Order:
        o = _Order(
            id=r["order_id"],
            side=r["side"],
            kind=r["order_type"],
            price=r.get("price_ticks"),
            remaining=int(r["remaining_qty"]),
            gw=r["gateway_id"],
            smp=r.get("smp_action") or "NONE",
            peak=r.get("visible_qty"),
            stop=r.get("stop_price_ticks"),
            offset=r.get("trail_offset_ticks"),
            oco=r.get("oco_group_id"),
        )
        return o

    def _indicative(self, p: dict[str, Any]) -> None:
        """D10: the engine's indicative uncross is the replayed book's."""
        sym = p["symbol"]
        if sym in self.diverged:
            self.indicatives_skipped += 1  # D9 already names the divergence
            return
        self.indicatives += 1
        book = self._book(sym)
        cached = self._uncross_at.get(sym)
        if cached is not None and cached[0] == book.version:
            mine = cached[1]
        else:
            mine = _uncross_of(book)
            self._uncross_at[sym] = (book.version, mine)
        price = p.get("eq_price")
        engine = (
            _ticks(price, book.td) if price is not None else None,
            p.get("eq_qty") or 0,
            p.get("imbalance_qty") or 0,
            p.get("imbalance_side") or "",
        )
        replay = mine if mine is not None else (None, 0, 0, "")
        if engine != replay:
            self._flag(
                "D10",
                symbol=sym,
                phase=p.get("phase"),
                engine=list(engine),
                replay=list(replay),
            )

    def _price(self, book: _Book, t: dict[str, Any]) -> int:
        """The trade's price in ticks: ``price_ticks``, canonical, when the
        trade carries it; the display price must lie on the grid and agree."""
        td = int(t.get("tick_decimals", book.td))
        raw = float(t["price"]) * 10.0**td
        ticks = round(raw)
        if abs(raw - ticks) > 1e-6:
            self._flag("D8", trade_id=t["id"], price=t["price"], tick_decimals=td)
        canonical = t.get("price_ticks")
        if canonical is None:
            return ticks
        if canonical != ticks:
            self._flag("D8", error="display price is not price_ticks", trade_id=t["id"], price=t["price"], price_ticks=canonical)  # fmt: skip
        return int(canonical)


class _Nobody:
    """Stands in for "no order to keep" in ``_Book.top``."""


_NOBODY: Any = _Nobody()


def _book_view(book: _Book) -> dict[str, Any]:
    """The replayed book as a checkpoint lists it: each side in priority
    order (id, remaining, shown), stops (id, trigger) in trigger order,
    trailing stops in arming order."""
    side = {
        s: [
            (o.id, o.remaining, o.shown)
            for price in sorted(book.levels[s], reverse=s == BUY)
            for o in book.levels[s][price].values()
        ]
        for s in (BUY, SELL)
    }
    stops = sorted(book.stops.values(), key=lambda o: (o.side, o.stop if o.side == BUY else -(o.stop or 0), o.seq))  # fmt: skip
    return {
        "bids": side[BUY],
        "asks": side[SELL],
        "stops": [(o.id, o.stop) for o in stops],
        "trailing stops": [(o.id, o.stop) for o in book.trailing.values()],
    }


def _checkpoint_view(p: dict[str, Any]) -> dict[str, Any]:
    def side(rows: list[dict[str, Any]]) -> list[tuple[Any, ...]]:
        return [
            (r["order_id"], r["remaining_qty"], r["displayed_qty"] if r.get("visible_qty") else r["remaining_qty"])  # fmt: skip
            for r in rows
        ]

    return {
        "bids": side(p.get("bids") or []),
        "asks": side(p.get("asks") or []),
        "stops": [(r["order_id"], r["stop_price_ticks"]) for r in (p.get("buy_stops") or []) + (p.get("sell_stops") or [])],  # fmt: skip
        "trailing stops": [(r["order_id"], r["stop_price_ticks"]) for r in p.get("trailing_stops") or []],  # fmt: skip
    }


def _fingerprint(
    levels: dict[int, tuple[int, int]], side: str
) -> tuple[int | None, int, int]:
    """(best price, shown quantity, order count) of one side."""
    if not levels:
        return None, 0, 0
    best = max(levels) if side == BUY else min(levels)
    return best, sum(q for q, _ in levels.values()), sum(c for _, c in levels.values())


def _ticks(price: float, td: int) -> int:
    return round(float(price) * 10.0**td)


def _aggressor(t: dict[str, Any]) -> str:
    return str(t["buy_order_id"] if t["aggressor_side"] == BUY else t["sell_order_id"])


def _breached(o: _Order, last: int) -> bool:
    if o.stop is None:
        return False
    return last >= o.stop if o.side == BUY else last <= o.stop


#: (price, executable qty, surplus, imbalance side "BUY"/"SELL"/"").
_Uncross = tuple[int | None, int, int, str]


def _smp_action(bid: _Order, ask: _Order) -> tuple[str, bool]:
    """The SMP policy of a crossing bid and ask of one gateway, and whether
    it is the ask's: both are resting, so the bid's policy wins and the ask's
    applies only when the bid's is NONE."""
    if bid.gw != ask.gw:
        return "NONE", False
    if bid.smp != "NONE":
        return bid.smp, False
    return ask.smp, True


def _walk(book: _Book, price: int) -> tuple[int, int, int]:
    """The uncross walk at *price*, SMP included, without trading anything:
    (executed, buy total, sell total), the totals being what traded plus what
    survives of the orders that cross *price*. An iceberg trades its shown
    slice and refills at the back of its level."""

    def queues(side: str) -> list[deque[list[Any]]]:
        prices = sorted(book.levels[side], reverse=side == BUY)
        return [
            deque([o, o.remaining, o.shown] for o in book.levels[side][p].values())
            for p in prices
            if (p >= price if side == BUY else p <= price)
        ]

    bids, asks = queues(BUY), queues(SELL)
    everyone = [c for qs in (bids, asks) for q in qs for c in q]
    gone: set[int] = set()  # ids of cancelled or used-up candidates

    def head(
        levels: list[deque[list[Any]]],
    ) -> tuple[deque[list[Any]], list[Any]] | None:
        for level in levels:
            while level and id(level[0]) in gone:
                level.popleft()
            if level:
                return level, level[0]
        return None

    def cancel(c: list[Any]) -> None:
        c[1] = c[2] = 0
        gone.add(id(c))

    traded = 0
    while True:
        top_bid, top_ask = head(bids), head(asks)
        if top_bid is None or top_ask is None:
            break
        bid, ask = top_bid[1], top_ask[1]
        action, from_ask = _smp_action(bid[0], ask[0])
        if action != "NONE":
            aggressor, passive = (ask, bid) if from_ask else (bid, ask)
            if action in ("CANCEL_AGGRESSOR", "CANCEL_BOTH"):
                cancel(aggressor)
            if action in ("CANCEL_RESTING", "CANCEL_BOTH"):
                cancel(passive)
            continue
        fill = min(bid[2], ask[2])
        traded += fill
        for level, c in (top_bid, top_ask):
            c[1] -= fill
            c[2] -= fill
            if c[1] == 0:
                level.popleft()
                gone.add(id(c))
            elif c[2] == 0:
                c[2] = min(c[0].peak or 0, c[1])
                level.popleft()
                level.append(c)
    buy = traded + sum(c[1] for c in everyone if c[0].side == BUY)
    sell = traded + sum(c[1] for c in everyone if c[0].side == SELL)
    return traded, buy, sell


def _uncross_of(book: _Book) -> _Uncross | None:
    """The uncross the book makes: the most executable quantity, then the
    least surplus, then the lowest price; hidden iceberg quantity counts, and
    so does SMP -- an order that would trade its own gateway's is cancelled in
    the walk, so the quantity at a price is the walk's, not the curves'."""
    decided = _decided(book)
    return None if decided is None else decided[0]


def _decided(book: _Book) -> tuple[_Uncross, int, str, list[int]] | None:
    """``_uncross_of``'s uncross, the price it runs at (also when nothing
    prints there), the rule that decided it (VOLUME, SURPLUS, LOWEST_PRICE)
    and the prices still tied when it did -- what engine.trace UNCROSS_PRICE
    says (S36)."""
    bids: dict[int, int] = defaultdict(int)
    asks: dict[int, int] = defaultdict(int)
    for o in book.orders.values():
        assert o.price is not None
        (bids if o.side == BUY else asks)[o.price] += o.remaining
    if not bids or not asks:
        return None
    prices = sorted(set(bids) | set(asks))
    # buy[i]: bids at prices[i] or above; sell[i]: asks at prices[i] or below.
    buy, sell = [0] * len(prices), [0] * len(prices)
    running = 0
    for i in range(len(prices) - 1, -1, -1):
        running += bids.get(prices[i], 0)
        buy[i] = running
    running = 0
    for i, price in enumerate(prices):
        running += asks.get(price, 0)
        sell[i] = running
    candidates = [i for i in range(len(prices)) if min(buy[i], sell[i])]
    if not candidates:
        return None
    # A gateway on both sides with a policy is the only way the walk can
    # differ from the curves.
    policy = {o.gw for o in book.orders.values() if o.smp != "NONE"}
    sides = {BUY: set[str](), SELL: set[str]()}
    for o in book.orders.values():
        sides[o.side].add(o.gw)
    simulate = bool(policy & sides[BUY] & sides[SELL])
    best: tuple[int, int, int] | None = None  # (-qty, surplus, price): least wins
    side = ""
    walked: list[tuple[int, int, int]] = []
    # Best bound first; nothing after a bound below the best found can win.
    for i in sorted(candidates, key=lambda j: -min(buy[j], sell[j])):
        bound = min(buy[i], sell[i])
        if best is not None and bound < -best[0]:
            break
        if simulate:
            qty, b, a = _walk(book, prices[i])
        else:
            qty, b, a = bound, buy[i], sell[i]
        key = (-qty, abs(b - a), prices[i])
        walked.append(key)
        if best is None or key < best:
            best, side = key, "BUY" if b > a else "SELL" if a > b else ""
    assert best is not None
    qty = -best[0]
    most = sorted(p for q, _, p in walked if q == best[0])
    least = sorted(p for q, s, p in walked if q == best[0] and s == best[1])
    rule, tied = (
        ("VOLUME", most)
        if len(most) == 1
        else ("SURPLUS", most) if len(least) == 1 else ("LOWEST_PRICE", least)
    )
    return ((best[2] if qty else None), qty, best[1], side), best[2], rule, tied


def _replay(ds: Dataset) -> _Replay:
    cached = ds.cache.get("matching")
    if isinstance(cached, Skipped):
        raise cached
    if isinstance(cached, _Replay):
        return cached
    try:
        files = audit_files(ds.data_dir)
        if not files:
            raise Skipped("no audit.log in the data dir")
        try:
            engine = json.loads(run_config_text(files))["engine"]
        except Skipped:
            # An audit from mid-run: tick sizes then come from the messages
            # (trades and books carry them), SMP modes from acks and checkpoints.
            engine = {}
        smp = {
            gw: str(c.get("smp_action") or "NONE")
            for gw, c in engine.get("participants", {}).items()
        }
        replay = _Replay(engine.get("symbols", {}), smp)
        replay.run(lines(files))
    except Skipped as exc:
        ds.cache["matching"] = exc
        raise
    ds.cache["matching"] = replay
    return replay


def _outcome(ds: Dataset, cid: str, note: str = "") -> Outcome:
    r = _replay(ds)
    return Outcome(r.counts[cid], r.samples[cid], note)


@check(
    "D1",
    "book-state",
    "The engine's book snapshots are never crossed in CONTINUOUS",
    needs=(),
)
def crossed_snapshots(ds: Dataset) -> Outcome:
    r = _replay(ds)
    return _outcome(ds, "D1", f"{r.snapshots} snapshots")


@check(
    "D2",
    "book-state",
    "No order rests marketable: after each dispatch in CONTINUOUS the replayed book is uncrossed",
    needs=(),
)
def marketable_rested(ds: Dataset) -> Outcome:
    r = _replay(ds)
    return _outcome(
        ds, "D2", f"{r.dispatches} dispatches, {r.trades_replayed} trades replayed"
    )


@check("D3", "book-state", "Every fill is at or inside the aggressor's limit", needs=())
def limits(ds: Dataset) -> Outcome:
    return _outcome(ds, "D3")


@check(
    "D4",
    "book-state",
    "Every fill is at the resting order's price, the best opposite price (no trade-through)",
    needs=(),
)
def trade_through(ds: Dataset) -> Outcome:
    return _outcome(ds, "D4")


@check(
    "D5",
    "book-state",
    "Fills follow time priority in a level, each as big as the aggressor and the shown slice allow",
    needs=(),
)
def priority(ds: Dataset) -> Outcome:
    return _outcome(ds, "D5")


@check(
    "D6",
    "book-state",
    "Each uncross prints one volume-maximising price, as auction.result says, in priority",
    needs=(),
)
def uncross(ds: Dataset) -> Outcome:
    r = _replay(ds)
    return _outcome(
        ds,
        "D6",
        f"{r.uncrosses} uncrosses with prints, {r.decisions} price decisions compared",
    )


@check(
    "C12",
    "lifecycle",
    "Every refusal holds on the state and book it was made on, and no acceptance meets one",
    needs=(),
)
def refusals_justified(ds: Dataset) -> Outcome:
    """The state part is ``refusals.py``'s pass; the book part this replay's
    (``_Replay._refusals``)."""
    p = refusals.state_pass(ds)
    r = _replay(ds)
    errors = p.errors + r.c12_errors
    samples = (p.samples + r.samples.get("C12", []))[:_KEEP]
    note = ", ".join(f"{k} {n}" for k, n in sorted(p.judged.items()))
    note += f"; on the books: {r.c12_judged} FOK / AON refusals and combos"
    note += "".join(f"; {e}: {n}" for e, n in errors.most_common())
    if p.unjudged:
        note += "; not judged here: " + ", ".join(f"{k} {n}" for k, n in p.unjudged.most_common(8))  # fmt: skip
    return Outcome(sum(errors.values()), samples, note)


@check(
    "C13",
    "lifecycle",
    "A kill switch or a disconnect cancels exactly the live orders it names, for its reason",
    needs=(),
)
def sweeps_complete(ds: Dataset) -> Outcome:
    """``refusals.py``'s pass, which C12 shares."""
    p = refusals.state_pass(ds)
    note = ", ".join(f"{k} {n}" for k, n in sorted(p.sweeps.items())) or "no kill switch or disconnect"  # fmt: skip
    note += "".join(f"; {e}: {n}" for e, n in p.sweep_errors.most_common())
    return Outcome(sum(p.sweep_errors.values()), p.sweep_samples, note)


@check(
    "C14",
    "lifecycle",
    "Orders expire as their time in force ends, never a GTC one, and none outlives it",
    needs=(),
)
def expiries(ds: Dataset) -> Outcome:
    """``refusals.py``'s pass, which C12 and C13 share."""
    p = refusals.state_pass(ds)
    note = ", ".join(f"{k} {n}" for k, n in sorted(p.expiries.items())) or "no window closed"  # fmt: skip
    note += "".join(f"; {e}: {n}" for e, n in p.expiry_errors.most_common())
    return Outcome(sum(p.expiry_errors.values()), p.expiry_samples, note)


@check("D7", "book-state", "No continuous self-trade under SMP", needs=())
def self_trades(ds: Dataset) -> Outcome:
    r = _replay(ds)
    return _outcome(ds, "D7", f"auction self-trades (X2, Q2): {r.auction_self_trades}")


@check(
    "D8",
    "book-state",
    "Trade prices lie on the tick grid; every priced order enters inside its collar",
    needs=(),
)
def tick_grid(ds: Dataset) -> Outcome:
    r = _replay(ds)
    note = f"{r.entries_banded} entries checked against a collar" if r.bands else "no collar in this run"  # fmt: skip
    return _outcome(ds, "D8", note)


@check("D11", "book-state", "No continuous trade in a halted symbol", needs=())
def halted_trades(ds: Dataset) -> Outcome:
    r = _replay(ds)
    return _outcome(ds, "D11", f"{r.halts} halts")


@check(
    "D10",
    "book-state",
    "Each indicative uncross the engine publishes in a call phase is the replayed book's",
    needs=(),
)
def indicatives(ds: Dataset) -> Outcome:
    r = _replay(ds)
    note = f"{r.indicatives} indicatives compared"
    if r.indicatives_skipped:
        note += f", {r.indicatives_skipped} skipped on symbols D9 found diverged"
    return _outcome(ds, "D10", note)


@check(
    "D9",
    "replay",
    "The replayed book equals every engine snapshot and every fill's remaining_qty",
    needs=(),
)
def replay_agrees(ds: Dataset) -> Outcome:
    r = _replay(ds)
    note = (
        f"{r.snapshots} snapshots compared, {r.snapshots_differing} differ; "
        f"{r.checkpoints} checkpoints, {r.restarts} engine restart(s)"
    )
    if r.skipped_lines:
        note += f"; {r.skipped_lines} lines before the first checkpoint not replayed"
    note += f"; {r.amends} amends, {r.combo_legs} combo legs, {r.halts} halts replayed"
    return _outcome(ds, "D9", note)


@check(
    "C7",
    "lifecycle",
    "Stops trigger exactly when a trade reaches their (ratcheted) stop price",
    needs=(),
)
def stop_triggers(ds: Dataset) -> Outcome:
    r = _replay(ds)
    return _outcome(ds, "C7", f"{r.stops_triggered} stops triggered")
