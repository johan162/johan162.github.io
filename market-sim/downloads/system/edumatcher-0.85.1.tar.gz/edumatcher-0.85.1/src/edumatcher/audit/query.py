"""Audit trail parser and filter helpers for pm-audit-cli.

Reads the audit files written by ``pm-audit``, one line per message::

    [2026-07-08T09:30:00.123+00:00] [trade.executed] [seq=12 eseq=4711 msg=01J… chain=01J…] {"id": "000001-000000042", "symbol": "AAPL"}

(the bracketed metadata section is optional, see ``_LINE_RE``), with comment
lines (``# ...``: the file header, a recorder-start marker) in between.
Files are read as plain text (the active log and closed day parts) or
decompressed zstd (daily archives ending in ``.zst``).  All filtering is
applied during streaming so large log files are never fully loaded into
memory.
"""

from __future__ import annotations

import json
import re
from compression import zstd
from datetime import datetime, timezone, tzinfo
from functools import lru_cache
from pathlib import Path
from collections import deque
from itertools import islice
from typing import Any, Iterable, Iterator, cast
from edumatcher.audit.writer import file_day
from edumatcher.models.generated.book import PREFIX_BOOK_SNAPSHOT, PREFIX_DEPTH
from edumatcher.models.generated.order import (
    PREFIX_ORDER_ACK,
    PREFIX_ORDER_AMENDED,
    PREFIX_ORDER_EXPIRED,
    PREFIX_ORDER_FILL,
    TOPIC_ORDER_CANCEL,
    TOPIC_ORDER_NEW,
)
from edumatcher.models.generated.registry import TOPIC_REGISTRY
from edumatcher.models.generated.trade import TOPIC_TRADE_EXECUTED

# ---------------------------------------------------------------------------
# Line format
# ---------------------------------------------------------------------------

# [2026-07-08T09:30:00.123+00:00] [trade.executed] [seq=12 msg=01J… cause=01J… chain=01J…] {...}
#
# The metadata section is optional: a line written before pm-audit recorded the
# envelope, or one whose publisher stamps no envelope, simply has none. Keeping
# it optional here means the parser reads a mixed archive without a flag.
_LINE_RE = re.compile(
    r"^\[(?P<ts>[^\]]+)\]\s+\[(?P<topic>[^\]]+)\]"
    r"(?:\s+\[(?P<meta>[^\]]*)\])?"
    r"\s+(?P<payload>\{.*\})\s*$"
)


def parse_meta(raw: str | None) -> dict[str, str]:
    """Parse the `key=value` metadata section into a dict.

    Unknown keys are kept rather than dropped: this format is meant to grow,
    and a reader that discards what it does not recognise makes that painful.
    """
    if not raw:
        return {}
    out: dict[str, str] = {}
    for token in raw.split():
        key, _, value = token.partition("=")
        if key and value:
            out[key] = value
    return out


# ---------------------------------------------------------------------------
# Topic resolution
#
# A topic read off the wire is either a spec topic verbatim (`order.new`) or a
# wildcard topic with its parameter filled in (`order.ack.TRADER01`). Splitting
# the second into kind and actor cannot be done by string surgery: naive
# rsplit turns `index.corp_action` into `("index", "corp_action")`, inventing
# an actor for a topic that has none. It has to be a lookup against the spec,
# which is what the generated registry is for.
#
# Shared rather than private because pm-audit-replay resolves the same topics,
# and two tools disagreeing about what `order.ack.TRADER01` means would be a
# silent, plausible-looking wrong answer in exactly the place a reader would
# not think to check.
# ---------------------------------------------------------------------------

_EXACT_TOPICS: frozenset[str] = frozenset(
    topic for topic, entry in TOPIC_REGISTRY.items() if not entry["params"]
)

#: (prefix, template), longest prefix first. Order matters: `index.rebalance.`
#: would otherwise be shadowed by a shorter sibling that also matches.
_WILDCARD_PREFIXES: tuple[tuple[str, str], ...] = tuple(
    sorted(
        (
            (str(entry["prefix"]), topic)
            for topic, entry in TOPIC_REGISTRY.items()
            if entry["params"]
        ),
        key=lambda pair: -len(pair[0]),
    )
)


@lru_cache(maxsize=1 << 16)
def _match_topic(topic: str) -> tuple[str, str | None] | None:
    """Return ``(template, actor)`` for a wire topic, or None if unknown.

    Cached: a trail holds a few thousand distinct topics (families times
    gateways or symbols) over millions of lines, and the wildcard prefixes
    are scanned in turn.
    """
    if topic in _EXACT_TOPICS:
        return topic, None
    for prefix, template in _WILDCARD_PREFIXES:
        if topic.startswith(prefix):
            return template, topic[len(prefix) :]
    return None


def split_topic(topic: str) -> tuple[str, str | None]:
    """Split a wire topic into ``(kind, actor)``.

    ``order.ack.TRADER01`` splits into kind ``order.ack`` and actor
    ``TRADER01``; a topic with no wildcard is its own kind and has no actor.
    An unrecognised topic is returned whole with no actor rather than guessed at — the caller reports it (design section 12.5,
    ``UNKNOWN_TOPIC``) instead of narrating a fabricated split.
    """
    match = _match_topic(topic)
    if match is None:
        return topic, None
    template, actor = match
    if actor is None:
        return template, None
    return template[: template.index("{")].rstrip("."), actor


def event_name(topic: str) -> str:
    """The message kind's last word: ``ack`` for ``order.ack.TRADER01``,
    ``book`` for ``book.AAPL``, ``executed`` for ``trade.executed``."""
    return split_topic(topic)[0].rsplit(".", 1)[-1]


def lookup_topic(topic: str) -> dict[str, Any] | None:
    """Return the spec registry entry a wire topic resolves to, else None.

    The entry carries the declaring family and message and, most usefully for a
    reader of the log, every field's declared unit.
    """
    match = _match_topic(topic)
    if match is None:
        return None
    return dict(TOPIC_REGISTRY[match[0]])


# ---------------------------------------------------------------------------
# Timestamp helpers
# ---------------------------------------------------------------------------


def parse_ts(value: str, *, end_of_day: bool = False) -> datetime:
    """Parse a ``YYYY-MM-DD`` or ISO-8601 string to an *aware* UTC datetime.

    A bare date is a UTC day: its midnight, or with ``end_of_day`` its last
    microsecond, so ``--to 2026-07-08`` includes that day.  An ISO time
    without an offset is UTC.
    """
    value = value.strip()
    # A value with a time part is never a bare date: skip the strptime, which
    # costs a raised ValueError per audit line on the replay's hot path.
    if "T" not in value:
        try:
            dt = datetime.strptime(value, "%Y-%m-%d").replace(tzinfo=timezone.utc)
            if end_of_day:
                dt = dt.replace(hour=23, minute=59, second=59, microsecond=999999)
            return dt
        except ValueError:
            pass
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        pass
    raise ValueError(
        f"Cannot parse timestamp {value!r}. "
        "Use YYYY-MM-DD or ISO-8601 (e.g. 2026-07-08T09:30:00+00:00)."
    )


def validate_date(value: str) -> None:
    """Raise ``ValueError`` if *value* is not a valid ``YYYY-MM-DD`` string."""
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except ValueError as exc:
        raise ValueError(f"Invalid date {value!r}. Expected YYYY-MM-DD.") from exc


def validate_iso_ts(value: str) -> None:
    """Raise ``ValueError`` if *value* is not a parseable timestamp."""
    parse_ts(value)  # raises ValueError on failure


def date_to_range(date_str: str) -> tuple[datetime, datetime]:
    """Return (start_of_day, end_of_day) UTC datetimes for a YYYY-MM-DD string."""
    dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    end = dt.replace(hour=23, minute=59, second=59, microsecond=999999)
    return dt, end


# ---------------------------------------------------------------------------
# Log file discovery
# ---------------------------------------------------------------------------


#: Closed parts of a day: ``audit-2026-10-25.3.log`` (in ``<dir>/audit/``).
_PART_RE = re.compile(r"^audit-(\d{4}-\d{2}-\d{2})\.(\d+)\.log$")
#: One archive per archived day: ``audit-2026-10-24.log.zst``.
_ARCHIVE_RE = re.compile(r"^audit-(\d{4}-\d{2}-\d{2})\.log\.zst$")


def is_explicit_file(log_file: Path) -> bool:
    """True when ``log_file`` names one archive or day part, not the active log."""
    return bool(_ARCHIVE_RE.match(log_file.name) or _PART_RE.match(log_file.name))


def discover_day_files(
    log_file: Path, day: str, tz: tzinfo, log_dir: Path | None = None
) -> list[Path]:
    """The files holding trading day ``day`` (session timezone), oldest first.

    Its archive if there is one, else its parts, then ``audit.log`` if that
    holds the day too (today, or a day pm-audit has not yet closed).
    """
    search_dir = log_dir if log_dir is not None else log_file.parent
    parts_dir = search_dir / "audit"
    archive = parts_dir / f"audit-{day}.log.zst"
    if archive.exists():
        files = [archive]
    elif parts_dir.is_dir():
        found = [
            (int(m.group(2)), p)
            for p in parts_dir.iterdir()
            if (m := _PART_RE.match(p.name)) and m.group(1) == day
        ]
        files = [p for _, p in sorted(found)]
    else:
        files = []
    if log_file.exists() and file_day(log_file, tz) == day:
        files.append(log_file)
    return files


def discover_log_files(log_file: Path, log_dir: Path | None = None) -> list[Path]:
    """Return the live trail in chronological order (oldest first).

    That is every closed day part not yet archived, ordered by (date, part
    number), then the active log.  Archives are not included: they are read
    by explicit path (which is returned alone) or by ``discover_day_files``.
    A day that has an archive but still has parts (a crash between the
    archive's rename and the parts' deletion) is read from its archive only,
    so no line appears twice.
    """
    if is_explicit_file(log_file):
        return [log_file] if log_file.exists() else []

    search_dir = log_dir if log_dir is not None else log_file.parent
    parts_dir = search_dir / "audit"

    parts: list[tuple[str, int, Path]] = []
    archived: set[str] = set()
    if parts_dir.is_dir():
        for candidate in parts_dir.iterdir():
            if m := _PART_RE.match(candidate.name):
                parts.append((m.group(1), int(m.group(2)), candidate))
            elif m := _ARCHIVE_RE.match(candidate.name):
                archived.add(m.group(1))

    parts.sort(key=lambda t: t[:2])
    ordered: list[Path] = [p for day, _, p in parts if day not in archived]

    if log_file.exists():
        ordered.append(log_file)

    return ordered


# ---------------------------------------------------------------------------
# Line iterator
# ---------------------------------------------------------------------------


def open_log_file(path: Path) -> Iterator[str]:
    """Yield raw text lines from a plain or zstd-compressed (``.zst``) file."""
    if path.suffix == ".zst":
        with zstd.open(path, "rt", encoding="utf-8", errors="replace") as fh:
            yield from fh
    else:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            yield from fh


def parse_line(
    raw: str,
) -> tuple[str, str, dict[str, Any], dict[str, str]] | None:
    """Return ``(timestamp_str, topic, payload_dict, meta)`` or ``None``.

    ``meta`` is empty for a line with no metadata section.
    """
    m = _LINE_RE.match(raw.rstrip("\n"))
    if m is None:
        return None
    try:
        payload: dict[str, Any] = json.loads(m.group("payload"))
    except json.JSONDecodeError:
        return None
    return m.group("ts"), m.group("topic"), payload, parse_meta(m.group("meta"))


# ---------------------------------------------------------------------------
# AuditEntry — typed result row
# ---------------------------------------------------------------------------


class AuditEntry:
    """A single parsed audit log line."""

    __slots__ = (
        "timestamp",
        "topic",
        "payload",
        "gateway_id",
        "symbol",
        "order_id",
        "trade_id",
        "seq",
        "eseq",
        "msg_id",
        "causation_id",
        "correlation_id",
        "file",
        "line_no",
        "marks",
    )

    def __init__(
        self,
        timestamp: str,
        topic: str,
        payload: dict[str, Any],
        meta: dict[str, str] | None = None,
        *,
        file: str | None = None,
        line_no: int = 0,
    ) -> None:
        self.timestamp = timestamp
        self.topic = topic
        self.payload = payload
        #: Source coordinates, so any derived output can be traced back to the
        #: bytes it came from (`audit.log:118423`). A reader who distrusts a
        #: narration has to be able to go and read the line themselves.
        #: Absent (None / 0) for an entry constructed directly rather than read
        #: from a file.
        self.file = file
        self.line_no = line_no
        #: Comment lines (``# ...``) directly before this one: the file
        #: header, or a recorder-start marker (``writer.RECORDER_START_PREFIX``).
        self.marks: tuple[str, ...] = ()
        meta = meta or {}
        raw_seq = meta.get("seq")
        self.seq: int | None = int(raw_seq) if raw_seq and raw_seq.isdigit() else None
        raw_eseq = meta.get("eseq")
        self.eseq: int | None = (
            int(raw_eseq) if raw_eseq and raw_eseq.isdigit() else None
        )
        #: ULID of this message. None for a line recorded without an envelope.
        self.msg_id: str | None = meta.get("msg")
        #: ULID of the message that caused this one. None means it had no
        #: external cause — not that the cause is unknown.
        self.causation_id: str | None = meta.get("cause")
        #: ULID shared by every message in one causal chain.
        self.correlation_id: str | None = meta.get("chain")
        self.gateway_id: str | None = self._extract_gateway()
        self.symbol: str | None = payload.get("symbol") or payload.get("s")
        self.order_id: str | None = (
            payload.get("order_id") or payload.get("id")
            if "trade" not in topic
            else None
        )
        self.trade_id: str | None = payload.get("trade_id") or (
            payload.get("id") if "trade" in topic else None
        )

    def _extract_gateway(self) -> str | None:
        p = self.payload
        return (
            p.get("gateway_id") or p.get("buy_gateway_id") or p.get("sell_gateway_id")
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.timestamp,
            "topic": self.topic,
            "gateway": self.gateway_id,
            "symbol": self.symbol,
            "order_id": self.order_id,
            "trade_id": self.trade_id,
            "seq": self.seq,
            "eseq": self.eseq,
            "msg_id": self.msg_id,
            "causation_id": self.causation_id,
            "correlation_id": self.correlation_id,
            "file": self.file,
            "line_no": self.line_no,
            "payload": self.payload,
        }


# ---------------------------------------------------------------------------
# Core streaming iterator with filters
# ---------------------------------------------------------------------------


#: The offset pm-audit writes on every stamp (``datetime.isoformat`` of a UTC
#: time); stamps in this form compare as strings in time order.
_UTC_SUFFIX = "+00:00"


def _stamp_floor(after_ts: str | None, from_dt: datetime | None) -> str | None:
    """The stamp string below which a line can be skipped unparsed, or None."""
    floors: list[str] = []
    if after_ts is not None and after_ts.endswith(_UTC_SUFFIX):
        floors.append(after_ts)
    if from_dt is not None:
        # Truncated to ms like the stamps: a stamp below it is below from_dt.
        utc = from_dt.astimezone(timezone.utc)
        floors.append(utc.isoformat(timespec="milliseconds"))
    return max(floors, default=None)


def iter_entries(
    log_files: list[Path],
    *,
    topic_prefix: str | None = None,
    gateway: str | None = None,
    symbol: str | None = None,
    from_dt: datetime | None = None,
    to_dt: datetime | None = None,
    limit: int | None = None,
    after_ts: str | None = None,
    after_skip: int = 0,
) -> Iterator[AuditEntry]:
    """Stream :class:`AuditEntry` objects from *log_files* with optional filters.

    Filtering is applied during iteration so memory usage stays proportional
    to *limit*, not to file size.

    ``after_ts``/``after_skip`` resume a previous scan: entries with a raw
    timestamp string less than ``after_ts`` are skipped outright, and of the
    entries stamped ``after_ts`` *that pass the filters*, the first
    ``after_skip`` are skipped too -- the ones the previous scan returned.
    This is how ``--follow`` avoids re-emitting entries it already printed
    without needing a ``seq`` (which is optional and often absent -- see the
    module docstring).

    A line stamped before ``after_ts`` or ``from_dt`` is skipped unparsed
    when its stamp is in the recorder's UTC form (``...+00:00``), where
    string order is time order; that keeps a ``--follow`` poll cheap.
    """
    count = 0
    ties_seen = 0
    floor = _stamp_floor(after_ts, from_dt)
    for path in log_files:
        if not path.exists():
            continue
        file_name = str(path)
        # Counted over raw lines, not parsed ones: the ordinal has to be what
        # `sed -n 118423p` would show, or it is no use for tracing back.
        marks: list[str] = []
        for line_no, raw in enumerate(open_log_file(path), start=1):
            if floor is not None and raw.startswith("["):
                stamp = raw[1 : raw.find("]")]
                if stamp.endswith(_UTC_SUFFIX) and stamp < floor:
                    marks.clear()
                    continue
            parsed = parse_line(raw)
            if parsed is None:
                if raw.startswith("# "):
                    marks.append(raw.rstrip("\n"))
                continue
            ts_str, topic, payload, meta = parsed
            line_marks = tuple(marks)
            marks.clear()

            if after_ts is not None and ts_str < after_ts:
                continue

            # Topic prefix filter
            if topic_prefix and not topic.startswith(topic_prefix):
                continue

            # Time range filter — parse only when a range is active
            if from_dt is not None or to_dt is not None:
                try:
                    entry_dt = parse_ts(ts_str)
                except ValueError:
                    continue
                if from_dt is not None and entry_dt < from_dt:
                    continue
                if to_dt is not None and entry_dt > to_dt:
                    continue

            entry = AuditEntry(
                ts_str, topic, payload, meta, file=file_name, line_no=line_no
            )
            entry.marks = line_marks

            # Gateway filter
            if gateway is not None and entry.gateway_id != gateway:
                # Also check buy/sell gateway for trade entries
                p = entry.payload
                if (
                    p.get("buy_gateway_id") != gateway
                    and p.get("sell_gateway_id") != gateway
                ):
                    continue

            # Symbol filter
            if symbol is not None and entry.symbol != symbol:
                continue

            if ts_str == after_ts and ties_seen < after_skip:
                ties_seen += 1
                continue

            yield entry
            count += 1
            if limit is not None and count >= limit:
                return


# ---------------------------------------------------------------------------
# Command query functions
# ---------------------------------------------------------------------------


def query_events(
    log_files: list[Path],
    *,
    topic: str | None = None,
    gateway: str | None = None,
    symbol: str | None = None,
    from_dt: datetime | None = None,
    to_dt: datetime | None = None,
    date_str: str | None = None,
    limit: int = 100,
    reverse: bool = False,
    tail: bool = False,
    after_ts: str | None = None,
    after_skip: int = 0,
) -> list[dict[str, Any]]:
    """Return event rows for the ``events`` command.

    The first ``limit`` matches, oldest first; with ``tail`` the last
    ``limit``, oldest first; with ``reverse`` the last ``limit``, newest
    first.
    """
    if date_str:
        from_dt, to_dt = date_to_range(date_str)

    matches = iter_entries(
        log_files,
        topic_prefix=topic,
        gateway=gateway,
        symbol=symbol,
        from_dt=from_dt,
        to_dt=to_dt,
        limit=None if reverse or tail else limit,
        after_ts=after_ts,
        after_skip=after_skip,
    )
    entries: Iterable[AuditEntry] = (
        deque(matches, maxlen=limit) if reverse or tail else matches
    )
    if reverse:
        entries = reversed(cast(deque[AuditEntry], entries))

    return [event_row(e) for e in entries]


def event_row(entry: AuditEntry) -> dict[str, Any]:
    """One row of the ``events`` command (also built from index rows)."""
    return {
        "timestamp": entry.timestamp,
        "topic": entry.topic,
        "gateway": entry.gateway_id,
        "symbol": entry.symbol,
        "order_id": entry.order_id,
        "summary": _summarise(entry),
    }


def _display_price(p: dict[str, Any]) -> Any:
    """``price``, or ``price_ticks`` in money when the message carries only
    ticks (``order.new``); None for an order without a price (MARKET)."""
    price = p.get("price")
    ticks = p.get("price_ticks")
    decimals = p.get("tick_decimals")
    if price is None and ticks is not None and decimals is not None:
        return round(ticks / 10**decimals, decimals)
    return price


def _first(p: dict[str, Any], *keys: str) -> Any:
    """The first of ``keys`` present (not None) in ``p``; a 0 counts."""
    return next((p[k] for k in keys if p.get(k) is not None), None)


def _order_qty_price(topic: str, p: dict[str, Any]) -> tuple[Any, Any]:
    """(qty, price) of an ``order.*`` message, by the spec's fields for its
    kind (spec/messages/order.yaml).  A fill carries the order's limit in
    ``price`` and ``qty``; what it filled is ``fill_qty`` at ``fill_price``."""
    if topic.startswith(PREFIX_ORDER_FILL):
        return p.get("fill_qty"), p.get("fill_price")
    if topic.startswith((PREFIX_ORDER_ACK, PREFIX_ORDER_AMENDED)):
        return p.get("qty"), _display_price(p)
    return _first(p, "quantity", "qty", "remaining_qty"), _display_price(p)


def _ack_status(p: dict[str, Any]) -> str | None:
    accepted = p.get("accepted")
    if accepted is None:
        return None
    return "ACCEPTED" if accepted else "REJECTED"


def _summarise(entry: AuditEntry) -> str:
    """Return a short human-readable summary of an audit entry."""
    p = entry.payload
    t = entry.topic
    if t == TOPIC_TRADE_EXECUTED:
        return f"{p.get('symbol', '')} {p.get('quantity', '')}@{p.get('price', '')}"
    if t.startswith(PREFIX_ORDER_FILL):
        return f"FILL {p.get('fill_qty', '')}@{p.get('fill_price', '')}"
    if t.startswith(PREFIX_ORDER_ACK):
        detail = f" reject={p['reject_code']}" if p.get("reject_code") else ""
        return (
            f"ACK {_ack_status(p) or ''} {p.get('order_type', '')} "
            f"{p.get('side', '')}{detail}"
        )
    if t.startswith(TOPIC_ORDER_NEW):
        price = _display_price(p)
        at = "" if price is None else f"@{price}"
        return (
            f"{p.get('order_type', '')} {p.get('side', '')} {p.get('quantity', '')}{at}"
        )
    if t.startswith(TOPIC_ORDER_CANCEL):
        detail = f" reason={p['cancel_reason']}" if p.get("cancel_reason") else ""
        return f"CANCEL {p.get('status', '')}{detail}"
    if t.startswith(PREFIX_ORDER_AMENDED):
        return f"AMEND price={p.get('price', '')} qty={p.get('qty', '')}"
    if t.startswith(PREFIX_ORDER_EXPIRED):
        return "EXPIRED"
    if t.startswith("session."):
        return str(p.get("state", p.get("phase", "")))
    if t.startswith(PREFIX_BOOK_SNAPSHOT):
        # A book.* row isn't about one order -- it's the whole resting book
        # after some mutation (a new rest, a cancel, a fill...), which is
        # exactly why order_id is blank on these rows too. Summarise the
        # touch price levels so the row still says something on its own,
        # without needing to cross-reference the order.* row next to it.
        bids = p.get("bids") or []
        asks = p.get("asks") or []
        bid = f"{bids[0]['price']}x{bids[0]['qty']}" if bids else "—"
        ask = f"{asks[0]['price']}x{asks[0]['qty']}" if asks else "—"
        return f"book: bid {bid} / ask {ask}"
    if t.startswith(PREFIX_DEPTH):
        mid = p.get("mid_price", "")
        imbalance = p.get("imbalance", "")
        return f"depth: mid={mid} imbalance={imbalance}"
    return ""


def query_orders(
    log_files: list[Path],
    *,
    order_ids: list[str] | None = None,
    gateway: str | None = None,
    symbol: str | None = None,
    from_dt: datetime | None = None,
    to_dt: datetime | None = None,
    date_str: str | None = None,
    limit: int = 100,
) -> list[dict[str, Any]]:
    """Return order event rows for the ``orders`` command."""
    if date_str:
        from_dt, to_dt = date_to_range(date_str)

    ids_set = set(order_ids) if order_ids else None

    rows: list[dict[str, Any]] = []
    for entry in iter_entries(
        log_files,
        topic_prefix="order.",
        gateway=gateway,
        symbol=symbol,
        from_dt=from_dt,
        to_dt=to_dt,
        limit=None,
    ):
        p = entry.payload
        oid = p.get("order_id") or p.get("id")
        if ids_set is not None and oid not in ids_set:
            continue
        qty, price = _order_qty_price(entry.topic, p)
        rows.append(
            {
                "timestamp": entry.timestamp,
                "order_id": oid,
                "event": event_name(entry.topic),
                "gateway": entry.gateway_id,
                "symbol": entry.symbol,
                "side": p.get("side"),
                "qty": qty,
                "price": price,
                # order.ack has no status field, only `accepted`.
                "status": p.get("status") or _ack_status(p),
                # order.ack's reject_code, order.cancelled's cancel_reason, or
                # a generic reason string -- whichever this event carries.
                # Previously dropped entirely from the `orders` view; only
                # the raw `timeline` dump surfaced it.
                "reason": p.get("reject_code")
                or p.get("cancel_reason")
                or p.get("reason"),
            }
        )
        if len(rows) >= limit:
            break
    return rows


def query_trades(
    log_files: list[Path],
    *,
    symbol: str | None = None,
    gateway: str | None = None,
    buy_gateway: str | None = None,
    sell_gateway: str | None = None,
    min_price: float | None = None,
    max_price: float | None = None,
    min_qty: int | None = None,
    from_dt: datetime | None = None,
    to_dt: datetime | None = None,
    date_str: str | None = None,
    limit: int = 100,
    reverse: bool = False,
) -> list[dict[str, Any]]:
    """Return trade rows for the ``trades`` command: the first ``limit``
    matches, or with ``reverse`` the last ``limit``, newest first."""
    if date_str:
        from_dt, to_dt = date_to_range(date_str)

    def rows() -> Iterator[dict[str, Any]]:
        for entry in iter_entries(
            log_files,
            topic_prefix=TOPIC_TRADE_EXECUTED,
            symbol=symbol,
            from_dt=from_dt,
            to_dt=to_dt,
            limit=None,
        ):
            p = entry.payload
            bg = p.get("buy_gateway_id", "")
            sg = p.get("sell_gateway_id", "")

            if gateway and bg != gateway and sg != gateway:
                continue
            if buy_gateway and bg != buy_gateway:
                continue
            if sell_gateway and sg != sell_gateway:
                continue

            price = p.get("price")
            qty = p.get("quantity")

            if min_price is not None and (price is None or float(price) < min_price):
                continue
            if max_price is not None and (price is None or float(price) > max_price):
                continue
            if min_qty is not None and (qty is None or int(qty) < min_qty):
                continue

            yield {
                "timestamp": entry.timestamp,
                "trade_id": p.get("trade_id") or p.get("id"),
                "symbol": entry.symbol,
                "price": price,
                "quantity": qty,
                "buy_gateway": bg,
                "sell_gateway": sg,
                "aggressor": p.get("aggressor_side"),
            }

    # The first `limit` rows end the scan; --reverse keeps only the last
    # `limit` of all of them.
    if reverse:
        return list(reversed(deque(rows(), maxlen=limit)))
    return list(islice(rows(), limit))


def query_topics(
    log_files: list[Path],
    *,
    prefix: str | None = None,
    from_dt: datetime | None = None,
    to_dt: datetime | None = None,
    date_str: str | None = None,
    sort_by: str = "count",
) -> list[dict[str, Any]]:
    """Return topic count rows for the ``topics`` command."""
    if date_str:
        from_dt, to_dt = date_to_range(date_str)

    counts: dict[str, int] = {}
    first_seen: dict[str, str] = {}
    last_seen: dict[str, str] = {}

    for entry in iter_entries(
        log_files,
        topic_prefix=prefix,
        from_dt=from_dt,
        to_dt=to_dt,
        limit=None,
    ):
        t = entry.topic
        counts[t] = counts.get(t, 0) + 1
        if t not in first_seen:
            first_seen[t] = entry.timestamp
        last_seen[t] = entry.timestamp

    rows = [
        {
            "topic": t,
            "count": counts[t],
            "first_seen": first_seen[t],
            "last_seen": last_seen[t],
        }
        for t in counts
    ]

    if sort_by == "alpha":
        rows.sort(key=lambda r: cast(str, r["topic"]))
    else:
        rows.sort(key=lambda r: cast(int, r["count"]), reverse=True)

    return rows


def query_gateways(
    log_files: list[Path],
    *,
    from_dt: datetime | None = None,
    to_dt: datetime | None = None,
    date_str: str | None = None,
    min_events: int | None = None,
) -> list[dict[str, Any]]:
    """Return gateway activity rows for the ``gateways`` command."""
    if date_str:
        from_dt, to_dt = date_to_range(date_str)

    events: dict[str, int] = {}
    orders: dict[str, int] = {}
    fills: dict[str, int] = {}
    trades: dict[str, int] = {}
    first_seen: dict[str, str] = {}
    last_seen: dict[str, str] = {}

    for entry in iter_entries(
        log_files,
        from_dt=from_dt,
        to_dt=to_dt,
        limit=None,
    ):
        gw_ids: set[str] = set()
        if entry.gateway_id:
            gw_ids.add(entry.gateway_id)
        bg = entry.payload.get("buy_gateway_id")
        sg = entry.payload.get("sell_gateway_id")
        if bg:
            gw_ids.add(str(bg))
        if sg:
            gw_ids.add(str(sg))

        for gw in gw_ids:
            events[gw] = events.get(gw, 0) + 1
            if gw not in first_seen:
                first_seen[gw] = entry.timestamp
            last_seen[gw] = entry.timestamp

            if entry.topic.startswith(TOPIC_ORDER_NEW):
                orders[gw] = orders.get(gw, 0) + 1
            elif entry.topic.startswith(PREFIX_ORDER_FILL):
                fills[gw] = fills.get(gw, 0) + 1
            elif entry.topic == TOPIC_TRADE_EXECUTED:
                trades[gw] = trades.get(gw, 0) + 1

    rows = [
        {
            "gateway_id": gw,
            "events": events[gw],
            "orders": orders.get(gw, 0),
            "fills": fills.get(gw, 0),
            "trades": trades.get(gw, 0),
            "first_seen": first_seen[gw],
            "last_seen": last_seen[gw],
        }
        for gw in sorted(events)
    ]

    if min_events is not None:
        rows = [r for r in rows if cast(int, r["events"]) >= min_events]

    rows.sort(key=lambda r: cast(int, r["events"]), reverse=True)
    return rows


def query_timeline(
    log_files: list[Path],
    *,
    topic_prefix: str | None = None,
    gateway: str | None = None,
    symbol: str | None = None,
    from_dt: datetime | None = None,
    to_dt: datetime | None = None,
    limit: int = 500,
    tail: bool = False,
    after_ts: str | None = None,
    after_skip: int = 0,
) -> list[dict[str, Any]]:
    """Return chronological raw event rows for the ``timeline`` command: the
    first ``limit`` matches, or with ``tail`` the last ``limit``."""
    matches = iter_entries(
        log_files,
        topic_prefix=topic_prefix,
        gateway=gateway,
        symbol=symbol,
        from_dt=from_dt,
        to_dt=to_dt,
        limit=None if tail else limit,
        after_ts=after_ts,
        after_skip=after_skip,
    )
    rows: list[dict[str, Any]] = []
    for entry in deque(matches, maxlen=limit) if tail else matches:
        rows.append(
            {
                "timestamp": entry.timestamp,
                "topic": entry.topic,
                "gateway": entry.gateway_id,
                "symbol": entry.symbol,
                "payload": json.dumps(entry.payload),
            }
        )
    return rows


def query_stats(
    log_files: list[Path],
    *,
    verbose: bool = False,
) -> dict[str, Any]:
    """Return summary statistics for the ``stats`` command."""
    total_events = 0
    total_bytes = 0
    compressed_bytes = 0
    oldest: str | None = None
    newest: str | None = None
    topics: set[str] = set()
    gateways: set[str] = set()
    file_stats: list[dict[str, Any]] = []

    for path in log_files:
        if not path.exists():
            continue
        file_events = 0
        file_bytes = path.stat().st_size
        total_bytes += file_bytes
        if path.suffix == ".zst":
            compressed_bytes += file_bytes

        for entry in iter_entries([path], limit=None):
            file_events += 1
            if oldest is None:
                oldest = entry.timestamp
            newest = entry.timestamp
            topics.add(entry.topic)
            if entry.gateway_id:
                gateways.add(entry.gateway_id)

        total_events += file_events
        if verbose:
            file_stats.append(
                {
                    "file": str(path),
                    "events": file_events,
                    "size_bytes": file_bytes,
                }
            )

    return {
        "total_events": total_events,
        "total_bytes": total_bytes,
        "compressed_bytes": compressed_bytes,
        "file_count": len(log_files),
        "oldest_event": oldest,
        "newest_event": newest,
        "topic_count": len(topics),
        "gateway_count": len(gateways),
        "files": file_stats if verbose else [],
    }
