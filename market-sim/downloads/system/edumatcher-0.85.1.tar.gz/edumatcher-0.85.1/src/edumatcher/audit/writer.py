"""The audit trail's file writer: one active file, closed into day parts.

``audit.log`` holds the lines of one trading day.  It is closed into
``<dir>/audit/audit-YYYY-MM-DD.N.log`` when it reaches ``max_bytes`` or when
a line of a later day arrives; ``N`` is the next free number for that date,
so a part is never renamed again and nothing is ever deleted here.

Every file starts with a header line naming the line format::

    # edumatcher-audit format=1 pm-audit=<version> started=<iso>

Readers skip it: it does not start with ``[`` (``query.parse_line``).
"""

from __future__ import annotations

import contextlib
import logging
import os
import re
import time
from collections.abc import Callable
from datetime import datetime, timezone, tzinfo
from pathlib import Path

from edumatcher.cli_version import package_version

#: The audit line format (``[ts] [topic] [meta] {json}``) this writer writes.
AUDIT_FORMAT_VERSION = 1

_PART_NUMBER_RE = re.compile(r"\.(\d+)\.log$")

log = logging.getLogger(__name__)


def file_day(path: Path, tz: tzinfo) -> str | None:
    """Session date of an audit file, from its first record's stamp (None if
    it holds no record).

    Every line of ``audit.log`` was received on one day, so the first record
    names it.  It follows the comment lines: the header, and a recorder-start
    marker when a started recorder began the file.  The mtime is used only
    when that record's stamp does not parse.
    """
    try:
        with path.open("rb") as fh:
            first = fh.readline().decode("utf-8", errors="replace")
            while first.startswith("#"):
                first = fh.readline().decode("utf-8", errors="replace")
    except FileNotFoundError:
        return None
    if not first:
        return None
    try:
        stamp = datetime.fromisoformat(first[1 : first.index("]")])
    except ValueError:
        stamp = datetime.fromtimestamp(path.stat().st_mtime, tz)
    return stamp.astimezone(tz).date().isoformat()


#: Prefix of the line a started recorder writes before its first line.  A
#: comment, so readers skip it; ``query.iter_entries`` hands it to the next
#: entry so the replay can say the recorder was not running just before it.
RECORDER_START_PREFIX = "# edumatcher-audit recorder-start "


def recorder_start_line() -> str:
    started = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
    return f"{RECORDER_START_PREFIX}pm-audit={package_version()} started={started}"


def header_line() -> str:
    """The first line of every audit file."""
    started = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
    return (
        f"# edumatcher-audit format={AUDIT_FORMAT_VERSION} "
        f"pm-audit={package_version()} started={started}"
    )


class AuditFile:
    """Append-only writer with size and date rollover.

    Not thread-safe: the caller serialises ``write`` and the close calls.
    """

    def __init__(
        self,
        path: Path,
        max_bytes: int,
        tz: tzinfo,
        on_day_closed: Callable[[], None] = lambda: None,
        *,
        fsync_interval: float = 1.0,
        announce_start: bool = False,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        #: Seconds between fsyncs of the active file; 0 syncs every flush.
        #: Bounds what a power loss or kernel crash takes (a killed process
        #: loses nothing already flushed; the OS has it).
        self._fsync_interval = fsync_interval
        self._clock = clock
        self._last_sync: float | None = None
        #: Written since the last fsync (the page cache holds it, not the disk).
        self._unsynced = False
        #: The next write begins with a recorder-start marker.
        self._announce_start = announce_start
        #: Called when a roll closes a day that has ended (not on a size roll).
        self._on_day_closed = on_day_closed
        self._path = path
        self._parts_dir = path.parent / "audit"
        self._max_bytes = max_bytes
        self._tz = tz
        path.parent.mkdir(parents=True, exist_ok=True)
        #: The date every line in ``audit.log`` was received on, or None when
        #: the file is empty.
        self._day = file_day(path, tz)
        self._fh = path.open("ab")
        self._size = path.stat().st_size

    def write(self, day: str, lines: list[str]) -> None:
        """Append ``lines``, all received on ``day``; closes an earlier day first."""
        if self._day is not None and day > self._day and self._try_roll():
            self._on_day_closed()
        if self._day is None:
            self._day = day
        if self._announce_start:
            lines = [recorder_start_line(), *lines]
        if self._size == 0:
            lines = [header_line(), *lines]
        data = ("\n".join(lines) + "\n").encode("utf-8")
        try:
            self._fh.write(data)
            self._fh.flush()
        except OSError:
            self._undo_partial_write()
            raise
        self._announce_start = False
        self._unsynced = True
        self._size += len(data)
        try:
            self.sync_if_due()
        except OSError as exc:
            # The lines are written: raising would make the caller write them
            # again. The sync stays due; the recorder's loop retries it with
            # sync_if_due and counts a failure there.
            log.error("cannot sync %s: %s", self._path, exc)
        if self._size >= self._max_bytes:
            self._try_roll()

    def _undo_partial_write(self) -> None:
        """Cut ``audit.log`` back to its last whole write, so a retry of the
        failed lines (the caller keeps them) does not repeat a torn part."""
        try:
            with contextlib.suppress(OSError):
                self._fh.close()  # flushing what is buffered may fail again
            os.truncate(self._path, self._size)
        finally:
            self._fh = self._path.open("ab")

    def sync_due(self) -> bool:
        """Whether written lines wait for an fsync that is due.  Reads two
        fields and the clock only, so a caller may ask it without the lock that
        serialises ``write`` and take the lock only to ``sync_if_due``."""
        return self._unsynced and (
            self._last_sync is None
            or self._clock() - self._last_sync >= self._fsync_interval
        )

    def sync_if_due(self) -> None:
        """fsync what was written, at most once per ``fsync_interval``.  Called
        on every write, and by the recorder's loop while no line arrives, so a
        quiet tail is not left unsynced until the next write."""
        if self.sync_due():
            os.fsync(self._fh.fileno())
            self._last_sync = self._clock()
            self._unsynced = False

    def close_days_before(self, today: str) -> None:
        """Close ``audit.log`` if it holds a day before ``today`` (idle midnight)."""
        if self._day is not None and self._day < today and self._try_roll():
            self._on_day_closed()

    def _try_roll(self) -> bool:
        """``roll``, but a failure keeps appending to ``audit.log`` (no line is
        held back or lost); the next write or day check tries again."""
        try:
            self.roll()
        except OSError as exc:
            log.error("cannot close %s as a day part: %s", self._path, exc)
            return False
        return True

    def roll(self) -> None:
        """Close ``audit.log`` as the next part of its day and start a new one.

        On failure ``audit.log`` stays open and unchanged.
        """
        if self._day is None or self._size == 0:
            return
        self._fh.flush()
        os.fsync(self._fh.fileno())
        self._unsynced = False
        self._parts_dir.mkdir(parents=True, exist_ok=True)
        part = self._parts_dir / f"audit-{self._day}.{self._next_part_number()}.log"
        self._fh.close()
        try:
            os.replace(self._path, part)
        finally:
            self._fh = self._path.open("ab")
        self._size = 0
        self._day = None

    def _next_part_number(self) -> int:
        numbers = [
            int(m.group(1))
            for p in self._parts_dir.glob(f"audit-{self._day}.*.log")
            if (m := _PART_NUMBER_RE.search(p.name))
        ]
        return max(numbers, default=0) + 1

    def close(self) -> None:
        self._fh.flush()
        os.fsync(self._fh.fileno())
        self._fh.close()
