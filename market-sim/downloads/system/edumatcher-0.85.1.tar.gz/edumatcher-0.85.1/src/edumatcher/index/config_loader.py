from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from edumatcher.engine.config_loader import (
    EngineConfig,
    IndexConfig,
    SymbolConfig,
    load_engine_config,
)


@dataclass(frozen=True)
class IndexRuntimeConfig:
    id: str
    description: str
    base_value: float
    publish_interval_sec: float
    history_file: str
    state_file: str
    constituents: list[str]
    outstanding_shares: dict[str, int]
    reference_prices: dict[str, float]
    #: Every symbol the exchange trades. A runtime ADD must name one, or the
    #: new constituent would never trade and never move (C12).
    tradeable_symbols: frozenset[str]


def _reference_price(symbol: str, cfg: SymbolConfig) -> float:
    buy = cfg.last_buy_price
    sell = cfg.last_sell_price
    if buy is not None and sell is not None:
        return (float(buy) + float(sell)) / 2.0
    if buy is not None:
        return float(buy)
    if sell is not None:
        return float(sell)
    raise ValueError(
        f"Symbol '{symbol}' requires at least one of last_buy_price/last_sell_price"
    )


def _to_runtime_index_config(
    idx: IndexConfig,
    symbols: dict[str, SymbolConfig],
) -> IndexRuntimeConfig:
    shares: dict[str, int] = {}
    prices: dict[str, float] = {}
    for symbol in idx.constituents:
        sym_cfg = symbols[symbol]
        if sym_cfg.outstanding_shares is None:
            raise ValueError(
                f"Index '{idx.id}' constituent '{symbol}' is missing outstanding_shares"
            )
        shares[symbol] = int(sym_cfg.outstanding_shares)
        prices[symbol] = _reference_price(symbol, sym_cfg)

    return IndexRuntimeConfig(
        id=idx.id,
        description=idx.description,
        base_value=idx.base_value,
        publish_interval_sec=idx.publish_interval_sec,
        history_file=idx.history_file,
        state_file=idx.state_file,
        constituents=list(idx.constituents),
        outstanding_shares=shares,
        reference_prices=prices,
        tradeable_symbols=frozenset(symbols),
    )


def index_runtime_configs(engine_cfg: EngineConfig) -> list[IndexRuntimeConfig]:
    """Enrich each configured index with its constituents' reference data.

    ``outstanding_shares`` and ``reference_prices`` are not separate config
    fields — they are gathered from the constituent symbols, which the
    compiled artifact already carries. Taking an ``EngineConfig`` rather than a
    path is what lets pm-index read the artifact instead of re-parsing the YAML
    and arriving at its own answer.
    """
    return [
        _to_runtime_index_config(idx, engine_cfg.symbols) for idx in engine_cfg.indices
    ]


def load_index_runtime_configs(config_path: Path) -> list[IndexRuntimeConfig]:
    """Load and enrich index runtime configs straight from engine config YAML.

    Not on the runtime path — pm-index reads the compiled artifact. Retained
    for tools and tests that work on an authored file.
    """
    return index_runtime_configs(load_engine_config(config_path))
