from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from edumatcher.models.generated._runtime import MessageValidationError
from edumatcher.models.generated.index import HistoryRecord

log = logging.getLogger(__name__)

# Record types written to the JSONL file. This file is an append-only
# structural/audit log — it is NOT the home for level-update history.
# Every index.update tick (including end-of-day closes) is instead
# recorded by pm-stats in the index_level_snapshots / index_daily_stats
# SQLite tables, which are built for efficient time-range queries.
# See ../../../docs/books/operator-guide/part-4-run-a-market/070-market-index.md and ../../../docs/books/operator-guide/part-4-run-a-market/060-statistics-and-reporting.md.
STRUCTURAL_RECORD_TYPES: frozenset[str] = frozenset(
    {"INIT", "CORP_ACTION", "DELIST", "ADD_CONSTITUENT", "REBALANCE"}
)


class IndexHistory:
    """Append-only JSONL manager for structural index audit records.

    Holds only structural/corporate-action events (index creation,
    splits, dividends, share issuance, delistings, constituent
    additions, rebalances) — never per-tick level updates. Level and end-of-day
    history now lives exclusively in pm-stats' SQLite tables.
    """

    def __init__(self, history_file: str) -> None:
        self._path = Path(history_file)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._fh = self._path.open("a", encoding="utf-8")

    @property
    def path(self) -> Path:
        return self._path

    def append(self, record: dict[str, Any]) -> None:
        # Validate on write so the archive is canonical by construction; a
        # record that fails is a producer bug — log it and store as-is rather
        # than raise out of the command that is writing it.
        try:
            canonical = HistoryRecord.from_dict(record)
            canonical.validate()
            record = canonical.to_dict()
        except (KeyError, MessageValidationError) as exc:
            log.error(
                "index history record failed validation, storing as-is: %s | record=%s",
                exc,
                json.dumps(record, separators=(",", ":")),
            )
        self._fh.write(json.dumps(record, separators=(",", ":")) + "\n")
        log.debug(
            "history append path=%s type=%s index_id=%s",
            self._path,
            record.get("type", "?"),
            record.get("index_id", "?"),
        )

    def write_through(self, record: dict[str, Any]) -> None:
        """Append ``record`` and flush it, for a command that must be on disk
        before it is acknowledged.

        On an OSError the handle is reopened: a failed flush keeps the line
        buffered, and the next flush would write the record of a command
        pm-index then rejected.
        """
        try:
            self.append(record)
            self._fh.flush()
        except OSError:
            try:
                self._fh.close()
            except OSError:
                pass
            self._fh = self._path.open("a", encoding="utf-8")
            raise

    def flush(self) -> None:
        self._fh.flush()

    def close(self) -> None:
        if not self._fh.closed:
            self._fh.close()

    def __enter__(self) -> "IndexHistory":
        return self

    def __exit__(self, exc_type: object, exc: object, tb: object) -> None:
        _ = (exc_type, exc, tb)
        self.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            # Never raise during GC finalization.
            pass

    def query(
        self,
        from_ts_ns: int,
        to_ts_ns: int,
        types: set[str],
        max_records: int = 10_000,
    ) -> tuple[list[dict[str, Any]], list[str]]:
        results: list[dict[str, Any]] = []
        warnings: list[str] = []
        if to_ts_ns < from_ts_ns:
            raise ValueError("to_ts_ns must be >= from_ts_ns")
        if max_records <= 0:
            raise ValueError("max_records must be > 0")

        try:
            with self._path.open("r", encoding="utf-8") as fh:
                for raw_line in fh:
                    line = raw_line.strip()
                    if not line:
                        continue
                    try:
                        rec = json.loads(line)
                    except json.JSONDecodeError:
                        warnings.append("ignored malformed history line")
                        continue

                    rec_type = rec.get("type")
                    ts = rec.get("ts_ns")
                    if not isinstance(rec_type, str):
                        warnings.append("ignored record with invalid type")
                        continue
                    if rec_type not in types:
                        if rec_type not in STRUCTURAL_RECORD_TYPES:
                            warnings.append(f"ignored unknown record type: {rec_type}")
                        continue
                    try:
                        ts_i = int(ts)
                    except TypeError, ValueError:
                        warnings.append("ignored record with invalid timestamp")
                        continue

                    if from_ts_ns <= ts_i <= to_ts_ns:
                        # The reply now builds through the checked builder, so a
                        # non-conforming row (a legacy shape in an existing
                        # archive) is dropped with a warning rather than failing
                        # the whole response.
                        try:
                            HistoryRecord.from_dict(rec).validate()
                        except (KeyError, MessageValidationError) as exc:
                            warnings.append(
                                f"ignored non-conforming history record: {exc}"
                            )
                            continue
                        results.append(rec)
                        if len(results) >= max_records:
                            break
        except FileNotFoundError:
            # Benign: the archive is created lazily on the first append.
            return [], []
        except OSError as exc:
            # The file exists but cannot be read (permissions, disk error) —
            # distinct from "no history yet" so an operator can act on it.
            log.error(
                "index history file unreadable: path=%s error=%s", self._path, exc
            )
            warnings.append(f"index history file unreadable: {exc}")
            return [], warnings

        log.debug(
            "history query path=%s from_ts_ns=%d to_ts_ns=%d types=%s max_records=%d returned=%d warnings=%d",
            self._path,
            from_ts_ns,
            to_ts_ns,
            sorted(types),
            max_records,
            len(results),
            len(warnings),
        )
        return results, warnings
