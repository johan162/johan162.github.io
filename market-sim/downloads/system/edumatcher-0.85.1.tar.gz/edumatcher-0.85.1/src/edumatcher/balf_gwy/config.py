"""Configuration loading for ``pm-balf-gwy``.

The gateway reads two sections from the engine config YAML:
- ``balf_gateway`` — BALF-specific runtime settings (port, timeouts, etc.)
- ``participants``  — gateway identity allowlist shared with ALF in v1.0.0

Gateway identity and ``disconnect_behaviour`` come from ``participants``
to keep Phase-1 engine changes at zero.  See spec §12.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


from edumatcher.config import ENGINE_PULL_ADDR, ENGINE_PUB_ADDR
from edumatcher.config_include import load_config_mapping
from edumatcher.config import resolve_gateway_bind_host
from edumatcher.config_coerce import as_bool, as_float, as_int, as_str


@dataclass(frozen=True)
class BalfGatewayConfig:
    """Runtime settings for the BALF TCP gateway."""

    enabled: bool = True
    name: str = "balf-gwy01"
    bind_address: str = field(default_factory=resolve_gateway_bind_host)
    port: int = 5560
    engine_pull_addr: str = ENGINE_PULL_ADDR
    engine_pub_addr: str = ENGINE_PUB_ADDR
    # Liveness
    heartbeat_interval_sec: float = 1.0
    heartbeat_timeout_sec: float = 5.0
    idle_timeout_sec: float = 30.0
    auth_timeout_sec: float = 10.0
    # Capacity
    max_connections: int = 64
    max_client_queue: int = 10_000
    max_messages_per_second: int = 100
    # Error tolerance before hard-close
    max_errors_before_disconnect: int = 10
    error_window_sec: float = 60.0
    # Duplicate session policy: "REJECT_NEW" or "EVICT_OLD"
    duplicate_session_policy: str = "REJECT_NEW"
    # Gateway roles from participants: tuple of (gateway_id, role)
    gateway_roles: tuple[tuple[str, str], ...] = ()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _optional_str(raw: object, label: str) -> str | None:
    return None if raw is None else as_str(raw, label)


def _as_int(raw: object, field: str) -> int:
    return as_int(raw, f"balf_gateway.{field}")


def _as_float(raw: object, field: str) -> float:
    return as_float(raw, f"balf_gateway.{field}", positive=True)


def _parse_gateway_roles(raw: Any) -> tuple[tuple[str, str], ...]:
    """Read gateway identity + role list from ``participants``."""
    participants = raw.get("participants") if isinstance(raw, dict) else None
    if not isinstance(participants, list):
        return ()

    parsed: list[tuple[str, str]] = []
    for idx, item in enumerate(participants):
        if not isinstance(item, dict):
            raise ValueError(f"participants[{idx}] must be a mapping")
        gw_id = str(item.get("id", "")).strip().upper()
        role = str(item.get("role", "TRADER")).strip().upper()
        if not gw_id:
            raise ValueError(f"participants[{idx}].id must be a non-empty string")
        parsed.append((gw_id, role))

    # Prefix uniqueness guard (same rule as ALF gateway)
    for idx, (gw_id, _) in enumerate(parsed):
        for other_idx, (other_id, _) in enumerate(parsed):
            if idx != other_idx and other_id.startswith(gw_id):
                raise ValueError(
                    "participants IDs must not be prefixes of each other "
                    f"({gw_id!r}, {other_id!r})"
                )
    return tuple(parsed)


# ---------------------------------------------------------------------------
# Public loaders
# ---------------------------------------------------------------------------


def _load_balf_gateway_config_from_raw(raw: dict[str, Any]) -> BalfGatewayConfig:
    gw_roles = _parse_gateway_roles(raw)

    section = raw.get("balf_gateway")
    if section is None:
        return BalfGatewayConfig(gateway_roles=gw_roles)
    if not isinstance(section, dict):
        raise ValueError("balf_gateway must be a mapping")

    enabled = as_bool(section.get("enabled", True), "balf_gateway.enabled")
    name = as_str(section.get("name", "balf-gwy01"), "balf_gateway.name")
    bind_address = resolve_gateway_bind_host(
        _optional_str(section.get("bind_address"), "balf_gateway.bind_address")
    )
    port = _as_int(section.get("port", 5560), "port")
    if port <= 0 or port > 65535:
        raise ValueError("balf_gateway.port must be in 1-65535")

    heartbeat_interval_sec = _as_float(
        section.get("heartbeat_interval_sec", 1.0), "heartbeat_interval_sec"
    )
    heartbeat_timeout_sec = _as_float(
        section.get("heartbeat_timeout_sec", 5.0), "heartbeat_timeout_sec"
    )
    idle_timeout_sec = _as_float(
        section.get("idle_timeout_sec", 30.0), "idle_timeout_sec"
    )
    auth_timeout_sec = _as_float(
        section.get("auth_timeout_sec", 10.0), "auth_timeout_sec"
    )
    max_connections = _as_int(section.get("max_connections", 64), "max_connections")
    if max_connections <= 0:
        raise ValueError("balf_gateway.max_connections must be > 0")
    max_client_queue = _as_int(
        section.get("max_client_queue", 10_000), "max_client_queue"
    )
    if max_client_queue <= 0:
        raise ValueError("balf_gateway.max_client_queue must be > 0")
    max_messages_per_second = _as_int(
        section.get("max_messages_per_second", 100), "max_messages_per_second"
    )
    if max_messages_per_second <= 0:
        raise ValueError("balf_gateway.max_messages_per_second must be > 0")
    max_errors_before_disconnect = _as_int(
        section.get("max_errors_before_disconnect", 10),
        "max_errors_before_disconnect",
    )
    if max_errors_before_disconnect <= 0:
        raise ValueError("balf_gateway.max_errors_before_disconnect must be > 0")
    error_window_sec = _as_float(
        section.get("error_window_sec", 60.0), "error_window_sec"
    )

    dup_policy_raw = str(section.get("duplicate_session_policy", "REJECT_NEW")).upper()
    if dup_policy_raw not in {"REJECT_NEW", "EVICT_OLD"}:
        raise ValueError(
            "balf_gateway.duplicate_session_policy must be REJECT_NEW or EVICT_OLD"
        )

    return BalfGatewayConfig(
        enabled=enabled,
        name=name,
        bind_address=bind_address,
        port=port,
        engine_pull_addr=ENGINE_PULL_ADDR,
        engine_pub_addr=ENGINE_PUB_ADDR,
        heartbeat_interval_sec=heartbeat_interval_sec,
        heartbeat_timeout_sec=heartbeat_timeout_sec,
        idle_timeout_sec=idle_timeout_sec,
        auth_timeout_sec=auth_timeout_sec,
        max_connections=max_connections,
        max_client_queue=max_client_queue,
        max_messages_per_second=max_messages_per_second,
        max_errors_before_disconnect=max_errors_before_disconnect,
        error_window_sec=error_window_sec,
        duplicate_session_policy=dup_policy_raw,
        gateway_roles=gw_roles,
    )


def load_balf_gateway_config(path: Path) -> BalfGatewayConfig:
    """Load the ``balf_gateway`` section from an engine config YAML.

    Falls back to defaults for any missing field.
    Raises ``ValueError`` for invalid values.
    """
    if not path.exists():
        return BalfGatewayConfig()

    raw = load_config_mapping(path).data

    return _load_balf_gateway_config_from_raw(raw)


def validate_balf_gateway_section(raw: dict[str, Any]) -> None:
    """Validate the ``balf_gateway`` section using runtime loader semantics."""
    _load_balf_gateway_config_from_raw(raw)


def load_default_balf_gateway_config() -> BalfGatewayConfig:
    """Return this subsystem's section of the deployed compiled configuration.

    Falls back to dataclass defaults when nothing has been deployed yet, which
    is exactly what the YAML loader above did for a missing file — many tools
    that read this section, such as the spies and viewers, must still run
    against an exchange whose configuration was never installed.

    The import is deferred because ``config_artifact`` imports this module to
    describe the artifact's shape.
    """
    from edumatcher.config_artifact import load_compiled_config

    compiled = load_compiled_config()
    return BalfGatewayConfig() if compiled is None else compiled.balf_gateway
