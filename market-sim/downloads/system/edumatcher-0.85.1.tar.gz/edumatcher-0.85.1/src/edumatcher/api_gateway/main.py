"""Command-line entry point and FastAPI app factory for ``pm-api-gwy``."""

from __future__ import annotations

import argparse
import asyncio
import dataclasses
import logging
import sys
from contextlib import asynccontextmanager
from typing import Any, AsyncGenerator, cast

import uvicorn
from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.routing import APIRoute
from starlette.exceptions import HTTPException as StarletteHTTPException

from edumatcher.config_artifact import exit_on_config_error
from edumatcher.api_gateway.errors import ERROR_CODES
from edumatcher.api_gateway.idempotency import IdempotencyStore
from edumatcher.api_gateway.metrics import install as install_metrics
from edumatcher.api_gateway.openapi_docs import (
    API_DESCRIPTION,
    TAGS_METADATA,
    drop_stock_validation_error,
    errors,
    restore_example_nulls,
)
from edumatcher.health import HealthReporter
from edumatcher.api_gateway.config import (
    ApiGatewayConfig,
    load_default_api_gateway_config,
)
from edumatcher.api_gateway.engine_client import EngineClient
from edumatcher.api_gateway.index_client import IndexClient
from edumatcher.api_gateway.sim_client import SimClient
from edumatcher.config import REF_DATA_DIR, SIM_PUB_ADDR
from edumatcher.market_sim.config import FILE_NAME as SIM_FILE_NAME, load_sectors
from edumatcher.api_gateway.rate_limit import RateLimiter
from edumatcher.messaging.reject_report import RejectReporter
from edumatcher.api_gateway.routers import (
    admin,
    bootstrap,
    clearing,
    history,
    market,
    orders,
    reference,
    ws,
)
from edumatcher.api_gateway.sessions import SessionRegistry
from edumatcher.config import resolve_data_path
from edumatcher.models.message import GATEWAY_HEARTBEAT_INTERVAL_SEC
from edumatcher.log_srv.config import (
    load_default_log_client_config,
    load_default_log_server_config,
    resolve_host_default,
)
from edumatcher.logclient.discovery import resolve_handler
from edumatcher.models.price import TickViolation

_CLIENT_NAME = "pm-api-gwy"
#: How often the health task wakes; its oversleep is the event-loop lag.
HEALTH_TICK_SEC = 0.25
#: Longest uvicorn waits for open connections at shutdown. A backstop: every
#: WebSocket handler ends when its client closes, but one that did not would
#: otherwise keep a SIGTERM'd process (and port 8080) alive indefinitely.
GRACEFUL_SHUTDOWN_SEC = 5
_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s - %(message)s"

log = logging.getLogger(__name__)


#: `code` for an HTTPException raised with a plain-string detail -- in
#: practice only Starlette's own routing errors, since every route raises the
#: structured `{"error": {...}}` form.
_HTTP_STATUS_CODES = {404: "NOT_FOUND", 405: "METHOD_NOT_ALLOWED"}


def _extract_correlation(body: object, request: Request) -> dict[str, str]:
    tags: dict[str, str] = {}
    if isinstance(body, dict):
        for field in ("client_tag", "request_tag"):
            value = body.get(field)
            if value is not None:
                tags[field] = str(value)
    request_tag = request.query_params.get("request_tag")
    if request_tag is not None:
        tags["request_tag"] = request_tag
    return tags


async def _safe_body(request: Request) -> object:
    """Re-read the request body for correlation tags, tolerating failure.

    ``RequestValidationError`` arrives with the parsed body attached; an
    exception raised inside a route handler does not, so the body has to be
    read back. Starlette has already buffered it by then, but echoing a tag is
    a convenience and must never turn one error into a different one.
    """
    try:
        return await request.json()
    except Exception:
        return None


def _validation_reject_code(error_type: str, message: str) -> str:
    # The shared per-type rule names its verdict (schemas._check_type_fields).
    if error_type in ("missing_field", "unsupported_field", "invalid_value"):
        return error_type.upper()
    lower_message = message.lower()
    if (
        error_type == "missing"
        or "required" in lower_message
        or "requires" in lower_message
    ):
        return "MISSING_FIELD"
    if error_type == "extra_forbidden":
        return "UNSUPPORTED_FIELD"
    return "INVALID_VALUE"


def _operation_id(route: APIRoute) -> str:
    return route.name


def create_app(config: ApiGatewayConfig, *, instance: str | None = None) -> FastAPI:
    """Create a configured FastAPI application.

    ``instance`` is the ``--instance`` this process was started with (``None``
    without one). The health beacon carries it rather than ``config.name``: the
    pm-opctl-cli roster knows a process by its command line, and a bare
    ``pm-api-gwy`` that picked the single configured entry (or the built-in
    ``default``) would otherwise read MISSING next to itself (A+B review, I90).

    FastAPI automatically publishes OpenAPI at ``/openapi.json`` and Swagger UI
    at ``/docs``.  Those endpoints are controlled by ``swagger_enabled`` in the
    central ``api_gateways`` config.
    """

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
        loop = asyncio.get_running_loop()
        engine = EngineClient(
            config.engine_pull_addr,
            config.engine_pub_addr,
            loop,
            market_cache_sec=config.market_data_cache_sec,
        )

        def _listener_died() -> None:
            # main() turns this into exit status 1 once the server has
            # stopped, so a supervisor sees the failure (review C5).
            app.state.listener_failed = True
            server = getattr(app.state, "server", None)
            if server is not None:
                server.should_exit = True

        engine.on_listener_failure = _listener_died
        engine.start_listener()
        index_client = IndexClient(config.index_pull_addr, config.index_pub_addr, loop)
        index_client.on_listener_failure = _listener_died
        index_client.start_listener()
        sim = SimClient(
            SIM_PUB_ADDR, loop, sectors=load_sectors(REF_DATA_DIR / SIM_FILE_NAME)
        )
        sim.on_listener_failure = _listener_died
        sim.start_listener()
        app.state.sim = sim
        app.state.config = config
        app.state.engine = engine
        app.state.rejects = RejectReporter("REST", lambda frames: engine.report(frames))
        app.state.index_client = index_client
        app.state.sessions = SessionRegistry.from_config(config)
        metrics.register_keys(app.state.sessions.labels())
        app.state.rate_limiter = RateLimiter(
            config.rate_limit.writes_per_second,
            config.rate_limit.burst,
        )

        async def _evict_terminal_orders() -> None:
            """Bound the order cache. Without this it grows for the process's
            lifetime and the admin order table would show this morning's
            fills as current."""
            interval = max(60, config.order_retention_sec // 10)
            while True:
                await asyncio.sleep(interval)
                dropped = engine.evict_terminal_orders(config.order_retention_sec)
                if dropped:
                    logging.getLogger(__name__).debug(
                        "evicted %d terminal order(s) older than %ds",
                        dropped,
                        config.order_retention_sec,
                    )

        async def _send_heartbeats() -> None:
            """Tell the engine every ID this process holds is still alive, so
            a hung or killed gateway frees them instead of locking them."""
            while True:
                await asyncio.sleep(GATEWAY_HEARTBEAT_INTERVAL_SEC)
                for gateway_id in engine.active_gateways():
                    engine.send_heartbeat(gateway_id)

        # Health beacon: a task that only sleeps and ticks, so loop_lag_ms is
        # the event loop's own stall time. Never ticked from EngineClient's
        # receive thread -- the loop is what must not stall (design A5.4).
        reporter = HealthReporter.start_from_compiled_config(_CLIENT_NAME, instance)

        async def _report_health(reporter: HealthReporter) -> None:
            while True:
                await asyncio.sleep(HEALTH_TICK_SEC)
                reporter.tick_and_publish(lambda: metrics.samples(engine))

        health_task = (
            asyncio.create_task(_report_health(reporter))
            if reporter is not None
            else None
        )
        heartbeat_task = asyncio.create_task(_send_heartbeats())
        sweeper = (
            asyncio.create_task(_evict_terminal_orders())
            if config.order_retention_sec > 0
            else None
        )
        try:
            yield
        finally:
            if health_task is not None:
                health_task.cancel()
            if reporter is not None:
                # Off the loop: stop() joins the sampler thread (< ~1 s).
                await asyncio.to_thread(reporter.stop)
            heartbeat_task.cancel()
            if sweeper is not None:
                sweeper.cancel()
            for gateway_id in engine.active_gateways():
                # Best-effort: a 503 raised here would skip the two
                # stop_listener calls below and leak the reader threads, and
                # "the engine is already gone" is the ordinary case at
                # shutdown, not an error.
                engine.send_disconnect(
                    gateway_id, "api gateway shutdown", require_engine=False
                )
            engine.stop_listener()
            index_client.stop_listener()
            sim.stop_listener()

    docs_url = "/docs" if config.swagger_enabled else None
    openapi_url = "/openapi.json" if config.swagger_enabled else None
    app = FastAPI(
        title="EduMatcher API Gateway",
        version="1.0.0",
        description=API_DESCRIPTION,
        openapi_tags=TAGS_METADATA,
        # Every route can fail with a gateway bug; each route lists the rest.
        responses=errors("INTERNAL_ERROR"),
        docs_url=docs_url,
        redoc_url=None,
        openapi_url=openapi_url,
        lifespan=lifespan,
        # operationIds become generated-SDK method names, so they are the
        # handler names (`submit_order`) rather than FastAPI's default
        # `submit_order_api_v1_orders_post`. Unique across routers by test.
        generate_unique_id_function=_operation_id,
    )
    metrics = install_metrics(app)
    # Idempotency-Key replies live as long as finished orders do; with
    # eviction disabled (0) they still expire, so the store stays bounded.
    app.state.idempotency = IdempotencyStore(config.order_retention_sec or 3600)

    default_openapi = app.openapi

    def openapi() -> dict[str, Any]:
        schema = default_openapi()
        drop_stock_validation_error(schema)
        restore_example_nulls(schema, app.routes)
        return schema

    app.openapi = openapi  # type: ignore[method-assign]

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(  # pyright: ignore[reportUnusedFunction]
        request: Request,
        exc: RequestValidationError,
    ) -> JSONResponse:
        first = exc.errors()[0] if exc.errors() else {}
        loc = first.get("loc", [])
        field = str(loc[-1]) if loc else None
        message = str(first.get("msg", "Invalid request"))
        body = getattr(exc, "body", None)
        return JSONResponse(
            status_code=400,
            content={
                "error": {
                    "code": "VALIDATION",
                    "message": message,
                    "field": field,
                    "reject_code": _validation_reject_code(
                        str(first.get("type", "")), message
                    ),
                    **_extract_correlation(body, request),
                }
            },
        )

    @app.exception_handler(TickViolation)
    async def tick_violation_handler(  # pyright: ignore[reportUnusedFunction]
        request: Request,
        exc: TickViolation,
    ) -> JSONResponse:
        """One handler, not a try/except at every conversion site.

        ``translate.py`` converts prices in five places across orders, quotes,
        OCO legs and combo legs; catching there would mean five near-identical
        bodies that could drift apart. The transport decides the status code
        (400, a malformed request); ``reject_code`` is the value the
        cross-transport equivalence assertion compares, and it must equal what
        ALF answers for the same price.
        """
        return JSONResponse(
            status_code=400,
            content={
                "error": {
                    "code": "VALIDATION",
                    "message": str(exc),
                    "field": "price",
                    "reject_code": "TICK_VIOLATION",
                    **_extract_correlation(await _safe_body(request), request),
                }
            },
        )

    # Registered on Starlette's base class, not FastAPI's subclass: routing
    # raises the base class for an unknown path (404) or method (405), and
    # those must use the envelope too.
    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(  # pyright: ignore[reportUnusedFunction]
        _request: Request,
        exc: StarletteHTTPException,
    ) -> JSONResponse:
        detail = exc.detail
        if isinstance(detail, dict) and isinstance(detail.get("error"), dict):
            detail_dict = cast(dict[str, Any], detail)
            error = dict(cast(dict[str, Any], detail_dict["error"]))
            code = str(error.get("code", "UNKNOWN"))
            known = ERROR_CODES.get(code)
            error.setdefault("reject_code", known.reject_code if known else "UNKNOWN")
        else:
            error = {
                "code": _HTTP_STATUS_CODES.get(exc.status_code, "HTTP_ERROR"),
                "message": str(detail),
                "reject_code": "UNKNOWN",
            }
        # Headers carry meaning here: WWW-Authenticate on a 401, Allow on a 405.
        return JSONResponse(
            status_code=exc.status_code, content={"error": error}, headers=exc.headers
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(  # pyright: ignore[reportUnusedFunction]
        _request: Request,
        _exc: Exception,
    ) -> JSONResponse:
        """A bug, not a client error: the envelope, and no internals in it.

        Starlette re-raises the exception after sending this response, so the
        server still logs the traceback.
        """
        return JSONResponse(
            status_code=500,
            content={
                "error": {
                    "code": "INTERNAL_ERROR",
                    "message": "Internal server error",
                    "reject_code": "INTERNAL_ERROR",
                }
            },
        )

    app.include_router(orders.router)
    app.include_router(reference.router)
    app.include_router(market.router)
    app.include_router(history.router)
    app.include_router(clearing.router)
    app.include_router(admin.router)
    app.include_router(bootstrap.router)
    app.include_router(ws.router)
    return app


def _config_with_overrides(args: argparse.Namespace) -> ApiGatewayConfig:
    config = load_default_api_gateway_config(instance=args.instance)
    engine_pull_addr = config.engine_pull_addr
    engine_pub_addr = config.engine_pub_addr
    index_pull_addr = config.index_pull_addr
    index_pub_addr = config.index_pub_addr
    if args.engine_host:
        engine_pull_addr = f"tcp://{args.engine_host}:5555"
        engine_pub_addr = f"tcp://{args.engine_host}:5556"
        index_pull_addr = f"tcp://{args.engine_host}:5559"
        index_pub_addr = f"tcp://{args.engine_host}:5558"
    # replace(), not a field-by-field rebuild: a rebuild silently reset every
    # field it did not list to its default (order_retention_sec, audit_db).
    return dataclasses.replace(
        config,
        host=args.host or config.host,
        port=args.port or config.port,
        engine_pull_addr=engine_pull_addr,
        engine_pub_addr=engine_pub_addr,
        index_pull_addr=index_pull_addr,
        index_pub_addr=index_pub_addr,
        stats_db=resolve_data_path(args.stats_db) if args.stats_db else config.stats_db,
        clearing_db=(
            resolve_data_path(args.clearing_db)
            if args.clearing_db
            else config.clearing_db
        ),
        log_level=args.log_level.lower() if args.log_level else config.log_level,
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="EduMatcher REST API gateway")
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-api-gwy")
    parser.add_argument(
        "--host", default=None, metavar="ADDR", help="HTTP bind address"
    )
    parser.add_argument(
        "--port", default=None, type=int, metavar="PORT", help="HTTP listen port"
    )
    parser.add_argument(
        "--instance",
        default=None,
        metavar="NAME",
        help="Named api_gateways entry to run when multiple API gateway processes are configured",
    )
    parser.add_argument(
        "--engine-host",
        default=None,
        metavar="HOST",
        help="Override engine host in ZMQ URLs",
    )
    parser.add_argument(
        "--stats-db", default=None, metavar="PATH", help="Path to stats.db"
    )
    parser.add_argument(
        "--clearing-db",
        default=None,
        metavar="PATH",
        help="Path to clearing.db, read-only, for period realized P&L on /positions "
        "and the /clearing routes",
    )
    parser.add_argument(
        "--log-level",
        choices=["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"],
        default=None,
        help="Logging level override (default: WARNING)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase log verbosity (-v: INFO, -vv: DEBUG)",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Explicit WARNING log level (the default)",
    )
    parser.add_argument(
        "--log-target",
        choices=["server", "stdout", "file"],
        default=None,
        help=(
            "Where this process's own operational log records go: "
            "server (default, auto-detected pm-log-srv), stdout, or file"
        ),
    )
    parser.add_argument(
        "--log-file",
        default=None,
        metavar="PATH",
        help="Operational log file path — required when --log-target file",
    )
    parser.add_argument(
        "--log-failover-timeout",
        type=float,
        default=None,
        metavar="SECONDS",
        help=(
            "Grace window before falling back to a local log file once "
            "pm-log-srv becomes unreachable (default: 30, from config)"
        ),
    )
    return parser


def _configure_logging(args: argparse.Namespace) -> int:
    log_level = getattr(args, "log_level", None)
    verbose = getattr(args, "verbose", 0)
    quiet = getattr(args, "quiet", False)

    if log_level:
        level_name = str(log_level).upper()
        level = getattr(logging, level_name, logging.WARNING)
    elif verbose >= 2:
        level = logging.DEBUG
    elif verbose == 1:
        level = logging.INFO
    elif quiet:
        level = logging.WARNING
    else:
        level = logging.WARNING

    client_config = load_default_log_client_config()
    server_config = load_default_log_server_config()
    failover_timeout = getattr(args, "log_failover_timeout", None)
    handler = resolve_handler(
        log_target=getattr(args, "log_target", None),
        log_file=getattr(args, "log_file", None),
        client_name=_CLIENT_NAME,
        # Several pm-api-gwy processes run at once (one per api_gateways
        # entry), so the instance name is what tells them apart in the log
        # server's connection registry. args is already parsed here.
        instance=getattr(args, "instance", None),
        host=resolve_host_default(),
        port=server_config.port,
        connect_timeout_sec=client_config.connect_timeout_sec,
        failover_timeout_sec=(
            failover_timeout
            if failover_timeout is not None
            else client_config.failover_timeout_sec
        ),
        failover_dir=client_config.failover_dir,
    )
    logging.basicConfig(level=level, format=_LOG_FORMAT, handlers=[handler])
    return int(level)


def _route_uvicorn_logging(level: str) -> None:
    """Send Uvicorn records through the API gateway's configured handler."""
    uvicorn_level = getattr(logging, str(level).upper(), logging.INFO)
    root = logging.getLogger()
    root.setLevel(min(root.level, uvicorn_level))
    for logger_name in ("uvicorn", "uvicorn.error", "uvicorn.access", "uvicorn.asgi"):
        uvicorn_logger = logging.getLogger(logger_name)
        uvicorn_logger.handlers.clear()
        uvicorn_logger.propagate = True
        uvicorn_logger.setLevel(uvicorn_level)


@exit_on_config_error
def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    _configure_logging(args)
    try:
        config = _config_with_overrides(args)
    except Exception as exc:
        log.critical("failed to resolve configuration: %s", exc)
        sys.exit(1)
    if not config.enabled:
        log.warning("selected api_gateways entry is disabled")
        sys.exit(1)
    app = create_app(config, instance=args.instance)
    _route_uvicorn_logging(config.log_level)
    # A Server rather than uvicorn.run(): the lifespan needs a handle to stop
    # it when the engine listener dies.
    server = uvicorn.Server(
        uvicorn.Config(
            app,
            host=config.host,
            port=config.port,
            log_level=config.log_level,
            log_config=None,
            timeout_graceful_shutdown=GRACEFUL_SHUTDOWN_SEC,
        )
    )
    app.state.server = server
    try:
        server.run()
    except Exception as exc:
        log.critical("fatal runtime error: %s", exc)
        raise
    if getattr(app.state, "listener_failed", False):
        log.critical("a listener died; exiting with status 1")
        sys.exit(1)


if __name__ == "__main__":
    main()
