"""Mapping from engine PUB topics to WebSocket event envelopes."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from edumatcher.models.generated.trade import TOPIC_TRADE_EXECUTED
from edumatcher.models.generated.order import (
    PREFIX_ORDER_ACK,
    PREFIX_ORDER_AMENDED,
    PREFIX_ORDER_CANCELLED,
    PREFIX_ORDER_EXPIRED,
    PREFIX_ORDER_FILL,
    PREFIX_ORDER_TRIGGERED,
    PREFIX_ORDERS,
)
from edumatcher.models.generated.session import TOPIC_SESSION_STATE
from edumatcher.models.generated.book import PREFIX_BOOK_SNAPSHOT, PREFIX_DEPTH
from edumatcher.models.generated.auction import (
    PREFIX_AUCTION_INDICATIVE,
    PREFIX_AUCTION_RESULT,
)
from edumatcher.models.generated.admin import PREFIX_ADMIN_ACTION
from edumatcher.models.generated.risk import PREFIX_KILL_SWITCH_ACK
from edumatcher.models.generated.structure import (
    PREFIX_COMBO_ACK,
    PREFIX_COMBO_CANCEL_ACK,
    PREFIX_COMBO_STATUS,
    PREFIX_OCO_ACK,
    PREFIX_OCO_CANCEL_ACK,
    PREFIX_OCO_CANCELLED,
)
from edumatcher.models.generated.quote import (
    PREFIX_QUOTE_ACK,
    PREFIX_QUOTE_CANCEL_ACK,
    PREFIX_QUOTE_STATUS,
)
from edumatcher.models.generated.registry import TOPIC_REGISTRY
from edumatcher.models.generated.system import (
    PREFIX_GATEWAY_AUTH,
    PREFIX_QUOTE_BOOTSTRAP,
    PREFIX_QUOTE_LEGS,
    PREFIX_SESSION_STATUS,
    PREFIX_SYMBOLS,
)

ORDER_ACK_PREFIX = PREFIX_ORDER_ACK
ORDER_FILL_PREFIX = PREFIX_ORDER_FILL
ORDER_AMENDED_PREFIX = PREFIX_ORDER_AMENDED
ORDER_CANCELLED_PREFIX = PREFIX_ORDER_CANCELLED
ORDER_EXPIRED_PREFIX = PREFIX_ORDER_EXPIRED
SYSTEM_SYMBOLS_PREFIX = PREFIX_SYMBOLS

#: Synthetic admin-monitor-only event (see models.message.make_admin_action_msg).
#: Deliberately NOT in PRIVATE_PREFIXES: it isn't addressed to the trading
#: gateway named in its topic suffix the way order/quote acks are, and must
#: never reach that gateway's own private stream. EngineClient._handle_event
#: checks this prefix before the private/market-data split so it only ever
#: reaches admin monitor sinks.
ADMIN_ACTION_PREFIX = PREFIX_ADMIN_ACTION

#: Topics a *client* sends to the engine, which the engine now re-publishes so
#: the audit trail contains them (engine/main.py::_echo_command). They must
#: reach no client stream: one trader's order intent is not market data, and it
#: is not addressed to any gateway the way an ack is.
#:
#: Read from the spec rather than listed here. Every one of these travels on
#: `engine_push`, and nothing else does, so the set maintains itself as the
#: message families grow -- which matters because the failure mode of a missing
#: entry is a silent leak, not an error.
COMMAND_TOPICS: frozenset[str] = frozenset(
    topic
    for topic, entry in TOPIC_REGISTRY.items()
    if "engine_push" in entry["transport"]
)

PRIVATE_PREFIXES = (
    ORDER_ACK_PREFIX,
    ORDER_FILL_PREFIX,
    ORDER_AMENDED_PREFIX,
    ORDER_CANCELLED_PREFIX,
    ORDER_EXPIRED_PREFIX,
    # A fired stop, ahead of its fills: WebSocket type `order.triggered`.
    PREFIX_ORDER_TRIGGERED,
    PREFIX_ORDERS,
    PREFIX_COMBO_ACK,
    PREFIX_COMBO_STATUS,
    PREFIX_OCO_ACK,
    PREFIX_OCO_CANCELLED,
    PREFIX_QUOTE_ACK,
    PREFIX_QUOTE_STATUS,
    # The outcome of each structure cancel (WP-API17).
    PREFIX_OCO_CANCEL_ACK,
    PREFIX_COMBO_CANCEL_ACK,
    PREFIX_QUOTE_CANCEL_ACK,
    PREFIX_KILL_SWITCH_ACK,
    PREFIX_GATEWAY_AUTH,
    SYSTEM_SYMBOLS_PREFIX,
    PREFIX_QUOTE_BOOTSTRAP,
    PREFIX_QUOTE_LEGS,
    PREFIX_SESSION_STATUS,
)


#: Engine topics addressed to one gateway that are not part of its private
#: stream: replies to its requests (reference bundle, gateway roster, position
#: snapshot, halt status, ...) and acks of its admin commands. Read from the
#: spec, like COMMAND_TOPICS: every engine-published topic whose only
#: parameter is the gateway id, less the private stream and admin.action.
#: They resolve the waiter that asked and go no further.
REPLY_PREFIXES: tuple[str, ...] = tuple(
    sorted(
        entry["prefix"]
        for entry in TOPIC_REGISTRY.values()
        if "engine_pub" in entry["transport"]
        and tuple(entry["params"]) == ("gateway_id",)
        and not entry["prefix"].startswith(PRIVATE_PREFIXES)
        and not entry["prefix"].startswith(ADMIN_ACTION_PREFIX)
    )
)


def now_iso() -> str:
    """Return an RFC3339-ish UTC timestamp for outgoing envelopes."""
    return (
        datetime.now(timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


def gateway_from_topic(topic: str) -> str | None:
    """Extract the trailing gateway id from a private engine topic."""
    for prefix in PRIVATE_PREFIXES:
        if topic.startswith(prefix):
            return topic[len(prefix) :]
    return None


def websocket_type(topic: str) -> str:
    """Translate an engine topic to the stable public WebSocket type."""
    if topic.startswith(ADMIN_ACTION_PREFIX):
        return "admin.action"
    if topic.startswith(PREFIX_KILL_SWITCH_ACK):
        return "mass_cancel.ack"
    if topic == TOPIC_TRADE_EXECUTED:
        return "trade"
    if topic.startswith(PREFIX_BOOK_SNAPSHOT):
        return "book"
    if topic.startswith(PREFIX_DEPTH):
        return "depth"
    if topic == TOPIC_SESSION_STATE:
        return "session"
    if topic.startswith("circuit_breaker."):
        return "circuit_breaker"
    # Two tenses of the same mechanism: `auction.result` is what printed,
    # `auction.indicative` is what would print if the call phase ended now.
    # Both ride the client's `auction` channel; distinct types let the UI tell
    # them apart without inspecting the payload.
    if topic.startswith(PREFIX_AUCTION_INDICATIVE):
        return "auction.indicative"
    if topic.startswith(PREFIX_AUCTION_RESULT):
        return "auction"
    parts = topic.split(".")
    if len(parts) >= 2:
        return f"{parts[0]}.{parts[1]}"
    return topic


def envelope(
    topic: str,
    payload: dict[str, Any],
    *,
    seq: int | None = None,
    stream_seq: int | None = None,
) -> dict[str, Any]:
    """Build the uniform JSON event envelope used by both WebSockets.

    ``topic`` and ``seq`` are additive: ``type``, ``ts``, ``data`` and
    ``gateway_id`` keep their existing meanings, so a client written against
    the previous envelope keeps working and simply ignores the new fields.

    ``topic`` is the engine topic the event came from and is what ``seq``
    counts within — a client tracking gaps must key on ``topic``, not on
    ``type``, because one type (``depth``) spans many topics (``depth.AAPL``,
    ``depth.MSFT``) each with its own independent sequence.

    ``stream_seq`` is present on private events only. Those reach a client
    unfiltered, so one counter across the whole gateway stream is contiguous
    and is simpler to check than one counter per topic. Market data has no
    equivalent because subscribers filter.
    """
    body: dict[str, Any] = {
        "type": websocket_type(topic),
        "topic": topic,
        "ts": now_iso(),
        "data": payload,
    }
    if seq is not None:
        body["seq"] = seq
    if stream_seq is not None:
        body["stream_seq"] = stream_seq
    gateway_id = gateway_from_topic(topic)
    if gateway_id is not None:
        body["gateway_id"] = gateway_id
    return body


def market_data_symbol(topic: str, payload: dict[str, Any]) -> str | None:
    """Find the symbol associated with a public market-data event."""
    if topic.startswith(PREFIX_BOOK_SNAPSHOT) or topic.startswith(PREFIX_DEPTH):
        return topic.split(".", 1)[1]
    if topic.startswith(PREFIX_AUCTION_INDICATIVE):
        return topic[len(PREFIX_AUCTION_INDICATIVE) :].upper()
    if topic.startswith(PREFIX_AUCTION_RESULT):
        return topic[len(PREFIX_AUCTION_RESULT) :].upper()
    raw_symbol = payload.get("symbol")
    return str(raw_symbol).upper() if raw_symbol else None
