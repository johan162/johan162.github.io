"""Per-gateway session caches maintained from engine events."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from edumatcher.api_gateway.events import (
    ORDER_ACK_PREFIX,
    ORDER_AMENDED_PREFIX,
    ORDER_CANCELLED_PREFIX,
    ORDER_EXPIRED_PREFIX,
    ORDER_FILL_PREFIX,
    SYSTEM_SYMBOLS_PREFIX,
)
from edumatcher.models.generated.trade import TOPIC_TRADE_EXECUTED

#: Statuses after which an order can no longer change. Only these are eligible
#: for eviction — a resting order is live state whatever its age.
TERMINAL_ORDER_STATUSES = frozenset({"FILLED", "CANCELLED", "EXPIRED", "REJECTED"})


@dataclass
class SessionCaches:
    """Small in-memory read model for one engine gateway id."""

    orders: dict[str, dict[str, Any]] = field(default_factory=dict)
    quote_legs: dict[str, dict[str, Any]] = field(default_factory=dict)
    positions: dict[str, int] = field(default_factory=dict)
    position_avg_costs: dict[str, float] = field(default_factory=dict)
    last_prices: dict[str, float] = field(default_factory=dict)
    known_symbols: dict[str, dict[str, Any]] = field(default_factory=dict)
    #: order_id -> monotonic-ish wall time the order became terminal, used
    #: only for eviction. Kept beside `orders` rather than inside the order
    #: dicts so it never reaches the wire.
    terminal_at: dict[str, float] = field(default_factory=dict)
    #: Ids of the orders that are still working (not terminal), in the order
    #: they became so. A dict for its order; the values are unused. Kept so a
    #: working-order view costs O(live orders), not a scan of every terminal
    #: order retained for `order_retention_sec` (P1, P2).
    live: dict[str, None] = field(default_factory=dict)

    def apply(self, topic: str, payload: dict[str, Any]) -> None:
        """Fold one engine event into the local cache."""
        if topic.startswith(ORDER_ACK_PREFIX):
            order_id = str(payload.get("order_id", ""))
            if order_id:
                current = self.orders.setdefault(order_id, {"order_id": order_id})
                current.update(payload)
                # order.ack accepted=false answers three different requests:
                # a refused NEW order, and a refused cancel or amend against
                # an order that is still resting. `request` says which. A
                # cancel/amend refusal must not touch the order's status: the
                # order it targets never stopped resting. (request_tag cannot
                # tell them apart: a cancel or amend carries one only when the
                # client set it; API gateway review C1.)
                is_cancel_or_amend_reject = not payload.get("accepted") and payload.get(
                    "request"
                ) in ("CANCEL", "AMEND")
                if not is_cancel_or_amend_reject:
                    self._set_status(
                        order_id,
                        current,
                        "NEW" if payload.get("accepted") else "REJECTED",
                    )
        elif topic.startswith(ORDER_FILL_PREFIX):
            order_id = str(payload.get("order_id", ""))
            if order_id:
                current = self.orders.setdefault(order_id, {"order_id": order_id})
                current.update(payload)
                self._set_status(
                    order_id,
                    current,
                    str(payload.get("status", current.get("status", "PARTIAL"))),
                )
            symbol = str(payload.get("symbol", ""))
            side = str(payload.get("side", ""))
            qty = int(payload.get("fill_qty", 0) or 0)
            price = payload.get("fill_price")
            if symbol and qty and isinstance(price, (int, float)):
                self._apply_fill(symbol, side, qty, float(price))
        elif topic.startswith(ORDER_AMENDED_PREFIX):
            order_id = str(payload.get("order_id", ""))
            if order_id:
                current = self.orders.setdefault(order_id, {"order_id": order_id})
                current.update(payload)
                self._set_status(order_id, current, "AMENDED")
        elif topic.startswith(ORDER_CANCELLED_PREFIX):
            order_id = str(payload.get("order_id", ""))
            if order_id:
                current = self.orders.setdefault(order_id, {"order_id": order_id})
                current.update(payload)
                self._set_status(order_id, current, "CANCELLED")
        elif topic.startswith(ORDER_EXPIRED_PREFIX):
            order_id = str(payload.get("order_id", ""))
            if order_id:
                current = self.orders.setdefault(order_id, {"order_id": order_id})
                current.update(payload)
                self._set_status(order_id, current, "EXPIRED")
        elif topic.startswith("quote."):
            quote_id = str(payload.get("quote_id", ""))
            if quote_id:
                current = self.quote_legs.setdefault(quote_id, {"quote_id": quote_id})
                current.update(payload)
        elif topic.startswith(SYSTEM_SYMBOLS_PREFIX):
            entries = payload.get("symbols", [])
            if isinstance(entries, list):
                for entry in entries:
                    if not isinstance(entry, dict):
                        continue
                    sym = str(entry.get("symbol", "")).upper()
                    if sym:
                        self.known_symbols[sym] = entry
        elif topic == TOPIC_TRADE_EXECUTED:
            symbol = str(payload.get("symbol", ""))
            price = payload.get("price")
            if symbol and isinstance(price, (int, float)):
                self.last_prices[symbol] = float(price)

    def _apply_fill(self, symbol: str, side: str, qty: int, price: float) -> None:
        """Update the per-symbol position ledger from one fill report."""
        pos = self.positions.get(symbol, 0)
        avg_cost = self.position_avg_costs.get(symbol, 0.0)

        if side == "BUY":
            new_pos = pos + qty
            if pos >= 0:
                new_cost = (
                    (avg_cost * pos + price * qty) / new_pos if new_pos != 0 else 0.0
                )
            elif new_pos < 0:
                new_cost = avg_cost
            elif new_pos == 0:
                new_cost = 0.0
            else:
                new_cost = price
        elif side == "SELL":
            new_pos = pos - qty
            if pos <= 0:
                abs_new = abs(new_pos)
                new_cost = (
                    (avg_cost * abs(pos) + price * qty) / abs_new
                    if abs_new != 0
                    else 0.0
                )
            elif new_pos > 0:
                new_cost = avg_cost
            elif new_pos == 0:
                new_cost = 0.0
            else:
                new_cost = price
        else:
            return

        self.positions[symbol] = new_pos
        if new_pos == 0:
            self.position_avg_costs.pop(symbol, None)
        else:
            self.position_avg_costs[symbol] = new_cost

    def _set_status(self, order_id: str, order: dict[str, Any], status: str) -> None:
        """Record a status transition, noting when it became terminal.

        The first terminal timestamp wins: a FILLED order that later receives
        a duplicate event should age from when it actually finished, not from
        the last message about it.
        """
        order["status"] = status
        if status in TERMINAL_ORDER_STATUSES:
            self.terminal_at.setdefault(order_id, time.time())
            self.live.pop(order_id, None)
        else:
            self.terminal_at.pop(order_id, None)
            self.live[order_id] = None

    def submitted(self, order_id: str, order: dict[str, Any]) -> None:
        """Cache an order this gateway is about to send, as ``PENDING``."""
        self.orders[order_id] = order
        self._set_status(order_id, order, "PENDING")

    def evict_terminal_orders(
        self, retention_sec: int, now: float | None = None
    ) -> int:
        """Drop terminal orders older than *retention_sec*. Returns the count.

        Without this the cache grows for the lifetime of the process: nothing
        ever removed a filled or cancelled order. That was an invisible slow
        leak while the cache only backed `GET /orders`; it becomes a visible
        defect once the admin order table reads the same structure, because
        an operator would see this morning's fills in a table of "active"
        orders.

        Only *terminal* orders are evicted — a resting order is live state and
        must never disappear from the cache regardless of age. `retention_sec`
        of 0 disables eviction entirely.

        Positions are deliberately untouched: they are an aggregate, and
        forgetting the order that produced one would not un-do it.
        """
        if retention_sec <= 0:
            return 0
        cutoff = (now if now is not None else time.time()) - retention_sec
        stale = [
            order_id
            for order_id, at in self.terminal_at.items()
            if at < cutoff and order_id in self.orders
        ]
        for order_id in stale:
            del self.orders[order_id]
            del self.terminal_at[order_id]
        return len(stale)
