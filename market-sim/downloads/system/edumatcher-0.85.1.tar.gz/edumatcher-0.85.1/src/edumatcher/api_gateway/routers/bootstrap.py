"""Bootstrap aggregate endpoints — one-request startup payload per role.

Each endpoint issues all independent engine round-trips in parallel using
``asyncio.gather(..., return_exceptions=True)``.  Fields that require a
best-effort query (``session``, ``halts``, ``gateways``) are set to ``null``
and listed in ``incomplete`` when their query times out.  Fields that are
*required* (``reference``, ``orders`` and ``positions`` for trader/mm;
``reference`` for admin) return ``503 ENGINE_TIMEOUT`` if they fail — a
response without them would leave the UI in an unrecoverable state at login
time.

Design doc: docs-design/EduMatcher-bootstrap-api.md
"""

from __future__ import annotations

import asyncio
import logging
import time
from contextlib import closing
from typing import Annotated, Any, TypeAlias, cast

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status

from edumatcher.api_gateway import openapi_docs as docs
from edumatcher.api_gateway.config import ApiGatewayConfig
from edumatcher.api_gateway.events import now_iso
from edumatcher.api_gateway.responses import (
    BootstrapAdmin,
    BootstrapMM,
    BootstrapTrader,
)
from edumatcher.api_gateway.routing import ContractRoute
from edumatcher.api_gateway.routers.reference import (
    fetch_positions,
    fetch_reference_bundle,
    fetch_session,
)
from edumatcher.api_gateway.sessions import (
    Session,
    auth,
    correlation_id,
    report_refusal,
    require_admin,
    require_trading,
)
from edumatcher.audit.archive import session_timezone
from edumatcher.audit.indexer import index_is_available
from edumatcher.models.generated.order import topic_orders
from edumatcher.models.generated.system import (
    topic_gateways,
    topic_halt_status,
    topic_quote_bootstrap,
    topic_quote_legs,
)
from edumatcher.stats.query import (
    open_readonly_connection,
    query_order_events,
    resolve_session_timezone,
)
from edumatcher.stats.trading_day import timezone_name, trading_date

log = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/bootstrap", tags=["bootstrap"], route_class=ContractRoute
)

_FILLS_LIMIT_MAX = 500
_FILLS_LIMIT_DEFAULT = 50
_QueryResult: TypeAlias = dict[str, Any] | list[dict[str, Any]] | BaseException


# ---------------------------------------------------------------------------
# Internal async helpers — each returns the data or raises an exception.
# The callers use asyncio.gather(return_exceptions=True) so one failure
# never aborts the others.
# ---------------------------------------------------------------------------


async def _fetch_reference(request: Request, session: Session) -> dict[str, Any]:
    """Fetch the compiled reference bundle.  503 on timeout — caller treats
    this as a *required* field and re-raises immediately."""
    return await fetch_reference_bundle(request, session)


async def _await_topic(request: Request, topic: str) -> dict[str, Any]:
    return cast(
        dict[str, Any],
        await request.app.state.engine.await_topic(
            topic, request.app.state.config.timeouts.engine_reply_sec
        ),
    )


async def _fetch_orders(request: Request, gateway_id: str) -> dict[str, Any]:
    """Fetch active orders.  No cache fallback — stale order state at login
    is more dangerous than a 503."""
    engine = request.app.state.engine
    engine.request_orders(gateway_id)
    return await _await_topic(request, topic_orders(gateway_id))


def _query_fills_sync(
    config: ApiGatewayConfig, gateway_id: str, fills_limit: int
) -> dict[str, Any]:
    """Blocking stats-DB read for today's fills.

    Raises ``FileNotFoundError`` when the stats DB doesn't exist yet — the
    caller maps that to ``null`` + ``incomplete``.  Runs off the event loop
    via ``asyncio.to_thread`` (see ``_fetch_fills``) so the synchronous SQLite
    I/O never blocks the concurrent engine round-trips.
    """
    conn = open_readonly_connection(config.stats_db)
    with closing(conn) as conn:
        tz, warning = resolve_session_timezone(conn)
        if warning is not None:
            log.warning("bootstrap fills: %s", warning)
        today = trading_date(time.time(), tz)
        events, _ = query_order_events(
            conn,
            gateway_id=gateway_id,
            symbol=None,
            event_type="FILL",
            date_value=today,
            from_ts=None,
            to_ts=None,
            limit=fills_limit,
            tz=tz,
        )
    return {"events": events}


async def _fetch_fills(
    request: Request, gateway_id: str, fills_limit: int
) -> dict[str, Any]:
    """Fetch today's fills from the stats DB, off the event loop.

    Raises ``FileNotFoundError`` when the stats DB doesn't exist yet — the
    caller maps this to ``null`` + ``incomplete``."""
    return await asyncio.to_thread(
        _query_fills_sync, request.app.state.config, gateway_id, fills_limit
    )


async def _fetch_quote_bootstrap(request: Request, gateway_id: str) -> dict[str, Any]:
    engine = request.app.state.engine
    engine.request_quote_bootstrap(gateway_id)
    return await _await_topic(request, topic_quote_bootstrap(gateway_id))


async def _fetch_quote_legs(request: Request, gateway_id: str) -> dict[str, Any]:
    engine = request.app.state.engine
    engine.request_quote_legs(gateway_id)
    return await _await_topic(request, topic_quote_legs(gateway_id))


async def _fetch_gateways(request: Request, gateway_id: str) -> dict[str, Any]:
    engine = request.app.state.engine
    engine.request_gateways(gateway_id)
    return await _await_topic(request, topic_gateways(gateway_id))


async def _fetch_halts(request: Request, correlation: str) -> dict[str, Any]:
    engine = request.app.state.engine
    engine.request_halt_status(correlation)
    return await _await_topic(request, topic_halt_status(correlation))


# ---------------------------------------------------------------------------
# Common helpers
# ---------------------------------------------------------------------------


def _session_timezone() -> str:
    """IANA name of the exchange's ``locale.session_timezone``: the zone every
    client renders wall-clock times in."""
    return timezone_name(session_timezone())


def _capabilities(request: Request, reference: dict[str, Any]) -> dict[str, Any]:
    """Assemble the capability flags from config and reference data."""
    config = request.app.state.config
    schedule = reference.get("schedule") or {}
    sessions_enabled = bool(schedule.get("sessions_enabled", False))
    return {
        "sessions_enabled": sessions_enabled,
        "stats_db_available": config.stats_db.exists(),
        "audit_db_available": index_is_available(config.audit_db),
        "index_available": request.app.state.index_client.is_running(),
    }


def _active_order_counts(request: Request) -> dict[str, int]:
    """Per-gateway count of non-terminal orders.

    Seeded with ``0`` for every authenticated gateway so a connected gateway
    with no live orders still appears (matching the documented response shape
    and keeping the key set aligned with ``monitor_last_seq``).  Any gateway
    with cached orders but no live session is still counted via the union.
    """
    engine = request.app.state.engine
    counts: dict[str, int] = {gid: 0 for gid in engine.active_gateways()}
    for order in engine.all_orders(working=True):
        gid = str(order.get("gateway_id", ""))
        counts[gid] = counts.get(gid, 0) + 1
    return counts


def _monitor_last_seq(request: Request) -> dict[str, int]:
    engine = request.app.state.engine
    return {gid: engine.stream_seq(gid) for gid in sorted(engine.active_gateways())}


def _items(reply: dict[str, Any] | None, key: str) -> list[Any] | None:
    """The list a reply wraps, un-nested (D6); ``None`` stays ``None``."""
    return None if reply is None else list(reply.get(key, []))


def _require_or_503(field_results: list[tuple[str, Any]]) -> dict[str, Any]:
    """Return the required fields as a dict, or raise ``503 ENGINE_TIMEOUT``.

    *field_results* is a list of ``(field_name, value_or_exception)`` pairs
    for the endpoint's *required* fields.  A response missing any of them
    would be unusable at login, so the first exception aborts the whole
    request rather than degrading to a partial payload.
    """
    data: dict[str, Any] = {}
    for name, result in field_results:
        if isinstance(result, Exception):
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail={
                    "error": {
                        "code": "ENGINE_TIMEOUT",
                        "message": (
                            f"Required bootstrap field '{name}' could not be "
                            f"fetched: {result}"
                        ),
                    }
                },
            )
        data[name] = result
    return data


def _collect_optional(
    field_results: list[tuple[str, Any]],
    data: dict[str, Any],
    incomplete: list[str],
) -> None:
    """Fold optional results into *data* and *incomplete* in place."""
    for name, result in field_results:
        if isinstance(result, Exception):
            data[name] = None
            incomplete.append(name)
        else:
            data[name] = result


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/trader",
    response_model=BootstrapTrader,
    summary="Startup payload: trader",
    responses=docs.merge(
        docs.ok(
            docs.BOOTSTRAP_TRADER,
            "Everything a trading client needs to render after login. A "
            "read-only key gets `gateway_role: READ_ONLY`, empty positions and "
            "orders and `null` recent_fills, but session and halts like any key.",
        ),
        docs.errors(*docs.TRADING_KEY, "ENGINE_TIMEOUT", "VALIDATION"),
    ),
)
async def bootstrap_trader(
    request: Request,
    session: Annotated[Session, Depends(auth)],
    fills_limit: int = Query(
        default=_FILLS_LIMIT_DEFAULT,
        ge=1,
        le=_FILLS_LIMIT_MAX,
        description="Maximum number of today's fills to include (1–500).",
    ),
) -> dict[str, Any]:
    """One-request startup payload for TRADER, MARKET_MAKER, and ADMIN roles.

    Returns gateway identity, full reference data, live session state,
    positions, active orders, recent fills for today, currently-halted
    symbols, and capability flags.  ``reference``, ``orders`` and
    ``positions`` are required — the endpoint returns ``503`` if any cannot
    be fetched.  ``positions`` are the same engine-sourced rows as
    ``GET /positions``.
    All other engine-backed fields (``session``, ``recent_fills``,
    ``halts``) are optional: they appear as ``null`` with their name listed
    in ``incomplete`` on failure.

    Read-only keys (``gateway_id: null``) receive ``gateway_role: "READ_ONLY"``,
    empty ``positions`` and ``orders`` and ``null`` ``recent_fills`` (there is
    no gateway to own them), but ``session`` and ``halts`` like any caller.
    """
    engine = request.app.state.engine
    timeout = request.app.state.config.timeouts.engine_reply_sec
    gateway_id = session.gateway_id

    # --- read-only credential: no gateway-scoped state ----------------------
    # A keyless credential owns no positions, orders or fills: those are
    # *structurally* empty (not transiently failed), so they stay out of
    # `incomplete`, which means "retry the per-resource endpoint". Session
    # and halts are public and fetched like for anyone else.
    if gateway_id is None:
        correlation = correlation_id(session)
        ro_results: tuple[_QueryResult, _QueryResult, _QueryResult] = (
            await asyncio.gather(
                _fetch_reference(request, session),
                fetch_session(request, correlation),
                _fetch_halts(request, correlation),
                return_exceptions=True,
            )
        )
        ref_r, sess_r, halts_r = ro_results
        reference = _require_or_503([("reference", ref_r)])["reference"]
        ro_incomplete: list[str] = []
        ro_data: dict[str, Any] = {}
        _collect_optional(
            [("session", sess_r), ("halts", halts_r)], ro_data, ro_incomplete
        )
        return {
            "ts": now_iso(),
            "incomplete": ro_incomplete,
            "gateway_id": None,
            "gateway_role": "READ_ONLY",
            "session_timezone": _session_timezone(),
            "reference": reference,
            "session": ro_data.get("session"),
            "positions": [],
            "orders": [],
            "recent_fills": None,
            "halts": _items(ro_data.get("halts"), "halted"),
            "capabilities": _capabilities(request, reference),
        }

    # --- trading credential: all sub-queries in parallel --------------------
    gateway_role = await engine.resolve_role(gateway_id, timeout)
    results: tuple[
        _QueryResult,
        _QueryResult,
        _QueryResult,
        _QueryResult,
        _QueryResult,
        _QueryResult,
    ] = await asyncio.gather(
        _fetch_reference(request, session),
        fetch_session(request, gateway_id),
        _fetch_orders(request, gateway_id),
        fetch_positions(request, gateway_id),
        _fetch_fills(request, gateway_id, fills_limit),
        _fetch_halts(request, gateway_id),
        return_exceptions=True,
    )
    ref_r, sess_r, orders_r, pos_r, fills_r, halts_r = results

    required = _require_or_503(
        [("reference", ref_r), ("orders", orders_r), ("positions", pos_r)]
    )
    reference = required["reference"]

    incomplete: list[str] = []
    data: dict[str, Any] = {}
    _collect_optional(
        [("session", sess_r), ("recent_fills", fills_r), ("halts", halts_r)],
        data,
        incomplete,
    )

    return {
        "ts": now_iso(),
        "incomplete": incomplete,
        "gateway_id": gateway_id,
        "gateway_role": gateway_role,
        "session_timezone": _session_timezone(),
        "reference": reference,
        "session": data.get("session"),
        "positions": required["positions"],
        "orders": required["orders"]["orders"],
        "recent_fills": _items(data.get("recent_fills"), "events"),
        "halts": _items(data.get("halts"), "halted"),
        "capabilities": _capabilities(request, reference),
    }


@router.get(
    "/mm",
    response_model=BootstrapMM,
    summary="Startup payload: market maker",
    responses=docs.merge(
        docs.ok(
            docs.BOOTSTRAP_MM,
            "The trader payload plus the caller's quotes and quote legs.",
        ),
        docs.errors(*docs.TRADING_KEY, "ENGINE_TIMEOUT", "ROLE_DENIED", "VALIDATION"),
    ),
)
async def bootstrap_mm(
    request: Request,
    session: Annotated[Session, Depends(auth)],
    fills_limit: int = Query(
        default=_FILLS_LIMIT_DEFAULT,
        ge=1,
        le=_FILLS_LIMIT_MAX,
        description="Maximum number of today's fills to include (1–500).",
    ),
) -> dict[str, Any]:
    """One-request startup payload for MARKET_MAKER role.

    Superset of ``/bootstrap/trader``: adds ``quote_bootstrap`` (active quote
    state) and ``quote_legs`` (per-leg fill flags and prices).

    Restricted to MARKET_MAKER keys.  TRADER and ADMIN keys receive ``403``.
    ``reference``, ``orders`` and ``positions`` are required (503 on
    failure).  Quote fields and ``session``/``recent_fills``/``halts`` are
    optional (null + incomplete).
    """
    engine = request.app.state.engine
    timeout = request.app.state.config.timeouts.engine_reply_sec

    # Read-only keys raise 403 READ_ONLY here; role gate raises 403 ROLE_DENIED.
    gateway_id = require_trading(session)
    role = await engine.resolve_role(gateway_id, timeout)
    if role != "MARKET_MAKER":
        report_refusal(request, "ROLE_DENIED", "MARKET_MAKER role required", gateway_id)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": {
                    "code": "ROLE_DENIED",
                    "message": "MARKET_MAKER role required",
                }
            },
        )

    # --- all sub-queries in parallel ----------------------------------------
    # 8 args is past typeshed's asyncio.gather tuple overloads (it falls back
    # to list[Any] beyond 6) -- cast back to the known-fixed shape, same as
    # `_await_topic`'s cast a few lines up.
    results = cast(
        tuple[
            _QueryResult,
            _QueryResult,
            _QueryResult,
            _QueryResult,
            _QueryResult,
            _QueryResult,
            _QueryResult,
            _QueryResult,
        ],
        await asyncio.gather(
            _fetch_reference(request, session),
            fetch_session(request, gateway_id),
            _fetch_orders(request, gateway_id),
            fetch_positions(request, gateway_id),
            _fetch_fills(request, gateway_id, fills_limit),
            _fetch_quote_bootstrap(request, gateway_id),
            _fetch_quote_legs(request, gateway_id),
            _fetch_halts(request, gateway_id),
            return_exceptions=True,
        ),
    )
    ref_r, sess_r, orders_r, pos_r, fills_r, qb_r, ql_r, halts_r = results

    # --- required fields (503 on failure) -----------------------------------
    required = _require_or_503(
        [("reference", ref_r), ("orders", orders_r), ("positions", pos_r)]
    )
    reference = required["reference"]

    # --- optional fields ----------------------------------------------------
    incomplete: list[str] = []
    data: dict[str, Any] = {}
    _collect_optional(
        [
            ("session", sess_r),
            ("recent_fills", fills_r),
            ("quotes", qb_r),
            ("quote_legs", ql_r),
            ("halts", halts_r),
        ],
        data,
        incomplete,
    )

    caps = _capabilities(request, reference)

    return {
        "ts": now_iso(),
        "incomplete": incomplete,
        "gateway_id": gateway_id,
        "gateway_role": "MARKET_MAKER",
        "session_timezone": _session_timezone(),
        "reference": reference,
        "session": data.get("session"),
        "positions": required["positions"],
        "orders": required["orders"]["orders"],
        "recent_fills": _items(data.get("recent_fills"), "events"),
        "capabilities": caps,
        "quotes": _items(data.get("quotes"), "quotes"),
        "quote_legs": _items(data.get("quote_legs"), "legs"),
        "halts": _items(data.get("halts"), "halted"),
    }


@router.get(
    "/admin",
    response_model=BootstrapAdmin,
    summary="Startup payload: admin",
    responses=docs.merge(
        docs.ok(
            docs.BOOTSTRAP_ADMIN,
            "Everything an operator console needs after login. "
            "`monitor_last_seq` is each active gateway's private-stream "
            "`stream_seq` now: `/ws/admin/monitor` events for that gateway "
            "carry the same counter, so a console can skip the ones it "
            "already has. The counter belongs to one `pm-api-gwy` process: it "
            "matches only `/ws/admin/monitor` events from the same instance "
            "that answered this request. The monitor has no replay.",
        ),
        docs.errors(*docs.TRADING_KEY, "ENGINE_TIMEOUT", "ROLE_DENIED"),
    ),
)
async def bootstrap_admin(
    request: Request,
    session: Annotated[Session, Depends(auth)],
) -> dict[str, Any]:
    """One-request startup payload for ADMIN role.

    Returns reference data, session state, the full gateway roster, active
    halts, per-gateway active-order counts, per-gateway monitor sequence
    numbers, and capability flags.

    Restricted to ADMIN keys.  ``reference`` is required (503 on failure).
    ``session``, ``gateways``, and ``halts`` are optional (null + incomplete):
    both have the ``/ws/admin/monitor`` WebSocket ``monitor.snapshot`` as an
    immediate fallback.
    """
    gateway_id = await require_admin(request, session)

    # --- all sub-queries in parallel ----------------------------------------
    results: tuple[_QueryResult, _QueryResult, _QueryResult, _QueryResult] = (
        await asyncio.gather(
            _fetch_reference(request, session),
            fetch_session(request, gateway_id),
            _fetch_gateways(request, gateway_id),
            _fetch_halts(request, gateway_id),
            return_exceptions=True,
        )
    )
    ref_r, sess_r, gw_r, halts_r = results

    # --- required fields (503 on failure) -----------------------------------
    required = _require_or_503([("reference", ref_r)])
    reference = required["reference"]

    # --- optional fields ----------------------------------------------------
    incomplete: list[str] = []
    data: dict[str, Any] = {}
    _collect_optional(
        [("session", sess_r), ("gateways", gw_r), ("halts", halts_r)],
        data,
        incomplete,
    )

    caps = _capabilities(request, reference)

    return {
        "ts": now_iso(),
        "incomplete": incomplete,
        "gateway_id": gateway_id,
        "gateway_role": "ADMIN",
        "session_timezone": _session_timezone(),
        "reference": reference,
        "session": data.get("session"),
        "gateways": _items(data.get("gateways"), "gateways"),
        "halts": _items(data.get("halts"), "halted"),
        "active_order_counts": _active_order_counts(request),
        "monitor_last_seq": _monitor_last_seq(request),
        "capabilities": caps,
    }
