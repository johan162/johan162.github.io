"""``metrics.db``: pm-monitor's history for the operator dashboard (§9.5).

pm-monitor is the only writer; the dashboard bridge reads the file read-only.
WAL mode lets those reads run while pm-monitor writes. A second pm-monitor on
the same file is refused (an exclusive lock on ``metrics.db.lock``), since two
writers would each add their own increments to the same daily totals.

What is written, and when
-------------------------
* ``samples_raw`` -- every 10 s, the latest value of each series updated since
  the previous write (one row per series, not one per beacon), every row of
  one write stamped with the write's time. Stamped with each beacon's own
  arrival instead, one process's rows could fall either side of a 10 s
  bucket boundary while another's did not, and a chart of several series
  would miss one in some buckets (a stacked chart then dips to zero).
* ``samples_1m`` -- one row per series per closed minute (a counter's only
  when it moved; a labelled series is kept here only, not in
  ``samples_raw``), from every sample
  pm-monitor received (2 s resolution), not from the 10 s raw rows: min, avg,
  max, last, the number of samples, and for a counter the reset-corrected
  increment (``delta``). A minute written partly before a restart is merged
  with the rest of it afterwards.
* ``daily_totals`` -- per trading date (session timezone) and series, the sum
  of the increments counted into "today" (§9.4). Kept for good.
* ``counter_last`` -- the last value and ``boot_id`` of every counter series,
  as last heard: a row is written when the value or ``boot_id`` changed, or
  once on a new trading date, and only rows of the current trading date are
  resumed from.
* ``events`` -- every ``health.event``; its ``seq`` is the event's ``seq``.

``daily_totals`` and ``counter_last`` are written in the same transaction, so
after a restart pm-monitor resumes exactly where the file says it was: today's
totals come back, and the first beacon of a process that kept running counts
only what happened while pm-monitor was down (I69). Across a trading-date
change there is no resume point: what the process counted then is partly the
earlier day's, so its first value is a baseline, as on a new file.

While writes fail, closed minutes wait for the next write for at most
``BACKLOG_SEC``; older ones are dropped and counted (``dropped_rows``).

Retention runs hourly: raw rows older than ``raw_hours``, minute rows,
events and the ``counter_last`` rows of series not heard from older than
``minute_days``; then ``PRAGMA incremental_vacuum`` returns
the freed pages, so the file stops growing once it holds its window.

Timestamps are UTC ISO-8601 with milliseconds (``monitor.timefmt``); the
session timezone is pinned in ``metrics_meta`` on first open and a mismatch is
refused, as ``pm-stats`` does (F21).
"""

from __future__ import annotations

import logging
import sqlite3
from collections.abc import Generator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, time as dtime
from pathlib import Path
from typing import IO, Any

from edumatcher.monitor.timefmt import iso_utc
from edumatcher.stats.trading_day import resolve_timezone, trading_date

try:  # POSIX; on Windows a second writer is documented as unsupported
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None  # type: ignore[assignment]

log = logging.getLogger(__name__)

RAW_EVERY_SEC = 10.0
RETENTION_EVERY_SEC = 3600.0
MINUTE = 60.0
#: How far back closed minutes wait for the next write while writes fail;
#: older ones are dropped and counted (``dropped_rows``), so a full or
#: read-only disk costs history, not memory.
BACKLOG_SEC = 600.0

SCHEMA = """
CREATE TABLE IF NOT EXISTS metrics_meta (
    key     TEXT PRIMARY KEY,
    value   TEXT NOT NULL
);

-- One row per series; the sample tables refer to it by id, so a sample row
-- does not repeat its source, name and label (I70).
CREATE TABLE IF NOT EXISTS series (
    id      INTEGER PRIMARY KEY,
    source  TEXT NOT NULL,          -- "process/instance@host" or "host"
    name    TEXT NOT NULL,
    label   TEXT NOT NULL DEFAULT '',
    UNIQUE (name, label, source)
);

CREATE TABLE IF NOT EXISTS samples_raw (
    series  INTEGER NOT NULL,       -- series.id
    ts      TEXT NOT NULL,
    value   REAL NOT NULL,
    PRIMARY KEY (series, ts)
) WITHOUT ROWID;

CREATE TABLE IF NOT EXISTS samples_1m (
    series  INTEGER NOT NULL,       -- series.id
    ts      TEXT NOT NULL,          -- bucket start
    v_min   REAL, v_avg REAL, v_max REAL, v_last REAL,
    n       INTEGER NOT NULL,       -- samples in the bucket
    delta   REAL,                   -- counters: reset-corrected increment
    PRIMARY KEY (series, ts)
) WITHOUT ROWID;

-- The sample tables with their series spelled out, for people writing SQL.
CREATE VIEW IF NOT EXISTS v_samples_raw AS
    SELECT r.ts, s.source, s.name, s.label, r.value
    FROM samples_raw r JOIN series s ON s.id = r.series;
CREATE VIEW IF NOT EXISTS v_samples_1m AS
    SELECT m.ts, s.source, s.name, s.label,
           m.v_min, m.v_avg, m.v_max, m.v_last, m.n, m.delta
    FROM samples_1m m JOIN series s ON s.id = m.series;

CREATE TABLE IF NOT EXISTS daily_totals (
    date    TEXT NOT NULL,          -- trading date in the session timezone
    source  TEXT NOT NULL,
    name    TEXT NOT NULL,
    label   TEXT NOT NULL DEFAULT '',
    total   REAL NOT NULL,
    PRIMARY KEY (date, name, label, source)
);
-- avg_per_day looks up one name (and label) across dates; kept for good, so
-- without this every lookup would scan years of rows (review R6).
CREATE INDEX IF NOT EXISTS idx_daily_name ON daily_totals(name, label, date);
-- ... and over all labels: the last dates of one name without reading the
-- rest of its history.
CREATE INDEX IF NOT EXISTS idx_daily_name_date ON daily_totals(name, date);

CREATE TABLE IF NOT EXISTS counter_last (
    source  TEXT NOT NULL,
    name    TEXT NOT NULL,
    label   TEXT NOT NULL DEFAULT '',
    boot_id TEXT NOT NULL,
    value   REAL NOT NULL,
    ts      TEXT NOT NULL,
    PRIMARY KEY (source, name, label)
);

CREATE TABLE IF NOT EXISTS events (
    seq      INTEGER PRIMARY KEY AUTOINCREMENT,  -- numbered by pm-monitor; AUTOINCREMENT keeps the high-water mark
    ts       TEXT NOT NULL,
    kind     TEXT NOT NULL,
    severity TEXT NOT NULL,
    subject  TEXT NOT NULL,         -- gateway id, process key, symbol, rule
    detail   TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_ev_ts ON events(ts);
"""

SeriesKey = tuple[str, str, str]  # (source, name, label)


class StoreLockedError(RuntimeError):
    """Another pm-monitor already writes this metrics.db."""


class IncompatibleStoreError(RuntimeError):
    """The file was recorded under a different session timezone."""


def initialize_schema(conn: sqlite3.Connection) -> None:
    """Create the current schema (idempotent)."""
    conn.executescript(SCHEMA)


@dataclass
class _Minute:
    """One series' samples within one minute."""

    start: float
    v_min: float
    v_max: float
    total: float
    n: int
    last: float
    delta: float | None  # None for a gauge

    def add(self, value: float) -> None:
        self.v_min = min(self.v_min, value)
        self.v_max = max(self.v_max, value)
        self.total += value
        self.n += 1
        self.last = value


class MetricsStore:
    """The single writer of ``metrics.db``.

    Failed initialization closes the connection and releases the writer lock.
    """

    def __init__(
        self,
        path: Path,
        session_tz_name: str,
        *,
        raw_hours: int,
        minute_days: int,
    ) -> None:
        self.path = path
        self.raw_hours = raw_hours
        self.minute_days = minute_days
        session_tz = resolve_timezone(session_tz_name)
        if session_tz is None:
            raise ValueError(f"unknown session timezone {session_tz_name!r}")
        self._session_tz = session_tz
        path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = self._acquire_lock(path)
        conn: sqlite3.Connection | None = None
        try:
            conn = self.conn = sqlite3.connect(str(path), isolation_level=None)
            # Only takes effect on a new file, and only before anything is
            # written to it -- switching to WAL writes the header, so first.
            self.conn.execute("PRAGMA auto_vacuum = INCREMENTAL")
            self.conn.execute("PRAGMA journal_mode = WAL")
            self.conn.execute("PRAGMA synchronous = NORMAL")
            initialize_schema(self.conn)
            self._pin_timezone(session_tz_name)
            self._series: dict[SeriesKey, int] = {
                (src, name, label): sid
                for sid, src, name, label in self.conn.execute(
                    "SELECT id, source, name, label FROM series"
                )
            }
        except Exception:
            try:
                if conn is not None:
                    conn.close()
            finally:
                self._release_lock()
            raise
        self._raw: dict[SeriesKey, float] = {}  # -> the latest value
        #: Series recorded but not yet in the ``series`` table. Registered at
        #: the next raw write, so every series is known (to the history API)
        #: within one raw interval of its first sample, although a labelled
        #: one writes no raw rows and a quiet counter no minute rows (I123).
        self._unregistered: set[SeriesKey] = set()
        self._minutes: dict[SeriesKey, _Minute] = {}
        self._closed: list[tuple[SeriesKey, _Minute]] = []
        #: Closed minutes dropped unwritten (``BACKLOG_SEC``), until taken.
        self.dropped_rows = 0
        self._daily: dict[tuple[str, str, str, str], float] = {}
        #: ``(boot_id, value, trading date)`` of each ``counter_last`` row as
        #: last written, so an unchanged series is written once a date.
        self._written: dict[SeriesKey, tuple[str, float, str]] = {}
        #: Counter series whose ``counter_last`` row retention deleted.
        self.expired_counters: list[SeriesKey] = []
        self._next_raw = 0.0
        self._next_retention = 0.0
        self._new_series: list[SeriesKey] = []

    # ------------------------------------------------------------------
    # open / close
    # ------------------------------------------------------------------

    @staticmethod
    def _acquire_lock(path: Path) -> IO[str] | None:
        if fcntl is None:  # pragma: no cover
            return None
        handle = open(f"{path}.lock", "w", encoding="ascii")
        try:
            fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            handle.close()
            raise StoreLockedError(
                f"{path} is already written by another pm-monitor; run one "
                f"pm-monitor per data directory"
            ) from None
        return handle

    def _release_lock(self) -> None:
        if self._lock is not None:
            self._lock.close()  # closing the descriptor releases the flock
            self._lock = None

    def _pin_timezone(self, name: str) -> None:
        row = self.conn.execute(
            "SELECT value FROM metrics_meta WHERE key = 'session_timezone'"
        ).fetchone()
        if row is not None and row[0] != name:
            raise IncompatibleStoreError(
                f"{self.path} was recorded with session timezone {row[0]!r}, but "
                f"engine config now says {name!r}. Its daily totals would then "
                f"mean two different things. Fix engine config's "
                f"locale.session_timezone back to {row[0]!r}, or move "
                f"{self.path.name} aside to start a new history."
            )
        self.conn.execute(
            "INSERT OR REPLACE INTO metrics_meta(key, value) VALUES ('session_timezone', ?)",
            (name,),
        )

    def close(
        self,
        now_wall: float,
        counters: dict[SeriesKey, tuple[str, float]] | None = None,
    ) -> None:
        """Write everything pending (the current minute too) and close.

        Pass the tracker's ``counters`` whenever increments may be pending:
        the daily totals and the counter state must be written together.
        """
        try:
            self.flush_raw(now_wall, counters)
            self.flush_minutes(now_wall, force=True)
        finally:
            self.conn.close()
            self._release_lock()

    # ------------------------------------------------------------------
    # input
    # ------------------------------------------------------------------

    def record(
        self,
        key: SeriesKey,
        value: float,
        now_wall: float,
        *,
        counter: bool,
        raw: bool = True,
    ) -> None:
        """One sample of one series, as received. ``raw=False`` keeps it in
        the minute table only (I123)."""
        if raw:
            self._raw[key] = value
        elif key not in self._series:
            self._unregistered.add(key)
        start = now_wall - now_wall % MINUTE
        minute = self._minutes.get(key)
        if minute is not None and minute.start != start:
            self._closed.append((key, minute))
            minute = None
        if minute is None:
            self._minutes[key] = _Minute(
                start, value, value, value, 1, value, 0.0 if counter else None
            )
        else:
            minute.add(value)

    def record_increment(
        self, date: str, key: SeriesKey, delta: float, now_wall: float
    ) -> None:
        """An increment counted into ``date``'s total (after :meth:`record`).

        It is also growth in the series' open minute -- but only when
        ``date`` is that minute's trading date: an increment booked to
        another day (a backfill) did not happen in this minute (I102).
        """
        day_key = (date, *key)
        self._daily[day_key] = self._daily.get(day_key, 0.0) + delta
        minute = self._minutes.get(key)
        if (
            minute is not None
            and minute.start == now_wall - now_wall % MINUTE
            and date == trading_date(minute.start, self._session_tz)
        ):
            minute.delta = (minute.delta or 0.0) + delta

    # ------------------------------------------------------------------
    # output
    # ------------------------------------------------------------------

    def due_raw(self, now_wall: float) -> bool:
        return now_wall >= self._next_raw

    def flush_raw(
        self,
        now_wall: float,
        counters: dict[SeriesKey, tuple[str, float]] | None = None,
    ) -> int:
        """Raw rows, daily totals and counter state in one transaction.

        ``counters`` is the tracker's ``(boot_id, value)`` per counter series
        heard since the last write, so the file's totals and its counter
        state always agree. A row is written when its value or ``boot_id``
        changed, or once on a new trading date, so a series heard today has a
        row of today to resume from (:meth:`counter_state`). Returns the raw
        rows written.
        """
        self._next_raw = now_wall + RAW_EVERY_SEC
        daily = [(*k, total) for k, total in self._daily.items() if total]
        ts = iso_utc(now_wall)
        date = trading_date(now_wall, self._session_tz)
        written = {
            k: (boot, v, date)
            for k, (boot, v) in (counters or {}).items()
            if self._written.get(k) != (boot, v, date)
        }
        last = [(*k, boot, v, ts) for k, (boot, v, _date) in written.items()]
        conn = self.conn
        with self._transaction():
            for key in self._unregistered:
                self._series_id(key)
            raw = [(self._series_id(key), ts, v) for key, v in self._raw.items()]
            conn.executemany(
                "INSERT OR REPLACE INTO samples_raw(series, ts, value) VALUES (?, ?, ?)",
                raw,
            )
            conn.executemany(
                "INSERT INTO daily_totals(date, source, name, label, total) "
                "VALUES (?, ?, ?, ?, ?) ON CONFLICT(date, name, label, source) "
                "DO UPDATE SET total = total + excluded.total",
                daily,
            )
            conn.executemany(
                "INSERT OR REPLACE INTO counter_last"
                "(source, name, label, boot_id, value, ts) VALUES (?, ?, ?, ?, ?, ?)",
                last,
            )
        self._raw.clear()
        self._daily.clear()
        self._unregistered.clear()
        self._written.update(written)
        return len(raw)

    def flush_minutes(self, now_wall: float, *, force: bool = False) -> int:
        """Write every closed minute (and the open ones with ``force``).

        A bucket already in the file (written at a shutdown part-way through
        the minute) is merged, not replaced. Minutes that waited longer than
        ``BACKLOG_SEC`` for a write that kept failing are dropped first.
        """
        start = now_wall - now_wall % MINUTE
        for key, minute in list(self._minutes.items()):
            if force or minute.start < start:
                self._closed.append((key, minute))
                del self._minutes[key]
        cutoff = start - BACKLOG_SEC
        kept = [(key, m) for key, m in self._closed if m.start >= cutoff]
        self.dropped_rows += len(self._closed) - len(kept)
        self._closed = kept
        if not self._closed:
            return 0
        with self._transaction():
            self._write_minutes()
        n = len(self._closed)
        self._closed.clear()
        return n

    def _write_minutes(self) -> None:
        rows = [
            (
                self._series_id(key),
                iso_utc(m.start),
                m.v_min,
                m.total / m.n,
                m.v_max,
                m.last,
                m.n,
                m.delta,
            )
            for key, m in self._closed
            # A counter that did not move in its minute says nothing a rate
            # needs (a missing minute is 0): on a busy 300-symbol exchange
            # that was a quarter of every minute's rows (I123). Gauges are
            # always written: a missing minute would break a chart's line.
            if m.delta != 0
        ]
        self.conn.executemany(
            "INSERT INTO samples_1m"
            "(series, ts, v_min, v_avg, v_max, v_last, n, delta) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
            "ON CONFLICT(series, ts) DO UPDATE SET "
            "v_min = min(v_min, excluded.v_min), "
            "v_max = max(v_max, excluded.v_max), "
            "v_avg = (v_avg * n + excluded.v_avg * excluded.n) / (n + excluded.n), "
            "v_last = excluded.v_last, "
            "n = n + excluded.n, "
            "delta = CASE WHEN delta IS NULL AND excluded.delta IS NULL THEN NULL "
            "ELSE coalesce(delta, 0) + coalesce(excluded.delta, 0) END",
            rows,
        )

    def apply_retention(self, now_wall: float) -> bool:
        """Delete rows outside the windows, hourly; True when it ran."""
        if now_wall < self._next_retention:
            return False
        self._next_retention = now_wall + RETENTION_EVERY_SEC
        raw_cut = iso_utc(now_wall - self.raw_hours * 3600)
        minute_cut = iso_utc(now_wall - self.minute_days * 86400)
        with self._transaction():
            expired = self._delete_old(raw_cut, minute_cut)
        for key in expired:
            self._written.pop(key, None)
        self.expired_counters.extend(expired)
        self.conn.execute("PRAGMA incremental_vacuum")
        return True

    def _delete_old(self, raw_cut: str, minute_cut: str) -> list[SeriesKey]:
        """Delete what is outside the windows; return the counter series
        whose ``counter_last`` row went."""
        conn = self.conn
        # Per series, so each delete is a range of the primary key rather
        # than a scan of the table.
        ids = [(sid,) for sid in self._series.values()]
        conn.executemany(
            "DELETE FROM samples_raw WHERE series = ? AND ts < ?",
            [(sid, raw_cut) for (sid,) in ids],
        )
        conn.executemany(
            "DELETE FROM samples_1m WHERE series = ? AND ts < ?",
            [(sid, minute_cut) for (sid,) in ids],
        )
        conn.execute("DELETE FROM events WHERE ts < ?", (minute_cut,))
        return [
            (s, n, lb)
            for s, n, lb in conn.execute(
                "DELETE FROM counter_last WHERE ts < ? RETURNING source, name, label",
                (minute_cut,),
            )
        ]

    def next_event_seq(self) -> int:
        """The ``seq`` the next event takes: past every event ever stored,
        including those retention has deleted (``AUTOINCREMENT``'s record)."""
        row = self.conn.execute(
            "SELECT seq FROM sqlite_sequence WHERE name = 'events'"
        ).fetchone()
        return int(row[0]) + 1 if row else 1

    def add_event(
        self, seq: int, ts: str, kind: str, severity: str, subject: str, detail: str
    ) -> None:
        """Store one event under the ``seq`` it is published with.

        The caller numbers events, not ``AUTOINCREMENT``: an event published
        while a write failed keeps its number, and the next one stored does
        not take it again.
        """
        self.conn.execute(
            "INSERT INTO events(seq, ts, kind, severity, subject, detail) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (seq, ts, kind, severity, subject, detail),
        )

    @contextmanager
    def _transaction(self) -> Generator[None, None, None]:
        """One transaction; on failure roll back, including new series ids."""
        self.conn.execute("BEGIN")
        try:
            yield
            self.conn.execute("COMMIT")
        except BaseException:
            self.conn.execute("ROLLBACK")
            self._forget_new_series()
            raise
        self._new_series.clear()

    def _series_id(self, key: SeriesKey) -> int:
        """The id of a series, created on first use (inside a transaction)."""
        sid = self._series.get(key)
        if sid is None:
            source, name, label = key
            self.conn.execute(
                "INSERT OR IGNORE INTO series(source, name, label) VALUES (?, ?, ?)",
                key,
            )
            row = self.conn.execute(
                "SELECT id FROM series WHERE name = ? AND label = ? AND source = ?",
                (name, label, source),
            ).fetchone()
            sid = self._series[key] = int(row[0])
            self._new_series.append(key)
        return sid

    def _forget_new_series(self) -> None:
        """A rolled-back transaction took the series rows it created along."""
        for key in self._new_series:
            self._series.pop(key, None)
        self._new_series.clear()

    # ------------------------------------------------------------------
    # restart
    # ------------------------------------------------------------------

    def counter_state(self, date: str) -> dict[SeriesKey, tuple[str, float]]:
        """The ``(boot_id, value)`` of every counter series last written on
        trading date ``date``; they count as written today.

        A value written on an earlier date is no resume point: the increment
        from it would book part of that date (and, for the engine's counters
        it resets at PRE_OPEN, lose its total) to ``date``.
        """
        day = datetime.strptime(date, "%Y-%m-%d").date()
        start = datetime.combine(day, dtime.min, self._session_tz).timestamp()
        rows = self.conn.execute(
            "SELECT source, name, label, boot_id, value FROM counter_last "
            "WHERE ts >= ?",
            (iso_utc(start),),
        )
        state = {(s, n, lb): (boot, v) for s, n, lb, boot, v in rows}
        self._written.update({key: (boot, v, date) for key, (boot, v) in state.items()})
        return state

    def totals_for(self, date: str) -> list[tuple[str, str, str, float]]:
        """``(source, name, label, total)`` of one trading date."""
        rows = self.conn.execute(
            "SELECT source, name, label, total FROM daily_totals WHERE date = ?",
            (date,),
        )
        return [(s, n, lb, float(t)) for s, n, lb, t in rows]

    def session_opened(self, date: str) -> float | None:
        """When the session first left ``CLOSED`` on trading date ``date``,
        from its ``SESSION`` event (``CLOSED -> PRE_OPEN``); ``None`` if it
        has not."""
        day = datetime.strptime(date, "%Y-%m-%d").date()
        start = datetime.combine(day, dtime.min, self._session_tz).timestamp()
        row = self.conn.execute(
            "SELECT ts FROM events WHERE kind = 'SESSION' AND ts >= ? "
            "AND detail LIKE 'CLOSED -> %' AND detail != 'CLOSED -> CLOSED' "
            "ORDER BY ts LIMIT 1",
            (iso_utc(start),),
        ).fetchone()
        return None if row is None else datetime.fromisoformat(row[0]).timestamp()

    def avg_per_day(
        self, name: str, label: str | None, before: str, days: int = 7
    ) -> float | None:
        """Mean daily total of ``name`` (one label, or all summed) over the
        last ``days`` trading dates with data before ``before``; ``None``
        without any."""
        where = "name = ?"
        args: list[Any] = [name]
        if label is not None:
            where += " AND label = ?"
            args.append(label)
        # The dates first, from the index, then only their rows: grouping
        # every date of a name read its whole history, kept for good.
        rows = self.conn.execute(
            f"SELECT SUM(total) FROM daily_totals WHERE {where} AND date IN ("
            f"SELECT DISTINCT date FROM daily_totals WHERE {where} AND date < ? "
            f"ORDER BY date DESC LIMIT ?) GROUP BY date",
            (*args, *args, before, days),
        ).fetchall()
        if not rows:
            return None
        return sum(float(r[0]) for r in rows) / len(rows)
