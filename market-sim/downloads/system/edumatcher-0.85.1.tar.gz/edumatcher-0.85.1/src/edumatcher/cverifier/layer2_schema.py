"""Layer 2 — Schema validation: required fields, correct types, value ranges."""

from __future__ import annotations

import difflib
import math
from pathlib import Path
from typing import Any, cast

from edumatcher.alf_gwy.config import validate_alf_gateway_section
from edumatcher.api_gateway.config import validate_api_gateway_sections
from edumatcher.balf_gwy.config import validate_balf_gateway_section
from edumatcher.config_coerce import as_int
from edumatcher.dc_gateway.config import validate_dc_gateway_section
from edumatcher.engine.config_loader import EngineConfig, engine_config_from_raw
from edumatcher.log_srv.config import validate_log_server_section
from edumatcher.md_gateway.config import validate_market_data_gateway_section
from edumatcher.monitor.config import THRESHOLD_RULES, validate_monitor_section
from edumatcher.models.combo import ComboLeg, ComboType
from edumatcher.models.order import TIF
from edumatcher.models.price import TickViolation, to_ticks_exact_at
from edumatcher.ralf_gateway.config import validate_ralf_gateway_section
from edumatcher.cverifier.models import CheckResult, Severity

_VALID_ROLES = {"TRADER", "MARKET_MAKER", "ADMIN"}
_VALID_DISCONNECT = {"CANCEL_ALL", "CANCEL_QUOTES_ONLY", "LEAVE_ALL"}
_VALID_TIF = {"DAY", "GTC"}
_VALID_QUOTE_REFRESH = {
    "INACTIVATE_ON_ANY_FILL",
    "INACTIVATE_ON_FULL_FILL",
    "NEVER_INACTIVATE",
}
_VALID_SMP_ACTIONS = {
    "NONE",
    "CANCEL_AGGRESSOR",
    "CANCEL_RESTING",
    "CANCEL_BOTH",
}


def _is_positive_int(val: Any) -> bool:
    """Return True if *val* is a non-bool int (or int-like) that is > 0.

    ``bool`` is a subclass of ``int`` in Python, so ``int(True) == 1`` would
    otherwise silently validate a boolean as a positive integer.
    """
    if isinstance(val, bool):
        return False
    try:
        return int(val) > 0
    except TypeError, ValueError, OverflowError:
        return False


def _finite_float(value: Any) -> float:
    """``float(value)``, refusing NaN and infinity as well as non-numbers.

    YAML reads ``.nan`` and ``.inf`` as floats, and NaN passes every
    ``x <= 0`` check; no process can use either.
    """
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("not a finite number")
    return number


def _null_field(
    code: str,
    path: str,
    results: list[CheckResult],
    suggestion: str = "Give it a value, or remove the key to use the default.",
) -> None:
    """Report a key written with no value (YAML ``null``).

    The loaders read ``key:`` as present-and-null, not as absent, and refuse
    it; reporting it as absent would pass a file pm-config-deploy refuses.
    """
    results.append(
        CheckResult(
            code=code,
            severity=Severity.ERROR,
            message=f"'{path}' has no value (null).",
            suggestion=suggestion,
            path=path,
        )
    )


def check(raw: dict[str, Any], path: Path) -> list[CheckResult]:  # noqa: ARG001
    """Run Layer 2 schema checks against the raw YAML dict."""
    results: list[CheckResult] = []
    _check_top_level(raw, results)
    if any(r.severity is Severity.ERROR for r in results):
        # No point checking symbols/gateways if top-level structure is missing
        return results
    _check_runtime_flags(raw, results)
    _check_mm_obligation_defaults_schema(raw, results)
    _check_symbols(raw, results)
    _check_gateways(raw, results)
    _check_gateway_default(raw, results)
    _check_market_maker_combos(raw, results)
    _check_indices(raw, results)
    _check_cb_defaults(raw, results)
    _check_risk_controls(raw, results)
    _check_alf_gateway(raw, results)
    _check_balf_gateway(raw, results)
    _check_post_trade_gateway(raw, results)
    _check_market_data_gateway(raw, results)
    _check_dc_gateway(raw, results)
    _check_log_server(raw, results)
    _check_monitor(raw, results)
    _check_api_gateway_sections(raw, results)
    _check_unknown_process_keys(raw, results)
    _check_unknown_engine_keys(raw, results)
    return results


# ---------------------------------------------------------------------------
# Engine loader backstop (S132)
# ---------------------------------------------------------------------------

# Sections the engine loader does not read. Their findings say nothing about
# whether the engine section loads, so they do not suppress the backstop.
_PROCESS_SECTIONS = frozenset(
    {
        "alf_gateway",
        "balf_gateway",
        "market_data_gateway",
        "post_trade_gateway",
        "dc_gateway",
        "log_server",
        "monitor",
        "api_gateways",
        "api_gateway",
    }
)


def check_engine_loader(
    raw: dict[str, Any], reported: list[CheckResult]
) -> tuple[list[CheckResult], EngineConfig | None]:
    """S132 — run the engine loader on the mapping, as pm-config-deploy does.

    The hand-written checks give precise, independent messages; this makes
    sure a file they pass is also one the loader accepts. The CLI calls it
    after the semantic layer, because several M-codes describe loader errors
    more precisely. It stays quiet when an engine-section ERROR has already
    been reported: the loader stops at its first failure and would only
    restate it.

    Returns the findings and, when the file loads, the EngineConfig (also
    when the finding itself was suppressed).
    """
    try:
        return [], engine_config_from_raw(raw)
    except Exception as exc:  # compile_config turns any loader error into a refusal
        refusal = exc
    for result in reported:
        if result.severity is not Severity.ERROR:
            continue
        section = result.path.split(".", 1)[0].split("[", 1)[0]
        if section not in _PROCESS_SECTIONS:
            return [], None
    return [
        CheckResult(
            code="S132",
            severity=Severity.ERROR,
            message=f"The engine loader refuses this file: {refusal}.",
            suggestion=(
                "pm-config-deploy refuses it with the same message. Fix the "
                "field it names."
            ),
        )
    ], None


# ---------------------------------------------------------------------------
# Top-level required keys
# ---------------------------------------------------------------------------


def _check_top_level(raw: dict[str, Any], results: list[CheckResult]) -> None:
    symbols = raw.get("symbols")
    if not isinstance(symbols, dict):
        results.append(
            CheckResult(
                code="S001",
                severity=Severity.ERROR,
                message="'symbols' is required and must be a mapping.",
                suggestion="Add at least one symbol entry under 'symbols:'.",
                path="symbols",
            )
        )
    elif not symbols:
        results.append(
            CheckResult(
                code="S004",
                severity=Severity.ERROR,
                message="'symbols' contains no entries.",
                suggestion="Add at least one symbol (e.g. AAPL) with tick_decimals.",
                path="symbols",
            )
        )

    participants = raw.get("participants")
    if not isinstance(participants, list):
        results.append(
            CheckResult(
                code="S002",
                severity=Severity.ERROR,
                message="'participants' is required and must be a list of participant entries.",
                suggestion=(
                    "Add a 'participants:' list. "
                    "See the configuration guide for the required fields."
                ),
                path="participants",
            )
        )
    elif not participants:
        results.append(
            CheckResult(
                code="S005",
                severity=Severity.ERROR,
                message="'participants' contains no participant entries.",
                suggestion="Add at least one participant with an id and role.",
                path="participants",
            )
        )


# ---------------------------------------------------------------------------
# Price grid
# ---------------------------------------------------------------------------


def _tick_decimals_of(cfg: dict[str, Any]) -> int | None:
    """A symbol's declared tick precision, or None when it is unusable.

    A malformed ``tick_decimals`` is S010's to report. There is no grid to
    check prices against until it is fixed, so the grid checks stand down
    rather than guessing at the two-decimal default.
    """
    td = cfg.get("tick_decimals", 2)
    if isinstance(td, bool):
        return None
    try:
        td_int = int(td)
    except TypeError, ValueError, OverflowError:
        return None
    return td_int if 0 <= td_int <= 8 else None


def _check_price_on_grid(
    value: Any,
    tick_decimals: int,
    symbol: str,
    label: str,
    path: str,
    results: list[CheckResult],
) -> None:
    """S078 — a price the symbol's tick grid cannot represent.

    Every price in this file is display money that the engine converts to
    integer ticks, and it refuses one that is not a whole number of them.
    Checking it here costs nothing and moves the failure from a startup on a
    deployed host to the verifier the config passes through first.

    A non-numeric value is somebody else's check; this one stays quiet so a
    single bad field does not report twice.
    """
    try:
        price = _finite_float(value)
    except TypeError, ValueError, OverflowError:
        return
    try:
        to_ticks_exact_at(price, tick_decimals, symbol)
    except TickViolation as exc:
        results.append(
            CheckResult(
                code="S078",
                severity=Severity.ERROR,
                message=(
                    f"{label} {price} is not a multiple of {symbol}'s tick size "
                    f"{exc.tick_size:.{tick_decimals}f}."
                ),
                suggestion=(
                    f"With tick_decimals={tick_decimals}, {symbol} prices carry at "
                    f"most {tick_decimals} decimal place(s). Round the price, or "
                    f"raise symbols.{symbol}.tick_decimals."
                ),
                path=path,
            )
        )


# ---------------------------------------------------------------------------
# Symbol validation
# ---------------------------------------------------------------------------


def _check_symbols(raw: dict[str, Any], results: list[CheckResult]) -> None:
    symbols = raw.get("symbols", {})
    if not isinstance(symbols, dict):
        return

    defined_levels = _get_defined_risk_levels(raw)
    cb_default_levels = _get_cb_default_levels(raw)

    for sym_raw, cfg in symbols.items():
        sym = str(sym_raw).upper()
        if not isinstance(cfg, dict):
            cfg = {}

        _check_symbol_tick_decimals(sym, cfg, results)
        _check_symbol_prices(sym, cfg, results)
        _check_symbol_outstanding_shares(sym, cfg, results)
        _check_symbol_level(sym, cfg, defined_levels, results)
        _check_symbol_mm_quotes(sym, cfg, results)
        _check_symbol_collar(sym, cfg, results)
        _check_symbol_order_limits(sym, cfg, results)
        _check_symbol_circuit_breaker(sym, cfg, cb_default_levels, results)


def _check_symbol_tick_decimals(
    sym: str, cfg: dict[str, Any], results: list[CheckResult]
) -> None:
    td = cfg.get("tick_decimals", 2)
    try:
        if isinstance(td, bool):
            raise ValueError("bool is not a valid integer")
        td_int = int(td)
        if not (0 <= td_int <= 8):
            raise ValueError("out of range")
    except TypeError, ValueError, OverflowError:
        results.append(
            CheckResult(
                code="S010",
                severity=Severity.ERROR,
                message=(
                    f"Symbol '{sym}': tick_decimals must be an integer between 0 and 8. "
                    f"Got '{td}'."
                ),
                suggestion=(
                    "Common values are 2 (dollars/cents) or 0 (integer ticks).\n"
                    f"    symbols:\n      {sym}:\n        tick_decimals: 2"
                ),
                path=f"symbols.{sym}.tick_decimals",
            )
        )


def _check_symbol_prices(
    sym: str, cfg: dict[str, Any], results: list[CheckResult]
) -> None:
    tick_decimals = _tick_decimals_of(cfg)
    for price_field in ("last_buy_price", "last_sell_price"):
        val = cfg.get(price_field)
        if val is None:
            continue
        try:
            _finite_float(val)
        except TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S011",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}': {price_field} must be a finite number. "
                        f"Got '{val}'."
                    ),
                    suggestion="Set to a positive number or omit entirely.",
                    path=f"symbols.{sym}.{price_field}",
                )
            )
            continue
        if tick_decimals is not None:
            _check_price_on_grid(
                val,
                tick_decimals,
                sym,
                f"Symbol '{sym}': {price_field}",
                f"symbols.{sym}.{price_field}",
                results,
            )


def _check_symbol_outstanding_shares(
    sym: str, cfg: dict[str, Any], results: list[CheckResult]
) -> None:
    val = cfg.get("outstanding_shares")
    if val is not None and not _is_positive_int(val):
        results.append(
            CheckResult(
                code="S012",
                severity=Severity.ERROR,
                message=(
                    f"Symbol '{sym}': outstanding_shares must be a positive integer. "
                    f"Got '{val}'."
                ),
                suggestion="This field is required for index constituents.",
                path=f"symbols.{sym}.outstanding_shares",
            )
        )


def _check_symbol_level(
    sym: str,
    cfg: dict[str, Any],
    defined_levels: set[str],
    results: list[CheckResult],
) -> None:
    level_raw = cfg.get("level")
    if level_raw is not None and defined_levels:
        level = str(level_raw).strip().upper()
        if level not in defined_levels:
            defined_str = ", ".join(sorted(defined_levels)) or "(none)"
            results.append(
                CheckResult(
                    code="S013",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}': level '{level}' is not defined in "
                        f"risk_controls.levels. Defined levels are: {defined_str}."
                    ),
                    suggestion=(
                        f"Either add '{level}' to risk_controls.levels or change "
                        f"the symbol's level to an existing one."
                    ),
                    path=f"symbols.{sym}.level",
                )
            )
    elif level_raw is not None and not defined_levels:
        level = str(level_raw).strip().upper()
        results.append(
            CheckResult(
                code="S013",
                severity=Severity.ERROR,
                message=(
                    f"Symbol '{sym}': level '{level}' is not defined in "
                    f"risk_controls.levels. No risk_controls.levels are defined."
                ),
                suggestion=(
                    "Add risk_controls.levels to the config or remove the level field."
                ),
                path=f"symbols.{sym}.level",
            )
        )


def _check_symbol_mm_quotes(
    sym: str, cfg: dict[str, Any], results: list[CheckResult]
) -> None:
    mm_quotes = cfg.get("market_maker_quotes")
    if mm_quotes is None:
        return
    if not isinstance(mm_quotes, list):
        results.append(
            CheckResult(
                code="S017",
                severity=Severity.ERROR,
                message=(
                    f"Symbol '{sym}': market_maker_quotes must be a list. "
                    f"Got {type(mm_quotes).__name__}."
                ),
                suggestion="Set market_maker_quotes to a YAML list or remove it.",
                path=f"symbols.{sym}.market_maker_quotes",
            )
        )
        return
    for i, quote in enumerate(mm_quotes):
        if not isinstance(quote, dict):
            results.append(
                CheckResult(
                    code="S018",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}': market_maker_quotes[{i}] must be a mapping. "
                        f"Got {type(quote).__name__}."
                    ),
                    suggestion="Each quote seed must be a YAML mapping with required fields.",
                    path=f"symbols.{sym}.market_maker_quotes[{i}]",
                )
            )
            continue
        gateway_id_raw = quote.get("gateway_id")
        if gateway_id_raw is not None and (
            not isinstance(gateway_id_raw, str) or not gateway_id_raw.strip()
        ):
            results.append(
                CheckResult(
                    code="S019",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}': market_maker_quotes[{i}].gateway_id "
                        "must be a non-empty string when present."
                    ),
                    suggestion="Use a configured gateway id, e.g. MM01.",
                    path=f"symbols.{sym}.market_maker_quotes[{i}].gateway_id",
                )
            )
        # Required fields
        for required in ("gateway_id", "bid_price", "ask_price", "bid_qty", "ask_qty"):
            if required in quote and quote[required] is None:
                # pm-config-gen writes null price stubs for the operator to fill.
                _null_field(
                    "S014",
                    f"symbols.{sym}.market_maker_quotes[{i}].{required}",
                    results,
                    suggestion=(
                        "Fill it in: each quote seed requires gateway_id, "
                        "bid_price, ask_price, bid_qty and ask_qty."
                    ),
                )
            elif required not in quote:
                results.append(
                    CheckResult(
                        code="S014",
                        severity=Severity.ERROR,
                        message=(
                            f"Symbol '{sym}': market_maker_quotes[{i}] is missing '{required}'."
                        ),
                        suggestion=(
                            "Each quote seed requires gateway_id, bid_price, ask_price, "
                            "bid_qty, and ask_qty."
                        ),
                        path=f"symbols.{sym}.market_maker_quotes[{i}]",
                    )
                )
        # Bid/ask crossing
        bid = quote.get("bid_price")
        ask = quote.get("ask_price")
        if bid is not None and ask is not None:
            try:
                if float(bid) >= float(ask):
                    results.append(
                        CheckResult(
                            code="S015",
                            severity=Severity.ERROR,
                            message=(
                                f"Symbol '{sym}': market_maker_quotes[{i}] has "
                                f"bid_price ({bid}) >= ask_price ({ask}). "
                                "The bid must be strictly less than the ask."
                            ),
                            suggestion=(
                                "Swap the values or correct the prices:\n"
                                f"    symbols:\n      {sym}:\n        market_maker_quotes:\n"
                                f"          - gateway_id: ...\n"
                                f"            bid_price: {ask}\n"
                                f"            ask_price: {bid}"
                            ),
                            path=f"symbols.{sym}.market_maker_quotes[{i}]",
                        )
                    )
            except TypeError, ValueError, OverflowError:
                pass

        _check_mm_quote_validity(sym, i, quote, _tick_decimals_of(cfg), results)


def _check_mm_quote_validity(
    sym: str,
    i: int,
    quote: dict[str, Any],
    tick_decimals: int | None,
    results: list[CheckResult],
) -> None:
    """S016 — prices/quantities/tif that the engine would reject at startup."""
    problems: list[str] = []

    for price_field in ("bid_price", "ask_price"):
        val = quote.get(price_field)
        if val is None:
            continue
        try:
            _finite_float(val)
        except TypeError, ValueError, OverflowError:
            problems.append(f"{price_field} must be a finite number (got '{val}')")
            continue
        if tick_decimals is not None:
            _check_price_on_grid(
                val,
                tick_decimals,
                sym,
                f"Symbol '{sym}': market_maker_quotes[{i}].{price_field}",
                f"symbols.{sym}.market_maker_quotes[{i}].{price_field}",
                results,
            )

    for qty_field in ("bid_qty", "ask_qty"):
        val = quote.get(qty_field)
        if val is None:
            continue
        try:
            qty = int(val)
        except TypeError, ValueError, OverflowError:
            problems.append(f"{qty_field} must be a positive integer (got '{val}')")
            continue
        if qty <= 0:
            problems.append(f"{qty_field} must be positive (got {qty})")

    tif = quote.get("tif")
    if "tif" in quote and str(tif).upper() not in _VALID_TIF:
        problems.append(
            f"tif '{tif}' is not valid (use {' or '.join(sorted(_VALID_TIF))})"
        )

    if problems:
        results.append(
            CheckResult(
                code="S016",
                severity=Severity.ERROR,
                message=(
                    f"Symbol '{sym}': market_maker_quotes[{i}] is invalid: "
                    + "; ".join(problems)
                    + "."
                ),
                suggestion=(
                    "The engine rejects this seed at startup. "
                    "Quantities must be positive integers, prices numeric, "
                    "and tif one of DAY or GTC."
                ),
                path=f"symbols.{sym}.market_maker_quotes[{i}]",
            )
        )


def _check_symbol_collar(
    sym: str, cfg: dict[str, Any], results: list[CheckResult]
) -> None:
    """S036–S038 — inline ``symbols.<SYM>.collar`` override.

    Mirrors the validation the engine loader performs on this same field
    (``engine/config_loader.py``, "Optional collar section"), which is
    otherwise never checked here — only the ``risk_controls.levels.*.collar``
    path is (S041/S042).
    """
    collar = cfg.get("collar")
    if collar is None:
        return
    if not isinstance(collar, dict):
        results.append(
            CheckResult(
                code="S036",
                severity=Severity.ERROR,
                message=f"Symbol '{sym}': collar must be a mapping.",
                suggestion="Set collar to a mapping with static_band_pct/dynamic_band_pct.",
                path=f"symbols.{sym}.collar",
            )
        )
        return

    sbp = collar.get("static_band_pct")
    if "static_band_pct" in collar and sbp is None:
        _null_field("S037", f"symbols.{sym}.collar.static_band_pct", results)
    elif sbp is not None:
        try:
            sbp_f = float(sbp)
            if not (0 < sbp_f < 1):
                raise ValueError("out of range")
        except TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S037",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}': collar.static_band_pct {sbp} is outside (0, 1)."
                    ),
                    suggestion="A typical value is 0.20 (20%).",
                    path=f"symbols.{sym}.collar.static_band_pct",
                )
            )

    dbp = collar.get("dynamic_band_pct")
    if "dynamic_band_pct" in collar and dbp is None:
        _null_field("S038", f"symbols.{sym}.collar.dynamic_band_pct", results)
    elif dbp is not None:
        try:
            dbp_f = float(dbp)
            if not (0 < dbp_f < 1):
                raise ValueError("out of range")
        except TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S038",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}': collar.dynamic_band_pct {dbp} is outside (0, 1)."
                    ),
                    suggestion="A typical value is 0.02 (2%).",
                    path=f"symbols.{sym}.collar.dynamic_band_pct",
                )
            )


def _check_symbol_order_limits(
    sym: str, cfg: dict[str, Any], results: list[CheckResult]
) -> None:
    """S114–S116 — ``symbols.<SYM>.order_limits``.

    Mirrors the validation the engine loader performs: the block is a mapping,
    ``max_order_qty`` a positive integer and ``max_order_value`` a positive
    number. An absent cap is legal — it means the cap is not enforced. Symbol
    scope is the only scope; see S117 for the level-scope refusal.
    """
    limits = cfg.get("order_limits")
    if limits is None:
        return
    if not isinstance(limits, dict):
        results.append(
            CheckResult(
                code="S114",
                severity=Severity.ERROR,
                message=f"Symbol '{sym}': order_limits must be a mapping.",
                suggestion=(
                    "Set order_limits to a mapping with max_order_qty and/or "
                    "max_order_value."
                ),
                path=f"symbols.{sym}.order_limits",
            )
        )
        return

    qty = limits.get("max_order_qty")
    if qty is not None:
        try:
            if isinstance(qty, bool):
                raise ValueError("not an integer")
            qty_i = int(qty)
            if qty_i != qty or qty_i <= 0:
                raise ValueError("out of range")
        except TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S115",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}': order_limits.max_order_qty {qty} is "
                        "not a positive integer."
                    ),
                    suggestion="Use a whole number of shares, e.g. 100000.",
                    path=f"symbols.{sym}.order_limits.max_order_qty",
                )
            )

    value = limits.get("max_order_value")
    if value is not None:
        try:
            if isinstance(value, bool):
                raise ValueError("not a number")
            if _finite_float(value) <= 0:
                raise ValueError("out of range")
        except TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S116",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}': order_limits.max_order_value {value} "
                        "is not a positive number."
                    ),
                    suggestion="Use a notional amount in display money, e.g. 5000000.",
                    path=f"symbols.{sym}.order_limits.max_order_value",
                )
            )


def _check_symbol_circuit_breaker(
    sym: str,
    cfg: dict[str, Any],
    cb_default_levels: dict[str, dict[str, Any]],
    results: list[CheckResult],
) -> None:
    """S065–S069 — inline ``symbols.<SYM>.circuit_breaker.levels`` override.

    Mirrors ``_check_cb_defaults`` (S030-S034) field-for-field, but for the
    per-symbol override that the engine loader also fully validates
    (``engine/config_loader.py``, "Optional circuit_breaker section") and
    which was previously never checked here at all.
    """
    cb = cfg.get("circuit_breaker")
    if cb is None:
        return
    if not isinstance(cb, dict):
        results.append(
            CheckResult(
                code="S065",
                severity=Severity.ERROR,
                message=f"Symbol '{sym}': circuit_breaker must be a mapping.",
                suggestion="Set circuit_breaker to a mapping with a 'levels:' key.",
                path=f"symbols.{sym}.circuit_breaker",
            )
        )
        return

    _check_reopening(
        cb.get("reopening"),
        f"symbols.{sym}.circuit_breaker",
        results,
        is_defaults=False,
    )

    levels = cb.get("levels")
    if levels is None:
        return
    if not isinstance(levels, dict):
        results.append(
            CheckResult(
                code="S065",
                severity=Severity.ERROR,
                message=f"Symbol '{sym}': circuit_breaker.levels must be a mapping.",
                suggestion=(
                    "Each key is a level name (e.g. L1) and each value must have price_shift_pct."
                ),
                path=f"symbols.{sym}.circuit_breaker.levels",
            )
        )
        return

    for name, level_cfg in levels.items():
        if not isinstance(level_cfg, dict):
            continue
        default_level = cb_default_levels.get(str(name).upper(), {})
        psp = level_cfg.get("price_shift_pct", default_level.get("price_shift_pct"))
        if psp is None:
            results.append(
                CheckResult(
                    code="S066",
                    severity=Severity.ERROR,
                    message=(
                        f"Symbol '{sym}': circuit_breaker.levels.{name}: "
                        "price_shift_pct is required."
                    ),
                    suggestion="Must be a float in (0, 1), e.g. 0.07 for 7%.",
                    path=f"symbols.{sym}.circuit_breaker.levels.{name}.price_shift_pct",
                )
            )
        else:
            try:
                psp_f = float(psp)
                if not (0 < psp_f < 1):
                    raise ValueError("out of range")
            except TypeError, ValueError, OverflowError:
                results.append(
                    CheckResult(
                        code="S067",
                        severity=Severity.ERROR,
                        message=(
                            f"Symbol '{sym}': circuit_breaker.levels.{name}: "
                            f"price_shift_pct {psp} is outside (0, 1)."
                        ),
                        suggestion="Set a fraction such as 0.07 for 7%.",
                        path=f"symbols.{sym}.circuit_breaker.levels.{name}.price_shift_pct",
                    )
                )

        hd = level_cfg.get("halt_duration_ns")
        if hd is not None:
            try:
                hd_i = int(hd)
                if hd_i <= 0:
                    raise ValueError("must be positive")
            except TypeError, ValueError, OverflowError:
                results.append(
                    CheckResult(
                        code="S068",
                        severity=Severity.ERROR,
                        message=(
                            f"Symbol '{sym}': circuit_breaker.levels.{name}: "
                            f"halt_duration_ns must be a positive integer or null. Got '{hd}'."
                        ),
                        suggestion="Use nanoseconds (e.g. 300000000000 for 5 minutes).",
                        path=f"symbols.{sym}.circuit_breaker.levels.{name}.halt_duration_ns",
                    )
                )


# ---------------------------------------------------------------------------
# Gateway validation
# ---------------------------------------------------------------------------


def _get_cb_default_levels(raw: dict[str, Any]) -> dict[str, dict[str, Any]]:
    cb_defaults = raw.get("circuit_breaker_defaults")
    if not isinstance(cb_defaults, dict):
        return {}
    levels = cb_defaults.get("levels")
    if not isinstance(levels, dict):
        return {}
    return {
        str(name).upper(): level
        for name, level in levels.items()
        if isinstance(level, dict)
    }


def _check_gateway_default(raw: dict[str, Any], results: list[CheckResult]) -> None:
    """S118–S120 — the top-level ``participant_defaults`` block."""
    section = raw.get("participant_defaults")
    if section is None:
        return
    if not isinstance(section, dict):
        results.append(
            CheckResult(
                code="S118",
                severity=Severity.ERROR,
                message=f"'participant_defaults' must be a mapping. Got '{section}'.",
                suggestion=(
                    "Set participant_defaults to a mapping with smp_action and/or "
                    "disconnect_behaviour."
                ),
                path="participant_defaults",
            )
        )
        return

    for key in sorted(set(section) - {"smp_action", "disconnect_behaviour"}, key=str):
        results.append(
            CheckResult(
                code="S118",
                severity=Severity.ERROR,
                message=f"'participant_defaults.{key}' is not a recognised field.",
                suggestion="Supported fields: smp_action, disconnect_behaviour.",
                path=f"participant_defaults.{key}",
            )
        )

    disconnect = section.get("disconnect_behaviour")
    if "disconnect_behaviour" in section and (
        str(disconnect).upper() not in _VALID_DISCONNECT
    ):
        results.append(
            CheckResult(
                code="S119",
                severity=Severity.ERROR,
                message=(
                    f"'participant_defaults.disconnect_behaviour' '{disconnect}' "
                    "is not valid."
                ),
                suggestion=f"Accepted values: {', '.join(sorted(_VALID_DISCONNECT))}.",
                path="participant_defaults.disconnect_behaviour",
            )
        )

    smp_action = section.get("smp_action")
    if "smp_action" in section and str(smp_action).upper() not in _VALID_SMP_ACTIONS:
        results.append(
            CheckResult(
                code="S120",
                severity=Severity.ERROR,
                message=f"'participant_defaults.smp_action' '{smp_action}' is not valid.",
                suggestion=f"Accepted values: {', '.join(sorted(_VALID_SMP_ACTIONS))}.",
                path="participant_defaults.smp_action",
            )
        )


def _check_gateways(raw: dict[str, Any], results: list[CheckResult]) -> None:
    participants = raw.get("participants", [])
    if not isinstance(participants, list):
        return

    seen_ids: dict[str, int] = {}
    gateway_ids: list[tuple[int, str]] = []
    for n, gw in enumerate(participants):
        if not isinstance(gw, dict):
            results.append(
                CheckResult(
                    code="S029",
                    severity=Severity.ERROR,
                    message=(
                        f"participants[{n}] must be a mapping. "
                        f"Got {type(gw).__name__}."
                    ),
                    suggestion="Each participants entry must be a YAML mapping.",
                    path=f"participants[{n}]",
                )
            )
            continue
        gw_id = gw.get("id")
        if not gw_id or not isinstance(gw_id, str) or not str(gw_id).strip():
            results.append(
                CheckResult(
                    code="S020",
                    severity=Severity.ERROR,
                    message=f"participants[{n}] has no 'id' field.",
                    suggestion="Every gateway must have a unique alphanumeric id.",
                    path=f"participants[{n}]",
                )
            )
            continue
        gw_id = str(gw_id).strip().upper()
        if gw_id in seen_ids:
            results.append(
                CheckResult(
                    code="S021",
                    severity=Severity.ERROR,
                    message=(
                        f"Duplicate participant id '{gw_id}' at participants[{n}] "
                        f"and participants[{seen_ids[gw_id]}]."
                    ),
                    suggestion="Each gateway must have a unique id.",
                    path=f"participants[{n}].id",
                )
            )
        else:
            seen_ids[gw_id] = n
            gateway_ids.append((n, gw_id))

        role = gw.get("role", "TRADER")
        if str(role).upper() not in _VALID_ROLES:
            results.append(
                CheckResult(
                    code="S022",
                    severity=Severity.ERROR,
                    message=(f"Gateway '{gw_id}': role '{role}' is not valid."),
                    suggestion=f"Accepted values: {', '.join(sorted(_VALID_ROLES))}.",
                    path=f"participants[{n}].role",
                )
            )

        disconnect = gw.get("disconnect_behaviour")
        if (
            "disconnect_behaviour" in gw
            and str(disconnect).upper() not in _VALID_DISCONNECT
        ):
            results.append(
                CheckResult(
                    code="S023",
                    severity=Severity.ERROR,
                    message=(
                        f"Gateway '{gw_id}': disconnect_behaviour '{disconnect}' is not valid."
                    ),
                    suggestion=(
                        f"Accepted values: {', '.join(sorted(_VALID_DISCONNECT))}."
                    ),
                    path=f"participants[{n}].disconnect_behaviour",
                )
            )

        quote_refresh = gw.get("quote_refresh_policy")
        if (
            quote_refresh is not None
            and str(quote_refresh).upper() not in _VALID_QUOTE_REFRESH
        ):
            results.append(
                CheckResult(
                    code="S024",
                    severity=Severity.ERROR,
                    message=(
                        f"Gateway '{gw_id}': quote_refresh_policy '{quote_refresh}' is not valid."
                    ),
                    suggestion=(
                        "Accepted values: "
                        + ", ".join(sorted(_VALID_QUOTE_REFRESH))
                        + "."
                    ),
                    path=f"participants[{n}].quote_refresh_policy",
                )
            )

        smp_action = gw.get("smp_action")
        if smp_action is not None and str(smp_action).upper() not in _VALID_SMP_ACTIONS:
            results.append(
                CheckResult(
                    code="S086",
                    severity=Severity.ERROR,
                    message=(
                        f"Gateway '{gw_id}': smp_action '{smp_action}' is not valid."
                    ),
                    suggestion=(
                        f"Accepted values: {', '.join(sorted(_VALID_SMP_ACTIONS))}."
                    ),
                    path=f"participants[{n}].smp_action",
                )
            )

        enforce_mm = gw.get("enforce_mm_obligation")
        if enforce_mm is not None and not isinstance(enforce_mm, bool):
            results.append(
                CheckResult(
                    code="S025",
                    severity=Severity.ERROR,
                    message=(
                        f"Gateway '{gw_id}': enforce_mm_obligation must be a boolean. "
                        f"Got '{enforce_mm}'."
                    ),
                    suggestion="Set to true or false.",
                    path=f"participants[{n}].enforce_mm_obligation",
                )
            )

        for field in ("mm_max_spread_ticks", "mm_min_qty"):
            val = gw.get(field)
            if val is None:
                continue
            if not _is_positive_int(val):
                results.append(
                    CheckResult(
                        code="S026",
                        severity=Severity.ERROR,
                        message=(
                            f"Gateway '{gw_id}': {field} must be a positive integer. "
                            f"Got '{val}'."
                        ),
                        suggestion=f"Set participants[{n}].{field} to an integer > 0.",
                        path=f"participants[{n}].{field}",
                    )
                )

        mm_obligations = gw.get("mm_obligations")
        if mm_obligations is not None and not isinstance(mm_obligations, dict):
            results.append(
                CheckResult(
                    code="S027",
                    severity=Severity.ERROR,
                    message=(
                        f"Gateway '{gw_id}': mm_obligations must be a mapping when present."
                    ),
                    suggestion="Use symbol keys under mm_obligations, each with a mapping value.",
                    path=f"participants[{n}].mm_obligations",
                )
            )
        elif isinstance(mm_obligations, dict):
            for sym_raw, obl_raw in mm_obligations.items():
                sym = str(sym_raw).upper()
                if not isinstance(obl_raw, dict):
                    results.append(
                        CheckResult(
                            code="S028",
                            severity=Severity.ERROR,
                            message=(
                                f"Gateway '{gw_id}': mm_obligations.{sym} must be a mapping."
                            ),
                            suggestion="Provide enforce_mm_obligation, max_spread_ticks, min_qty fields.",
                            path=f"participants[{n}].mm_obligations.{sym}",
                        )
                    )
                    continue

                enforce = obl_raw.get("enforce_mm_obligation")
                if enforce is not None and not isinstance(enforce, bool):
                    results.append(
                        CheckResult(
                            code="S028",
                            severity=Severity.ERROR,
                            message=(
                                f"Gateway '{gw_id}': mm_obligations.{sym}.enforce_mm_obligation "
                                "must be a boolean."
                            ),
                            suggestion="Set enforce_mm_obligation to true or false.",
                            path=(
                                f"participants[{n}].mm_obligations.{sym}.enforce_mm_obligation"
                            ),
                        )
                    )

                for field in ("max_spread_ticks", "min_qty"):
                    val = obl_raw.get(field)
                    if val is None:
                        continue
                    if not _is_positive_int(val):
                        results.append(
                            CheckResult(
                                code="S028",
                                severity=Severity.ERROR,
                                message=(
                                    f"Gateway '{gw_id}': mm_obligations.{sym}.{field} "
                                    f"must be a positive integer. Got '{val}'."
                                ),
                                suggestion=f"Set {field} to an integer > 0.",
                                path=f"participants[{n}].mm_obligations.{sym}.{field}",
                            )
                        )

    for i, (idx_a, gw_a) in enumerate(gateway_ids):
        for _idx_b, gw_b in gateway_ids[i + 1 :]:
            if gw_a.startswith(gw_b) or gw_b.startswith(gw_a):
                results.append(
                    CheckResult(
                        code="S084",
                        severity=Severity.ERROR,
                        message=(
                            "participants IDs must not be prefixes of each other "
                            f"('{gw_a}', '{gw_b}')."
                        ),
                        suggestion=(
                            "Rename one of the gateway IDs so neither ID is a "
                            "prefix of another."
                        ),
                        path=f"participants[{idx_a}].id",
                    )
                )


def _check_market_maker_combos(raw: dict[str, Any], results: list[CheckResult]) -> None:
    combos = raw.get("market_maker_combos")
    if combos is None:
        return
    if not isinstance(combos, list):
        results.append(
            CheckResult(
                code="S055",
                severity=Severity.ERROR,
                message="'market_maker_combos' must be a list.",
                suggestion="Set market_maker_combos to a YAML list of combo mappings.",
                path="market_maker_combos",
            )
        )
        return

    raw_symbols = raw.get("symbols") or {}
    symbol_names = {str(sym).upper() for sym in raw_symbols}
    tick_decimals_by_symbol = {
        str(sym).upper(): _tick_decimals_of(cfg if isinstance(cfg, dict) else {})
        for sym, cfg in raw_symbols.items()
    }
    for i, combo in enumerate(combos):
        if not isinstance(combo, dict):
            results.append(
                CheckResult(
                    code="S056",
                    severity=Severity.ERROR,
                    message=(
                        f"market_maker_combos[{i}] must be a mapping. "
                        f"Got {type(combo).__name__}."
                    ),
                    suggestion="Each combo seed entry must be a YAML mapping.",
                    path=f"market_maker_combos[{i}]",
                )
            )
            continue

        combo_id = combo.get("combo_id")
        if not isinstance(combo_id, str) or not combo_id.strip():
            results.append(
                CheckResult(
                    code="S056",
                    severity=Severity.ERROR,
                    message=(
                        f"market_maker_combos[{i}].combo_id must be a non-empty string."
                    ),
                    suggestion="Set combo_id to a non-empty identifier.",
                    path=f"market_maker_combos[{i}].combo_id",
                )
            )

        try:
            ComboType(str(combo.get("combo_type", ComboType.AON.value)).upper())
        except ValueError:
            results.append(
                CheckResult(
                    code="S057",
                    severity=Severity.ERROR,
                    message=f"market_maker_combos[{i}].combo_type is invalid.",
                    suggestion="Use a valid combo_type value (currently AON).",
                    path=f"market_maker_combos[{i}].combo_type",
                )
            )

        try:
            TIF(str(combo.get("tif", TIF.DAY.value)).upper())
        except ValueError:
            results.append(
                CheckResult(
                    code="S057",
                    severity=Severity.ERROR,
                    message=f"market_maker_combos[{i}].tif is invalid.",
                    suggestion="Use one of DAY, GTC, ATO, or ATC.",
                    path=f"market_maker_combos[{i}].tif",
                )
            )

        legs = combo.get("legs")
        if not isinstance(legs, list):
            results.append(
                CheckResult(
                    code="S058",
                    severity=Severity.ERROR,
                    message=f"market_maker_combos[{i}].legs must be a list.",
                    suggestion="Set legs to a YAML list with 2 to 10 leg entries.",
                    path=f"market_maker_combos[{i}].legs",
                )
            )
            continue
        if len(legs) < 2 or len(legs) > 10:
            results.append(
                CheckResult(
                    code="S058",
                    severity=Severity.ERROR,
                    message=f"market_maker_combos[{i}] must have 2 to 10 legs.",
                    suggestion="Adjust the legs list length to be within 2..10.",
                    path=f"market_maker_combos[{i}].legs",
                )
            )

        seen_symbols: set[str] = set()
        for j, leg in enumerate(legs):
            if not isinstance(leg, dict):
                results.append(
                    CheckResult(
                        code="S059",
                        severity=Severity.ERROR,
                        message=(
                            f"market_maker_combos[{i}].legs[{j}] must be a mapping. "
                            f"Got {type(leg).__name__}."
                        ),
                        suggestion="Each combo leg must be a YAML mapping.",
                        path=f"market_maker_combos[{i}].legs[{j}]",
                    )
                )
                continue

            payload = dict(leg)
            if "symbol" in payload:
                payload["symbol"] = str(payload["symbol"]).upper()
            if "side" in payload:
                payload["side"] = str(payload["side"]).upper()
            if "order_type" in payload:
                payload["order_type"] = str(payload["order_type"]).upper()
            if "smp_action" in payload and payload["smp_action"] is not None:
                payload["smp_action"] = str(payload["smp_action"]).upper()

            try:
                parsed_leg = ComboLeg.from_dict(payload)
            except KeyError, TypeError, ValueError, OverflowError:
                results.append(
                    CheckResult(
                        code="S059",
                        severity=Severity.ERROR,
                        message=f"market_maker_combos[{i}].legs[{j}] is invalid.",
                        suggestion=(
                            "Use valid combo leg fields (symbol, side, order_type, "
                            "quantity, and required price/stop fields)."
                        ),
                        path=f"market_maker_combos[{i}].legs[{j}]",
                    )
                )
                continue

            if parsed_leg.symbol in seen_symbols:
                results.append(
                    CheckResult(
                        code="S059",
                        severity=Severity.ERROR,
                        message=(
                            f"market_maker_combos[{i}] contains duplicate symbol "
                            f"'{parsed_leg.symbol}'."
                        ),
                        suggestion="Each symbol may appear at most once per combo.",
                        path=f"market_maker_combos[{i}].legs[{j}].symbol",
                    )
                )
            seen_symbols.add(parsed_leg.symbol)

            if parsed_leg.symbol not in symbol_names:
                results.append(
                    CheckResult(
                        code="S059",
                        severity=Severity.ERROR,
                        message=(
                            f"market_maker_combos[{i}] references unknown symbol "
                            f"'{parsed_leg.symbol}'."
                        ),
                        suggestion=(
                            f"Add '{parsed_leg.symbol}' under symbols or update the leg symbol."
                        ),
                        path=f"market_maker_combos[{i}].legs[{j}].symbol",
                    )
                )
                continue

            for price_field in ("price", "stop_price"):
                leg_price = leg.get(price_field)
                try:
                    if leg_price is not None:
                        _finite_float(leg_price)
                except TypeError, ValueError:
                    results.append(
                        CheckResult(
                            code="S059",
                            severity=Severity.ERROR,
                            message=(
                                f"market_maker_combos[{i}].legs[{j}].{price_field} "
                                f"must be a finite number. Got '{leg_price}'."
                            ),
                            suggestion="Use a display price, e.g. 209.50.",
                            path=f"market_maker_combos[{i}].legs[{j}].{price_field}",
                        )
                    )

            # A leg's scale comes from its own symbol: the legs of one combo
            # trade different instruments and need not share a tick size.
            leg_decimals = tick_decimals_by_symbol.get(parsed_leg.symbol)
            if leg_decimals is None:
                continue
            for price_field in ("price", "stop_price"):
                leg_price = leg.get(price_field)
                if leg_price is None:
                    continue
                _check_price_on_grid(
                    leg_price,
                    leg_decimals,
                    parsed_leg.symbol,
                    f"market_maker_combos[{i}].legs[{j}].{price_field}",
                    f"market_maker_combos[{i}].legs[{j}].{price_field}",
                    results,
                )


def _check_indices(raw: dict[str, Any], results: list[CheckResult]) -> None:
    indices = raw.get("indices")
    if indices is None:
        return
    if not isinstance(indices, list):
        results.append(
            CheckResult(
                code="S043",
                severity=Severity.ERROR,
                message="'indices' must be a list.",
                suggestion="Set indices to a YAML list of index mappings.",
                path="indices",
            )
        )
        return

    seen_ids: set[str] = set()
    for i, idx in enumerate(indices):
        if not isinstance(idx, dict):
            results.append(
                CheckResult(
                    code="S044",
                    severity=Severity.ERROR,
                    message=(
                        f"indices[{i}] must be a mapping. Got {type(idx).__name__}."
                    ),
                    suggestion="Each index entry must be a YAML mapping.",
                    path=f"indices[{i}]",
                )
            )
            continue

        idx_id_raw = idx.get("id")
        idx_id = str(idx_id_raw).strip().upper() if isinstance(idx_id_raw, str) else ""
        if not idx_id:
            results.append(
                CheckResult(
                    code="S045",
                    severity=Severity.ERROR,
                    message=f"indices[{i}].id must be a non-empty string.",
                    suggestion="Set id to a non-empty alphanumeric string.",
                    path=f"indices[{i}].id",
                )
            )
        elif not idx_id.isalnum():
            results.append(
                CheckResult(
                    code="S045",
                    severity=Severity.ERROR,
                    message=f"indices[{i}].id must be alphanumeric.",
                    suggestion="Use only letters and digits in the index id.",
                    path=f"indices[{i}].id",
                )
            )
        elif idx_id in seen_ids:
            results.append(
                CheckResult(
                    code="S045",
                    severity=Severity.ERROR,
                    message=f"Duplicate index id in indices: {idx_id}",
                    suggestion="Ensure each index id is unique.",
                    path=f"indices[{i}].id",
                )
            )
        else:
            seen_ids.add(idx_id)

        desc = idx.get("description")
        if not isinstance(desc, str) or not desc.strip():
            results.append(
                CheckResult(
                    code="S046",
                    severity=Severity.ERROR,
                    message=f"indices[{i}].description must be a non-empty string.",
                    suggestion="Provide a human-readable index description.",
                    path=f"indices[{i}].description",
                )
            )

        for field in ("base_value", "publish_interval_sec"):
            if field not in idx:
                continue
            raw_val = cast(object, idx[field])
            if isinstance(raw_val, bool) or not isinstance(raw_val, (int, float, str)):
                results.append(
                    CheckResult(
                        code="S047",
                        severity=Severity.ERROR,
                        message=f"indices[{i}].{field} must be a number > 0.",
                        suggestion=f"Set {field} to a positive numeric value.",
                        path=f"indices[{i}].{field}",
                    )
                )
                continue
            try:
                num_val = _finite_float(raw_val)
                if num_val <= 0:
                    raise ValueError
            except ValueError:
                results.append(
                    CheckResult(
                        code="S047",
                        severity=Severity.ERROR,
                        message=f"indices[{i}].{field} must be a number > 0.",
                        suggestion=f"Set {field} to a positive numeric value.",
                        path=f"indices[{i}].{field}",
                    )
                )

        for field in ("history_file", "state_file"):
            if field not in idx:
                continue
            path_val = idx.get(field)
            if not isinstance(path_val, str) or not path_val.strip():
                results.append(
                    CheckResult(
                        code="S048",
                        severity=Severity.ERROR,
                        message=f"indices[{i}].{field} must be a non-empty string.",
                        suggestion=f"Set {field} to a non-empty path string.",
                        path=f"indices[{i}].{field}",
                    )
                )

        constituents = idx.get("constituents")
        if not isinstance(constituents, list) or not constituents:
            results.append(
                CheckResult(
                    code="S049",
                    severity=Severity.ERROR,
                    message=f"indices[{i}].constituents must be a non-empty list.",
                    suggestion="Provide a non-empty list of symbol ids.",
                    path=f"indices[{i}].constituents",
                )
            )
            continue

        seen_constituents: set[str] = set()
        for sym in constituents:
            sym_id = str(sym).upper()
            if sym_id in seen_constituents:
                results.append(
                    CheckResult(
                        code="S049",
                        severity=Severity.ERROR,
                        message=(
                            f"indices[{i}].constituents contains duplicate symbol '{sym_id}'."
                        ),
                        suggestion="Remove duplicate symbol entries from constituents.",
                        path=f"indices[{i}].constituents",
                    )
                )
            seen_constituents.add(sym_id)


# ---------------------------------------------------------------------------
# Reopening / Automated Corridor Expansion (ACE)
# ---------------------------------------------------------------------------


def _check_reopening(
    reopening: Any,
    base_path: str,
    results: list[CheckResult],
    *,
    is_defaults: bool,
) -> None:
    """S104–S112 — the ``circuit_breaker.reopening`` block.

    Shared by ``circuit_breaker_defaults`` and each symbol's inline override.
    ``is_defaults`` is False for symbols, which gates the two engine-wide keys:
    ``random_seed`` (one generator serves the whole engine) and ``expansions``
    (the escalation schedule is venue policy, not an instrument property).
    """
    if reopening is None:
        return
    path = f"{base_path}.reopening"
    if not isinstance(reopening, dict):
        results.append(
            CheckResult(
                code="S104",
                severity=Severity.ERROR,
                message=f"'{path}' must be a mapping.",
                suggestion=(
                    "Use a mapping with keys such as enabled, initial_band_pct, "
                    "expansions, random_end_max_ns."
                ),
                path=path,
            )
        )
        return

    if "enabled" in reopening and not isinstance(reopening["enabled"], bool):
        results.append(
            CheckResult(
                code="S105",
                severity=Severity.ERROR,
                message=f"'{path}.enabled' must be a boolean.",
                suggestion="Set true or false.",
                path=f"{path}.enabled",
            )
        )

    if "initial_band_pct" in reopening:
        try:
            band = float(reopening["initial_band_pct"])
            if not (0 < band < 1):
                raise ValueError("out of range")
        except TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S106",
                    severity=Severity.ERROR,
                    message=(
                        f"'{path}.initial_band_pct' "
                        f"({reopening['initial_band_pct']}) is outside (0, 1)."
                    ),
                    suggestion="Set a fraction such as 0.10 for a +/-10% corridor.",
                    path=f"{path}.initial_band_pct",
                )
            )

    if "random_end_max_ns" in reopening:
        try:
            tail = int(reopening["random_end_max_ns"])
            if tail < 0:
                raise ValueError("negative")
        except TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S111",
                    severity=Severity.ERROR,
                    message=(
                        f"'{path}.random_end_max_ns' "
                        f"({reopening['random_end_max_ns']}) must be an integer >= 0."
                    ),
                    suggestion="Use nanoseconds, e.g. 30000000000 for 30s. 0 disables the random end.",
                    path=f"{path}.random_end_max_ns",
                )
            )

    if "random_seed" in reopening and not is_defaults:
        results.append(
            CheckResult(
                code="S110",
                severity=Severity.ERROR,
                message=(
                    f"'{path}.random_seed' is engine-wide and cannot be set per symbol."
                ),
                suggestion="Move random_seed to circuit_breaker_defaults.reopening.",
                path=f"{path}.random_seed",
            )
        )

    if "expansions" in reopening and not is_defaults:
        results.append(
            CheckResult(
                code="S112",
                severity=Severity.ERROR,
                message=(
                    f"'{path}.expansions' is exchange-wide and cannot be set "
                    "per symbol."
                ),
                suggestion=(
                    "Move the ladder to circuit_breaker_defaults.reopening. A "
                    "symbol may still override initial_band_pct."
                ),
                path=f"{path}.expansions",
            )
        )
        return

    expansions = reopening.get("expansions")
    if expansions is None:
        return
    if not isinstance(expansions, list) or not expansions:
        results.append(
            CheckResult(
                code="S107",
                severity=Severity.ERROR,
                message=f"'{path}.expansions' must be a non-empty list.",
                suggestion=(
                    "Each entry needs widen_pct and min_duration_ns. The last entry "
                    "repeats indefinitely, which is what terminates the ladder."
                ),
                path=f"{path}.expansions",
            )
        )
        return

    for idx, rung in enumerate(expansions):
        rung_path = f"{path}.expansions[{idx}]"
        if not isinstance(rung, dict):
            results.append(
                CheckResult(
                    code="S107",
                    severity=Severity.ERROR,
                    message=f"'{rung_path}' must be a mapping.",
                    suggestion="Use {widen_pct: 0.10, min_duration_ns: 120000000000}.",
                    path=rung_path,
                )
            )
            continue
        try:
            widen = float(rung["widen_pct"])
            if not (0 < widen < 1):
                raise ValueError("out of range")
        except KeyError, TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S108",
                    severity=Severity.ERROR,
                    message=(
                        f"'{rung_path}.widen_pct' is required and must be in (0, 1)."
                    ),
                    suggestion="Set a fraction such as 0.10 to widen the corridor by 10%.",
                    path=f"{rung_path}.widen_pct",
                )
            )
        try:
            dur = int(rung["min_duration_ns"])
            if dur <= 0:
                raise ValueError("not positive")
        except KeyError, TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S109",
                    severity=Severity.ERROR,
                    message=(
                        f"'{rung_path}.min_duration_ns' is required and must be > 0."
                    ),
                    suggestion="Use nanoseconds, e.g. 120000000000 for a 2-minute call phase.",
                    path=f"{rung_path}.min_duration_ns",
                )
            )


# ---------------------------------------------------------------------------
# Circuit breaker defaults
# ---------------------------------------------------------------------------


def _check_cb_defaults(raw: dict[str, Any], results: list[CheckResult]) -> None:
    cb = raw.get("circuit_breaker_defaults")
    if cb is None:
        return
    if not isinstance(cb, dict):
        results.append(
            CheckResult(
                code="S030",
                severity=Severity.ERROR,
                message="'circuit_breaker_defaults' must be a mapping.",
                suggestion="Change circuit_breaker_defaults to a mapping with a 'levels:' key.",
                path="circuit_breaker_defaults",
            )
        )
        return

    _check_reopening(
        cb.get("reopening"), "circuit_breaker_defaults", results, is_defaults=True
    )

    levels = cb.get("levels")
    if levels is None:
        return
    if not isinstance(levels, dict):
        results.append(
            CheckResult(
                code="S030",
                severity=Severity.ERROR,
                message="'circuit_breaker_defaults.levels' must be a mapping.",
                suggestion=(
                    "Each key is a level name (e.g. L1) and each value must have price_shift_pct."
                ),
                path="circuit_breaker_defaults.levels",
            )
        )
        return

    thresholds: list[tuple[str, float]] = []
    for name, level_cfg in levels.items():
        if not isinstance(level_cfg, dict):
            continue
        psp = level_cfg.get("price_shift_pct")
        if psp is None:
            results.append(
                CheckResult(
                    code="S031",
                    severity=Severity.ERROR,
                    message=(
                        f"circuit_breaker_defaults.levels.{name}: "
                        "price_shift_pct is required."
                    ),
                    suggestion="Must be a float in (0, 1), e.g. 0.07 for 7%.",
                    path=f"circuit_breaker_defaults.levels.{name}.price_shift_pct",
                )
            )
        else:
            try:
                psp_f = float(psp)
                if not (0 < psp_f < 1):
                    raise ValueError("out of range")
                thresholds.append((str(name), psp_f))
            except TypeError, ValueError, OverflowError:
                results.append(
                    CheckResult(
                        code="S032",
                        severity=Severity.ERROR,
                        message=(
                            f"circuit_breaker_defaults.levels.{name}: "
                            f"price_shift_pct {psp} is outside (0, 1)."
                        ),
                        suggestion="Set a fraction such as 0.07 for 7%.",
                        path=f"circuit_breaker_defaults.levels.{name}.price_shift_pct",
                    )
                )

        hd = level_cfg.get("halt_duration_ns")
        if hd is not None:
            try:
                hd_i = int(hd)
                if hd_i <= 0:
                    raise ValueError("must be positive")
            except TypeError, ValueError, OverflowError:
                results.append(
                    CheckResult(
                        code="S033",
                        severity=Severity.ERROR,
                        message=(
                            f"circuit_breaker_defaults.levels.{name}: "
                            f"halt_duration_ns must be a positive integer or null. Got '{hd}'."
                        ),
                        suggestion="Use nanoseconds (e.g. 300000000000 for 5 minutes).",
                        path=f"circuit_breaker_defaults.levels.{name}.halt_duration_ns",
                    )
                )

    # Warn if thresholds are not strictly increasing
    if len(thresholds) >= 2:
        sorted_by_pct = sorted(thresholds, key=lambda x: x[1])
        if [n for n, _ in thresholds] != [n for n, _ in sorted_by_pct]:
            detail = ", ".join(f"{n}={v:.0%}" for n, v in thresholds)
            results.append(
                CheckResult(
                    code="M014",
                    severity=Severity.WARN,
                    message=(
                        "circuit_breaker_defaults levels are not in ascending order of "
                        f"price_shift_pct: {detail}."
                    ),
                    suggestion="Reorder the levels from smallest to largest threshold.",
                    path="circuit_breaker_defaults.levels",
                )
            )


# ---------------------------------------------------------------------------
# Risk controls
# ---------------------------------------------------------------------------


def _check_risk_controls(raw: dict[str, Any], results: list[CheckResult]) -> None:
    rc = raw.get("risk_controls")
    if rc is None:
        return
    if not isinstance(rc, dict):
        return

    defined_levels = _get_defined_risk_levels(raw)

    default_level = rc.get("default_level")
    if default_level is not None and defined_levels:
        dl = str(default_level).strip().upper()
        if dl not in defined_levels:
            results.append(
                CheckResult(
                    code="S040",
                    severity=Severity.ERROR,
                    message=(
                        f"risk_controls.default_level '{default_level}' is not defined "
                        f"in risk_controls.levels."
                    ),
                    suggestion=(
                        "Add it or change default_level to a name that exists: "
                        + ", ".join(sorted(defined_levels))
                    ),
                    path="risk_controls.default_level",
                )
            )

    levels = rc.get("levels", {})
    if not isinstance(levels, dict):
        return

    for level_name, level_cfg in levels.items():
        if not isinstance(level_cfg, dict):
            continue

        # S035: CB should not be in risk_controls.levels
        if "circuit_breaker" in level_cfg:
            results.append(
                CheckResult(
                    code="S035",
                    severity=Severity.ERROR,
                    message=(
                        f"risk_controls.levels.{level_name}: circuit_breaker is no longer "
                        "supported here."
                    ),
                    suggestion=(
                        "Move it to the top-level circuit_breaker_defaults section."
                    ),
                    path=f"risk_controls.levels.{level_name}.circuit_breaker",
                )
            )

        # S117: order limits are a per-symbol control. Accepting them here
        # would silently enforce nothing, since neither the loader nor the
        # engine reads a level-scope block.
        if level_cfg.get("order_limits") is not None:
            results.append(
                CheckResult(
                    code="S117",
                    severity=Severity.ERROR,
                    message=(
                        f"risk_controls.levels.{level_name}: order_limits is not "
                        "supported here."
                    ),
                    suggestion=(
                        "Set order_limits on each symbol that needs a cap; there "
                        "is no level or global default."
                    ),
                    path=f"risk_controls.levels.{level_name}.order_limits",
                )
            )

        collar = level_cfg.get("collar")
        if not isinstance(collar, dict):
            continue

        sbp = collar.get("static_band_pct")
        if "static_band_pct" in collar and sbp is None:
            _null_field(
                "S041",
                f"risk_controls.levels.{level_name}.collar.static_band_pct",
                results,
            )
        elif sbp is not None:
            try:
                sbp_f = float(sbp)
                if not (0 < sbp_f < 1):
                    raise ValueError("out of range")
            except TypeError, ValueError, OverflowError:
                results.append(
                    CheckResult(
                        code="S041",
                        severity=Severity.ERROR,
                        message=(
                            f"risk_controls.levels.{level_name}.collar.static_band_pct "
                            f"{sbp} is outside (0, 1)."
                        ),
                        suggestion="A typical value is 0.20 (20%).",
                        path=f"risk_controls.levels.{level_name}.collar.static_band_pct",
                    )
                )

        dbp = collar.get("dynamic_band_pct")
        if "dynamic_band_pct" in collar and dbp is None:
            _null_field(
                "S042",
                f"risk_controls.levels.{level_name}.collar.dynamic_band_pct",
                results,
            )
        elif dbp is not None:
            try:
                dbp_f = float(dbp)
                if not (0 < dbp_f < 1):
                    raise ValueError("out of range")
            except TypeError, ValueError, OverflowError:
                results.append(
                    CheckResult(
                        code="S042",
                        severity=Severity.ERROR,
                        message=(
                            f"risk_controls.levels.{level_name}.collar.dynamic_band_pct "
                            f"{dbp} is outside (0, 1)."
                        ),
                        suggestion="A typical value is 0.02 (2%).",
                        path=f"risk_controls.levels.{level_name}.collar.dynamic_band_pct",
                    )
                )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_defined_risk_levels(raw: dict[str, Any]) -> set[str]:
    rc = raw.get("risk_controls")
    if not isinstance(rc, dict):
        return set()
    levels = rc.get("levels")
    if not isinstance(levels, dict):
        return set()
    return {str(k).strip().upper() for k in levels}


def _check_runtime_flags(raw: dict[str, Any], results: list[CheckResult]) -> None:
    sessions_enabled = raw.get("sessions_enabled")
    if "sessions_enabled" in raw and not isinstance(sessions_enabled, bool):
        results.append(
            CheckResult(
                code="S060",
                severity=Severity.ERROR,
                message=(
                    f"'sessions_enabled' must be a boolean when provided. Got '{sessions_enabled}'."
                ),
                suggestion="Set sessions_enabled to true or false.",
                path="sessions_enabled",
            )
        )

    engine_tuning = raw.get("engine_tuning")
    snapshot_path = "engine_tuning.snapshot_interval_sec"
    snapshot_interval = (
        engine_tuning.get("snapshot_interval_sec")
        if isinstance(engine_tuning, dict)
        else None
    )
    if isinstance(engine_tuning, dict) and "snapshot_interval_sec" in engine_tuning:
        try:
            snap = _finite_float(engine_tuning["snapshot_interval_sec"])
            if snap <= 0:
                raise ValueError
        except TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code="S061",
                    severity=Severity.ERROR,
                    message=(
                        "'snapshot_interval_sec' must be a positive number. "
                        f"Got '{snapshot_interval}'."
                    ),
                    suggestion="Set snapshot_interval_sec to a value > 0, e.g. 0.5.",
                    path=snapshot_path,
                )
            )

    enforce_collars = raw.get("enforce_collars")
    if "enforce_collars" in raw and not isinstance(enforce_collars, bool):
        results.append(
            CheckResult(
                code="S062",
                severity=Severity.ERROR,
                message=(
                    f"'enforce_collars' must be a boolean when provided. Got '{enforce_collars}'."
                ),
                suggestion="Set enforce_collars to true or false.",
                path="enforce_collars",
            )
        )

    enforce_cb = raw.get("enforce_circuit_breakers")
    if "enforce_circuit_breakers" in raw and not isinstance(enforce_cb, bool):
        results.append(
            CheckResult(
                code="S063",
                severity=Severity.ERROR,
                message=(
                    "'enforce_circuit_breakers' must be a boolean when provided. "
                    f"Got '{enforce_cb}'."
                ),
                suggestion="Set enforce_circuit_breakers to true or false.",
                path="enforce_circuit_breakers",
            )
        )

    require_mm_seed_quotes = raw.get("require_mm_seed_quotes")
    if "require_mm_seed_quotes" in raw and not isinstance(require_mm_seed_quotes, bool):
        results.append(
            CheckResult(
                code="S113",
                severity=Severity.ERROR,
                message=(
                    "'require_mm_seed_quotes' must be a boolean when provided. "
                    f"Got '{require_mm_seed_quotes}'."
                ),
                suggestion="Set require_mm_seed_quotes to true or false.",
                path="require_mm_seed_quotes",
            )
        )

    schedule = raw.get("schedule")
    if schedule is not None and not isinstance(schedule, dict):
        results.append(
            CheckResult(
                code="S064",
                severity=Severity.ERROR,
                message=f"'schedule' must be a mapping when provided. Got '{schedule}'.",
                suggestion="Set schedule to a YAML mapping with HH:MM fields.",
                path="schedule",
            )
        )

    locale = raw.get("locale")
    if locale is not None and not isinstance(locale, dict):
        results.append(
            CheckResult(
                code="S122",
                severity=Severity.ERROR,
                message=f"'locale' must be a mapping when provided. Got '{locale}'.",
                suggestion="Set locale to a mapping with country/session_timezone fields.",
                path="locale",
            )
        )
    elif locale is not None:
        country = locale.get("country")
        if country is not None and (
            not isinstance(country, str) or not country.strip()
        ):
            results.append(
                CheckResult(
                    code="S134",
                    severity=Severity.ERROR,
                    message=(
                        "'locale.country' must be a non-empty string when "
                        f"provided. Got '{country}'."
                    ),
                    suggestion=(
                        'Set locale.country to a country name (e.g. "Sweden") or an '
                        'ISO 3166-1 alpha-2 code (e.g. "SE").'
                    ),
                    path="locale.country",
                )
            )

        session_timezone = locale.get("session_timezone")
        if session_timezone is not None and (
            not isinstance(session_timezone, str) or not session_timezone.strip()
        ):
            results.append(
                CheckResult(
                    code="S123",
                    severity=Severity.ERROR,
                    message=(
                        "'locale.session_timezone' must be a non-empty string "
                        f"when provided. Got '{session_timezone}'."
                    ),
                    suggestion="Set locale.session_timezone to an IANA timezone name.",
                    path="locale.session_timezone",
                )
            )


def _check_mm_obligation_defaults_schema(
    raw: dict[str, Any], results: list[CheckResult]
) -> None:
    section = raw.get("mm_obligation_defaults")
    if section is None:
        return

    if not isinstance(section, dict):
        results.append(
            CheckResult(
                code="S070",
                severity=Severity.ERROR,
                message="'mm_obligation_defaults' must be a mapping.",
                suggestion="Set mm_obligation_defaults to a mapping with policy fields.",
                path="mm_obligation_defaults",
            )
        )
        return

    enforce = section.get("enforce_mm_obligation")
    if "enforce_mm_obligation" in section and not isinstance(enforce, bool):
        results.append(
            CheckResult(
                code="S071",
                severity=Severity.ERROR,
                message=(
                    "'mm_obligation_defaults.enforce_mm_obligation' must be a boolean. "
                    f"Got '{enforce}'."
                ),
                suggestion="Set to true or false.",
                path="mm_obligation_defaults.enforce_mm_obligation",
            )
        )

    for field, code in (
        ("mm_max_spread_ticks", "S072"),
        ("mm_min_qty", "S073"),
    ):
        if field not in section:
            continue
        val = section[field]
        try:
            parsed = int(val)
            if parsed <= 0:
                raise ValueError
        except TypeError, ValueError, OverflowError:
            results.append(
                CheckResult(
                    code=code,
                    severity=Severity.ERROR,
                    message=(
                        f"'mm_obligation_defaults.{field}' must be a positive integer. "
                        f"Got '{val}'."
                    ),
                    suggestion=f"Set {field} to an integer > 0.",
                    path=f"mm_obligation_defaults.{field}",
                )
            )

    sym_map = section.get("symbols")
    if sym_map is not None and not isinstance(sym_map, dict):
        results.append(
            CheckResult(
                code="S074",
                severity=Severity.ERROR,
                message="'mm_obligation_defaults.symbols' must be a mapping.",
                suggestion="Use symbol keys (e.g. AAPL) with mapping values.",
                path="mm_obligation_defaults.symbols",
            )
        )
        return

    if not isinstance(sym_map, dict):
        return

    for sym_raw, sym_cfg in sym_map.items():
        sym = str(sym_raw).upper()
        if not isinstance(sym_cfg, dict):
            results.append(
                CheckResult(
                    code="S075",
                    severity=Severity.ERROR,
                    message=(
                        f"'mm_obligation_defaults.symbols.{sym}' must be a mapping."
                    ),
                    suggestion=(
                        "Set symbol override to a mapping with enforce_mm_obligation, "
                        "mm_max_spread_ticks, and mm_min_qty."
                    ),
                    path=f"mm_obligation_defaults.symbols.{sym}",
                )
            )
            continue

        sym_enforce = sym_cfg.get("enforce_mm_obligation")
        if "enforce_mm_obligation" in sym_cfg and not isinstance(sym_enforce, bool):
            results.append(
                CheckResult(
                    code="S076",
                    severity=Severity.ERROR,
                    message=(
                        "'mm_obligation_defaults.symbols."
                        f"{sym}.enforce_mm_obligation' must be a boolean."
                    ),
                    suggestion="Set enforce_mm_obligation to true or false.",
                    path=f"mm_obligation_defaults.symbols.{sym}.enforce_mm_obligation",
                )
            )

        for field in ("mm_max_spread_ticks", "mm_min_qty"):
            if field not in sym_cfg:
                continue
            val = sym_cfg[field]
            try:
                parsed = int(val)
                if parsed <= 0:
                    raise ValueError
            except TypeError, ValueError, OverflowError:
                results.append(
                    CheckResult(
                        code="S077",
                        severity=Severity.ERROR,
                        message=(
                            "'mm_obligation_defaults.symbols."
                            f"{sym}.{field}' must be a positive integer. Got '{val}'."
                        ),
                        suggestion=f"Set {field} to an integer > 0.",
                        path=f"mm_obligation_defaults.symbols.{sym}.{field}",
                    )
                )


# ---------------------------------------------------------------------------
# balf_gateway section
# ---------------------------------------------------------------------------

_VALID_BALF_DUPLICATE_POLICY = {"REJECT_NEW", "EVICT_OLD"}

_BALF_POSITIVE_INT_FIELDS = (
    "max_connections",
    "max_client_queue",
    "max_messages_per_second",
    "max_errors_before_disconnect",
)

_BALF_POSITIVE_FLOAT_FIELDS = (
    "heartbeat_interval_sec",
    "heartbeat_timeout_sec",
    "idle_timeout_sec",
    "auth_timeout_sec",
    "error_window_sec",
)


def _check_balf_gateway(raw: dict[str, Any], results: list[CheckResult]) -> None:
    """Validate the optional balf_gateway section (S050–S054).

    These field-level checks are hand-written for precise, per-field
    messages, which duplicates (rather than delegates to) the rules in
    ``balf_gwy/config.py``. To close the drift risk that duplication implies
    — a future change to the real loader's rules silently not mirrored here —
    ``_check_balf_gateway_drift_backstop`` below re-validates the section
    against the actual runtime loader and reports anything these field-level
    checks missed.
    """
    section = raw.get("balf_gateway")
    if section is None:
        return

    local: list[CheckResult] = []

    if not isinstance(section, dict):
        local.append(
            CheckResult(
                code="S050",
                severity=Severity.ERROR,
                message="'balf_gateway' must be a mapping.",
                suggestion="Change balf_gateway to a mapping with field=value pairs.",
                path="balf_gateway",
            )
        )
        results.extend(local)
        _check_balf_gateway_drift_backstop(raw, local, results)
        return

    # port
    port = section.get("port")
    if port is not None:
        if (
            isinstance(port, bool)
            or not isinstance(port, int)
            or not (1 <= port <= 65535)
        ):
            local.append(
                CheckResult(
                    code="S051",
                    severity=Severity.ERROR,
                    message="'balf_gateway.port' must be an integer in 1\u201365535.",
                    suggestion="Set port to a valid TCP port number, e.g. 5560.",
                    path="balf_gateway.port",
                )
            )

    # positive integer capacity fields
    for field in _BALF_POSITIVE_INT_FIELDS:
        val = section.get(field)
        if val is not None:
            if isinstance(val, bool) or not isinstance(val, int) or val <= 0:
                local.append(
                    CheckResult(
                        code="S052",
                        severity=Severity.ERROR,
                        message=f"'balf_gateway.{field}' must be a positive integer.",
                        suggestion=f"Set {field} to an integer > 0.",
                        path=f"balf_gateway.{field}",
                    )
                )

    # positive numeric timeout/interval fields
    for field in _BALF_POSITIVE_FLOAT_FIELDS:
        val = section.get(field)
        if val is not None:
            try:
                fval = _finite_float(val)
                if fval <= 0:
                    raise ValueError
            except TypeError, ValueError, OverflowError:
                local.append(
                    CheckResult(
                        code="S053",
                        severity=Severity.ERROR,
                        message=f"'balf_gateway.{field}' must be a positive number.",
                        suggestion=f"Set {field} to a number > 0.",
                        path=f"balf_gateway.{field}",
                    )
                )

    # duplicate_session_policy
    dup_policy = section.get("duplicate_session_policy")
    if dup_policy is not None:
        if str(dup_policy).upper() not in _VALID_BALF_DUPLICATE_POLICY:
            local.append(
                CheckResult(
                    code="S054",
                    severity=Severity.ERROR,
                    message=(
                        "'balf_gateway.duplicate_session_policy' must be "
                        "'REJECT_NEW' or 'EVICT_OLD'."
                    ),
                    suggestion="Use REJECT_NEW (default) or EVICT_OLD.",
                    path="balf_gateway.duplicate_session_policy",
                )
            )

    results.extend(local)
    _check_balf_gateway_drift_backstop(raw, local, results)


def _check_balf_gateway_drift_backstop(
    raw: dict[str, Any],
    already_reported: list[CheckResult],
    results: list[CheckResult],
) -> None:
    """S085 \u2014 safety net for balf_gateway rules not mirrored above.

    Only fires when the hand-written field checks above found nothing wrong,
    so a config that already gets a specific S050-S054 message doesn't also
    get this generic one. If the real loader still rejects the section for a
    reason the checks above don't know about, this is what catches it.
    """
    if already_reported:
        return
    try:
        validate_balf_gateway_section(raw)
    except ValueError as exc:
        results.append(
            CheckResult(
                code="S085",
                severity=Severity.ERROR,
                message=f"'balf_gateway' section is invalid: {exc}",
                suggestion=(
                    "The pm-balf-gwy loader rejects this section for a reason "
                    "not covered by the S050-S054 checks above. Match the "
                    "balf_gwy/config.py loader schema exactly."
                ),
                path="balf_gateway",
            )
        )


def _check_api_gateway_sections(
    raw: dict[str, Any], results: list[CheckResult]
) -> None:
    """Validate api_gateways using the runtime loader semantics."""

    try:
        validate_api_gateway_sections(raw)
    except ValueError as exc:
        msg = str(exc)
        path = "api_gateway" if "api_gateway" in msg else "api_gateways"
        section = "api_gateway" if path == "api_gateway" else "api_gateways"
        results.append(
            CheckResult(
                code="S080",
                severity=Severity.ERROR,
                message=f"'{section}' section is invalid: {msg}",
                suggestion=(
                    "Match the pm-api-gwy loader schema for api_gateways "
                    "(named mapping entries, unique non-null gateway_id ownership, "
                    "and valid credentials/rate_limit/timeouts/port values)."
                ),
                path=path,
            )
        )


def _check_alf_gateway(raw: dict[str, Any], results: list[CheckResult]) -> None:
    """Validate the optional alf_gateway section using runtime loader semantics.

    Unlike balf_gateway/post_trade_gateway/market_data_gateway, this section
    previously had zero validation coverage anywhere in pm-cverifier — a
    malformed alf_gateway block (bad port, non-positive timeout, etc.) would
    pass cverifier cleanly and then crash pm-alf-gwy at startup.

    Only when the section is present: the loader also checks the participant
    ids, which S084 already reports for every file.
    """
    if "alf_gateway" not in raw:
        return
    try:
        validate_alf_gateway_section(raw)
    except ValueError as exc:
        results.append(
            CheckResult(
                code="S081",
                severity=Severity.ERROR,
                message=f"'alf_gateway' section is invalid: {exc}",
                suggestion=(
                    "Match the pm-alf-gwy loader schema for alf_gateway "
                    "(mapping shape and positive integer limits)."
                ),
                path="alf_gateway",
            )
        )


def _check_post_trade_gateway(raw: dict[str, Any], results: list[CheckResult]) -> None:
    try:
        validate_ralf_gateway_section(raw)
    except ValueError as exc:
        results.append(
            CheckResult(
                code="S082",
                severity=Severity.ERROR,
                message=f"'post_trade_gateway' section is invalid: {exc}",
                suggestion=(
                    "Match the pm-ralf-gwy loader schema for post_trade_gateway "
                    "(mapping shape, allowed_roles list, and positive integer limits)."
                ),
                path="post_trade_gateway",
            )
        )


def _check_market_data_gateway(raw: dict[str, Any], results: list[CheckResult]) -> None:
    try:
        validate_market_data_gateway_section(raw)
    except ValueError as exc:
        results.append(
            CheckResult(
                code="S083",
                severity=Severity.ERROR,
                message=f"'market_data_gateway' section is invalid: {exc}",
                suggestion=(
                    "Match the pm-md-gwy loader schema for market_data_gateway "
                    "(mapping shape and positive integer limits)."
                ),
                path="market_data_gateway",
            )
        )


# ---------------------------------------------------------------------------
# dc_gateway schema checks (S090–S094, S133)
# ---------------------------------------------------------------------------

_DC_POSITIVE_INT_FIELDS = ("max_connections", "max_client_queue")

# Whole seconds: pm-dc-gwy reads them with as_int, which refuses 1.5 and true.
_DC_POSITIVE_SECONDS_FIELDS = (
    "heartbeat_interval_sec",
    "idle_timeout_sec",
)


def _check_dc_gateway(raw: dict[str, Any], results: list[CheckResult]) -> None:
    """Validate the optional dc_gateway section (S090–S094, S133)."""
    section = raw.get("dc_gateway")
    if section is None:
        return

    if not isinstance(section, dict):
        results.append(
            CheckResult(
                code="S090",
                severity=Severity.ERROR,
                message="'dc_gateway' must be a mapping.",
                suggestion="Change dc_gateway to a mapping with field=value pairs.",
                path="dc_gateway",
            )
        )
        return

    # port
    port = section.get("port")
    if port is not None:
        if (
            isinstance(port, bool)
            or not isinstance(port, int)
            or not (1 <= port <= 65535)
        ):
            results.append(
                CheckResult(
                    code="S091",
                    severity=Severity.ERROR,
                    message="'dc_gateway.port' must be an integer in 1\u201365535.",
                    suggestion="Set port to a valid TCP port number, e.g. 5590.",
                    path="dc_gateway.port",
                )
            )

    # name / bind_address must be non-empty strings when present
    for str_field in ("name", "bind_address"):
        val = section.get(str_field)
        if val is not None:
            if not isinstance(val, str) or not val.strip():
                results.append(
                    CheckResult(
                        code="S092",
                        severity=Severity.ERROR,
                        message=f"'dc_gateway.{str_field}' must be a non-empty string.",
                        suggestion=f"Set {str_field} to a non-empty string value.",
                        path=f"dc_gateway.{str_field}",
                    )
                )

    # positive integer capacity fields
    for field in _DC_POSITIVE_INT_FIELDS:
        val = section.get(field)
        if val is not None:
            if isinstance(val, bool) or not isinstance(val, int) or val <= 0:
                results.append(
                    CheckResult(
                        code="S093",
                        severity=Severity.ERROR,
                        message=f"'dc_gateway.{field}' must be a positive integer.",
                        suggestion=f"Set {field} to an integer > 0.",
                        path=f"dc_gateway.{field}",
                    )
                )

    # whole-second timeout/interval fields
    for field in _DC_POSITIVE_SECONDS_FIELDS:
        val = section.get(field)
        if val is not None:
            try:
                if as_int(val, field) <= 0:
                    raise ValueError("non-positive")
            except ValueError:
                results.append(
                    CheckResult(
                        code="S094",
                        severity=Severity.ERROR,
                        message=(
                            f"'dc_gateway.{field}' must be a positive whole number "
                            "of seconds."
                        ),
                        suggestion=f"Set {field} to an integer > 0.",
                        path=f"dc_gateway.{field}",
                    )
                )

    # Drift safety net, as for log_server (S101): only when nothing above
    # reported on this section.
    if any(r.path.startswith("dc_gateway") for r in results):
        return
    try:
        validate_dc_gateway_section(raw)
    except ValueError as exc:
        results.append(
            CheckResult(
                code="S133",
                severity=Severity.ERROR,
                message=f"'dc_gateway' section is invalid: {exc}",
                suggestion=(
                    "The pm-dc-gwy loader rejects this section for a reason not "
                    "covered by S090-S094. Match dc_gateway/config.py."
                ),
                path="dc_gateway",
            )
        )


# ---------------------------------------------------------------------------
# log_server schema checks (S095–S099)
# ---------------------------------------------------------------------------

_LOG_SERVER_POSITIVE_INT_FIELDS = (
    "max_message_bytes",
    "max_client_queue",
    "write_batch_size",
    "write_batch_interval_ms",
    "heartbeat_interval_sec",
    # LALF-PS (../../../docs/books/operator-guide/part-6-observe-and-recover/040-log-server.md)
    "lease_sec",
    "max_lease_sec",
    "max_subscribers",
    "notify_interval_ms",
    "backfill_chunk_rows",
    "max_backfill_minutes",
    "max_backfill_rows",
    "max_pending_rows",
    "pub_sndhwm",
)

_LOG_SERVER_BOOL_FIELDS = ("enabled", "pubsub_enabled")

# Every TCP/ZeroMQ port pm-log-srv binds. Checked for range here (S097) and
# for mutual distinctness in S102; layer 3's M018 additionally checks them
# against every *other* section's ports.
_LOG_SERVER_PORT_FIELDS = ("port", "pub_port", "pull_port")


def _check_log_server(raw: dict[str, Any], results: list[CheckResult]) -> None:
    """Validate the optional log_server section (S095–S103)."""
    section = raw.get("log_server")
    if section is None:
        return

    if not isinstance(section, dict):
        results.append(
            CheckResult(
                code="S095",
                severity=Severity.ERROR,
                message="'log_server' must be a mapping.",
                suggestion="Change log_server to a mapping with field=value pairs.",
                path="log_server",
            )
        )
        return

    # enabled / pubsub_enabled: must be real bools when present
    for bool_field in _LOG_SERVER_BOOL_FIELDS:
        val = section.get(bool_field)
        if val is not None and not isinstance(val, bool):
            results.append(
                CheckResult(
                    code="S096",
                    severity=Severity.ERROR,
                    message=f"'log_server.{bool_field}' must be a boolean.",
                    suggestion=(f"Set {bool_field} to true or false (without quotes)."),
                    path=f"log_server.{bool_field}",
                )
            )

    # port / pub_port / pull_port
    for port_field, port_default in zip(_LOG_SERVER_PORT_FIELDS, (5600, 5601, 5602)):
        port = section.get(port_field)
        if port is None:
            continue
        if (
            isinstance(port, bool)
            or not isinstance(port, int)
            or not (1 <= port <= 65535)
        ):
            results.append(
                CheckResult(
                    code="S097",
                    severity=Severity.ERROR,
                    message=(
                        f"'log_server.{port_field}' must be an integer in 1–65535."
                    ),
                    suggestion=(
                        f"Set {port_field} to a valid TCP port number, "
                        f"e.g. {port_default}."
                    ),
                    path=f"log_server.{port_field}",
                )
            )

    # name / bind_address / db_path must be non-empty strings when present
    for str_field in ("name", "bind_address", "db_path"):
        val = section.get(str_field)
        if val is not None:
            if not isinstance(val, str) or not val.strip():
                results.append(
                    CheckResult(
                        code="S098",
                        severity=Severity.ERROR,
                        message=f"'log_server.{str_field}' must be a non-empty string.",
                        suggestion=f"Set {str_field} to a non-empty string value.",
                        path=f"log_server.{str_field}",
                    )
                )

    # positive integer fields (throughput / capacity / timing knobs)
    for field in _LOG_SERVER_POSITIVE_INT_FIELDS:
        val = section.get(field)
        if val is not None:
            if isinstance(val, bool) or not isinstance(val, int) or val <= 0:
                results.append(
                    CheckResult(
                        code="S099",
                        severity=Severity.ERROR,
                        message=f"'log_server.{field}' must be a positive integer.",
                        suggestion=f"Set {field} to an integer > 0.",
                        path=f"log_server.{field}",
                    )
                )

    # retention_days: nullable non-negative integer (null/0 both mean
    # "unbounded retention" — see log_srv/config.py's own normalisation).
    retention_days = section.get("retention_days")
    if retention_days is not None:
        if (
            isinstance(retention_days, bool)
            or not isinstance(retention_days, int)
            or retention_days < 0
        ):
            results.append(
                CheckResult(
                    code="S100",
                    severity=Severity.ERROR,
                    message=(
                        "'log_server.retention_days' must be a non-negative "
                        "integer or null."
                    ),
                    suggestion=(
                        "Set retention_days to an integer >= 0, or omit/null "
                        "it for unbounded retention."
                    ),
                    path="log_server.retention_days",
                )
            )

    _check_log_server_ports_distinct(section, results)
    _check_log_server_lease_bounds(section, results)

    # Cross-check against the runtime loader's own validator so this layer
    # stays in lockstep with edumatcher.log_srv.config._load_log_server_config_from_raw
    # even if a future field is added there but not mirrored above.
    #
    # Suppressed once anything above has already reported on this section:
    # the loader stops at its *first* failure, so re-reporting it here would
    # only restate a problem the reader has already been told about in more
    # specific terms. S101 is the drift safety net for fields this layer does
    # not yet know about, not a second opinion on the ones it does.
    if any(r.path.startswith("log_server") for r in results):
        return

    try:
        validate_log_server_section({"log_server": section})
    except ValueError as exc:
        results.append(
            CheckResult(
                code="S101",
                severity=Severity.ERROR,
                message=f"'log_server' section is invalid: {exc}",
                suggestion=(
                    "Match the pm-log-srv loader schema for log_server "
                    "(mapping shape and positive integer limits)."
                ),
                path="log_server",
            )
        )


def _check_log_server_ports_distinct(
    section: dict[str, Any], results: list[CheckResult]
) -> None:
    """S102 — pm-log-srv's three listeners must not share a port.

    Compares *effective* values, applying each port's own default when the
    key is omitted, so `pub_port: 5600` collides with the default LALF port
    just as surely as two explicit duplicates would. pm-log-srv refuses to
    start on such a file; catching it here turns a startup failure into a
    verification error.
    """
    effective: dict[str, int] = {}
    for port_field, port_default in zip(_LOG_SERVER_PORT_FIELDS, (5600, 5601, 5602)):
        val = section.get(port_field, port_default)
        if isinstance(val, bool) or not isinstance(val, int):
            return  # malformed; already reported as S097
        effective[port_field] = val

    seen: dict[int, str] = {}
    for port_field, port in effective.items():
        prior = seen.get(port)
        if prior is not None:
            results.append(
                CheckResult(
                    code="S102",
                    severity=Severity.ERROR,
                    message=(
                        f"'log_server.{port_field}' ({port}) collides with "
                        f"'log_server.{prior}'."
                    ),
                    suggestion=(
                        "Give port (LALF/TCP), pub_port and pull_port (LALF-PS) "
                        "three different port numbers, e.g. 5600/5601/5602."
                    ),
                    path=f"log_server.{port_field}",
                )
            )
        else:
            seen[port] = port_field


def _check_log_server_lease_bounds(
    section: dict[str, Any], results: list[CheckResult]
) -> None:
    """S103 — the LALF-PS lease ceiling must not sit below the default lease.

    `max_lease_sec` is the clamp applied to a subscriber's requested
    `lease_sec`. A ceiling below the server's own default would mean the
    default itself is unreachable, which is incoherent rather than merely
    unusual, so pm-log-srv rejects it outright.
    """
    lease = section.get("lease_sec", 30)
    max_lease = section.get("max_lease_sec", 300)
    if isinstance(lease, bool) or not isinstance(lease, int):
        return  # already reported as S099
    if isinstance(max_lease, bool) or not isinstance(max_lease, int):
        return
    if max_lease < lease:
        results.append(
            CheckResult(
                code="S103",
                severity=Severity.ERROR,
                message=(
                    f"'log_server.max_lease_sec' ({max_lease}) is below "
                    f"'log_server.lease_sec' ({lease})."
                ),
                suggestion=(
                    "Raise max_lease_sec to at least lease_sec — it is the "
                    "ceiling applied to a subscriber's requested lease, so it "
                    "cannot be lower than the default lease the server grants."
                ),
                path="log_server.max_lease_sec",
            )
        )


# ---------------------------------------------------------------------------
# monitor section (S124-S131)
# ---------------------------------------------------------------------------
# Shape only; the cross-field rules (band order, hung vs. interval) are layer 3
# (M029-M031) and port collisions are M018. Unknown keys at every level are
# S121. See docs-design/EduMatcher-Operator-Dashboard.md §14.

_MONITOR_PORT_FIELDS = (("pull_port", 5610), ("pub_port", 5611))
_MONITOR_TEXT_FIELDS = ("bind_address", "host")
_MONITOR_POSITIVE_NUMBER_FIELDS = (
    "beacon_interval_sec",
    "hung_after_sec",
    "book_metrics_interval_sec",
)


def _is_number(val: object) -> bool:
    return not isinstance(val, bool) and isinstance(val, (int, float))


def _is_strict_positive_int(val: object) -> bool:
    # Unlike _is_positive_int above, a numeric string does not pass: the
    # monitor loader reads ints as ints, so "6" would fail at compile.
    return not isinstance(val, bool) and isinstance(val, int) and val > 0


def _monitor_error(
    results: list[CheckResult], code: str, path: str, message: str, suggestion: str
) -> None:
    results.append(
        CheckResult(
            code=code,
            severity=Severity.ERROR,
            message=message,
            suggestion=suggestion,
            path=path,
        )
    )


def _check_monitor(raw: dict[str, Any], results: list[CheckResult]) -> None:
    """Validate the optional monitor section (S124-S131)."""
    section = raw.get("monitor")
    if section is None:
        return
    if not isinstance(section, dict):
        _monitor_error(
            results,
            "S124",
            "monitor",
            "'monitor' must be a mapping.",
            "Change monitor to a mapping of field: value pairs, or remove it "
            "to run on defaults.",
        )
        return

    enabled = section.get("enabled")
    if enabled is not None and not isinstance(enabled, bool):
        _monitor_error(
            results,
            "S125",
            "monitor.enabled",
            "'monitor.enabled' must be a boolean.",
            "Set enabled to true or false (without quotes).",
        )

    for port_field, example in _MONITOR_PORT_FIELDS:
        port = section.get(port_field)
        if port is not None and not (
            _is_strict_positive_int(port) and cast(int, port) <= 65535
        ):
            _monitor_error(
                results,
                "S126",
                f"monitor.{port_field}",
                f"'monitor.{port_field}' must be an integer in 1–65535.",
                f"Set {port_field} to a valid TCP port number, e.g. {example}.",
            )

    for text_field in _MONITOR_TEXT_FIELDS:
        val = section.get(text_field)
        if val is not None and (not isinstance(val, str) or not val.strip()):
            _monitor_error(
                results,
                "S127",
                f"monitor.{text_field}",
                f"'monitor.{text_field}' must be a non-empty string.",
                f"Set {text_field} to a host name or address, e.g. 127.0.0.1.",
            )

    for number_field in _MONITOR_POSITIVE_NUMBER_FIELDS:
        val = section.get(number_field)
        if val is not None and not (_is_number(val) and val > 0):
            _monitor_error(
                results,
                "S128",
                f"monitor.{number_field}",
                f"'monitor.{number_field}' must be a positive number of seconds.",
                f"Set {number_field} to a number > 0.",
            )
    silent = section.get("silent_after_beacons")
    if silent is not None and not _is_strict_positive_int(silent):
        _monitor_error(
            results,
            "S128",
            "monitor.silent_after_beacons",
            "'monitor.silent_after_beacons' must be a positive integer.",
            "Set silent_after_beacons to a whole number of missed beacons, e.g. 3.",
        )

    _check_monitor_retention(section.get("retention"), results)
    _check_monitor_thresholds(section.get("thresholds"), results)

    # Drift safety net, as for log_server (S101): suppressed once anything
    # above has reported on this section, because the loader stops at its
    # first failure and would only restate it less specifically.
    if any(r.path.startswith("monitor") for r in results):
        return
    try:
        validate_monitor_section({"monitor": section})
    except ValueError as exc:
        _monitor_error(
            results,
            "S131",
            "monitor",
            f"'monitor' section is invalid: {exc}",
            "Match the pm-monitor loader schema (edumatcher/monitor/config.py).",
        )


def _check_monitor_retention(retention: object, results: list[CheckResult]) -> None:
    if retention is None:
        return
    if not isinstance(retention, dict):
        _monitor_error(
            results,
            "S129",
            "monitor.retention",
            "'monitor.retention' must be a mapping.",
            "Use e.g. retention: {raw_hours: 6, minute_days: 7}.",
        )
        return
    for key in ("raw_hours", "minute_days"):
        val = retention.get(key)
        if val is not None and not _is_strict_positive_int(val):
            _monitor_error(
                results,
                "S129",
                f"monitor.retention.{key}",
                f"'monitor.retention.{key}' must be a positive integer.",
                f"Set {key} to a whole number >= 1.",
            )


def _check_monitor_thresholds(thresholds: object, results: list[CheckResult]) -> None:
    if thresholds is None:
        return
    if not isinstance(thresholds, dict):
        _monitor_error(
            results,
            "S130",
            "monitor.thresholds",
            "'monitor.thresholds' must be a mapping of rule: {warn, crit}.",
            "Use e.g. thresholds: {host_cpu_pct: {warn: 80, crit: 95}}.",
        )
        return
    for rule in THRESHOLD_RULES:
        band = thresholds.get(rule)
        if band is None:
            continue
        path = f"monitor.thresholds.{rule}"
        if not isinstance(band, dict):
            _monitor_error(
                results,
                "S130",
                path,
                f"'{path}' must be a mapping with 'warn' and 'crit'.",
                f"Use e.g. {rule}: {{warn: …, crit: …}}.",
            )
            continue
        for edge in ("warn", "crit"):
            val = band.get(edge)
            if not (_is_number(val) and cast(float, val) >= 0):
                _monitor_error(
                    results,
                    "S130",
                    f"{path}.{edge}",
                    f"'{path}.{edge}' must be a non-negative number"
                    + (" and is required." if val is None else "."),
                    "Give both warn and crit; a band with only one edge has no "
                    "defined second level.",
                )


# ---------------------------------------------------------------------------
# Unknown keys (S121)
# ---------------------------------------------------------------------------
# The runtime loaders ignore a key they do not read, so a misspelled option
# silently falls back to its default. These sets are the keys each loader reads;
# tests/test_cverifier.py pins the process-block sets to the loaders' config
# dataclasses. The engine sets further down follow the specification (§3-§5).

_PROCESS_BLOCK_KEYS: dict[str, frozenset[str]] = {
    "alf_gateway": frozenset(
        {
            "enabled",
            "name",
            "bind_address",
            "port",
            "heartbeat_interval_sec",
            "handshake_timeout_sec",
            "idle_timeout_sec",
            "max_connections",
            "max_client_queue",
            "max_commands_per_second",
            "max_errors_before_disconnect",
            "error_window_sec",
        }
    ),
    "balf_gateway": frozenset(
        {
            "enabled",
            "name",
            "bind_address",
            "port",
            "heartbeat_interval_sec",
            "heartbeat_timeout_sec",
            "idle_timeout_sec",
            "auth_timeout_sec",
            "max_connections",
            "max_client_queue",
            "max_messages_per_second",
            "max_errors_before_disconnect",
            "error_window_sec",
            "duplicate_session_policy",
        }
    ),
    "market_data_gateway": frozenset(
        {
            "enabled",
            "name",
            "bind_address",
            "port",
            "heartbeat_interval_sec",
            "idle_timeout_sec",
            "replay_window_sec",
            "max_connections",
            "max_messages_per_second",
            "max_symbols_per_client",
            "max_client_queue",
            "depth_levels",
        }
    ),
    "post_trade_gateway": frozenset(
        {
            "name",
            "bind_address",
            "port",
            "replay_retention_sec",
            "heartbeat_interval_sec",
            "idle_timeout_sec",
            "max_connections",
            "max_client_queue",
            "allowed_roles",
        }
    ),
    "dc_gateway": frozenset(
        {
            "name",
            "bind_address",
            "port",
            "heartbeat_interval_sec",
            "idle_timeout_sec",
            "max_connections",
            "max_client_queue",
        }
    ),
    "log_server": frozenset(
        {
            "enabled",
            "name",
            "bind_address",
            "port",
            "db_path",
            "retention_days",
            "max_message_bytes",
            "max_client_queue",
            "write_batch_size",
            "write_batch_interval_ms",
            "heartbeat_interval_sec",
            "pubsub_enabled",
            "pub_port",
            "pull_port",
            "lease_sec",
            "max_lease_sec",
            "max_subscribers",
            "notify_interval_ms",
            "backfill_chunk_rows",
            "max_backfill_minutes",
            "max_backfill_rows",
            "max_pending_rows",
            "pub_sndhwm",
            "client",
        }
    ),
    "monitor": frozenset(
        {
            "enabled",
            "bind_address",
            "host",
            "pull_port",
            "pub_port",
            "beacon_interval_sec",
            "hung_after_sec",
            "silent_after_beacons",
            "book_metrics_interval_sec",
            "retention",
            "thresholds",
        }
    ),
}
_LOG_CLIENT_KEYS = frozenset(
    {"connect_timeout_sec", "failover_timeout_sec", "failover_dir"}
)
_MONITOR_RETENTION_KEYS = frozenset({"raw_hours", "minute_days"})
_MONITOR_THRESHOLD_KEYS = frozenset(THRESHOLD_RULES)
_MONITOR_BAND_KEYS = frozenset({"warn", "crit"})
_API_INSTANCE_KEYS = frozenset(
    {
        "enabled",
        "host",
        "port",
        "log_level",
        "swagger_enabled",
        "stats_db",
        "audit_db",
        "clearing_db",
        "eod_db",
        "order_retention_sec",
        "market_data_cache_sec",
        "engine_pull_addr",
        "engine_pub_addr",
        "index_pull_addr",
        "index_pub_addr",
        "credentials",
        "rate_limit",
        "timeouts",
    }
)
_API_RATE_LIMIT_KEYS = frozenset({"writes_per_second", "burst"})
_API_TIMEOUT_KEYS = frozenset({"engine_auth_sec", "engine_reply_sec", "wait_ack_sec"})
_API_CREDENTIAL_KEYS = frozenset({"api_key", "gateway_id", "description"})


def _report_unknown_keys(
    section: object,
    allowed: frozenset[str],
    path: str,
    results: list[CheckResult],
) -> None:
    if not isinstance(section, dict):
        return  # a non-mapping is reported by the section's own checks
    for key in sorted(section, key=str):
        if key in allowed:
            continue
        close = difflib.get_close_matches(str(key), sorted(allowed), n=1)
        hint = f" Did you mean '{close[0]}'?" if close else ""
        full = f"{path}.{key}" if path else str(key)
        results.append(
            CheckResult(
                code="S121",
                severity=Severity.ERROR,
                message=f"'{full}' is not a recognised field.",
                suggestion=(
                    f"The loader ignores unknown keys, so this setting has no "
                    f"effect.{hint} Accepted: {', '.join(sorted(allowed))}."
                ),
                path=full,
            )
        )


def _check_unknown_process_keys(
    raw: dict[str, Any], results: list[CheckResult]
) -> None:
    """S121 — a key that no process loader reads, in a gateway/service block."""
    for block, allowed in _PROCESS_BLOCK_KEYS.items():
        _report_unknown_keys(raw.get(block), allowed, block, results)

    log_server = raw.get("log_server")
    if isinstance(log_server, dict):
        _report_unknown_keys(
            log_server.get("client"), _LOG_CLIENT_KEYS, "log_server.client", results
        )

    monitor = raw.get("monitor")
    if isinstance(monitor, dict):
        _report_unknown_keys(
            monitor.get("retention"),
            _MONITOR_RETENTION_KEYS,
            "monitor.retention",
            results,
        )
        thresholds = monitor.get("thresholds")
        _report_unknown_keys(
            thresholds, _MONITOR_THRESHOLD_KEYS, "monitor.thresholds", results
        )
        if isinstance(thresholds, dict):
            for rule in sorted(_MONITOR_THRESHOLD_KEYS & set(thresholds)):
                _report_unknown_keys(
                    thresholds[rule],
                    _MONITOR_BAND_KEYS,
                    f"monitor.thresholds.{rule}",
                    results,
                )

    instances = raw.get("api_gateways")
    if not isinstance(instances, dict):
        return
    for name, instance in instances.items():
        base = f"api_gateways.{name}"
        _report_unknown_keys(instance, _API_INSTANCE_KEYS, base, results)
        if not isinstance(instance, dict):
            continue
        _report_unknown_keys(
            instance.get("rate_limit"),
            _API_RATE_LIMIT_KEYS,
            f"{base}.rate_limit",
            results,
        )
        _report_unknown_keys(
            instance.get("timeouts"), _API_TIMEOUT_KEYS, f"{base}.timeouts", results
        )
        credentials = instance.get("credentials")
        if isinstance(credentials, list):
            for index, credential in enumerate(credentials):
                _report_unknown_keys(
                    credential,
                    _API_CREDENTIAL_KEYS,
                    f"{base}.credentials[{index}]",
                    results,
                )


_ENGINE_TOP_LEVEL_KEYS = frozenset(
    {
        "symbols",
        "participants",
        "participant_defaults",
        "sessions_enabled",
        "enforce_collars",
        "enforce_circuit_breakers",
        "require_mm_seed_quotes",
        "auction_indicative_interval_sec",
        "engine_tuning",
        "mm_obligation_defaults",
        "risk_controls",
        "circuit_breaker_defaults",
        "market_maker_combos",
        "indices",
        "schedule",
        "locale",
        "api_gateways",
        *_PROCESS_BLOCK_KEYS,
    }
)
_SYMBOL_KEYS = frozenset(
    {
        "level",
        "tick_decimals",
        "outstanding_shares",
        "last_buy_price",
        "last_sell_price",
        "market_maker_quotes",
        "collar",
        "order_limits",
        "circuit_breaker",
    }
)
_MM_QUOTE_KEYS = frozenset(
    {
        "gateway_id",
        "bid_price",
        "ask_price",
        "bid_qty",
        "ask_qty",
        "tif",
        "quote_id",
        "seed_once",
    }
)
_COLLAR_KEYS = frozenset({"static_band_pct", "dynamic_band_pct"})
_ORDER_LIMIT_KEYS = frozenset({"max_order_qty", "max_order_value"})
_PARTICIPANT_KEYS = frozenset(
    {
        "id",
        "description",
        "role",
        "disconnect_behaviour",
        "quote_refresh_policy",
        "enforce_mm_obligation",
        "mm_max_spread_ticks",
        "mm_min_qty",
        "mm_obligations",
        "smp_action",
    }
)
_PARTICIPANT_OBLIGATION_KEYS = frozenset(
    {"enforce_mm_obligation", "max_spread_ticks", "min_qty"}
)
_MM_DEFAULTS_KEYS = frozenset(
    {"enforce_mm_obligation", "mm_max_spread_ticks", "mm_min_qty", "symbols"}
)
_MM_DEFAULTS_SYMBOL_KEYS = frozenset(
    {"enforce_mm_obligation", "mm_max_spread_ticks", "mm_min_qty"}
)
_ENGINE_TUNING_KEYS = frozenset(
    {
        "snapshot_interval_sec",
        "quote_history_maxlen",
        "drop_copy_buffer_size",
        "recent_trades_maxlen",
        "depth_snapshot_tolerance_ticks",
    }
)
_RISK_CONTROLS_KEYS = frozenset({"default_level", "levels"})
# circuit_breaker and order_limits are not supported under a risk level, but
# are rejected by their own checks; naming them here avoids a second error.
_RISK_LEVEL_KEYS = frozenset({"collar", "circuit_breaker", "order_limits"})
_CB_KEYS = frozenset({"reference_window_ns", "levels", "reopening"})
_CB_LEVEL_KEYS = frozenset({"price_shift_pct", "halt_duration_ns"})
_CB_REOPENING_KEYS = frozenset(
    {"enabled", "initial_band_pct", "expansions", "random_end_max_ns", "random_seed"}
)
_CB_EXPANSION_KEYS = frozenset({"widen_pct", "min_duration_ns"})
_COMBO_KEYS = frozenset({"combo_id", "combo_type", "tif", "legs"})
_COMBO_LEG_KEYS = frozenset(
    {"symbol", "side", "order_type", "quantity", "price", "stop_price", "smp_action"}
)
_INDEX_KEYS = frozenset(
    {
        "id",
        "description",
        "base_value",
        "publish_interval_sec",
        "history_file",
        "state_file",
        "constituents",
    }
)
_LOCALE_KEYS = frozenset({"country", "session_timezone"})
_SCHEDULE_DAY_KEYS = frozenset(
    {
        "pre_open",
        "opening_auction_start",
        "continuous_start",
        "closing_auction_start",
        "closing_auction_end",
    }
)
_SCHEDULE_BLOCK_NAMES = frozenset(
    {"weekdays", "weekend", "holidays", "mon", "tue", "wed", "thu", "fri", "sat", "sun"}
)


def _each(section: object) -> list[tuple[str, object]]:
    """``(index-or-key suffix, item)`` pairs of a list or mapping, else empty."""
    if isinstance(section, list):
        return [(f"[{i}]", item) for i, item in enumerate(section)]
    if isinstance(section, dict):
        return [(f".{k}", v) for k, v in section.items()]
    return []


def _check_unknown_cb_keys(cb: object, path: str, results: list[CheckResult]) -> None:
    """S121 — a ``circuit_breaker`` / ``circuit_breaker_defaults`` block."""
    _report_unknown_keys(cb, _CB_KEYS, path, results)
    if not isinstance(cb, dict):
        return
    for suffix, level in _each(cb.get("levels")):
        _report_unknown_keys(level, _CB_LEVEL_KEYS, f"{path}.levels{suffix}", results)
    reopening = cb.get("reopening")
    _report_unknown_keys(reopening, _CB_REOPENING_KEYS, f"{path}.reopening", results)
    if isinstance(reopening, dict):
        for suffix, rung in _each(reopening.get("expansions")):
            _report_unknown_keys(
                rung,
                _CB_EXPANSION_KEYS,
                f"{path}.reopening.expansions{suffix}",
                results,
            )


def _check_unknown_engine_keys(raw: dict[str, Any], results: list[CheckResult]) -> None:
    """S121 — a key no engine loader reads, at any level of an engine section."""
    _report_unknown_keys(raw, _ENGINE_TOP_LEVEL_KEYS, "", results)

    symbols = raw.get("symbols")
    if isinstance(symbols, dict):
        for sym, cfg in symbols.items():
            base = f"symbols.{sym}"
            _report_unknown_keys(cfg, _SYMBOL_KEYS, base, results)
            if not isinstance(cfg, dict):
                continue
            for suffix, quote in _each(cfg.get("market_maker_quotes")):
                _report_unknown_keys(
                    quote,
                    _MM_QUOTE_KEYS,
                    f"{base}.market_maker_quotes{suffix}",
                    results,
                )
            _report_unknown_keys(
                cfg.get("collar"), _COLLAR_KEYS, f"{base}.collar", results
            )
            _report_unknown_keys(
                cfg.get("order_limits"),
                _ORDER_LIMIT_KEYS,
                f"{base}.order_limits",
                results,
            )
            _check_unknown_cb_keys(
                cfg.get("circuit_breaker"), f"{base}.circuit_breaker", results
            )

    for suffix, participant in _each(raw.get("participants")):
        base = f"participants{suffix}"
        _report_unknown_keys(participant, _PARTICIPANT_KEYS, base, results)
        if isinstance(participant, dict):
            for sym, obligation in _each(participant.get("mm_obligations")):
                _report_unknown_keys(
                    obligation,
                    _PARTICIPANT_OBLIGATION_KEYS,
                    f"{base}.mm_obligations{sym}",
                    results,
                )

    mm_defaults = raw.get("mm_obligation_defaults")
    _report_unknown_keys(
        mm_defaults, _MM_DEFAULTS_KEYS, "mm_obligation_defaults", results
    )
    if isinstance(mm_defaults, dict):
        for suffix, entry in _each(mm_defaults.get("symbols")):
            _report_unknown_keys(
                entry,
                _MM_DEFAULTS_SYMBOL_KEYS,
                f"mm_obligation_defaults.symbols{suffix}",
                results,
            )

    _report_unknown_keys(
        raw.get("engine_tuning"), _ENGINE_TUNING_KEYS, "engine_tuning", results
    )
    _report_unknown_keys(raw.get("locale"), _LOCALE_KEYS, "locale", results)

    risk = raw.get("risk_controls")
    _report_unknown_keys(risk, _RISK_CONTROLS_KEYS, "risk_controls", results)
    if isinstance(risk, dict):
        for suffix, level in _each(risk.get("levels")):
            level_path = f"risk_controls.levels{suffix}"
            _report_unknown_keys(level, _RISK_LEVEL_KEYS, level_path, results)
            if isinstance(level, dict):
                _report_unknown_keys(
                    level.get("collar"), _COLLAR_KEYS, f"{level_path}.collar", results
                )

    _check_unknown_cb_keys(
        raw.get("circuit_breaker_defaults"), "circuit_breaker_defaults", results
    )

    for suffix, combo in _each(raw.get("market_maker_combos")):
        base = f"market_maker_combos{suffix}"
        _report_unknown_keys(combo, _COMBO_KEYS, base, results)
        if isinstance(combo, dict):
            for leg_suffix, leg in _each(combo.get("legs")):
                _report_unknown_keys(
                    leg, _COMBO_LEG_KEYS, f"{base}.legs{leg_suffix}", results
                )

    for suffix, index in _each(raw.get("indices")):
        _report_unknown_keys(index, _INDEX_KEYS, f"indices{suffix}", results)

    schedule = raw.get("schedule")
    if isinstance(schedule, dict):
        # Unknown keys of ``schedule`` itself are M027.
        for name in sorted(_SCHEDULE_BLOCK_NAMES & set(schedule)):
            _report_unknown_keys(
                schedule[name], _SCHEDULE_DAY_KEYS, f"schedule.{name}", results
            )
