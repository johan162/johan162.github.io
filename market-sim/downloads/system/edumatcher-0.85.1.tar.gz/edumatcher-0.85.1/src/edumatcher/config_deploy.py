"""
pm-config-deploy — compile an engine configuration and install it.

EduMatcher separates the configuration you *author* from the configuration the
exchange *runs*:

  * The authored ``engine_config.yaml`` lives wherever suits you — typically
    under version control next to the rest of your course material. Edit it,
    review it, diff it.
  * The compiled artifact lives at ``<DATA_DIR>/ref_data/engine_config.json``
    and is the only file any running process reads. No process accepts a
    config path, which is what makes it impossible for two of them to
    disagree.

This command is the bridge. It validates the authored file with the same four
layers ``pm-cverifier`` runs, resolves every default exactly once, and installs
the result. Two consequences worth knowing:

  * A configuration that fails validation is never installed, so a process can
    no longer be started against a file nobody checked.
  * Defaults are decided here rather than in eight separate loaders, so they
    cannot drift apart between subsystems.

The authored YAML is installed alongside the artifact, purely so the deployed
directory records what the running exchange was built from. A
``market_sim.yaml`` next to the source (the market model's parameters, read by
``pm-market-sim``) is checked against the engine's symbols and installed with
it; deploying a source without one removes a previously installed one.

Usage
-----
  pm-config-deploy engine_config.yaml       # validate, compile and install
  pm-config-deploy --check engine_config.yaml   # validate only, install nothing
  pm-config-deploy --show                   # print the deployed paths
    pm-config-deploy --example s3-basic    # deploy a bundled example config
    pm-config-deploy --example s3-basic-nomm   # same, with an empty order book
"""

from __future__ import annotations

import argparse
import os
import shutil
import sys
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path

from edumatcher.cli_pipe import pipe_safe
from edumatcher.alf_gwy.config import load_alf_gateway_config
from edumatcher.api_gateway.config import load_named_api_gateway_configs
from edumatcher.balf_gwy.config import load_balf_gateway_config
from edumatcher.cli_version import package_version
from edumatcher.config import COMPILED_CONFIG_FILE, ENGINE_CONFIG_FILE
from edumatcher.config_include import ConfigIncludeError, load_config_mapping
from edumatcher.config_artifact import (
    SCHEMA_VERSION,
    ArtifactMeta,
    CompiledConfig,
    content_digest,
    encode,
    config_digest,
)
from edumatcher.cverifier.cli import run as run_verifier
from edumatcher.cverifier.models import CheckResult, Severity
from edumatcher.dc_gateway.config import load_dc_gateway_config
from edumatcher.engine.config_loader import load_engine_config
from edumatcher.examples import examples_root as examples_root  # noqa: F401
from edumatcher.examples import resolve_example as resolve_example
from edumatcher.log_srv.config import load_log_client_config, load_log_server_config
from edumatcher.monitor.config import load_monitor_config
from edumatcher.market_sim.config import (
    FILE_NAME as SIM_FILE_NAME,
    SimConfigError,
    load_sim_config,
)
from edumatcher.md_gateway.config import load_market_data_gateway_config
from edumatcher.ralf_gateway.config import load_ralf_gateway_config


class CompileError(Exception):
    """The authored configuration cannot be compiled.

    ``findings`` holds the blocking verifier results when validation was what
    failed, and is empty when a loader rejected the file for its own reasons.
    """

    def __init__(self, message: str, findings: list[CheckResult] | None = None) -> None:
        super().__init__(message)
        self.findings = findings or []


def validate(source: Path) -> list[CheckResult]:
    """Return the blocking findings for *source* — empty means it compiles.

    Only ``ERROR`` blocks. Warnings are advice about a configuration that will
    still run, and a deploy command that refused on advice would push people
    towards editing the deployed copy directly, which is the habit this whole
    arrangement exists to remove.
    """
    results, _raw = run_verifier(source)
    return [r for r in results if r.severity is Severity.ERROR]


def compile_config(source: Path) -> CompiledConfig:
    """Validate *source* and resolve it into a compiled artifact.

    Every section is produced by the subsystem's own loader, so compiling
    reuses the behaviour those loaders already have rather than restating it.
    """
    blocking = validate(source)
    if blocking:
        raise CompileError(f"{source} failed validation", blocking)

    meta = ArtifactMeta(
        schema_version=SCHEMA_VERSION,
        compiler_version=package_version(),
        compiled_at=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z"),
        source_path=str(source),
        source_sha256=config_digest(load_config_mapping(source).files),
    )

    try:
        compiled = CompiledConfig(
            meta=meta,
            engine=load_engine_config(source),
            alf_gateway=load_alf_gateway_config(source),
            balf_gateway=load_balf_gateway_config(source),
            market_data_gateway=load_market_data_gateway_config(source),
            post_trade_gateway=load_ralf_gateway_config(source),
            dc_gateway=load_dc_gateway_config(source),
            log_server=load_log_server_config(source),
            log_client=load_log_client_config(source),
            monitor=load_monitor_config(source),
            api_gateways=load_named_api_gateway_configs(source),
        )
    except CompileError:
        raise
    except Exception as exc:
        raise CompileError(f"{source} could not be resolved: {exc}") from exc

    sim_source = source.with_name(SIM_FILE_NAME)
    if sim_source.is_file():
        try:
            load_sim_config(sim_source, set(compiled.engine.symbols))
        except SimConfigError as exc:
            raise CompileError(str(exc)) from exc

    # Stamp the payload digest last: it covers every section but not the meta
    # block that carries it, so it has to be computed once the sections exist.
    return replace(
        compiled, meta=replace(meta, content_sha256=content_digest(compiled))
    )


def _write_atomically(path: Path, text: str, mode_of: Path | None = None) -> None:
    """Write *text* to *path* via a staged rename.

    A process starting midway through a deploy must see either the old file or
    the new one, never half of either. With *mode_of*, the file gets that
    file's permissions, so a private credentials file stays private.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    staged = path.with_name(path.name + ".tmp")
    staged.write_text(text, encoding="utf-8")
    if mode_of is not None:
        shutil.copymode(mode_of, staged)
    os.replace(staged, path)


def _installed_includes(installed: Path) -> list[Path]:
    """The include files a previous deploy left beside *installed*."""
    try:
        return list(load_config_mapping(installed).files[1:])
    except OSError, ConfigIncludeError:
        # An unreadable old copy leaves nothing we can safely identify.
        return []


def _install_source(source: Path, installed: Path) -> None:
    """Copy the authored file and its includes next to the artifact.

    Includes keep their layout relative to the main file. Includes a previous
    deploy installed that this source no longer lists are removed, so the
    directory never records files the running configuration was not built from.
    """
    loaded = load_config_mapping(source)
    previous = _installed_includes(installed)
    _write_atomically(installed, source.read_text("utf-8"))
    kept = set()
    for path in loaded.files[1:]:
        target = installed.parent / path.relative_to(source.parent)
        _write_atomically(target, path.read_text("utf-8"), mode_of=path)
        kept.add(target)
    if installed.parent.resolve() == source.parent.resolve():
        return  # deploying in place: those files are the authored ones
    for stale in set(previous) - kept:
        stale.unlink(missing_ok=True)
        try:
            stale.parent.rmdir()
        except OSError:
            pass  # not empty, or the install directory itself


def deploy(source: Path, dest: Path = COMPILED_CONFIG_FILE) -> CompiledConfig:
    """Compile *source* and install the artifact at *dest*.

    The authored YAML is copied *beside the artifact*, derived from ``dest``
    rather than from the global path, so that deploying somewhere else puts
    both files there together. A deployed directory holding an artifact and
    an unrelated source would be worse than one holding neither.
    """
    config = compile_config(source)
    _write_atomically(dest, encode(config))
    _install_source(source, dest.with_name(ENGINE_CONFIG_FILE.name))
    sim_source = source.with_name(SIM_FILE_NAME)
    sim_dest = dest.with_name(SIM_FILE_NAME)
    if sim_source.is_file():
        _write_atomically(sim_dest, sim_source.read_text("utf-8"))
    else:
        # A model for some other configuration's symbols would be wrong here.
        sim_dest.unlink(missing_ok=True)
    return config


def _report(findings: list[CheckResult]) -> None:
    for finding in findings:
        where = finding.path
        if finding.file:
            where = f"{finding.file}: {where}"
        location = f" [{where}]" if where else ""
        print(f"  {finding.code}{location}: {finding.message}", file=sys.stderr)
        if finding.suggestion:
            print(f"      {finding.suggestion}", file=sys.stderr)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pm-config-deploy",
        description=(
            "Validate and compile an engine configuration, and install it as "
            "the one every EduMatcher process reads."
        ),
    )
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-config-deploy")
    parser.add_argument(
        "source",
        metavar="SOURCE",
        nargs="?",
        help="Authored engine_config.yaml to validate, compile and install",
    )
    parser.add_argument(
        "--example",
        metavar="NAME",
        help=(
            "Use a bundled example config instead of SOURCE, e.g. 's3-basic' "
            "for docs/examples/ref_data/s3-basic-setup/engine_config.yaml; "
            "append '-nomm' for the no-market-maker-quotes variant, e.g. "
            "'s3-basic-nomm'"
        ),
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Validate and compile, but install nothing",
    )
    parser.add_argument(
        "--show",
        action="store_true",
        help="Print the deployed configuration paths and exit",
    )
    return parser


@pipe_safe
def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.show:
        print(f"compiled: {COMPILED_CONFIG_FILE}")
        print(f"source:   {ENGINE_CONFIG_FILE}")
        return

    if args.source and args.example:
        parser.error("SOURCE and --example are mutually exclusive")

    if args.example:
        try:
            source = resolve_example(args.example)
        except ValueError as exc:
            print(f"[ERROR] {exc}", file=sys.stderr)
            sys.exit(1)
    elif args.source:
        source = Path(args.source).expanduser().resolve()
        if not source.is_file():
            print(f"[ERROR] No such configuration file: {source}", file=sys.stderr)
            sys.exit(1)
    else:
        parser.error("SOURCE is required (or pass --example / --show)")
        return  # unreachable, parser.error() exits; keeps type checkers happy

    try:
        config = compile_config(source) if args.check else deploy(source)
    except CompileError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        _report(exc.findings)
        print("        Nothing was deployed.", file=sys.stderr)
        sys.exit(1)

    symbols = len(config.engine.symbols)
    gateways = len(config.engine.participants)
    if args.check:
        print(f"OK — {source} compiles ({symbols} symbol(s), {gateways} gateway(s))")
        return

    print(f"Compiled {source}")
    print(f"      to {COMPILED_CONFIG_FILE}")
    print(f"   {symbols} symbol(s), {gateways} gateway(s).")
    print("   Restart any running processes to pick it up.")


if __name__ == "__main__":
    main()
