"""DC gateway configuration loading helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


from edumatcher.config import DROP_COPY_PUB_ADDR
from edumatcher.config_include import load_config_mapping
from edumatcher.config import resolve_gateway_bind_host
from edumatcher.config_coerce import as_int


@dataclass(frozen=True)
class DcGatewayConfig:
    """Runtime settings for the DC TCP gateway."""

    name: str = "dc-gwy01"
    bind_address: str = field(default_factory=resolve_gateway_bind_host)
    port: int = 5590
    drop_copy_pub_addr: str = DROP_COPY_PUB_ADDR
    heartbeat_interval_sec: int = 2
    idle_timeout_sec: int = 20
    max_connections: int = 64
    max_client_queue: int = 10_000


def _as_int(raw: object, field: str) -> int:
    return as_int(raw, f"dc_gateway.{field}")


def _load_dc_gateway_config_from_raw(raw: dict[str, Any]) -> DcGatewayConfig:
    section = raw.get("dc_gateway")
    if section is None:
        return DcGatewayConfig()
    if not isinstance(section, dict):
        raise ValueError("dc_gateway must be a mapping")

    name = str(section.get("name", "dc-gwy01"))
    # Sent as WELCOME|...|GW=<name>: build_line refuses these characters, which
    # would end the gateway at the first HELLO.
    if not name or any(ch in name for ch in "|\r\n"):
        raise ValueError(
            "dc_gateway.name must be non-empty, without '|' or line breaks"
        )
    bind_address = resolve_gateway_bind_host(section.get("bind_address"))
    port = _as_int(section.get("port", 5590), "port")
    if port <= 0 or port > 65535:
        raise ValueError("dc_gateway.port must be in 1-65535")
    heartbeat_interval_sec = _as_int(
        section.get("heartbeat_interval_sec", 2), "heartbeat_interval_sec"
    )
    idle_timeout_sec = _as_int(section.get("idle_timeout_sec", 20), "idle_timeout_sec")
    max_connections = _as_int(section.get("max_connections", 64), "max_connections")
    max_client_queue = _as_int(
        section.get("max_client_queue", 10_000), "max_client_queue"
    )

    if heartbeat_interval_sec <= 0:
        raise ValueError("dc_gateway.heartbeat_interval_sec must be > 0")
    if idle_timeout_sec <= 0:
        raise ValueError("dc_gateway.idle_timeout_sec must be > 0")
    if max_connections <= 0:
        raise ValueError("dc_gateway.max_connections must be > 0")
    if max_client_queue <= 0:
        raise ValueError("dc_gateway.max_client_queue must be > 0")

    return DcGatewayConfig(
        name=name,
        bind_address=bind_address,
        port=port,
        # drop_copy_pub_addr is always taken from the global DROP_COPY_PUB_ADDR
        # constant. It cannot be overridden per-gateway in YAML; use the
        # --engine-dc-pub CLI flag.
        drop_copy_pub_addr=DROP_COPY_PUB_ADDR,
        heartbeat_interval_sec=heartbeat_interval_sec,
        idle_timeout_sec=idle_timeout_sec,
        max_connections=max_connections,
        max_client_queue=max_client_queue,
    )


def load_dc_gateway_config(path: Path) -> DcGatewayConfig:
    """Load optional dc_gateway section from engine_config.yaml."""
    if not path.exists():
        return DcGatewayConfig()

    raw = load_config_mapping(path).data

    return _load_dc_gateway_config_from_raw(raw)


def validate_dc_gateway_section(raw: dict[str, Any]) -> None:
    """Validate dc_gateway section using runtime loader semantics."""

    _load_dc_gateway_config_from_raw(raw)


def load_default_dc_gateway_config() -> DcGatewayConfig:
    """Return this subsystem's section of the deployed compiled configuration.

    Falls back to dataclass defaults when nothing has been deployed yet, which
    is exactly what the YAML loader above did for a missing file — many tools
    that read this section, such as the spies and viewers, must still run
    against an exchange whose configuration was never installed.

    The import is deferred because ``config_artifact`` imports this module to
    describe the artifact's shape.
    """
    from edumatcher.config_artifact import load_compiled_config

    compiled = load_compiled_config()
    return DcGatewayConfig() if compiled is None else compiled.dc_gateway
