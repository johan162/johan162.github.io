"""
pm-setup — Bootstrap an EduMatcher session directory.

Run once after installation (pipx install edumatcher) to:
  1. Create the data directory where engine state is stored.
  2. Compile and deploy an example config so the exchange can start.
  3. Print the shell environment snippet to add to your shell profile.

The example is compiled to ``<DATA_DIR>/ref_data/engine_config.json`` — the
single file every process reads — with the source kept beside it. To run a
configuration of your own, author it wherever you like and install it with
``pm-config-deploy``.

Which example gets installed is controlled by ``--config`` and resolved the
same way ``pm-config-deploy --example`` resolves it — see
``edumatcher.examples.resolve_example`` for the shorthand-to-path
mapping (e.g. ``s3-basic`` ->
``docs/examples/ref_data/s3-basic-setup/engine_config.yaml``). When
``--config`` is omitted, ``s10-basic`` is installed.

Any example name also accepts an optional trailing ``-nomm`` to select the
no-market-maker-quotes variant of that example (e.g. ``s3-basic-nomm`` ->
``docs/examples/ref_data/s3-basic-nomm-setup/engine_config.yaml``)
— see ../../docs/books/participant-guide/part-3-market-making/010-market-maker-quotes.md.

Usage
-----
    pm-setup                          # use all defaults (s10-basic)
    pm-setup --config s1-basic       # install a specific bundled example
    pm-setup --config s1-basic-nomm  # same example with an empty order book
  pm-setup --data-dir ~/my-session  # explicit data directory
  pm-setup --force                  # replace an already-deployed config
  pm-setup --no-config              # only create the data dir
  pm-setup --show                   # print the data directory that would be used
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Neither import touches edumatcher.config, which would resolve -- and warn
# about -- the data directory this command has not created yet.
from edumatcher.data_dir import data_dir_preference
from edumatcher.examples import resolve_example

DEFAULT_EXAMPLE_CONFIG = "s10-basic"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pm-setup",
        description=(
            "Bootstrap an EduMatcher session directory. "
            "Creates the data dir and compiles a bundled example engine_config.yaml."
        ),
    )
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-setup")
    parser.add_argument(
        "--data-dir",
        metavar="PATH",
        default=None,
        help=(
            "Data directory for persistent engine files "
            "(default: $EDUMATCHER_DATA_DIR, or <repo>/src/data in a source "
            "checkout, or ~/.local/share/edumatcher)"
        ),
    )
    parser.add_argument(
        "--show",
        action="store_true",
        help="Print the data directory that would be used and exit",
    )
    parser.add_argument(
        "--config",
        metavar="NAME",
        default=DEFAULT_EXAMPLE_CONFIG,
        help=(
            "Bundled example config to deploy, e.g. 's1-basic', 's3-nominal', "
            "'s10-complex', or 's150-basic' (resolves under "
            "docs/examples/ref_data/; "
            "append '-nomm' for the no-market-maker-quotes variant, e.g. "
            "'s1-basic-nomm'; "
            f"default: {DEFAULT_EXAMPLE_CONFIG!r})"
        ),
    )
    parser.add_argument(
        "--force",
        action="store_true",
        help="Recompile and overwrite an already-deployed configuration",
    )
    parser.add_argument(
        "--no-config",
        action="store_true",
        help="Only create the data directory; do not deploy an example config",
    )
    return parser


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    # -----------------------------------------------------------------------
    # 1. Resolve the data directory
    # -----------------------------------------------------------------------
    if args.data_dir:
        data_dir = Path(args.data_dir).expanduser().resolve()
    else:
        data_dir, _ = data_dir_preference()

    if args.show:
        ref_data = data_dir / "ref_data"
        print(f"compiled: {ref_data / 'engine_config.json'}")
        print(f"source:   {ref_data / 'engine_config.yaml'}")
        return

    if not args.no_config:
        try:
            resolve_example(args.config)
        except ValueError as exc:
            parser.error(str(exc))

    print("\npm-setup — EduMatcher session initialisation")
    print(f"{'=' * 50}")

    # -----------------------------------------------------------------------
    # 2. Create the data directory
    # -----------------------------------------------------------------------
    if data_dir.exists():
        print(f"  ✓ Data directory already exists:  {data_dir}")
    else:
        try:
            data_dir.mkdir(parents=True, exist_ok=True)
            print(f"  ✓ Created data directory:          {data_dir}")
        except OSError as exc:
            print(f"  ✗ Could not create data directory: {data_dir}", file=sys.stderr)
            print(f"    {exc}", file=sys.stderr)
            sys.exit(1)

    # -----------------------------------------------------------------------
    # 3. Compile and deploy the selected bundled example engine_config.yaml
    # -----------------------------------------------------------------------
    if not args.no_config:
        artifact = data_dir / "ref_data" / "engine_config.json"

        if artifact.exists() and not args.force:
            print(f"  ✓ Config already deployed (kept):  {artifact}")
            print("    → Use --force to overwrite.")
        else:
            # Deploy straight from the bundled example: deploy() installs the
            # YAML and the example's market_sim.yaml beside the artifact.
            # config_deploy imports edumatcher.config, which resolves the data
            # directory: make it this one, which exists now.
            os.environ["EDUMATCHER_DATA_DIR"] = str(data_dir)
            from edumatcher.config_deploy import CompileError, deploy

            try:
                compiled = deploy(resolve_example(args.config), artifact)
            except CompileError as exc:
                print(
                    f"  ✗ Bundled {args.config!r} example config did not compile: {exc}",
                    file=sys.stderr,
                )
                sys.exit(1)
            print(f"  ✓ Example config {args.config!r} compiled to: {artifact}")
            print(f"    {len(compiled.engine.symbols)} symbol(s) ready to trade.")

    # -----------------------------------------------------------------------
    # 4. Print shell profile snippet
    # -----------------------------------------------------------------------
    shell = Path(os.environ.get("SHELL", "/bin/bash")).name
    rc_file = "~/.zshrc" if shell == "zsh" else "~/.bashrc"
    print()
    print("  Shell environment snippet — add to your shell profile:")
    print(f"  ({rc_file})")
    print()
    print("  " + "-" * 46)
    print(f'  export EDUMATCHER_DATA_DIR="{data_dir}"')
    print("  " + "-" * 46)
    print()
    print("  This is the only variable to set. Every process derives its")
    print("  configuration, database and log paths from it, so they cannot")
    print("  drift apart.")
    print()
    print("  To edit the configuration, work on your own copy and install it:")
    print()
    print("    pm-config-deploy my-engine_config.yaml")
    print()
    print("  Then start the exchange with:")
    print()
    print("    pm-opctl-cli start")
    print()
    print()


if __name__ == "__main__":
    main()
