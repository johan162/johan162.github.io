"""``eod.db`` — the settlement ledger.

One row per account per settled trading date.  The rows of a date add up to
exactly zero (the residual, rounding plus any float noise under the
settlement tolerance, sits on the ``EXCHANGE`` account), which
:func:`record_day` checks before it commits and :func:`check_zero_sum` can
re-check across all dates.  Amounts are integer minor units (2 decimals).
Balances are never stored: they are the sum of the amounts, so correcting a
day means recording it again with ``redo``, which drops every later date.
Each settled date also keeps the equity it was settled at, the next date's
baseline (``eod_close_equity``), and the ``clearing.db`` it was settled from
(``eod_close_source``).
"""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Mapping
from decimal import Decimal
from pathlib import Path
from typing import Any
from urllib.parse import quote

from edumatcher.eod.settle import EXCHANGE, Baseline, Settlement

SCHEMA = """
-- One row per account per settled trading date.  The rows of a date sum to
-- exactly 0: the exchange is the counterparty of every trader.
CREATE TABLE IF NOT EXISTS eod_settlement (
  trade_date   TEXT    NOT NULL,  -- YYYY-MM-DD, in the session timezone
  -- A gateway id, or 'EXCHANGE' for the rounding residual.
  account      TEXT    NOT NULL,
  -- The day's change in the account's mark-to-market equity, in integer minor
  -- units of the display currency (2 decimals: 1234 = 12.34).  Positive: the
  -- exchange owes the trader (credit).  Negative: the trader owes the
  -- exchange (debit).  A running balance is the sum of these plus the
  -- roster's opening balance; it is never stored.
  amount_minor INTEGER NOT NULL,
  -- {symbol: day P&L as a decimal string in display currency, same sign as
  -- amount_minor}; the unrounded parts the statement lists per symbol.
  detail_json  TEXT    NOT NULL,
  PRIMARY KEY (trade_date, account)
);

-- One row per position per settled trading date: the cumulative equity
-- (realized + unrealized P&L) the date was settled at, copied from that date's
-- close snapshot.  The next date is measured from these rows, not from
-- clearing.db, whose snapshot of a date changes when the date closes again.
CREATE TABLE IF NOT EXISTS eod_close_equity (
  trade_date TEXT NOT NULL,  -- YYYY-MM-DD, a date in eod_settlement
  gateway_id TEXT NOT NULL,
  symbol     TEXT NOT NULL,
  -- Exact decimal string in display currency (not minor units, not rounded).
  equity     TEXT NOT NULL,
  PRIMARY KEY (trade_date, gateway_id, symbol)
);

-- One row per settled trading date: which clearing.db it was settled from
-- (clearing_meta.instance_id, NULL if it had none).  A different one when the
-- next date settles means clearing.db was replaced (pm-opctl-cli clear
-- --state), so equity restarted at zero and eod_close_equity no longer applies.
CREATE TABLE IF NOT EXISTS eod_close_source (
  trade_date        TEXT PRIMARY KEY,  -- YYYY-MM-DD, a date in eod_settlement
  clearing_instance TEXT
);

-- One row per trading date pm-eod has run.  'ok' means settled and reported;
-- housekeeping warnings do not change it (they are in steps_json).
CREATE TABLE IF NOT EXISTS eod_runs (
  trade_date  TEXT PRIMARY KEY,
  status      TEXT NOT NULL,   -- ok | failed | report-failed
  started_at  TEXT NOT NULL,   -- ISO 8601, UTC
  finished_at TEXT NOT NULL,   -- ISO 8601, UTC
  steps_json  TEXT NOT NULL    -- [{"step", "status", "message"}, ...]
);
"""

_PRAGMAS = """
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
"""


class LedgerError(Exception):
    """A write the ledger refuses to make."""


def open_ledger(path: Path) -> sqlite3.Connection:
    """Open (or create) ``eod.db`` for read/write."""
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    try:
        conn.executescript(_PRAGMAS)
        conn.executescript(SCHEMA)
    except Exception:
        conn.close()
        raise
    return conn


def open_ledger_readonly(path: Path) -> sqlite3.Connection:
    """Open an existing ``eod.db`` read-only (the API gateway's reader).

    Never creates the file: a missing ledger means pm-eod has not run here,
    which a reader must report, not paper over with an empty database.
    """
    if not path.exists():
        raise FileNotFoundError(f"EOD ledger not found: {path}")
    # Percent-encoded: a '?' in the path would otherwise end the URI path.
    conn = sqlite3.connect(f"file:{quote(str(path.resolve()))}?mode=ro", uri=True)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA busy_timeout = 5000")
    return conn


def open_scratch_ledger(path: Path) -> sqlite3.Connection:
    """An in-memory copy of ``eod.db`` (empty if there is none) for a dry run.

    A dry run settles into this copy with the real code, so it refuses what
    the real run refuses, and the dates of a ``--pending --dry-run`` chain
    from one another.  Nothing reaches the file.
    """
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    try:
        if path.exists():
            source = open_ledger_readonly(path)
            try:
                source.backup(conn)
            finally:
                source.close()
        conn.executescript(SCHEMA)
    except Exception:
        conn.close()
        raise
    return conn


def settled_dates(conn: sqlite3.Connection) -> list[str]:
    rows = conn.execute(
        "SELECT DISTINCT trade_date FROM eod_settlement ORDER BY trade_date"
    )
    return [r[0] for r in rows]


def last_settled_before(conn: sqlite3.Connection, trade_date: str) -> str | None:
    """The latest settled date before ``trade_date``: the next day's baseline."""
    row = conn.execute(
        "SELECT MAX(trade_date) FROM eod_settlement WHERE trade_date < ?",
        (trade_date,),
    ).fetchone()
    return row[0] if row else None


def record_day(
    conn: sqlite3.Connection, trade_date: str, result: Settlement, *, redo: bool = False
) -> list[str]:
    """Write one day's settlement and its closing equity in a single transaction.

    With ``redo`` the same transaction first deletes ``trade_date`` and every
    later date (balances are cumulative, so a corrected day invalidates
    everything after it) and their runs; the dates removed are returned.
    """
    rows = dict(result.amounts_minor)
    if result.rounding_minor:
        rows[EXCHANGE] = result.rounding_minor
    if sum(rows.values()) != 0:
        raise LedgerError(f"{trade_date}: amounts do not sum to zero")
    dates = settled_dates(conn)
    gone = [d for d in dates if d >= trade_date] if redo else []
    if not redo and trade_date in dates:
        raise LedgerError(f"{trade_date} is already settled")
    if not redo and dates and dates[-1] > trade_date:
        raise LedgerError(f"{dates[-1]} is settled, which is later than {trade_date}")
    with conn:
        if redo:
            conn.execute(
                "DELETE FROM eod_settlement WHERE trade_date >= ?", (trade_date,)
            )
            conn.execute(
                "DELETE FROM eod_close_equity WHERE trade_date >= ?", (trade_date,)
            )
            conn.execute(
                "DELETE FROM eod_close_source WHERE trade_date >= ?", (trade_date,)
            )
            conn.execute("DELETE FROM eod_runs WHERE trade_date >= ?", (trade_date,))
        conn.executemany(
            "INSERT INTO eod_settlement (trade_date, account, amount_minor, detail_json)"
            " VALUES (?, ?, ?, ?)",
            [
                (
                    trade_date,
                    account,
                    amount,
                    json.dumps(
                        {s: str(v) for s, v in result.detail.get(account, {}).items()}
                    ),
                )
                for account, amount in rows.items()
            ],
        )
        conn.executemany(
            "INSERT INTO eod_close_equity (trade_date, gateway_id, symbol, equity)"
            " VALUES (?, ?, ?, ?)",
            [(trade_date, gw, sym, str(v)) for (gw, sym), v in result.equity.items()],
        )
        conn.execute(
            "INSERT INTO eod_close_source (trade_date, clearing_instance)"
            " VALUES (?, ?)",
            (trade_date, result.clearing_instance),
        )
    return gone


def settled_baseline(conn: sqlite3.Connection, trade_date: str) -> Baseline | None:
    """What ``trade_date`` was settled at; ``None`` if nothing was recorded."""
    rows = conn.execute(
        "SELECT gateway_id, symbol, equity FROM eod_close_equity WHERE trade_date = ?",
        (trade_date,),
    )
    equity = {(r[0], r[1]): Decimal(r[2]) for r in rows}
    if not equity:
        return None
    source = conn.execute(
        "SELECT clearing_instance FROM eod_close_source WHERE trade_date = ?",
        (trade_date,),
    ).fetchone()
    return Baseline(equity, None if source is None else source[0])


def day_amounts(conn: sqlite3.Connection, trade_date: str) -> dict[str, int]:
    rows = conn.execute(
        "SELECT account, amount_minor FROM eod_settlement WHERE trade_date = ?",
        (trade_date,),
    )
    return {r[0]: r[1] for r in rows}


def day_detail(
    conn: sqlite3.Connection, trade_date: str
) -> dict[str, dict[str, Decimal]]:
    """Per account, the day's result by symbol in display currency."""
    rows = conn.execute(
        "SELECT account, detail_json FROM eod_settlement WHERE trade_date = ?",
        (trade_date,),
    )
    return {
        r[0]: {sym: Decimal(v) for sym, v in json.loads(r[1]).items()} for r in rows
    }


def balances(
    conn: sqlite3.Connection,
    as_of: str | None = None,
    openings: Mapping[str, int] | None = None,
) -> dict[str, int]:
    """Running balance per account up to and including ``as_of``.

    ``openings`` (minor units) are added once; accounts that appear only there
    are included.
    """
    result = dict(openings or {})
    rows = conn.execute(
        "SELECT account, SUM(amount_minor) FROM eod_settlement"
        " WHERE (:as_of IS NULL OR trade_date <= :as_of) GROUP BY account",
        {"as_of": as_of},
    )
    for account, total in rows:
        result[account] = result.get(account, 0) + total
    return result


def record_run(
    conn: sqlite3.Connection,
    trade_date: str,
    status: str,
    started_at: str,
    finished_at: str,
    steps: list[dict[str, str]],
) -> None:
    with conn:
        conn.execute(
            "INSERT OR REPLACE INTO eod_runs"
            " (trade_date, status, started_at, finished_at, steps_json)"
            " VALUES (?, ?, ?, ?, ?)",
            (trade_date, status, started_at, finished_at, json.dumps(steps)),
        )


def runs(conn: sqlite3.Connection, limit: int = 30) -> list[dict[str, str]]:
    """Recorded runs, newest date first."""
    rows = conn.execute(
        "SELECT trade_date, status, started_at, finished_at, steps_json"
        " FROM eod_runs ORDER BY trade_date DESC LIMIT ?",
        (limit,),
    )
    return [dict(r) for r in rows]


def ok_dates(conn: sqlite3.Connection) -> set[str]:
    """Dates whose recorded run is ``ok``."""
    rows = conn.execute("SELECT trade_date FROM eod_runs WHERE status = 'ok'")
    return {r[0] for r in rows}


def run_for(conn: sqlite3.Connection, trade_date: str) -> dict[str, str] | None:
    """The recorded run of ``trade_date``, if any."""
    row = conn.execute(
        "SELECT trade_date, status, started_at, finished_at, steps_json"
        " FROM eod_runs WHERE trade_date = ?",
        (trade_date,),
    ).fetchone()
    return dict(row) if row else None


def query_settlements(
    conn: sqlite3.Connection,
    *,
    account: str | None = None,
    include_exchange: bool = True,
    date_value: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = 1000,
) -> list[dict[str, Any]]:
    """Settlement rows, newest date first, then account.

    ``include_exchange=False`` leaves out the rounding account even when
    ``account`` names it.
    """
    rows = conn.execute(
        "SELECT trade_date, account, amount_minor, detail_json FROM eod_settlement"
        " WHERE (:account IS NULL OR account = :account)"
        "   AND (:exchange OR account != :exchange_account)"
        "   AND (:date_value IS NULL OR trade_date = :date_value)"
        "   AND (:from_date IS NULL OR trade_date >= :from_date)"
        "   AND (:to_date IS NULL OR trade_date <= :to_date)"
        " ORDER BY trade_date DESC, account ASC"
        " LIMIT :limit",
        {
            "account": account,
            "exchange": 1 if include_exchange else 0,
            "exchange_account": EXCHANGE,
            "date_value": date_value,
            "from_date": from_date,
            "to_date": to_date,
            "limit": limit,
        },
    )
    return [dict(r) for r in rows]


def query_runs(
    conn: sqlite3.Connection,
    *,
    date_value: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = 1000,
) -> list[dict[str, str]]:
    """Recorded runs in a date range, newest date first."""
    rows = conn.execute(
        "SELECT trade_date, status, started_at, finished_at, steps_json"
        " FROM eod_runs"
        " WHERE (:date_value IS NULL OR trade_date = :date_value)"
        "   AND (:from_date IS NULL OR trade_date >= :from_date)"
        "   AND (:to_date IS NULL OR trade_date <= :to_date)"
        " ORDER BY trade_date DESC LIMIT :limit",
        {
            "date_value": date_value,
            "from_date": from_date,
            "to_date": to_date,
            "limit": limit,
        },
    )
    return [dict(r) for r in rows]


def last_settled_on_or_before(
    conn: sqlite3.Connection, as_of: str | None
) -> str | None:
    """The latest settled date up to ``as_of`` (any, when ``None``)."""
    row = conn.execute(
        "SELECT MAX(trade_date) FROM eod_settlement"
        " WHERE (:as_of IS NULL OR trade_date <= :as_of)",
        {"as_of": as_of},
    ).fetchone()
    return row[0] if row else None


def check_zero_sum(conn: sqlite3.Connection) -> list[str]:
    """Dates whose amounts do not add up to zero (should be none)."""
    rows = conn.execute(
        "SELECT trade_date FROM eod_settlement GROUP BY trade_date"
        " HAVING SUM(amount_minor) != 0 ORDER BY trade_date"
    )
    return [r[0] for r in rows]
