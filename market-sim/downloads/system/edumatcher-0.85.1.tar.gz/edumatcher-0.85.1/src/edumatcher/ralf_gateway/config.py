"""RALF gateway configuration loading helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


from edumatcher.config import ENGINE_PUB_ADDR
from edumatcher.config_include import load_config_mapping
from edumatcher.config import resolve_gateway_bind_host
from edumatcher.config_coerce import as_int


@dataclass(frozen=True)
class RalfGatewayConfig:
    name: str = "ralf-gwy01"
    bind_address: str = field(default_factory=resolve_gateway_bind_host)
    port: int = 5580
    engine_pub_addr: str = ENGINE_PUB_ADDR
    replay_retention_sec: int = 86_400
    heartbeat_interval_sec: int = 2
    idle_timeout_sec: int = 20
    max_connections: int = 64
    max_client_queue: int = 10_000
    allowed_roles: tuple[str, ...] = ("CLEARING", "DROP_COPY", "AUDIT")


def _as_int(raw: object, field: str) -> int:
    return as_int(raw, f"post_trade_gateway.{field}")


def _load_ralf_gateway_config_from_raw(raw: dict[str, Any]) -> RalfGatewayConfig:
    pg = raw.get("post_trade_gateway")
    if pg is None:
        return RalfGatewayConfig()
    if not isinstance(pg, dict):
        raise ValueError("post_trade_gateway must be a mapping")

    name = str(pg.get("name", "ralf-gwy01"))
    # Sent as WELCOME|...|GW=<name>: build_line refuses these characters, which
    # would end the gateway at the first HELLO.
    if not name or any(ch in name for ch in "|\r\n"):
        raise ValueError(
            "post_trade_gateway.name must be non-empty, without '|' or line breaks"
        )
    bind_address = resolve_gateway_bind_host(pg.get("bind_address"))
    port = _as_int(pg.get("port", 5580), "port")
    if port <= 0 or port > 65535:
        raise ValueError("post_trade_gateway.port must be in 1-65535")
    replay_retention_sec = _as_int(
        pg.get("replay_retention_sec", 86_400), "replay_retention_sec"
    )
    heartbeat_interval_sec = _as_int(
        pg.get("heartbeat_interval_sec", 2), "heartbeat_interval_sec"
    )
    idle_timeout_sec = _as_int(pg.get("idle_timeout_sec", 20), "idle_timeout_sec")
    max_connections = _as_int(pg.get("max_connections", 64), "max_connections")
    max_client_queue = _as_int(pg.get("max_client_queue", 10_000), "max_client_queue")

    allowed_roles_raw = pg.get("allowed_roles", ["CLEARING", "DROP_COPY", "AUDIT"])
    if not isinstance(allowed_roles_raw, list):
        raise ValueError("post_trade_gateway.allowed_roles must be a list")
    allowed_roles = tuple(str(x).upper() for x in allowed_roles_raw)
    # A role is also the channel it may read: any other name authenticated and
    # was then denied every SUB, and an empty list refused every HELLO.
    unknown = [r for r in allowed_roles if r not in ("CLEARING", "DROP_COPY", "AUDIT")]
    if not allowed_roles or unknown:
        raise ValueError(
            "post_trade_gateway.allowed_roles must be a non-empty list of "
            f"CLEARING, DROP_COPY, AUDIT (got {list(allowed_roles)})"
        )

    if replay_retention_sec <= 0:
        raise ValueError("post_trade_gateway.replay_retention_sec must be > 0")
    if heartbeat_interval_sec <= 0:
        raise ValueError("post_trade_gateway.heartbeat_interval_sec must be > 0")
    if idle_timeout_sec <= 0:
        raise ValueError("post_trade_gateway.idle_timeout_sec must be > 0")
    if max_connections <= 0:
        raise ValueError("post_trade_gateway.max_connections must be > 0")
    if max_client_queue <= 0:
        raise ValueError("post_trade_gateway.max_client_queue must be > 0")

    return RalfGatewayConfig(
        name=name,
        bind_address=bind_address,
        port=port,
        # engine_pub_addr is always taken from the global ENGINE_PUB_ADDR constant.
        # It cannot be overridden per-gateway in YAML; use the --engine-pub CLI flag.
        engine_pub_addr=ENGINE_PUB_ADDR,
        replay_retention_sec=replay_retention_sec,
        heartbeat_interval_sec=heartbeat_interval_sec,
        idle_timeout_sec=idle_timeout_sec,
        max_connections=max_connections,
        max_client_queue=max_client_queue,
        allowed_roles=allowed_roles,
    )


def load_ralf_gateway_config(path: Path) -> RalfGatewayConfig:
    """Load optional post_trade_gateway section from engine_config.yaml."""
    if not path.exists():
        return RalfGatewayConfig()

    raw = load_config_mapping(path).data

    return _load_ralf_gateway_config_from_raw(raw)


def validate_ralf_gateway_section(raw: dict[str, Any]) -> None:
    """Validate post_trade_gateway section using runtime loader semantics."""

    _load_ralf_gateway_config_from_raw(raw)


def load_default_ralf_gateway_config() -> RalfGatewayConfig:
    """Return this subsystem's section of the deployed compiled configuration.

    Falls back to dataclass defaults when nothing has been deployed yet, which
    is exactly what the YAML loader above did for a missing file — many tools
    that read this section, such as the spies and viewers, must still run
    against an exchange whose configuration was never installed.

    The import is deferred because ``config_artifact`` imports this module to
    describe the artifact's shape.
    """
    from edumatcher.config_artifact import load_compiled_config

    compiled = load_compiled_config()
    return RalfGatewayConfig() if compiled is None else compiled.post_trade_gateway
