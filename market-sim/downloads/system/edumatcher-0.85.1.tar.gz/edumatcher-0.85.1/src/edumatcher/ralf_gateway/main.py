"""CLI entrypoint for pm-ralf-gwy."""

from __future__ import annotations

import argparse
import logging

from edumatcher.config_artifact import exit_on_config_error
from edumatcher.health import HealthReporter
from edumatcher.ralf_gateway.config import (
    RalfGatewayConfig,
    load_default_ralf_gateway_config,
)
from edumatcher.ralf_gateway.gateway import RalfGateway
from edumatcher.log_srv.config import (
    load_default_log_client_config,
    load_default_log_server_config,
    resolve_host_default,
)
from edumatcher.logclient.discovery import resolve_handler

_CLIENT_NAME = "pm-ralf-gwy"
_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s - %(message)s"

log = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="EduMatcher RALF dissemination gateway"
    )
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-ralf-gwy")
    parser.add_argument("--bind", help="TCP bind address override")
    parser.add_argument("--port", type=int, help="TCP bind port override")
    parser.add_argument(
        "--engine-pub",
        default=None,
        help=(
            "Engine PUB socket address to subscribe to (default: "
            "tcp://$EDUMATCHER_ENGINE_HOST:5556, host 127.0.0.1 when unset)"
        ),
    )
    parser.add_argument(
        "--log-level",
        choices=["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"],
        help="Logging level override (default: WARNING)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase log verbosity (-v: INFO, -vv: DEBUG)",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Explicit WARNING log level (the default)",
    )
    parser.add_argument(
        "--log-target",
        choices=["server", "stdout", "file"],
        default=None,
        help=(
            "Where this process's own operational log records go: "
            "server (default, auto-detected pm-log-srv), stdout, or file"
        ),
    )
    parser.add_argument(
        "--log-file",
        default=None,
        metavar="PATH",
        help="Operational log file path — required when --log-target file",
    )
    parser.add_argument(
        "--log-failover-timeout",
        type=float,
        default=None,
        metavar="SECONDS",
        help=(
            "Grace window before falling back to a local log file once "
            "pm-log-srv becomes unreachable (default: 30, from config)"
        ),
    )
    return parser


def _configure_logging(args: argparse.Namespace) -> int:
    log_level = getattr(args, "log_level", None)
    verbose = getattr(args, "verbose", 0)
    quiet = getattr(args, "quiet", False)

    if log_level:
        level_name = str(log_level).upper()
        level = getattr(logging, level_name, logging.WARNING)
    elif verbose >= 2:
        level = logging.DEBUG
    elif verbose == 1:
        level = logging.INFO
    elif quiet:
        level = logging.WARNING
    else:
        level = logging.WARNING

    client_config = load_default_log_client_config()
    server_config = load_default_log_server_config()
    failover_timeout = getattr(args, "log_failover_timeout", None)
    handler = resolve_handler(
        log_target=getattr(args, "log_target", None),
        log_file=getattr(args, "log_file", None),
        client_name=_CLIENT_NAME,
        instance=None,
        host=resolve_host_default(),
        port=server_config.port,
        connect_timeout_sec=client_config.connect_timeout_sec,
        failover_timeout_sec=(
            failover_timeout
            if failover_timeout is not None
            else client_config.failover_timeout_sec
        ),
        failover_dir=client_config.failover_dir,
    )
    logging.basicConfig(level=level, format=_LOG_FORMAT, handlers=[handler])
    return int(level)


def _resolve_config(args: argparse.Namespace) -> RalfGatewayConfig:
    cfg = load_default_ralf_gateway_config()

    bind_address = str(args.bind) if args.bind else cfg.bind_address
    port = int(args.port) if args.port else cfg.port
    engine_pub_addr = str(args.engine_pub) if args.engine_pub else cfg.engine_pub_addr

    return RalfGatewayConfig(
        name=cfg.name,
        bind_address=bind_address,
        port=port,
        engine_pub_addr=engine_pub_addr,
        replay_retention_sec=cfg.replay_retention_sec,
        heartbeat_interval_sec=cfg.heartbeat_interval_sec,
        idle_timeout_sec=cfg.idle_timeout_sec,
        max_connections=cfg.max_connections,
        max_client_queue=cfg.max_client_queue,
        allowed_roles=cfg.allowed_roles,
    )


@exit_on_config_error
def main() -> None:
    from edumatcher.config_artifact import report_deployment

    parser = build_parser()
    args = parser.parse_args()
    log_level = _configure_logging(args)
    log.info("starting pm-ralf-gwy with log level %s", logging.getLevelName(log_level))
    report_deployment()

    try:
        config = _resolve_config(args)
    except Exception as exc:
        log.critical("failed to resolve configuration: %s", exc)
        parser.error(str(exc))

    log.debug(
        "resolved ralf-gateway config: bind=%s port=%s engine_pub=%s",
        config.bind_address,
        config.port,
        config.engine_pub_addr,
    )

    gateway = RalfGateway(config)
    reporter = HealthReporter.start_from_compiled_config(_CLIENT_NAME)
    if reporter is not None:
        gateway.attach_reporter(reporter)
    try:
        gateway.run()
    except Exception as exc:
        log.critical("fatal runtime error: %s", exc)
        raise
    finally:
        gateway.close()


__all__ = [
    "main",
    "build_parser",
    "_configure_logging",
    "_resolve_config",
    "load_default_ralf_gateway_config",
]
