# GENERATED FROM spec/messages/order.yaml - DO NOT EDIT
#
# Regenerate with:  poetry run pm-msgen generate
"""Generated bindings for the ``order`` message family.

Family version 1. Every symbol here is derived from ``spec/messages/order.yaml``; edit
the spec, not this file.

``pm-msgen check`` fails the build if this file and the spec disagree. See
../../../../docs/books/architecture-and-development/part-4-developing/040-message-
generation.md.
"""

from __future__ import annotations

import re
import struct as _struct
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, cast

from edumatcher.models import message as _msg
from edumatcher.models.generated._runtime import (
    MessageValidationError,
    balf_header as _msg_header,
    check_balf_frame as _check_frame,
)

FAMILY = "order"
FAMILY_VERSION = 1


_OCO_LEG_SIDE_VALUES = ("BUY", "SELL")
OcoLegSide = Literal["BUY", "SELL"]
_OCO_LEG_ORDER_TYPE_VALUES = (
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
)
OcoLegOrderType = Literal[
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
]


@dataclass(frozen=True, slots=True)
class OcoLeg:
    """One side of an OCO pair. It has no symbol or quantity of its own: both legs
    trade the same instrument in the same size, and the OCO carries those. That is
    what makes it a different record from a combo leg, which does own a symbol and
    a quantity.
    """

    side: OcoLegSide
    order_type: OcoLegOrderType
    price_ticks: int | None = None  # unit: ticks
    stop_price_ticks: int | None = None  # unit: ticks
    trail_offset_ticks: int | None = None  # unit: ticks

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.side not in _OCO_LEG_SIDE_VALUES:
            raise MessageValidationError(
                f"side: {self.side!r} is not one of {_OCO_LEG_SIDE_VALUES!r}"
            )
        if self.order_type not in _OCO_LEG_ORDER_TYPE_VALUES:
            raise MessageValidationError(
                f"order_type: {self.order_type!r} is not one of {_OCO_LEG_ORDER_TYPE_VALUES!r}"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OcoLeg":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            side=cast(OcoLegSide, str(p["side"])),
            order_type=cast(OcoLegOrderType, str(p["order_type"])),
            price_ticks=None if p.get("price_ticks") is None else int(p["price_ticks"]),
            stop_price_ticks=(
                None
                if p.get("stop_price_ticks") is None
                else int(p["stop_price_ticks"])
            ),
            trail_offset_ticks=(
                None
                if p.get("trail_offset_ticks") is None
                else int(p["trail_offset_ticks"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "side": self.side,
            "order_type": self.order_type,
        }
        if self.price_ticks is not None:
            payload["price_ticks"] = self.price_ticks
        if self.stop_price_ticks is not None:
            payload["stop_price_ticks"] = self.stop_price_ticks
        if self.trail_offset_ticks is not None:
            payload["trail_offset_ticks"] = self.trail_offset_ticks
        return payload


_COMBO_LEG_SIDE_VALUES = ("BUY", "SELL")
ComboLegSide = Literal["BUY", "SELL"]
_COMBO_LEG_ORDER_TYPE_VALUES = (
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
)
ComboLegOrderType = Literal[
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
]
_COMBO_LEG_SMP_ACTION_VALUES = (
    "NONE",
    "CANCEL_AGGRESSOR",
    "CANCEL_RESTING",
    "CANCEL_BOTH",
)
ComboLegSmpAction = Literal["NONE", "CANCEL_AGGRESSOR", "CANCEL_RESTING", "CANCEL_BOTH"]


@dataclass(frozen=True, slots=True)
class ComboLeg:
    """One leg of a combo. Unlike an OcoLeg it owns a symbol and a quantity: the legs
    of a combo trade different instruments, in sizes that need not match. That is
    why the two are separate types rather than one shared `leg` - an early draft
    of design section 15 assumed they could be merged and was wrong.
    """

    symbol: str
    side: ComboLegSide
    order_type: ComboLegOrderType
    quantity: int  # unit: shares
    tick_decimals: int  # unit: dimensionless
    price_ticks: int | None = None  # unit: ticks
    stop_price_ticks: int | None = None  # unit: ticks
    smp_action: ComboLegSmpAction | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.side not in _COMBO_LEG_SIDE_VALUES:
            raise MessageValidationError(
                f"side: {self.side!r} is not one of {_COMBO_LEG_SIDE_VALUES!r}"
            )
        if self.order_type not in _COMBO_LEG_ORDER_TYPE_VALUES:
            raise MessageValidationError(
                f"order_type: {self.order_type!r} is not one of {_COMBO_LEG_ORDER_TYPE_VALUES!r}"
            )
        if self.quantity <= 0:
            raise MessageValidationError(f"quantity: {self.quantity!r} must be > 0")
        if self.tick_decimals < 0:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be >= 0"
            )
        if self.tick_decimals > 8:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be <= 8"
            )
        if self.smp_action is not None:
            if self.smp_action not in _COMBO_LEG_SMP_ACTION_VALUES:
                raise MessageValidationError(
                    f"smp_action: {self.smp_action!r} is not one of {_COMBO_LEG_SMP_ACTION_VALUES!r}"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "ComboLeg":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            side=cast(ComboLegSide, str(p["side"])),
            order_type=cast(ComboLegOrderType, str(p["order_type"])),
            quantity=int(p["quantity"]),
            tick_decimals=int(p["tick_decimals"]),
            price_ticks=None if p.get("price_ticks") is None else int(p["price_ticks"]),
            stop_price_ticks=(
                None
                if p.get("stop_price_ticks") is None
                else int(p["stop_price_ticks"])
            ),
            smp_action=(
                None
                if p.get("smp_action") is None
                else cast(ComboLegSmpAction, str(p["smp_action"]))
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "symbol": self.symbol,
            "side": self.side,
            "order_type": self.order_type,
            "quantity": self.quantity,
            "tick_decimals": self.tick_decimals,
            "price_ticks": self.price_ticks,
            "stop_price_ticks": self.stop_price_ticks,
            "smp_action": self.smp_action,
        }


_ORDER_DISPLAY_SIDE_VALUES = ("BUY", "SELL")
OrderDisplaySide = Literal["BUY", "SELL"]
_ORDER_DISPLAY_ORDER_TYPE_VALUES = (
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
)
OrderDisplayOrderType = Literal[
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
]
_ORDER_DISPLAY_TIF_VALUES = ("DAY", "GTC", "ATO", "ATC")
OrderDisplayTif = Literal["DAY", "GTC", "ATO", "ATC"]
_ORDER_DISPLAY_STATUS_VALUES = (
    "NEW",
    "PARTIAL",
    "FILLED",
    "CANCELLED",
    "REJECTED",
    "EXPIRED",
)
OrderDisplayStatus = Literal[
    "NEW",
    "PARTIAL",
    "FILLED",
    "CANCELLED",
    "REJECTED",
    "EXPIRED",
]
_ORDER_DISPLAY_SMP_ACTION_VALUES = (
    "NONE",
    "CANCEL_AGGRESSOR",
    "CANCEL_RESTING",
    "CANCEL_BOTH",
)
OrderDisplaySmpAction = Literal[
    "NONE",
    "CANCEL_AGGRESSOR",
    "CANCEL_RESTING",
    "CANCEL_BOTH",
]
_ORDER_DISPLAY_ORIGIN_VALUES = ("ORDER", "QUOTE", "IMPLIED")
OrderDisplayOrigin = Literal["ORDER", "QUOTE", "IMPLIED"]


@dataclass(frozen=True, slots=True)
class OrderDisplay:
    """One resting order as the engine reports it in an `order.orders` snapshot, in
    display units. It is `Order.to_dict()` with price, stop_price and trail_offset
    converted from ticks to display money - the projection `order_to_display_dict`
    builds so an operator reads prices in the same money the book shows, not raw
    ticks. `timestamp` is carried through as `ts_ns` unconverted (AR-0.3b): unlike
    price, a raw nanosecond integer is exactly what a post-mortem needs to compare
    against `trade.executed.ts_ns` and the rest of the wire's ordering convention,
    and converting it to seconds here would only have to be undone by anything
    that wanted to compare it. `spec/messages/index.yaml`'s family made the same
    call for the same reason in AR-0.3; this type was out of scope for that pass
    (it is not part of the index family) and CP-0's own checklist item 3 is what
    caught it being left behind. Gateway_id is not included here; it is topic-only
    (part of the message topic as order.orders.{gateway_id}, not part of the
    record). The record contains the order state (id, symbol, side, etc.) exactly
    as Order.to_dict() produces, minus gateway_id; the eleven nullable ones ride
    as null when unset.
    """

    id: str
    symbol: str
    side: OrderDisplaySide
    order_type: OrderDisplayOrderType
    tif: OrderDisplayTif
    quantity: int  # unit: shares
    remaining_qty: int  # unit: shares
    ts_ns: int  # unit: epoch_nanos
    status: OrderDisplayStatus
    trail_offset: float | None = None  # unit: display_price
    oco_group_id: str | None = None
    price: float | None = None  # unit: display_price
    stop_price: float | None = None  # unit: display_price
    visible_qty: int | None = None  # unit: shares
    displayed_qty: int | None = None  # unit: shares
    smp_action: OrderDisplaySmpAction | None = None
    combo_parent_id: str | None = None
    leg_index: int | None = None  # unit: dimensionless
    origin: OrderDisplayOrigin = "ORDER"
    is_seed: bool = False
    quote_id: str | None = None
    client_tag: str | None = None
    arrival_seq: int = 0  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.id) > 64:
            raise MessageValidationError(
                f"id: length {len(self.id)} exceeds max_len 64"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.side not in _ORDER_DISPLAY_SIDE_VALUES:
            raise MessageValidationError(
                f"side: {self.side!r} is not one of {_ORDER_DISPLAY_SIDE_VALUES!r}"
            )
        if self.order_type not in _ORDER_DISPLAY_ORDER_TYPE_VALUES:
            raise MessageValidationError(
                f"order_type: {self.order_type!r} is not one of {_ORDER_DISPLAY_ORDER_TYPE_VALUES!r}"
            )
        if self.tif not in _ORDER_DISPLAY_TIF_VALUES:
            raise MessageValidationError(
                f"tif: {self.tif!r} is not one of {_ORDER_DISPLAY_TIF_VALUES!r}"
            )
        if self.quantity <= 0:
            raise MessageValidationError(f"quantity: {self.quantity!r} must be > 0")
        if self.remaining_qty < 0:
            raise MessageValidationError(
                f"remaining_qty: {self.remaining_qty!r} must be >= 0"
            )
        if self.oco_group_id is not None:
            if len(self.oco_group_id) > 64:
                raise MessageValidationError(
                    f"oco_group_id: length {len(self.oco_group_id)} exceeds max_len 64"
                )
        if self.ts_ns < 0:
            raise MessageValidationError(f"ts_ns: {self.ts_ns!r} must be >= 0")
        if self.status not in _ORDER_DISPLAY_STATUS_VALUES:
            raise MessageValidationError(
                f"status: {self.status!r} is not one of {_ORDER_DISPLAY_STATUS_VALUES!r}"
            )
        if self.smp_action is not None:
            if self.smp_action not in _ORDER_DISPLAY_SMP_ACTION_VALUES:
                raise MessageValidationError(
                    f"smp_action: {self.smp_action!r} is not one of {_ORDER_DISPLAY_SMP_ACTION_VALUES!r}"
                )
        if self.combo_parent_id is not None:
            if len(self.combo_parent_id) > 64:
                raise MessageValidationError(
                    f"combo_parent_id: length {len(self.combo_parent_id)} exceeds max_len 64"
                )
        if self.origin not in _ORDER_DISPLAY_ORIGIN_VALUES:
            raise MessageValidationError(
                f"origin: {self.origin!r} is not one of {_ORDER_DISPLAY_ORIGIN_VALUES!r}"
            )
        if self.quote_id is not None:
            if len(self.quote_id) > 64:
                raise MessageValidationError(
                    f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
                )
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderDisplay":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            id=str(p["id"]),
            symbol=str(p["symbol"]),
            side=cast(OrderDisplaySide, str(p["side"])),
            order_type=cast(OrderDisplayOrderType, str(p["order_type"])),
            tif=cast(OrderDisplayTif, str(p["tif"])),
            quantity=int(p["quantity"]),
            remaining_qty=int(p["remaining_qty"]),
            trail_offset=(
                None if p.get("trail_offset") is None else float(p["trail_offset"])
            ),
            oco_group_id=(
                None if p.get("oco_group_id") is None else str(p["oco_group_id"])
            ),
            ts_ns=int(p["ts_ns"]),
            status=cast(OrderDisplayStatus, str(p["status"])),
            price=None if p.get("price") is None else float(p["price"]),
            stop_price=None if p.get("stop_price") is None else float(p["stop_price"]),
            visible_qty=None if p.get("visible_qty") is None else int(p["visible_qty"]),
            displayed_qty=(
                None if p.get("displayed_qty") is None else int(p["displayed_qty"])
            ),
            smp_action=(
                None
                if p.get("smp_action") is None
                else cast(OrderDisplaySmpAction, str(p["smp_action"]))
            ),
            combo_parent_id=(
                None if p.get("combo_parent_id") is None else str(p["combo_parent_id"])
            ),
            leg_index=None if p.get("leg_index") is None else int(p["leg_index"]),
            origin=cast(OrderDisplayOrigin, str(p.get("origin", "ORDER"))),
            is_seed=bool(p.get("is_seed", False)),
            quote_id=None if p.get("quote_id") is None else str(p["quote_id"]),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
            arrival_seq=int(p.get("arrival_seq", 0)),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "id": self.id,
            "symbol": self.symbol,
            "side": self.side,
            "order_type": self.order_type,
            "tif": self.tif,
            "quantity": self.quantity,
            "remaining_qty": self.remaining_qty,
            "trail_offset": self.trail_offset,
            "oco_group_id": self.oco_group_id,
            "ts_ns": self.ts_ns,
            "status": self.status,
            "price": self.price,
            "stop_price": self.stop_price,
            "visible_qty": self.visible_qty,
            "displayed_qty": self.displayed_qty,
            "smp_action": self.smp_action,
            "combo_parent_id": self.combo_parent_id,
            "leg_index": self.leg_index,
            "origin": self.origin,
            "is_seed": self.is_seed,
            "quote_id": self.quote_id,
            "client_tag": self.client_tag,
            "arrival_seq": self.arrival_seq,
        }


_PRICE_LEVEL_ORDER_SIDE_VALUES = ("BUY", "SELL")
PriceLevelOrderSide = Literal["BUY", "SELL"]
_PRICE_LEVEL_ORDER_ORDER_TYPE_VALUES = (
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
)
PriceLevelOrderOrderType = Literal[
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
]
_PRICE_LEVEL_ORDER_TIF_VALUES = ("DAY", "GTC", "ATO", "ATC")
PriceLevelOrderTif = Literal["DAY", "GTC", "ATO", "ATC"]
_PRICE_LEVEL_ORDER_STATUS_VALUES = (
    "NEW",
    "PARTIAL",
    "FILLED",
    "CANCELLED",
    "REJECTED",
    "EXPIRED",
)
PriceLevelOrderStatus = Literal[
    "NEW",
    "PARTIAL",
    "FILLED",
    "CANCELLED",
    "REJECTED",
    "EXPIRED",
]
_PRICE_LEVEL_ORDER_SMP_ACTION_VALUES = (
    "NONE",
    "CANCEL_AGGRESSOR",
    "CANCEL_RESTING",
    "CANCEL_BOTH",
)
PriceLevelOrderSmpAction = Literal[
    "NONE",
    "CANCEL_AGGRESSOR",
    "CANCEL_RESTING",
    "CANCEL_BOTH",
]
_PRICE_LEVEL_ORDER_ORIGIN_VALUES = ("ORDER", "QUOTE", "IMPLIED")
PriceLevelOrderOrigin = Literal["ORDER", "QUOTE", "IMPLIED"]


@dataclass(frozen=True, slots=True)
class PriceLevelOrder:
    """One resting order as reported by order.price_level_orders — the same
    projection as OrderDisplay (order_to_display_dict, including its ts_ns field —
    see OrderDisplay's doc for why that one is not converted to display units the
    way price/stop_price/trail_offset are), with one field added: gateway_id.
    OrderDisplay can leave gateway_id topic-only because an order.orders reply is
    always about a single, already-known gateway; a price_level_orders reply spans
    every gateway resting at a symbol/price, so each record must say whose order
    it is. The generator has no type-extension mechanism, so this duplicates
    OrderDisplay's field list rather than referencing it — keep the two in sync by
    hand if OrderDisplay's fields change.
    """

    gateway_id: str
    id: str
    symbol: str
    side: PriceLevelOrderSide
    order_type: PriceLevelOrderOrderType
    tif: PriceLevelOrderTif
    quantity: int  # unit: shares
    remaining_qty: int  # unit: shares
    ts_ns: int  # unit: epoch_nanos
    status: PriceLevelOrderStatus
    trail_offset: float | None = None  # unit: display_price
    oco_group_id: str | None = None
    price: float | None = None  # unit: display_price
    stop_price: float | None = None  # unit: display_price
    visible_qty: int | None = None  # unit: shares
    displayed_qty: int | None = None  # unit: shares
    smp_action: PriceLevelOrderSmpAction | None = None
    combo_parent_id: str | None = None
    leg_index: int | None = None  # unit: dimensionless
    origin: PriceLevelOrderOrigin = "ORDER"
    is_seed: bool = False
    quote_id: str | None = None
    client_tag: str | None = None
    arrival_seq: int = 0  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.id) > 64:
            raise MessageValidationError(
                f"id: length {len(self.id)} exceeds max_len 64"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.side not in _PRICE_LEVEL_ORDER_SIDE_VALUES:
            raise MessageValidationError(
                f"side: {self.side!r} is not one of {_PRICE_LEVEL_ORDER_SIDE_VALUES!r}"
            )
        if self.order_type not in _PRICE_LEVEL_ORDER_ORDER_TYPE_VALUES:
            raise MessageValidationError(
                f"order_type: {self.order_type!r} is not one of {_PRICE_LEVEL_ORDER_ORDER_TYPE_VALUES!r}"
            )
        if self.tif not in _PRICE_LEVEL_ORDER_TIF_VALUES:
            raise MessageValidationError(
                f"tif: {self.tif!r} is not one of {_PRICE_LEVEL_ORDER_TIF_VALUES!r}"
            )
        if self.quantity <= 0:
            raise MessageValidationError(f"quantity: {self.quantity!r} must be > 0")
        if self.remaining_qty < 0:
            raise MessageValidationError(
                f"remaining_qty: {self.remaining_qty!r} must be >= 0"
            )
        if self.oco_group_id is not None:
            if len(self.oco_group_id) > 64:
                raise MessageValidationError(
                    f"oco_group_id: length {len(self.oco_group_id)} exceeds max_len 64"
                )
        if self.ts_ns < 0:
            raise MessageValidationError(f"ts_ns: {self.ts_ns!r} must be >= 0")
        if self.status not in _PRICE_LEVEL_ORDER_STATUS_VALUES:
            raise MessageValidationError(
                f"status: {self.status!r} is not one of {_PRICE_LEVEL_ORDER_STATUS_VALUES!r}"
            )
        if self.smp_action is not None:
            if self.smp_action not in _PRICE_LEVEL_ORDER_SMP_ACTION_VALUES:
                raise MessageValidationError(
                    f"smp_action: {self.smp_action!r} is not one of {_PRICE_LEVEL_ORDER_SMP_ACTION_VALUES!r}"
                )
        if self.combo_parent_id is not None:
            if len(self.combo_parent_id) > 64:
                raise MessageValidationError(
                    f"combo_parent_id: length {len(self.combo_parent_id)} exceeds max_len 64"
                )
        if self.origin not in _PRICE_LEVEL_ORDER_ORIGIN_VALUES:
            raise MessageValidationError(
                f"origin: {self.origin!r} is not one of {_PRICE_LEVEL_ORDER_ORIGIN_VALUES!r}"
            )
        if self.quote_id is not None:
            if len(self.quote_id) > 64:
                raise MessageValidationError(
                    f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
                )
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "PriceLevelOrder":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            id=str(p["id"]),
            symbol=str(p["symbol"]),
            side=cast(PriceLevelOrderSide, str(p["side"])),
            order_type=cast(PriceLevelOrderOrderType, str(p["order_type"])),
            tif=cast(PriceLevelOrderTif, str(p["tif"])),
            quantity=int(p["quantity"]),
            remaining_qty=int(p["remaining_qty"]),
            trail_offset=(
                None if p.get("trail_offset") is None else float(p["trail_offset"])
            ),
            oco_group_id=(
                None if p.get("oco_group_id") is None else str(p["oco_group_id"])
            ),
            ts_ns=int(p["ts_ns"]),
            status=cast(PriceLevelOrderStatus, str(p["status"])),
            price=None if p.get("price") is None else float(p["price"]),
            stop_price=None if p.get("stop_price") is None else float(p["stop_price"]),
            visible_qty=None if p.get("visible_qty") is None else int(p["visible_qty"]),
            displayed_qty=(
                None if p.get("displayed_qty") is None else int(p["displayed_qty"])
            ),
            smp_action=(
                None
                if p.get("smp_action") is None
                else cast(PriceLevelOrderSmpAction, str(p["smp_action"]))
            ),
            combo_parent_id=(
                None if p.get("combo_parent_id") is None else str(p["combo_parent_id"])
            ),
            leg_index=None if p.get("leg_index") is None else int(p["leg_index"]),
            origin=cast(PriceLevelOrderOrigin, str(p.get("origin", "ORDER"))),
            is_seed=bool(p.get("is_seed", False)),
            quote_id=None if p.get("quote_id") is None else str(p["quote_id"]),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
            arrival_seq=int(p.get("arrival_seq", 0)),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
            "id": self.id,
            "symbol": self.symbol,
            "side": self.side,
            "order_type": self.order_type,
            "tif": self.tif,
            "quantity": self.quantity,
            "remaining_qty": self.remaining_qty,
            "trail_offset": self.trail_offset,
            "oco_group_id": self.oco_group_id,
            "ts_ns": self.ts_ns,
            "status": self.status,
            "price": self.price,
            "stop_price": self.stop_price,
            "visible_qty": self.visible_qty,
            "displayed_qty": self.displayed_qty,
            "smp_action": self.smp_action,
            "combo_parent_id": self.combo_parent_id,
            "leg_index": self.leg_index,
            "origin": self.origin,
            "is_seed": self.is_seed,
            "quote_id": self.quote_id,
            "client_tag": self.client_tag,
            "arrival_seq": self.arrival_seq,
        }


_EXECUTION_REPORT_SYMBOL_RE = re.compile("^[A-Z0-9._]+$")
_EXECUTION_REPORT_SIDE_VALUES = ("BUY", "SELL")
ExecutionReportSide = Literal["BUY", "SELL"]
_EXECUTION_REPORT_STATUS_VALUES = ("PARTIAL", "FILLED")
ExecutionReportStatus = Literal["PARTIAL", "FILLED"]


_EXECUTION_REPORT_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "client_order_id",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Echoed from the original NEW_ORDER so a client can correlate.",
    },
    {
        "name": "order_id",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Session-scoped BALF order id assigned by the gateway. A u64 on the wire, not a string - this is the field the reference example got wrong.",
    },
    {
        "name": "fill_price",
        "type": "float",
        "unit": "display_price",
        "required": True,
        "doc": "Execution price in display money. On the wire it is an i64 scaled by the fixed BALF PRICE_SCALE of 10^8, never by the instrument's tick_decimals.",
        "constraints": {"gt": 0},
    },
    {
        "name": "fill_qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "Quantity matched in this event, not cumulatively.",
        "constraints": {"gt": 0},
    },
    {
        "name": "remaining_qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "Unfilled quantity after this fill; zero means the order is done.",
        "constraints": {"ge": 0},
    },
    {
        "name": "timestamp_ns",
        "type": "int",
        "unit": "epoch_nanos",
        "required": True,
        "doc": "Trade time in nanoseconds since the Unix epoch.",
        "constraints": {"ge": 0},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Instrument, echoed for convenience; matches the original order.",
        "constraints": {"max_len": 8, "pattern": "^[A-Z0-9._]+$"},
    },
    {
        "name": "side",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "Side of the filled order.",
        "values": _EXECUTION_REPORT_SIDE_VALUES,
    },
    {
        "name": "status",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "Whether this fill completed the order. Only these two values exist on BALF - there is no NEW or CANCELLED execution report.",
        "values": _EXECUTION_REPORT_STATUS_VALUES,
    },
)


@dataclass(frozen=True, slots=True)
class ExecutionReport:
    """Private per-order fill notification, sent to the gateway session that owns the
    order. Both sides of a match receive their own report.

    Sent for every partial or full fill, so a single order may produce several.
    remaining_qty reaching zero is what marks the order done; status FILLED says the
    same thing and the two must agree.
    """

    client_order_id: int  # unit: dimensionless
    order_id: int  # unit: dimensionless
    fill_price: float  # unit: display_price
    fill_qty: int  # unit: shares
    remaining_qty: int  # unit: shares
    timestamp_ns: int  # unit: epoch_nanos
    symbol: str
    side: ExecutionReportSide
    status: ExecutionReportStatus

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.fill_price <= 0:
            raise MessageValidationError(f"fill_price: {self.fill_price!r} must be > 0")
        if self.fill_qty <= 0:
            raise MessageValidationError(f"fill_qty: {self.fill_qty!r} must be > 0")
        if self.remaining_qty < 0:
            raise MessageValidationError(
                f"remaining_qty: {self.remaining_qty!r} must be >= 0"
            )
        if self.timestamp_ns < 0:
            raise MessageValidationError(
                f"timestamp_ns: {self.timestamp_ns!r} must be >= 0"
            )
        if len(self.symbol) > 8:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 8"
            )
        if not _EXECUTION_REPORT_SYMBOL_RE.fullmatch(self.symbol):
            raise MessageValidationError(
                f"symbol: {self.symbol!r} does not match {_EXECUTION_REPORT_SYMBOL_RE.pattern!r}"
            )
        if self.side not in _EXECUTION_REPORT_SIDE_VALUES:
            raise MessageValidationError(
                f"side: {self.side!r} is not one of {_EXECUTION_REPORT_SIDE_VALUES!r}"
            )
        if self.status not in _EXECUTION_REPORT_STATUS_VALUES:
            raise MessageValidationError(
                f"status: {self.status!r} is not one of {_EXECUTION_REPORT_STATUS_VALUES!r}"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "ExecutionReport":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            client_order_id=int(p["client_order_id"]),
            order_id=int(p["order_id"]),
            fill_price=float(p["fill_price"]),
            fill_qty=int(p["fill_qty"]),
            remaining_qty=int(p["remaining_qty"]),
            timestamp_ns=int(p["timestamp_ns"]),
            symbol=str(p["symbol"]),
            side=cast(ExecutionReportSide, str(p["side"])),
            status=cast(ExecutionReportStatus, str(p["status"])),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "client_order_id": self.client_order_id,
            "order_id": self.order_id,
            "fill_price": self.fill_price,
            "fill_qty": self.fill_qty,
            "remaining_qty": self.remaining_qty,
            "timestamp_ns": self.timestamp_ns,
            "symbol": self.symbol,
            "side": self.side,
            "status": self.status,
        }


def describe_execution_report() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _EXECUTION_REPORT_FIELDS


MSGTYPE_EXECUTION_REPORT_BALF = 0x20
FRAME_SIZE_EXECUTION_REPORT_BALF = 64
_EXECUTION_REPORT_BALF_FMT = "<QQqIIQ8sBB6x"
_EXECUTION_REPORT_BALF_STRUCT = _struct.Struct(_EXECUTION_REPORT_BALF_FMT)
PRICE_SCALE_EXECUTION_REPORT_BALF = 100000000
_EXECUTION_REPORT_BALF_SIDE_TO_WIRE = {"BUY": 1, "SELL": 2}
_EXECUTION_REPORT_BALF_SIDE_FROM_WIRE = {
    v: k for k, v in _EXECUTION_REPORT_BALF_SIDE_TO_WIRE.items()
}
_EXECUTION_REPORT_BALF_STATUS_TO_WIRE = {"PARTIAL": 1, "FILLED": 2}
_EXECUTION_REPORT_BALF_STATUS_FROM_WIRE = {
    v: k for k, v in _EXECUTION_REPORT_BALF_STATUS_TO_WIRE.items()
}


def serialise_execution_report_balf(
    payload: Mapping[str, Any],
    *,
    seq_no: int,
    flags: int = 0,
) -> bytes:
    """Serialise a payload into one BALF frame.

    Returns exactly FRAME_SIZE_EXECUTION_REPORT_BALF bytes: the fixed 8-byte header
    followed by the body laid out in the spec. The header is the generator's, not the
    spec's — it must not be declared in `layout` (design section B.13).

    Reads only the laid-out fields, and coerces each to its declared type, so this and
    the typed binding never disagree.
    """
    return _msg_header(
        MSGTYPE_EXECUTION_REPORT_BALF, seq_no, flags
    ) + _EXECUTION_REPORT_BALF_STRUCT.pack(
        int(payload["client_order_id"]),
        int(payload["order_id"]),
        round(float(payload["fill_price"]) * 100000000),
        int(payload["fill_qty"]),
        int(payload["remaining_qty"]),
        int(payload["timestamp_ns"]),
        str(payload["symbol"]).encode(),
        _EXECUTION_REPORT_BALF_SIDE_TO_WIRE[str(payload["side"])],
        _EXECUTION_REPORT_BALF_STATUS_TO_WIRE[str(payload["status"])],
    )


def parse_execution_report_balf(frame: bytes) -> "ExecutionReport":
    """Parse one BALF frame into this message.

    Validates the header (magic, version, msg_type) and the frame length, because a
    wrong-length frame is not this message and reading it as one would silently produce
    nonsense. Field values are coerced but their declared rules are not checked — call
    ``validate()`` for that (design section 5.1.1).

    Raises MessageValidationError on a header or length mismatch.
    """
    _check_frame(frame, MSGTYPE_EXECUTION_REPORT_BALF, FRAME_SIZE_EXECUTION_REPORT_BALF)
    (
        client_order_id,
        order_id,
        fill_price,
        fill_qty,
        remaining_qty,
        timestamp_ns,
        symbol,
        side,
        status,
    ) = _EXECUTION_REPORT_BALF_STRUCT.unpack_from(frame, 8)
    return ExecutionReport(
        client_order_id=client_order_id,
        order_id=order_id,
        fill_price=fill_price / 100000000,
        fill_qty=fill_qty,
        remaining_qty=remaining_qty,
        timestamp_ns=timestamp_ns,
        symbol=symbol.split(b"\x00")[0].decode(),
        side=cast(
            ExecutionReportSide, _EXECUTION_REPORT_BALF_SIDE_FROM_WIRE.get(side, "")
        ),
        status=cast(
            ExecutionReportStatus,
            _EXECUTION_REPORT_BALF_STATUS_FROM_WIRE.get(status, ""),
        ),
    )


_STOP_TRIGGERED_SYMBOL_RE = re.compile("^[A-Z0-9._]+$")
_STOP_TRIGGERED_ORDER_TYPE_VALUES = ("STOP", "STOP_LIMIT", "TRAILING_STOP")
StopTriggeredOrderType = Literal["STOP", "STOP_LIMIT", "TRAILING_STOP"]
_STOP_TRIGGERED_BECOMES_VALUES = ("MARKET", "LIMIT")
StopTriggeredBecomes = Literal["MARKET", "LIMIT"]


_STOP_TRIGGERED_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "client_order_id",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Echoed from the original NEW_ORDER.",
    },
    {
        "name": "order_id",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Session-scoped BALF order id assigned by the gateway.",
    },
    {
        "name": "stop_price",
        "type": "float",
        "unit": "display_price",
        "required": True,
        "doc": "The trigger price it fired at (a trailing stop's ratcheted one), in display money; i64 x 10^8 on the wire.",
        "constraints": {"gt": 0},
    },
    {
        "name": "trigger_price",
        "type": "float",
        "unit": "display_price",
        "required": True,
        "doc": "The price of the trade that reached the trigger; 0 when the last price came from a restart.",
        "constraints": {"ge": 0},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 8, "pattern": "^[A-Z0-9._]+$"},
    },
    {
        "name": "order_type",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "The order as it was armed (NEW_ORDER's order_type codes).",
        "values": _STOP_TRIGGERED_ORDER_TYPE_VALUES,
    },
    {
        "name": "becomes",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "STOP and TRAILING_STOP become MARKET; STOP_LIMIT becomes LIMIT.",
        "values": _STOP_TRIGGERED_BECOMES_VALUES,
    },
)


@dataclass(frozen=True, slots=True)
class StopTriggered:
    """A stop, stop-limit or trailing stop of this session has fired. Sent before the
    order's own execution reports, so a client knows why its stop traded -- the
    FIX analogue is ExecType=L.
    """

    client_order_id: int  # unit: dimensionless
    order_id: int  # unit: dimensionless
    stop_price: float  # unit: display_price
    trigger_price: float  # unit: display_price
    symbol: str
    order_type: StopTriggeredOrderType
    becomes: StopTriggeredBecomes

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.stop_price <= 0:
            raise MessageValidationError(f"stop_price: {self.stop_price!r} must be > 0")
        if self.trigger_price < 0:
            raise MessageValidationError(
                f"trigger_price: {self.trigger_price!r} must be >= 0"
            )
        if len(self.symbol) > 8:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 8"
            )
        if not _STOP_TRIGGERED_SYMBOL_RE.fullmatch(self.symbol):
            raise MessageValidationError(
                f"symbol: {self.symbol!r} does not match {_STOP_TRIGGERED_SYMBOL_RE.pattern!r}"
            )
        if self.order_type not in _STOP_TRIGGERED_ORDER_TYPE_VALUES:
            raise MessageValidationError(
                f"order_type: {self.order_type!r} is not one of {_STOP_TRIGGERED_ORDER_TYPE_VALUES!r}"
            )
        if self.becomes not in _STOP_TRIGGERED_BECOMES_VALUES:
            raise MessageValidationError(
                f"becomes: {self.becomes!r} is not one of {_STOP_TRIGGERED_BECOMES_VALUES!r}"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "StopTriggered":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            client_order_id=int(p["client_order_id"]),
            order_id=int(p["order_id"]),
            stop_price=float(p["stop_price"]),
            trigger_price=float(p["trigger_price"]),
            symbol=str(p["symbol"]),
            order_type=cast(StopTriggeredOrderType, str(p["order_type"])),
            becomes=cast(StopTriggeredBecomes, str(p["becomes"])),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "client_order_id": self.client_order_id,
            "order_id": self.order_id,
            "stop_price": self.stop_price,
            "trigger_price": self.trigger_price,
            "symbol": self.symbol,
            "order_type": self.order_type,
            "becomes": self.becomes,
        }


def describe_stop_triggered() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _STOP_TRIGGERED_FIELDS


MSGTYPE_STOP_TRIGGERED_BALF = 0x21
FRAME_SIZE_STOP_TRIGGERED_BALF = 56
_STOP_TRIGGERED_BALF_FMT = "<QQqq8sBB6x"
_STOP_TRIGGERED_BALF_STRUCT = _struct.Struct(_STOP_TRIGGERED_BALF_FMT)
PRICE_SCALE_STOP_TRIGGERED_BALF = 100000000
_STOP_TRIGGERED_BALF_ORDER_TYPE_TO_WIRE = {
    "STOP": 5,
    "STOP_LIMIT": 6,
    "TRAILING_STOP": 8,
}
_STOP_TRIGGERED_BALF_ORDER_TYPE_FROM_WIRE = {
    v: k for k, v in _STOP_TRIGGERED_BALF_ORDER_TYPE_TO_WIRE.items()
}
_STOP_TRIGGERED_BALF_BECOMES_TO_WIRE = {"MARKET": 1, "LIMIT": 2}
_STOP_TRIGGERED_BALF_BECOMES_FROM_WIRE = {
    v: k for k, v in _STOP_TRIGGERED_BALF_BECOMES_TO_WIRE.items()
}


def serialise_stop_triggered_balf(
    payload: Mapping[str, Any],
    *,
    seq_no: int,
    flags: int = 0,
) -> bytes:
    """Serialise a payload into one BALF frame.

    Returns exactly FRAME_SIZE_STOP_TRIGGERED_BALF bytes: the fixed 8-byte header
    followed by the body laid out in the spec. The header is the generator's, not the
    spec's — it must not be declared in `layout` (design section B.13).

    Reads only the laid-out fields, and coerces each to its declared type, so this and
    the typed binding never disagree.
    """
    return _msg_header(
        MSGTYPE_STOP_TRIGGERED_BALF, seq_no, flags
    ) + _STOP_TRIGGERED_BALF_STRUCT.pack(
        int(payload["client_order_id"]),
        int(payload["order_id"]),
        round(float(payload["stop_price"]) * 100000000),
        round(float(payload["trigger_price"]) * 100000000),
        str(payload["symbol"]).encode(),
        _STOP_TRIGGERED_BALF_ORDER_TYPE_TO_WIRE[str(payload["order_type"])],
        _STOP_TRIGGERED_BALF_BECOMES_TO_WIRE[str(payload["becomes"])],
    )


def parse_stop_triggered_balf(frame: bytes) -> "StopTriggered":
    """Parse one BALF frame into this message.

    Validates the header (magic, version, msg_type) and the frame length, because a
    wrong-length frame is not this message and reading it as one would silently produce
    nonsense. Field values are coerced but their declared rules are not checked — call
    ``validate()`` for that (design section 5.1.1).

    Raises MessageValidationError on a header or length mismatch.
    """
    _check_frame(frame, MSGTYPE_STOP_TRIGGERED_BALF, FRAME_SIZE_STOP_TRIGGERED_BALF)
    (
        client_order_id,
        order_id,
        stop_price,
        trigger_price,
        symbol,
        order_type,
        becomes,
    ) = _STOP_TRIGGERED_BALF_STRUCT.unpack_from(frame, 8)
    return StopTriggered(
        client_order_id=client_order_id,
        order_id=order_id,
        stop_price=stop_price / 100000000,
        trigger_price=trigger_price / 100000000,
        symbol=symbol.split(b"\x00")[0].decode(),
        order_type=cast(
            StopTriggeredOrderType,
            _STOP_TRIGGERED_BALF_ORDER_TYPE_FROM_WIRE.get(order_type, ""),
        ),
        becomes=cast(
            StopTriggeredBecomes,
            _STOP_TRIGGERED_BALF_BECOMES_FROM_WIRE.get(becomes, ""),
        ),
    )


TOPIC_ORDER_ACK = "order.ack.{gateway_id}"
PREFIX_ORDER_ACK = "order.ack."
_ORDER_ACK_RE = re.compile("order\\.ack\\.(?P<gateway_id>[^.]+)")
_ORDER_ACK_REJECT_CODE_VALUES = (
    "MALFORMED_MESSAGE",
    "MISSING_FIELD",
    "INVALID_VALUE",
    "UNSUPPORTED_FIELD",
    "AUTH_REQUIRED",
    "AUTH_FAILED",
    "ROLE_DENIED",
    "NOT_OWNER",
    "RATE_LIMITED",
    "GATEWAY_NOT_CONFIGURED",
    "UNKNOWN_SYMBOL",
    "SYMBOL_NOT_READY",
    "TICK_VIOLATION",
    "LOT_VIOLATION",
    "PRICE_OUT_OF_RANGE",
    "QTY_OUT_OF_RANGE",
    "COLLAR_BREACH",
    "MAX_ORDER_QTY",
    "MAX_ORDER_VALUE",
    "POSITION_LIMIT",
    "KILL_SWITCH_ACTIVE",
    "MARKET_CLOSED",
    "SESSION_NOT_PERMITTED",
    "INSTRUMENT_HALTED",
    "CIRCUIT_BREAKER_ACTIVE",
    "ORDER_NOT_FOUND",
    "ORDER_ALREADY_TERMINAL",
    "AMEND_NOT_PERMITTED",
    "DUPLICATE_ORDER",
    "INSUFFICIENT_LIQUIDITY",
    "SELF_MATCH_PREVENTED",
    "INTERNAL_ERROR",
    "UNKNOWN",
)
OrderAckRejectCode = Literal[
    "MALFORMED_MESSAGE",
    "MISSING_FIELD",
    "INVALID_VALUE",
    "UNSUPPORTED_FIELD",
    "AUTH_REQUIRED",
    "AUTH_FAILED",
    "ROLE_DENIED",
    "NOT_OWNER",
    "RATE_LIMITED",
    "GATEWAY_NOT_CONFIGURED",
    "UNKNOWN_SYMBOL",
    "SYMBOL_NOT_READY",
    "TICK_VIOLATION",
    "LOT_VIOLATION",
    "PRICE_OUT_OF_RANGE",
    "QTY_OUT_OF_RANGE",
    "COLLAR_BREACH",
    "MAX_ORDER_QTY",
    "MAX_ORDER_VALUE",
    "POSITION_LIMIT",
    "KILL_SWITCH_ACTIVE",
    "MARKET_CLOSED",
    "SESSION_NOT_PERMITTED",
    "INSTRUMENT_HALTED",
    "CIRCUIT_BREAKER_ACTIVE",
    "ORDER_NOT_FOUND",
    "ORDER_ALREADY_TERMINAL",
    "AMEND_NOT_PERMITTED",
    "DUPLICATE_ORDER",
    "INSUFFICIENT_LIQUIDITY",
    "SELF_MATCH_PREVENTED",
    "INTERNAL_ERROR",
    "UNKNOWN",
]
_ORDER_ACK_SMP_ACTION_VALUES = (
    "NONE",
    "CANCEL_AGGRESSOR",
    "CANCEL_RESTING",
    "CANCEL_BOTH",
)
OrderAckSmpAction = Literal["NONE", "CANCEL_AGGRESSOR", "CANCEL_RESTING", "CANCEL_BOTH"]
_ORDER_ACK_REQUEST_VALUES = ("NEW", "CANCEL", "AMEND")
OrderAckRequest = Literal["NEW", "CANCEL", "AMEND"]


_ORDER_ACK_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "order_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "accepted",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Rejection detail; empty when accepted.",
        "constraints": {"max_len": 256},
    },
    {
        "name": "reject_code",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "Machine-readable rejection classification, stable across every order-entry transport (ALF, BALF, REST) and every layer (gateway-local validation and engine-side business rules). Absent when accepted; present on every rejection. The human-readable detail rides in reason; this field never carries data values. New members may be added; existing members are never removed or renamed. A client must treat an unrecognised code as UNKNOWN.",
        "values": _ORDER_ACK_REJECT_CODE_VALUES,
    },
    {
        "name": "ts_ns",
        "type": "int",
        "unit": "epoch_nanos",
        "required": False,
        "doc": "The engine's clock when it decided this order's fate (accepted or refused), in Unix epoch nanoseconds from the same strictly increasing source as trade.executed.ts_ns, so an ack sorts against the prints around it. Absent on a record written before the field existed.",
        "constraints": {"ge": 0},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "side",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 8},
    },
    {
        "name": "order_type",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "tif",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 8},
    },
    {
        "name": "qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "",
    },
    {
        "name": "price",
        "type": "float",
        "unit": "display_price",
        "required": False,
        "doc": "Absent for a MARKET order, which has no limit price.",
    },
    {
        "name": "stop_price",
        "type": "float",
        "unit": "display_price",
        "required": False,
        "doc": "STOP / STOP_LIMIT / TRAILING_STOP trigger. Absent for a type that carries none.",
    },
    {
        "name": "visible_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "ICEBERG: fixed peak size. Absent for a type that carries none.",
    },
    {
        "name": "trail_offset",
        "type": "float",
        "unit": "display_price",
        "required": False,
        "doc": "TRAILING_STOP: trail distance, in display money. Absent for a type that carries none.",
    },
    {
        "name": "smp_action",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "Self-match prevention. Null means the client did not specify SMP at all, distinct from an explicit NONE. See SmpAction's docstring.",
        "values": _ORDER_ACK_SMP_ACTION_VALUES,
    },
    {
        "name": "client_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "request_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client correlation tag for this request, echoed on the resulting event or rejection. Distinct from the target order's client_tag, which identifies the order rather than the request acting on it. A client may have several requests outstanding against one order.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "request",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "Which request this ack answers: a new order (accepted or refused), or a cancel or amend the engine refused (an accepted cancel or amend is answered by order.cancelled or order.amended instead). A refused CANCEL or AMEND leaves the order it targets as it was, still resting; only a refused NEW order ends as REJECTED. request_tag cannot tell them apart, because a cancel or amend carries one only when the client set it. The engine sets this on every order.ack.",
        "values": _ORDER_ACK_REQUEST_VALUES,
    },
    {
        "name": "oco_group_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "combo_parent_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "leg_index",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "",
    },
    {
        "name": "is_seed",
        "type": "bool",
        "unit": None,
        "required": False,
        "doc": "True when this order was created by config-driven startup seeding rather than a live gateway submission. See OrderDisplay.is_seed (above) for the full rationale; this is the ack-time echo of the same fact. A seeded order has no order.new (the engine made it, no gateway sent it), so its order.ack is the first audit-visible event for it; a live order's order.new is echoed into the trail first.",
    },
    {
        "name": "tick_decimals",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "Decimal scale of the `*_ticks` prices in this message (1 tick = 10^-tick_decimals) -- the symbol's. Every message that carries a tick price carries its scale, so a reader of one line, or of a window of the trail that begins long after the book snapshot that declared it, can turn it into money without guessing. Absent when the message carries no tick price.",
        "constraints": {"ge": 0, "le": 9},
    },
    {
        "name": "price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "`price` in engine ticks. Canonical; the float beside it is for display. Scale: the symbol's tick_decimals.",
    },
    {
        "name": "stop_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "`stop_price` in engine ticks. Canonical; the float beside it is for display. Scale: the symbol's tick_decimals.",
    },
    {
        "name": "trail_offset_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "`trail_offset` in engine ticks. Canonical; the float beside it is for display. Scale: the symbol's tick_decimals.",
    },
)


@dataclass(frozen=True, slots=True)
class OrderAck:
    """Acknowledge acceptance or rejection of a new order, addressed to the gateway
    that submitted it.

    The order-detail fields are present only when the engine had the order to hand; on a
    rejection before lookup they are absent. reason is empty on an acceptance.
    """

    gateway_id: str
    order_id: str
    accepted: bool
    reason: str = ""
    reject_code: OrderAckRejectCode | None = None
    ts_ns: int | None = None  # unit: epoch_nanos
    symbol: str | None = None
    side: str | None = None
    order_type: str | None = None
    tif: str | None = None
    qty: int | None = None  # unit: shares
    price: float | None = None  # unit: display_price
    stop_price: float | None = None  # unit: display_price
    visible_qty: int | None = None  # unit: shares
    trail_offset: float | None = None  # unit: display_price
    smp_action: OrderAckSmpAction | None = None
    client_tag: str | None = None
    request_tag: str | None = None
    request: OrderAckRequest | None = None
    oco_group_id: str | None = None
    combo_parent_id: str | None = None
    quote_id: str | None = None
    leg_index: int | None = None  # unit: dimensionless
    is_seed: bool = False
    tick_decimals: int | None = None  # unit: dimensionless
    price_ticks: int | None = None  # unit: ticks
    stop_price_ticks: int | None = None  # unit: ticks
    trail_offset_ticks: int | None = None  # unit: ticks

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if len(self.reason) > 256:
            raise MessageValidationError(
                f"reason: length {len(self.reason)} exceeds max_len 256"
            )
        if self.reject_code is not None:
            if self.reject_code not in _ORDER_ACK_REJECT_CODE_VALUES:
                raise MessageValidationError(
                    f"reject_code: {self.reject_code!r} is not one of {_ORDER_ACK_REJECT_CODE_VALUES!r}"
                )
        if self.ts_ns is not None:
            if self.ts_ns < 0:
                raise MessageValidationError(f"ts_ns: {self.ts_ns!r} must be >= 0")
        if self.symbol is not None:
            if len(self.symbol) > 16:
                raise MessageValidationError(
                    f"symbol: length {len(self.symbol)} exceeds max_len 16"
                )
        if self.side is not None:
            if len(self.side) > 8:
                raise MessageValidationError(
                    f"side: length {len(self.side)} exceeds max_len 8"
                )
        if self.order_type is not None:
            if len(self.order_type) > 16:
                raise MessageValidationError(
                    f"order_type: length {len(self.order_type)} exceeds max_len 16"
                )
        if self.tif is not None:
            if len(self.tif) > 8:
                raise MessageValidationError(
                    f"tif: length {len(self.tif)} exceeds max_len 8"
                )
        if self.smp_action is not None:
            if self.smp_action not in _ORDER_ACK_SMP_ACTION_VALUES:
                raise MessageValidationError(
                    f"smp_action: {self.smp_action!r} is not one of {_ORDER_ACK_SMP_ACTION_VALUES!r}"
                )
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )
        if self.request_tag is not None:
            if len(self.request_tag) > 64:
                raise MessageValidationError(
                    f"request_tag: length {len(self.request_tag)} exceeds max_len 64"
                )
        if self.request is not None:
            if self.request not in _ORDER_ACK_REQUEST_VALUES:
                raise MessageValidationError(
                    f"request: {self.request!r} is not one of {_ORDER_ACK_REQUEST_VALUES!r}"
                )
        if self.oco_group_id is not None:
            if len(self.oco_group_id) > 64:
                raise MessageValidationError(
                    f"oco_group_id: length {len(self.oco_group_id)} exceeds max_len 64"
                )
        if self.combo_parent_id is not None:
            if len(self.combo_parent_id) > 64:
                raise MessageValidationError(
                    f"combo_parent_id: length {len(self.combo_parent_id)} exceeds max_len 64"
                )
        if self.quote_id is not None:
            if len(self.quote_id) > 64:
                raise MessageValidationError(
                    f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
                )
        if self.tick_decimals is not None:
            if self.tick_decimals < 0:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be >= 0"
                )
            if self.tick_decimals > 9:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be <= 9"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderAck":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            order_id=str(p["order_id"]),
            accepted=bool(p["accepted"]),
            reason=str(p.get("reason", "")),
            reject_code=(
                None
                if p.get("reject_code") is None
                else cast(OrderAckRejectCode, str(p["reject_code"]))
            ),
            ts_ns=None if p.get("ts_ns") is None else int(p["ts_ns"]),
            symbol=None if p.get("symbol") is None else str(p["symbol"]),
            side=None if p.get("side") is None else str(p["side"]),
            order_type=None if p.get("order_type") is None else str(p["order_type"]),
            tif=None if p.get("tif") is None else str(p["tif"]),
            qty=None if p.get("qty") is None else int(p["qty"]),
            price=None if p.get("price") is None else float(p["price"]),
            stop_price=None if p.get("stop_price") is None else float(p["stop_price"]),
            visible_qty=None if p.get("visible_qty") is None else int(p["visible_qty"]),
            trail_offset=(
                None if p.get("trail_offset") is None else float(p["trail_offset"])
            ),
            smp_action=(
                None
                if p.get("smp_action") is None
                else cast(OrderAckSmpAction, str(p["smp_action"]))
            ),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
            request_tag=None if p.get("request_tag") is None else str(p["request_tag"]),
            request=(
                None
                if p.get("request") is None
                else cast(OrderAckRequest, str(p["request"]))
            ),
            oco_group_id=(
                None if p.get("oco_group_id") is None else str(p["oco_group_id"])
            ),
            combo_parent_id=(
                None if p.get("combo_parent_id") is None else str(p["combo_parent_id"])
            ),
            quote_id=None if p.get("quote_id") is None else str(p["quote_id"]),
            leg_index=None if p.get("leg_index") is None else int(p["leg_index"]),
            is_seed=bool(p.get("is_seed", False)),
            tick_decimals=(
                None if p.get("tick_decimals") is None else int(p["tick_decimals"])
            ),
            price_ticks=None if p.get("price_ticks") is None else int(p["price_ticks"]),
            stop_price_ticks=(
                None
                if p.get("stop_price_ticks") is None
                else int(p["stop_price_ticks"])
            ),
            trail_offset_ticks=(
                None
                if p.get("trail_offset_ticks") is None
                else int(p["trail_offset_ticks"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
            "accepted": self.accepted,
            "reason": self.reason,
            "is_seed": self.is_seed,
        }
        if self.reject_code is not None:
            payload["reject_code"] = self.reject_code
        if self.ts_ns is not None:
            payload["ts_ns"] = self.ts_ns
        if self.symbol is not None:
            payload["symbol"] = self.symbol
        if self.side is not None:
            payload["side"] = self.side
        if self.order_type is not None:
            payload["order_type"] = self.order_type
        if self.tif is not None:
            payload["tif"] = self.tif
        if self.qty is not None:
            payload["qty"] = self.qty
        if self.price is not None:
            payload["price"] = self.price
        if self.stop_price is not None:
            payload["stop_price"] = self.stop_price
        if self.visible_qty is not None:
            payload["visible_qty"] = self.visible_qty
        if self.trail_offset is not None:
            payload["trail_offset"] = self.trail_offset
        if self.smp_action is not None:
            payload["smp_action"] = self.smp_action
        if self.client_tag is not None:
            payload["client_tag"] = self.client_tag
        if self.request_tag is not None:
            payload["request_tag"] = self.request_tag
        if self.request is not None:
            payload["request"] = self.request
        if self.oco_group_id is not None:
            payload["oco_group_id"] = self.oco_group_id
        if self.combo_parent_id is not None:
            payload["combo_parent_id"] = self.combo_parent_id
        if self.quote_id is not None:
            payload["quote_id"] = self.quote_id
        if self.leg_index is not None:
            payload["leg_index"] = self.leg_index
        if self.tick_decimals is not None:
            payload["tick_decimals"] = self.tick_decimals
        if self.price_ticks is not None:
            payload["price_ticks"] = self.price_ticks
        if self.stop_price_ticks is not None:
            payload["stop_price_ticks"] = self.stop_price_ticks
        if self.trail_offset_ticks is not None:
            payload["trail_offset_ticks"] = self.trail_offset_ticks
        return payload


def topic_order_ack(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"order.ack.{gateway_id}"


def match_order_ack(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _ORDER_ACK_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_order_ack(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderAck.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_order_ack(obj.gateway_id), obj.to_dict())


def make_order_ack_unchecked(
    *,
    gateway_id: str,
    order_id: str,
    accepted: bool,
    reason: str = "",
    reject_code: OrderAckRejectCode | None = None,
    ts_ns: int | None = None,
    symbol: str | None = None,
    side: str | None = None,
    order_type: str | None = None,
    tif: str | None = None,
    qty: int | None = None,
    price: float | None = None,
    stop_price: float | None = None,
    visible_qty: int | None = None,
    trail_offset: float | None = None,
    smp_action: OrderAckSmpAction | None = None,
    client_tag: str | None = None,
    request_tag: str | None = None,
    request: OrderAckRequest | None = None,
    oco_group_id: str | None = None,
    combo_parent_id: str | None = None,
    quote_id: str | None = None,
    leg_index: int | None = None,
    is_seed: bool = False,
    tick_decimals: int | None = None,
    price_ticks: int | None = None,
    stop_price_ticks: int | None = None,
    trail_offset_ticks: int | None = None,
) -> list[bytes]:
    """Identical frames to ``make_order_ack``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "order_id": str(order_id),
        "accepted": bool(accepted),
        "reason": str(reason),
        "is_seed": bool(is_seed),
    }
    if reject_code is not None:
        payload["reject_code"] = str(reject_code)
    if ts_ns is not None:
        payload["ts_ns"] = int(ts_ns)
    if symbol is not None:
        payload["symbol"] = str(symbol)
    if side is not None:
        payload["side"] = str(side)
    if order_type is not None:
        payload["order_type"] = str(order_type)
    if tif is not None:
        payload["tif"] = str(tif)
    if qty is not None:
        payload["qty"] = int(qty)
    if price is not None:
        payload["price"] = float(price)
    if stop_price is not None:
        payload["stop_price"] = float(stop_price)
    if visible_qty is not None:
        payload["visible_qty"] = int(visible_qty)
    if trail_offset is not None:
        payload["trail_offset"] = float(trail_offset)
    if smp_action is not None:
        payload["smp_action"] = str(smp_action)
    if client_tag is not None:
        payload["client_tag"] = str(client_tag)
    if request_tag is not None:
        payload["request_tag"] = str(request_tag)
    if request is not None:
        payload["request"] = str(request)
    if oco_group_id is not None:
        payload["oco_group_id"] = str(oco_group_id)
    if combo_parent_id is not None:
        payload["combo_parent_id"] = str(combo_parent_id)
    if quote_id is not None:
        payload["quote_id"] = str(quote_id)
    if leg_index is not None:
        payload["leg_index"] = int(leg_index)
    if tick_decimals is not None:
        payload["tick_decimals"] = int(tick_decimals)
    if price_ticks is not None:
        payload["price_ticks"] = int(price_ticks)
    if stop_price_ticks is not None:
        payload["stop_price_ticks"] = int(stop_price_ticks)
    if trail_offset_ticks is not None:
        payload["trail_offset_ticks"] = int(trail_offset_ticks)
    return [
        topic_order_ack(gateway_id).encode(),
        _msg.dumps(payload),
    ]


def parse_order_ack(frames: list[bytes]) -> "OrderAck":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_order_ack(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_ORDER_ACK!r}")
    payload = {**payload, "gateway_id": matched}
    obj = OrderAck.from_dict(payload)
    obj.validate()
    return obj


def describe_order_ack() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_ACK_FIELDS


TOPIC_ORDER_FILL = "order.fill.{gateway_id}"
PREFIX_ORDER_FILL = "order.fill."
_ORDER_FILL_RE = re.compile("order\\.fill\\.(?P<gateway_id>[^.]+)")
_ORDER_FILL_STATUS_VALUES = ("PARTIAL", "FILLED")
OrderFillStatus = Literal["PARTIAL", "FILLED"]
_ORDER_FILL_LIQUIDITY_FLAG_VALUES = ("MAKER", "TAKER", "AUCTION")
OrderFillLiquidityFlag = Literal["MAKER", "TAKER", "AUCTION"]


_ORDER_FILL_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "order_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "fill_qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "",
    },
    {
        "name": "fill_price",
        "type": "float",
        "unit": "display_price",
        "required": True,
        "doc": "",
    },
    {
        "name": "remaining_qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "",
    },
    {
        "name": "status",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "Whether this fill completed the order. The same two values BALF's execution_report uses, and the same vocabulary as order.new.status - there is one name for an order state across the system. This was the only status field the spec left as an unconstrained string, and it drifted: six publish sites derived the value from OrderStatus and sent PARTIAL while the continuous-matching hot path and _publish_amend_rematch sent PARTIAL_FILL, so a fill on a quote leg reported a different status from a fill on an ordinary order. Nothing in the system ever branched on PARTIAL_FILL - every consumer passed it through - so the two outliers were corrected rather than the six. BREAKING for anything matching the string: the ALF FILL line, the REST order cache and a bot written against docs-design/EduMatcher-AI-trading-bot-v2.md all carried PARTIAL_FILL verbatim. Nothing reads the old spelling any more, pm-audit-replay included - a log containing it does not describe a wire this build speaks.",
        "values": _ORDER_FILL_STATUS_VALUES,
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "side",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 8},
    },
    {
        "name": "order_type",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "tif",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 8},
    },
    {
        "name": "qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "",
    },
    {
        "name": "price",
        "type": "float",
        "unit": "display_price",
        "required": False,
        "doc": "",
    },
    {
        "name": "client_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "oco_group_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "combo_parent_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "leg_index",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "",
    },
    {
        "name": "is_seed",
        "type": "bool",
        "unit": None,
        "required": False,
        "doc": "True when this order was created by config-driven startup seeding rather than a live gateway submission. See OrderDisplay.is_seed for the full rationale; carried here too so a fill reached after the originating order.ack has rotated out of the audit log still says whether the filled order was a config seed.",
    },
    {
        "name": "ts_ns",
        "type": "int",
        "unit": "epoch_nanos",
        "required": False,
        "doc": "The match time of the trade behind this fill, in Unix epoch nanoseconds: identical to trade.executed.ts_ns (the last trade, when a sweep was coalesced into one fill). A fill and the print it reports carry one clock read. Absent on a record written before the field existed.",
        "constraints": {"ge": 0},
    },
    {
        "name": "trade_ids",
        "type": "list",
        "unit": None,
        "required": False,
        "doc": "The public trade.executed id(s) that composed this fill event. Usually one; more than one when an aggressor swept several resting orders and the engine coalesced them into a single VWAP fill (H5/H6). Every current call site only publishes order_fill from a real trade, so in practice this is never empty; it is typed as a list (not required) defensively, for a fill notification that might one day exist without one. Lets a reader link a private fill to the public trade tape without re-deriving the join.",
    },
    {
        "name": "liquidity_flag",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "Derived from the trade's aggressor side: the aggressor is the TAKER and the resting side the MAKER; both sides of an uncross print are AUCTION (same derivation as drop_copy.yaml::liquidity_flag). Nullable/omit_when_none for the same reason trade_ids is typed as an empty-able list: every current call site only publishes order_fill from a real trade, so this is never actually absent today, but nothing enforces that a future fill notification always has a trade behind it.",
        "values": _ORDER_FILL_LIQUIDITY_FLAG_VALUES,
    },
    {
        "name": "fill_notional_ticks",
        "type": "int",
        "unit": "notional_ticks",
        "required": False,
        "doc": "Σ price_ticks × quantity of the trades in `trade_ids`: the fill's money exactly (`fill_price` is its VWAP, rounded for display).",
        "constraints": {"ge": 0},
    },
    {
        "name": "cum_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "Quantity the order has filled in all, this fill included.",
        "constraints": {"ge": 0},
    },
    {
        "name": "cum_notional_ticks",
        "type": "int",
        "unit": "notional_ticks",
        "required": False,
        "doc": "Σ price_ticks × quantity of every fill of the order so far; with `cum_qty`, the exact average price.",
        "constraints": {"ge": 0},
    },
)


@dataclass(frozen=True, slots=True)
class OrderFill:
    """Private fill notification for one order, addressed to the gateway that owns
    it. The public counterpart is trade.executed.
    """

    gateway_id: str
    order_id: str
    fill_qty: int  # unit: shares
    fill_price: float  # unit: display_price
    remaining_qty: int  # unit: shares
    status: OrderFillStatus
    symbol: str | None = None
    side: str | None = None
    order_type: str | None = None
    tif: str | None = None
    qty: int | None = None  # unit: shares
    price: float | None = None  # unit: display_price
    client_tag: str | None = None
    oco_group_id: str | None = None
    combo_parent_id: str | None = None
    quote_id: str | None = None
    leg_index: int | None = None  # unit: dimensionless
    is_seed: bool = False
    ts_ns: int | None = None  # unit: epoch_nanos
    trade_ids: list[str] = field(default_factory=list)
    liquidity_flag: OrderFillLiquidityFlag | None = None
    fill_notional_ticks: int | None = None  # unit: notional_ticks
    cum_qty: int | None = None  # unit: shares
    cum_notional_ticks: int | None = None  # unit: notional_ticks

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if self.status not in _ORDER_FILL_STATUS_VALUES:
            raise MessageValidationError(
                f"status: {self.status!r} is not one of {_ORDER_FILL_STATUS_VALUES!r}"
            )
        if self.symbol is not None:
            if len(self.symbol) > 16:
                raise MessageValidationError(
                    f"symbol: length {len(self.symbol)} exceeds max_len 16"
                )
        if self.side is not None:
            if len(self.side) > 8:
                raise MessageValidationError(
                    f"side: length {len(self.side)} exceeds max_len 8"
                )
        if self.order_type is not None:
            if len(self.order_type) > 16:
                raise MessageValidationError(
                    f"order_type: length {len(self.order_type)} exceeds max_len 16"
                )
        if self.tif is not None:
            if len(self.tif) > 8:
                raise MessageValidationError(
                    f"tif: length {len(self.tif)} exceeds max_len 8"
                )
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )
        if self.oco_group_id is not None:
            if len(self.oco_group_id) > 64:
                raise MessageValidationError(
                    f"oco_group_id: length {len(self.oco_group_id)} exceeds max_len 64"
                )
        if self.combo_parent_id is not None:
            if len(self.combo_parent_id) > 64:
                raise MessageValidationError(
                    f"combo_parent_id: length {len(self.combo_parent_id)} exceeds max_len 64"
                )
        if self.quote_id is not None:
            if len(self.quote_id) > 64:
                raise MessageValidationError(
                    f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
                )
        if self.ts_ns is not None:
            if self.ts_ns < 0:
                raise MessageValidationError(f"ts_ns: {self.ts_ns!r} must be >= 0")
        if self.liquidity_flag is not None:
            if self.liquidity_flag not in _ORDER_FILL_LIQUIDITY_FLAG_VALUES:
                raise MessageValidationError(
                    f"liquidity_flag: {self.liquidity_flag!r} is not one of {_ORDER_FILL_LIQUIDITY_FLAG_VALUES!r}"
                )
        if self.fill_notional_ticks is not None:
            if self.fill_notional_ticks < 0:
                raise MessageValidationError(
                    f"fill_notional_ticks: {self.fill_notional_ticks!r} must be >= 0"
                )
        if self.cum_qty is not None:
            if self.cum_qty < 0:
                raise MessageValidationError(f"cum_qty: {self.cum_qty!r} must be >= 0")
        if self.cum_notional_ticks is not None:
            if self.cum_notional_ticks < 0:
                raise MessageValidationError(
                    f"cum_notional_ticks: {self.cum_notional_ticks!r} must be >= 0"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderFill":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            order_id=str(p["order_id"]),
            fill_qty=int(p["fill_qty"]),
            fill_price=float(p["fill_price"]),
            remaining_qty=int(p["remaining_qty"]),
            status=cast(OrderFillStatus, str(p["status"])),
            symbol=None if p.get("symbol") is None else str(p["symbol"]),
            side=None if p.get("side") is None else str(p["side"]),
            order_type=None if p.get("order_type") is None else str(p["order_type"]),
            tif=None if p.get("tif") is None else str(p["tif"]),
            qty=None if p.get("qty") is None else int(p["qty"]),
            price=None if p.get("price") is None else float(p["price"]),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
            oco_group_id=(
                None if p.get("oco_group_id") is None else str(p["oco_group_id"])
            ),
            combo_parent_id=(
                None if p.get("combo_parent_id") is None else str(p["combo_parent_id"])
            ),
            quote_id=None if p.get("quote_id") is None else str(p["quote_id"]),
            leg_index=None if p.get("leg_index") is None else int(p["leg_index"]),
            is_seed=bool(p.get("is_seed", False)),
            ts_ns=None if p.get("ts_ns") is None else int(p["ts_ns"]),
            trade_ids=[str(item) for item in p.get("trade_ids", [])],
            liquidity_flag=(
                None
                if p.get("liquidity_flag") is None
                else cast(OrderFillLiquidityFlag, str(p["liquidity_flag"]))
            ),
            fill_notional_ticks=(
                None
                if p.get("fill_notional_ticks") is None
                else int(p["fill_notional_ticks"])
            ),
            cum_qty=None if p.get("cum_qty") is None else int(p["cum_qty"]),
            cum_notional_ticks=(
                None
                if p.get("cum_notional_ticks") is None
                else int(p["cum_notional_ticks"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
            "fill_qty": self.fill_qty,
            "fill_price": self.fill_price,
            "remaining_qty": self.remaining_qty,
            "status": self.status,
            "is_seed": self.is_seed,
            "trade_ids": self.trade_ids,
        }
        if self.symbol is not None:
            payload["symbol"] = self.symbol
        if self.side is not None:
            payload["side"] = self.side
        if self.order_type is not None:
            payload["order_type"] = self.order_type
        if self.tif is not None:
            payload["tif"] = self.tif
        if self.qty is not None:
            payload["qty"] = self.qty
        if self.price is not None:
            payload["price"] = self.price
        if self.client_tag is not None:
            payload["client_tag"] = self.client_tag
        if self.oco_group_id is not None:
            payload["oco_group_id"] = self.oco_group_id
        if self.combo_parent_id is not None:
            payload["combo_parent_id"] = self.combo_parent_id
        if self.quote_id is not None:
            payload["quote_id"] = self.quote_id
        if self.leg_index is not None:
            payload["leg_index"] = self.leg_index
        if self.ts_ns is not None:
            payload["ts_ns"] = self.ts_ns
        if self.liquidity_flag is not None:
            payload["liquidity_flag"] = self.liquidity_flag
        if self.fill_notional_ticks is not None:
            payload["fill_notional_ticks"] = self.fill_notional_ticks
        if self.cum_qty is not None:
            payload["cum_qty"] = self.cum_qty
        if self.cum_notional_ticks is not None:
            payload["cum_notional_ticks"] = self.cum_notional_ticks
        return payload


def topic_order_fill(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"order.fill.{gateway_id}"


def match_order_fill(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _ORDER_FILL_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_order_fill(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderFill.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_order_fill(obj.gateway_id), obj.to_dict())


def make_order_fill_unchecked(
    *,
    gateway_id: str,
    order_id: str,
    fill_qty: int,
    fill_price: float,
    remaining_qty: int,
    status: OrderFillStatus,
    symbol: str | None = None,
    side: str | None = None,
    order_type: str | None = None,
    tif: str | None = None,
    qty: int | None = None,
    price: float | None = None,
    client_tag: str | None = None,
    oco_group_id: str | None = None,
    combo_parent_id: str | None = None,
    quote_id: str | None = None,
    leg_index: int | None = None,
    is_seed: bool = False,
    ts_ns: int | None = None,
    trade_ids: list[str] = [],
    liquidity_flag: OrderFillLiquidityFlag | None = None,
    fill_notional_ticks: int | None = None,
    cum_qty: int | None = None,
    cum_notional_ticks: int | None = None,
) -> list[bytes]:
    """Identical frames to ``make_order_fill``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "order_id": str(order_id),
        "fill_qty": int(fill_qty),
        "fill_price": float(fill_price),
        "remaining_qty": int(remaining_qty),
        "status": str(status),
        "is_seed": bool(is_seed),
        "trade_ids": [str(item) for item in trade_ids],
    }
    if symbol is not None:
        payload["symbol"] = str(symbol)
    if side is not None:
        payload["side"] = str(side)
    if order_type is not None:
        payload["order_type"] = str(order_type)
    if tif is not None:
        payload["tif"] = str(tif)
    if qty is not None:
        payload["qty"] = int(qty)
    if price is not None:
        payload["price"] = float(price)
    if client_tag is not None:
        payload["client_tag"] = str(client_tag)
    if oco_group_id is not None:
        payload["oco_group_id"] = str(oco_group_id)
    if combo_parent_id is not None:
        payload["combo_parent_id"] = str(combo_parent_id)
    if quote_id is not None:
        payload["quote_id"] = str(quote_id)
    if leg_index is not None:
        payload["leg_index"] = int(leg_index)
    if ts_ns is not None:
        payload["ts_ns"] = int(ts_ns)
    if liquidity_flag is not None:
        payload["liquidity_flag"] = str(liquidity_flag)
    if fill_notional_ticks is not None:
        payload["fill_notional_ticks"] = int(fill_notional_ticks)
    if cum_qty is not None:
        payload["cum_qty"] = int(cum_qty)
    if cum_notional_ticks is not None:
        payload["cum_notional_ticks"] = int(cum_notional_ticks)
    return [
        topic_order_fill(gateway_id).encode(),
        _msg.dumps(payload),
    ]


def parse_order_fill(frames: list[bytes]) -> "OrderFill":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_order_fill(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_ORDER_FILL!r}")
    payload = {**payload, "gateway_id": matched}
    obj = OrderFill.from_dict(payload)
    obj.validate()
    return obj


def describe_order_fill() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_FILL_FIELDS


TOPIC_ORDER_CANCELLED = "order.cancelled.{gateway_id}"
PREFIX_ORDER_CANCELLED = "order.cancelled."
_ORDER_CANCELLED_RE = re.compile("order\\.cancelled\\.(?P<gateway_id>[^.]+)")
_ORDER_CANCELLED_CANCEL_REASON_VALUES = (
    "SELF_MATCH_PREVENTED",
    "INSUFFICIENT_LIQUIDITY",
    "KILL_SWITCH",
    "CIRCUIT_BREAKER_HALT",
    "GATEWAY_DISCONNECT",
    "ADMIN_CANCEL_SYMBOL",
    "QUOTE_REPLACED",
    "QUOTE_LEG_FILLED",
)
OrderCancelledCancelReason = Literal[
    "SELF_MATCH_PREVENTED",
    "INSUFFICIENT_LIQUIDITY",
    "KILL_SWITCH",
    "CIRCUIT_BREAKER_HALT",
    "GATEWAY_DISCONNECT",
    "ADMIN_CANCEL_SYMBOL",
    "QUOTE_REPLACED",
    "QUOTE_LEG_FILLED",
]


_ORDER_CANCELLED_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "order_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Instrument this order belonged to. The engine has always had this at the publish site (the cancelled Order's own .symbol); it was simply never carried on the wire, which made order.cancelled invisible to a --symbol filter (AR-0.2). Nullable/omit_when_none, like old_price/old_qty on order.amended below, so archived records written before this field existed still parse.",
        "constraints": {"max_len": 16},
    },
    {
        "name": "client_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "request_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client correlation tag for this cancel request. Engine-initiated cancels publish with request_tag=null.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "cancel_reason",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": 'Why the exchange cancelled this order, when the exchange decided it rather than the client. Null for a client-requested cancel, and for engine-initiated cancels whose cause is not yet classified - so request_tag=null together with cancel_reason=null still means "the exchange did this, cause unstated". Deliberately not the same vocabulary as order_ack.reject_code: a cancel is not a rejection, and most reject codes can never apply to one. New members may be added; existing members are never removed or renamed. A client must ignore a value it does not recognise.',
        "values": _ORDER_CANCELLED_CANCEL_REASON_VALUES,
    },
    {
        "name": "oco_group_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "combo_parent_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "leg_index",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "",
    },
    {
        "name": "command_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The admin/kill-switch command_id (see system.admin_action) that caused this cancel, when one exists — lets a post-mortem join this event back to the exact command that triggered it. Null for a client-requested cancel and for engine-initiated cancels with no originating command (e.g. self-match prevention, insufficient liquidity, a quote leg cancelled because its sibling filled).",
        "constraints": {"max_len": 64},
    },
    {
        "name": "remaining_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "Quantity left unfilled when the order was cancelled.",
        "constraints": {"ge": 0},
    },
    {
        "name": "cum_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "Quantity the order had filled before it was cancelled.",
        "constraints": {"ge": 0},
    },
)


@dataclass(frozen=True, slots=True)
class OrderCancelled:
    """Confirm that a resting order has been cancelled."""

    gateway_id: str
    order_id: str
    symbol: str | None = None
    client_tag: str | None = None
    request_tag: str | None = None
    cancel_reason: OrderCancelledCancelReason | None = None
    oco_group_id: str | None = None
    combo_parent_id: str | None = None
    quote_id: str | None = None
    leg_index: int | None = None  # unit: dimensionless
    command_id: str | None = None
    remaining_qty: int | None = None  # unit: shares
    cum_qty: int | None = None  # unit: shares

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if self.symbol is not None:
            if len(self.symbol) > 16:
                raise MessageValidationError(
                    f"symbol: length {len(self.symbol)} exceeds max_len 16"
                )
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )
        if self.request_tag is not None:
            if len(self.request_tag) > 64:
                raise MessageValidationError(
                    f"request_tag: length {len(self.request_tag)} exceeds max_len 64"
                )
        if self.cancel_reason is not None:
            if self.cancel_reason not in _ORDER_CANCELLED_CANCEL_REASON_VALUES:
                raise MessageValidationError(
                    f"cancel_reason: {self.cancel_reason!r} is not one of {_ORDER_CANCELLED_CANCEL_REASON_VALUES!r}"
                )
        if self.oco_group_id is not None:
            if len(self.oco_group_id) > 64:
                raise MessageValidationError(
                    f"oco_group_id: length {len(self.oco_group_id)} exceeds max_len 64"
                )
        if self.combo_parent_id is not None:
            if len(self.combo_parent_id) > 64:
                raise MessageValidationError(
                    f"combo_parent_id: length {len(self.combo_parent_id)} exceeds max_len 64"
                )
        if self.quote_id is not None:
            if len(self.quote_id) > 64:
                raise MessageValidationError(
                    f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
                )
        if self.command_id is not None:
            if len(self.command_id) > 64:
                raise MessageValidationError(
                    f"command_id: length {len(self.command_id)} exceeds max_len 64"
                )
        if self.remaining_qty is not None:
            if self.remaining_qty < 0:
                raise MessageValidationError(
                    f"remaining_qty: {self.remaining_qty!r} must be >= 0"
                )
        if self.cum_qty is not None:
            if self.cum_qty < 0:
                raise MessageValidationError(f"cum_qty: {self.cum_qty!r} must be >= 0")

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderCancelled":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            order_id=str(p["order_id"]),
            symbol=None if p.get("symbol") is None else str(p["symbol"]),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
            request_tag=None if p.get("request_tag") is None else str(p["request_tag"]),
            cancel_reason=(
                None
                if p.get("cancel_reason") is None
                else cast(OrderCancelledCancelReason, str(p["cancel_reason"]))
            ),
            oco_group_id=(
                None if p.get("oco_group_id") is None else str(p["oco_group_id"])
            ),
            combo_parent_id=(
                None if p.get("combo_parent_id") is None else str(p["combo_parent_id"])
            ),
            quote_id=None if p.get("quote_id") is None else str(p["quote_id"]),
            leg_index=None if p.get("leg_index") is None else int(p["leg_index"]),
            command_id=None if p.get("command_id") is None else str(p["command_id"]),
            remaining_qty=(
                None if p.get("remaining_qty") is None else int(p["remaining_qty"])
            ),
            cum_qty=None if p.get("cum_qty") is None else int(p["cum_qty"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
        }
        if self.symbol is not None:
            payload["symbol"] = self.symbol
        if self.client_tag is not None:
            payload["client_tag"] = self.client_tag
        if self.request_tag is not None:
            payload["request_tag"] = self.request_tag
        if self.cancel_reason is not None:
            payload["cancel_reason"] = self.cancel_reason
        if self.oco_group_id is not None:
            payload["oco_group_id"] = self.oco_group_id
        if self.combo_parent_id is not None:
            payload["combo_parent_id"] = self.combo_parent_id
        if self.quote_id is not None:
            payload["quote_id"] = self.quote_id
        if self.leg_index is not None:
            payload["leg_index"] = self.leg_index
        if self.command_id is not None:
            payload["command_id"] = self.command_id
        if self.remaining_qty is not None:
            payload["remaining_qty"] = self.remaining_qty
        if self.cum_qty is not None:
            payload["cum_qty"] = self.cum_qty
        return payload


def topic_order_cancelled(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"order.cancelled.{gateway_id}"


def match_order_cancelled(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _ORDER_CANCELLED_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_order_cancelled(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderCancelled.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_order_cancelled(obj.gateway_id), obj.to_dict())


def make_order_cancelled_unchecked(
    *,
    gateway_id: str,
    order_id: str,
    symbol: str | None = None,
    client_tag: str | None = None,
    request_tag: str | None = None,
    cancel_reason: OrderCancelledCancelReason | None = None,
    oco_group_id: str | None = None,
    combo_parent_id: str | None = None,
    quote_id: str | None = None,
    leg_index: int | None = None,
    command_id: str | None = None,
    remaining_qty: int | None = None,
    cum_qty: int | None = None,
) -> list[bytes]:
    """Identical frames to ``make_order_cancelled``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "order_id": str(order_id),
    }
    if symbol is not None:
        payload["symbol"] = str(symbol)
    if client_tag is not None:
        payload["client_tag"] = str(client_tag)
    if request_tag is not None:
        payload["request_tag"] = str(request_tag)
    if cancel_reason is not None:
        payload["cancel_reason"] = str(cancel_reason)
    if oco_group_id is not None:
        payload["oco_group_id"] = str(oco_group_id)
    if combo_parent_id is not None:
        payload["combo_parent_id"] = str(combo_parent_id)
    if quote_id is not None:
        payload["quote_id"] = str(quote_id)
    if leg_index is not None:
        payload["leg_index"] = int(leg_index)
    if command_id is not None:
        payload["command_id"] = str(command_id)
    if remaining_qty is not None:
        payload["remaining_qty"] = int(remaining_qty)
    if cum_qty is not None:
        payload["cum_qty"] = int(cum_qty)
    return [
        topic_order_cancelled(gateway_id).encode(),
        _msg.dumps(payload),
    ]


def parse_order_cancelled(frames: list[bytes]) -> "OrderCancelled":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_order_cancelled(topic)
    if matched is None:
        raise MessageValidationError(
            f"topic {topic!r} is not {TOPIC_ORDER_CANCELLED!r}"
        )
    payload = {**payload, "gateway_id": matched}
    obj = OrderCancelled.from_dict(payload)
    obj.validate()
    return obj


def describe_order_cancelled() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_CANCELLED_FIELDS


TOPIC_ORDER_EXPIRED = "order.expired.{gateway_id}"
PREFIX_ORDER_EXPIRED = "order.expired."
_ORDER_EXPIRED_RE = re.compile("order\\.expired\\.(?P<gateway_id>[^.]+)")


_ORDER_EXPIRED_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "order_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Instrument this order belonged to. Same AR-0.2 rationale as order.cancelled.symbol above - the engine already has it at the publish site, it was simply never carried.",
        "constraints": {"max_len": 16},
    },
    {
        "name": "client_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "oco_group_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "combo_parent_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "leg_index",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "",
    },
    {
        "name": "remaining_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "Quantity left unfilled when the order expired.",
        "constraints": {"ge": 0},
    },
    {
        "name": "cum_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "Quantity the order had filled before it expired.",
        "constraints": {"ge": 0},
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": 'Why the order expired: "Opening auction ended", "Closing auction ended", or "Trading day ended".',
    },
)


@dataclass(frozen=True, slots=True)
class OrderExpired:
    """An order has expired because its time-in-force window ended. The optional
    reason distinguishes auction-only expiry from end-of-day expiry while
    remaining compatible with existing consumers. A sweep publishes its orders in
    (gateway_id, order_id) order, per symbol book, so the sequence does not depend
    on how the book was built (arrival order live, price priority after a
    restart).
    """

    gateway_id: str
    order_id: str
    symbol: str | None = None
    client_tag: str | None = None
    oco_group_id: str | None = None
    combo_parent_id: str | None = None
    quote_id: str | None = None
    leg_index: int | None = None  # unit: dimensionless
    remaining_qty: int | None = None  # unit: shares
    cum_qty: int | None = None  # unit: shares
    reason: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if self.symbol is not None:
            if len(self.symbol) > 16:
                raise MessageValidationError(
                    f"symbol: length {len(self.symbol)} exceeds max_len 16"
                )
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )
        if self.oco_group_id is not None:
            if len(self.oco_group_id) > 64:
                raise MessageValidationError(
                    f"oco_group_id: length {len(self.oco_group_id)} exceeds max_len 64"
                )
        if self.combo_parent_id is not None:
            if len(self.combo_parent_id) > 64:
                raise MessageValidationError(
                    f"combo_parent_id: length {len(self.combo_parent_id)} exceeds max_len 64"
                )
        if self.quote_id is not None:
            if len(self.quote_id) > 64:
                raise MessageValidationError(
                    f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
                )
        if self.remaining_qty is not None:
            if self.remaining_qty < 0:
                raise MessageValidationError(
                    f"remaining_qty: {self.remaining_qty!r} must be >= 0"
                )
        if self.cum_qty is not None:
            if self.cum_qty < 0:
                raise MessageValidationError(f"cum_qty: {self.cum_qty!r} must be >= 0")

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderExpired":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            order_id=str(p["order_id"]),
            symbol=None if p.get("symbol") is None else str(p["symbol"]),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
            oco_group_id=(
                None if p.get("oco_group_id") is None else str(p["oco_group_id"])
            ),
            combo_parent_id=(
                None if p.get("combo_parent_id") is None else str(p["combo_parent_id"])
            ),
            quote_id=None if p.get("quote_id") is None else str(p["quote_id"]),
            leg_index=None if p.get("leg_index") is None else int(p["leg_index"]),
            remaining_qty=(
                None if p.get("remaining_qty") is None else int(p["remaining_qty"])
            ),
            cum_qty=None if p.get("cum_qty") is None else int(p["cum_qty"]),
            reason=None if p.get("reason") is None else str(p["reason"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
        }
        if self.symbol is not None:
            payload["symbol"] = self.symbol
        if self.client_tag is not None:
            payload["client_tag"] = self.client_tag
        if self.oco_group_id is not None:
            payload["oco_group_id"] = self.oco_group_id
        if self.combo_parent_id is not None:
            payload["combo_parent_id"] = self.combo_parent_id
        if self.quote_id is not None:
            payload["quote_id"] = self.quote_id
        if self.leg_index is not None:
            payload["leg_index"] = self.leg_index
        if self.remaining_qty is not None:
            payload["remaining_qty"] = self.remaining_qty
        if self.cum_qty is not None:
            payload["cum_qty"] = self.cum_qty
        if self.reason is not None:
            payload["reason"] = self.reason
        return payload


def topic_order_expired(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"order.expired.{gateway_id}"


def match_order_expired(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _ORDER_EXPIRED_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_order_expired(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderExpired.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_order_expired(obj.gateway_id), obj.to_dict())


def make_order_expired_unchecked(
    *,
    gateway_id: str,
    order_id: str,
    symbol: str | None = None,
    client_tag: str | None = None,
    oco_group_id: str | None = None,
    combo_parent_id: str | None = None,
    quote_id: str | None = None,
    leg_index: int | None = None,
    remaining_qty: int | None = None,
    cum_qty: int | None = None,
    reason: str | None = None,
) -> list[bytes]:
    """Identical frames to ``make_order_expired``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "order_id": str(order_id),
    }
    if symbol is not None:
        payload["symbol"] = str(symbol)
    if client_tag is not None:
        payload["client_tag"] = str(client_tag)
    if oco_group_id is not None:
        payload["oco_group_id"] = str(oco_group_id)
    if combo_parent_id is not None:
        payload["combo_parent_id"] = str(combo_parent_id)
    if quote_id is not None:
        payload["quote_id"] = str(quote_id)
    if leg_index is not None:
        payload["leg_index"] = int(leg_index)
    if remaining_qty is not None:
        payload["remaining_qty"] = int(remaining_qty)
    if cum_qty is not None:
        payload["cum_qty"] = int(cum_qty)
    if reason is not None:
        payload["reason"] = str(reason)
    return [
        topic_order_expired(gateway_id).encode(),
        _msg.dumps(payload),
    ]


def parse_order_expired(frames: list[bytes]) -> "OrderExpired":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_order_expired(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_ORDER_EXPIRED!r}")
    payload = {**payload, "gateway_id": matched}
    obj = OrderExpired.from_dict(payload)
    obj.validate()
    return obj


def describe_order_expired() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_EXPIRED_FIELDS


TOPIC_ORDER_TRIGGERED = "order.triggered.{gateway_id}"
PREFIX_ORDER_TRIGGERED = "order.triggered."
_ORDER_TRIGGERED_RE = re.compile("order\\.triggered\\.(?P<gateway_id>[^.]+)")
_ORDER_TRIGGERED_ORDER_TYPE_VALUES = ("STOP", "STOP_LIMIT", "TRAILING_STOP")
OrderTriggeredOrderType = Literal["STOP", "STOP_LIMIT", "TRAILING_STOP"]
_ORDER_TRIGGERED_BECOMES_VALUES = ("MARKET", "LIMIT")
OrderTriggeredBecomes = Literal["MARKET", "LIMIT"]


_ORDER_TRIGGERED_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "order_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "order_type",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "The order as it was armed.",
        "values": _ORDER_TRIGGERED_ORDER_TYPE_VALUES,
    },
    {
        "name": "tick_decimals",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "Decimal scale of the `*_ticks` prices in this message (1 tick = 10^-tick_decimals) -- the symbol's. Every message that carries a tick price carries its scale, so a reader of one line, or of a window of the trail that begins long after the book snapshot that declared it, can turn it into money without guessing. Absent when the message carries no tick price.",
        "constraints": {"ge": 0, "le": 9},
    },
    {
        "name": "stop_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": True,
        "doc": "The trigger price it fired at (a trailing stop's ratcheted one).",
    },
    {
        "name": "trigger_trade_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The trade that reached the trigger; absent when the last price came from a restart.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "trigger_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "That trade's price.",
    },
    {
        "name": "becomes",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "STOP and TRAILING_STOP become MARKET; STOP_LIMIT becomes LIMIT at its limit.",
        "values": _ORDER_TRIGGERED_BECOMES_VALUES,
    },
    {
        "name": "client_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class OrderTriggered:
    """A stop, stop-limit or trailing stop has fired: the trade that reached its
    trigger, and what the order became. Published before the order's own fills, so
    a client knows why its stop traded -- the FIX analogue is ExecType=L.
    """

    gateway_id: str
    order_id: str
    symbol: str
    order_type: OrderTriggeredOrderType
    stop_price_ticks: int  # unit: ticks
    becomes: OrderTriggeredBecomes
    tick_decimals: int | None = None  # unit: dimensionless
    trigger_trade_id: str | None = None
    trigger_price_ticks: int | None = None  # unit: ticks
    client_tag: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.order_type not in _ORDER_TRIGGERED_ORDER_TYPE_VALUES:
            raise MessageValidationError(
                f"order_type: {self.order_type!r} is not one of {_ORDER_TRIGGERED_ORDER_TYPE_VALUES!r}"
            )
        if self.tick_decimals is not None:
            if self.tick_decimals < 0:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be >= 0"
                )
            if self.tick_decimals > 9:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be <= 9"
                )
        if self.trigger_trade_id is not None:
            if len(self.trigger_trade_id) > 64:
                raise MessageValidationError(
                    f"trigger_trade_id: length {len(self.trigger_trade_id)} exceeds max_len 64"
                )
        if self.becomes not in _ORDER_TRIGGERED_BECOMES_VALUES:
            raise MessageValidationError(
                f"becomes: {self.becomes!r} is not one of {_ORDER_TRIGGERED_BECOMES_VALUES!r}"
            )
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderTriggered":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            order_id=str(p["order_id"]),
            symbol=str(p["symbol"]),
            order_type=cast(OrderTriggeredOrderType, str(p["order_type"])),
            tick_decimals=(
                None if p.get("tick_decimals") is None else int(p["tick_decimals"])
            ),
            stop_price_ticks=int(p["stop_price_ticks"]),
            trigger_trade_id=(
                None
                if p.get("trigger_trade_id") is None
                else str(p["trigger_trade_id"])
            ),
            trigger_price_ticks=(
                None
                if p.get("trigger_price_ticks") is None
                else int(p["trigger_price_ticks"])
            ),
            becomes=cast(OrderTriggeredBecomes, str(p["becomes"])),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
            "symbol": self.symbol,
            "order_type": self.order_type,
            "stop_price_ticks": self.stop_price_ticks,
            "becomes": self.becomes,
        }
        if self.tick_decimals is not None:
            payload["tick_decimals"] = self.tick_decimals
        if self.trigger_trade_id is not None:
            payload["trigger_trade_id"] = self.trigger_trade_id
        if self.trigger_price_ticks is not None:
            payload["trigger_price_ticks"] = self.trigger_price_ticks
        if self.client_tag is not None:
            payload["client_tag"] = self.client_tag
        return payload


def topic_order_triggered(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"order.triggered.{gateway_id}"


def match_order_triggered(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _ORDER_TRIGGERED_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_order_triggered(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderTriggered.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_order_triggered(obj.gateway_id), obj.to_dict())


def make_order_triggered_unchecked(
    *,
    gateway_id: str,
    order_id: str,
    symbol: str,
    order_type: OrderTriggeredOrderType,
    stop_price_ticks: int,
    becomes: OrderTriggeredBecomes,
    tick_decimals: int | None = None,
    trigger_trade_id: str | None = None,
    trigger_price_ticks: int | None = None,
    client_tag: str | None = None,
) -> list[bytes]:
    """Identical frames to ``make_order_triggered``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "order_id": str(order_id),
        "symbol": str(symbol),
        "order_type": str(order_type),
        "stop_price_ticks": int(stop_price_ticks),
        "becomes": str(becomes),
    }
    if tick_decimals is not None:
        payload["tick_decimals"] = int(tick_decimals)
    if trigger_trade_id is not None:
        payload["trigger_trade_id"] = str(trigger_trade_id)
    if trigger_price_ticks is not None:
        payload["trigger_price_ticks"] = int(trigger_price_ticks)
    if client_tag is not None:
        payload["client_tag"] = str(client_tag)
    return [
        topic_order_triggered(gateway_id).encode(),
        _msg.dumps(payload),
    ]


def parse_order_triggered(frames: list[bytes]) -> "OrderTriggered":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_order_triggered(topic)
    if matched is None:
        raise MessageValidationError(
            f"topic {topic!r} is not {TOPIC_ORDER_TRIGGERED!r}"
        )
    payload = {**payload, "gateway_id": matched}
    obj = OrderTriggered.from_dict(payload)
    obj.validate()
    return obj


def describe_order_triggered() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_TRIGGERED_FIELDS


TOPIC_ENGINE_TRACE = "engine.trace.{symbol}"
PREFIX_ENGINE_TRACE = "engine.trace."
_ENGINE_TRACE_RE = re.compile("engine\\.trace\\.(?P<symbol>[^.]+)")
_ENGINE_TRACE_KIND_VALUES = (
    "RESTED",
    "ICEBERG_REFILL",
    "TRAILING_RATCHET",
    "UNCROSS_PRICE",
    "AON_PREFLIGHT",
    "SMP_DECISION",
)
EngineTraceKind = Literal[
    "RESTED",
    "ICEBERG_REFILL",
    "TRAILING_RATCHET",
    "UNCROSS_PRICE",
    "AON_PREFLIGHT",
    "SMP_DECISION",
]
_ENGINE_TRACE_RULE_VALUES = ("VOLUME", "SURPLUS", "LOWEST_PRICE", "OVERRIDE")
EngineTraceRule = Literal["VOLUME", "SURPLUS", "LOWEST_PRICE", "OVERRIDE"]
_ENGINE_TRACE_OUTCOME_VALUES = ("MATCH", "REST", "REJECT")
EngineTraceOutcome = Literal["MATCH", "REST", "REJECT"]
_ENGINE_TRACE_SMP_ACTION_VALUES = ("CANCEL_AGGRESSOR", "CANCEL_RESTING", "CANCEL_BOTH")
EngineTraceSmpAction = Literal["CANCEL_AGGRESSOR", "CANCEL_RESTING", "CANCEL_BOTH"]


_ENGINE_TRACE_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "kind",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "",
        "values": _ENGINE_TRACE_KIND_VALUES,
    },
    {
        "name": "order_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The order the record is about; SMP_DECISION: the order whose policy applied (the aggressor; in an uncross the bid, unless only the ask has a policy).",
        "constraints": {"max_len": 64},
    },
    {
        "name": "priority_seq",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "",
        "constraints": {"ge": 0},
    },
    {
        "name": "displayed_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "ICEBERG_REFILL: the new visible slice.",
        "constraints": {"ge": 0},
    },
    {
        "name": "tick_decimals",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "Decimal scale of the `*_ticks` prices in this message (1 tick = 10^-tick_decimals) -- the symbol's. Every message that carries a tick price carries its scale, so a reader of one line, or of a window of the trail that begins long after the book snapshot that declared it, can turn it into money without guessing. Absent when the message carries no tick price.",
        "constraints": {"ge": 0, "le": 9},
    },
    {
        "name": "stop_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "TRAILING_RATCHET: the new trigger.",
    },
    {
        "name": "last_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "TRAILING_RATCHET: the trade price that moved it.",
    },
    {
        "name": "auction_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "UNCROSS_PRICE: the uncross, as on its `auction.result`.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "eq_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "UNCROSS_PRICE: the price the uncross runs at (it prints nothing there when `eq_qty` is 0: SMP or an OCO pair took the whole overlap).",
    },
    {
        "name": "eq_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "UNCROSS_PRICE: the executable quantity at that price.",
        "constraints": {"ge": 0},
    },
    {
        "name": "surplus",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "UNCROSS_PRICE: the unmatched quantity at that price.",
        "constraints": {"ge": 0},
    },
    {
        "name": "rule",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "UNCROSS_PRICE: what decided -- the most volume (one price had it), then the least surplus among those, then the lowest price; OVERRIDE when the price was imposed (closing backstop, ADMIN_MANUAL).",
        "values": _ENGINE_TRACE_RULE_VALUES,
    },
    {
        "name": "tied_prices_ticks",
        "type": "list",
        "unit": None,
        "required": False,
        "doc": "UNCROSS_PRICE: the prices still tied when `rule` decided, lowest first (one price for VOLUME; the most-volume prices for SURPLUS; those with the least surplus too for LOWEST_PRICE). In ticks.",
    },
    {
        "name": "combo_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "AON_PREFLIGHT: the client's combo id.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "leg_index",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "AON_PREFLIGHT: the leg, in the combo's order.",
        "constraints": {"ge": 0},
    },
    {
        "name": "quantity",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "AON_PREFLIGHT: the leg's quantity.",
        "constraints": {"ge": 0},
    },
    {
        "name": "fillable_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "AON_PREFLIGHT: what the leg could fill now, the gateway's own orders left out under its SMP policy.",
        "constraints": {"ge": 0},
    },
    {
        "name": "fillable_no_smp_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "AON_PREFLIGHT: what the leg would trade now counting the gateway's own orders (more than 0 on a blocked combo is what rejects it).",
        "constraints": {"ge": 0},
    },
    {
        "name": "outcome",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "AON_PREFLIGHT: the combo's outcome, the same on every leg -- every leg fills in full and the legs match; a leg is short and the legs rest unmatched; or a leg is short and one would trade now, so the combo fails at its first leg (INSUFFICIENT_LIQUIDITY). Halted symbols and phases without matching rest.",
        "values": _ENGINE_TRACE_OUTCOME_VALUES,
    },
    {
        "name": "other_order_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "SMP_DECISION: the same gateway's order on the other side.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "smp_action",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "SMP_DECISION: the policy applied, of `order_id`'s order: which of the two was cancelled (both for CANCEL_BOTH). An unfillable FOK meets each same-gateway order in its range: one record each.",
        "values": _ENGINE_TRACE_SMP_ACTION_VALUES,
    },
)


@dataclass(frozen=True, slots=True)
class EngineTrace:
    """What the book did that no trade or order message shows, for the audit trail
    (no gateway forwards it): an order resting or arming and the place in the
    queue it got, an iceberg refilling its slice at the back of its level, a
    trailing stop ratcheting its trigger. A replay can then compare its model of
    priority and of trailing triggers with the engine's own, instead of inferring
    them. Three kinds say why the engine decided (S36): UNCROSS_PRICE (which rule
    chose an uncross's price, among which tied prices), AON_PREFLIGHT (per leg of
    an all-or-none combo, what could fill, and whether the combo matches, rests or
    is rejected) and SMP_DECISION (the same-gateway pair self-match prevention
    met, and the policy applied).

    `priority_seq` is the book's arrival sequence; it orders orders at one price,
    nothing more. A trailing stop rests in a list checked in arming order, so its RESTED
    has no `priority_seq`. UNCROSS_PRICE names no order; AON_PREFLIGHT names the combo
    and the leg, not an order (the leg's order does not exist yet).
    """

    symbol: str
    kind: EngineTraceKind
    order_id: str | None = None
    priority_seq: int | None = None  # unit: dimensionless
    displayed_qty: int | None = None  # unit: shares
    tick_decimals: int | None = None  # unit: dimensionless
    stop_price_ticks: int | None = None  # unit: ticks
    last_price_ticks: int | None = None  # unit: ticks
    auction_id: str | None = None
    eq_price_ticks: int | None = None  # unit: ticks
    eq_qty: int | None = None  # unit: shares
    surplus: int | None = None  # unit: shares
    rule: EngineTraceRule | None = None
    tied_prices_ticks: list[int] = field(default_factory=list)
    combo_id: str | None = None
    leg_index: int | None = None  # unit: dimensionless
    quantity: int | None = None  # unit: shares
    fillable_qty: int | None = None  # unit: shares
    fillable_no_smp_qty: int | None = None  # unit: shares
    outcome: EngineTraceOutcome | None = None
    other_order_id: str | None = None
    smp_action: EngineTraceSmpAction | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.kind not in _ENGINE_TRACE_KIND_VALUES:
            raise MessageValidationError(
                f"kind: {self.kind!r} is not one of {_ENGINE_TRACE_KIND_VALUES!r}"
            )
        if self.order_id is not None:
            if len(self.order_id) > 64:
                raise MessageValidationError(
                    f"order_id: length {len(self.order_id)} exceeds max_len 64"
                )
        if self.priority_seq is not None:
            if self.priority_seq < 0:
                raise MessageValidationError(
                    f"priority_seq: {self.priority_seq!r} must be >= 0"
                )
        if self.displayed_qty is not None:
            if self.displayed_qty < 0:
                raise MessageValidationError(
                    f"displayed_qty: {self.displayed_qty!r} must be >= 0"
                )
        if self.tick_decimals is not None:
            if self.tick_decimals < 0:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be >= 0"
                )
            if self.tick_decimals > 9:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be <= 9"
                )
        if self.auction_id is not None:
            if len(self.auction_id) > 32:
                raise MessageValidationError(
                    f"auction_id: length {len(self.auction_id)} exceeds max_len 32"
                )
        if self.eq_qty is not None:
            if self.eq_qty < 0:
                raise MessageValidationError(f"eq_qty: {self.eq_qty!r} must be >= 0")
        if self.surplus is not None:
            if self.surplus < 0:
                raise MessageValidationError(f"surplus: {self.surplus!r} must be >= 0")
        if self.rule is not None:
            if self.rule not in _ENGINE_TRACE_RULE_VALUES:
                raise MessageValidationError(
                    f"rule: {self.rule!r} is not one of {_ENGINE_TRACE_RULE_VALUES!r}"
                )
        if self.combo_id is not None:
            if len(self.combo_id) > 64:
                raise MessageValidationError(
                    f"combo_id: length {len(self.combo_id)} exceeds max_len 64"
                )
        if self.leg_index is not None:
            if self.leg_index < 0:
                raise MessageValidationError(
                    f"leg_index: {self.leg_index!r} must be >= 0"
                )
        if self.quantity is not None:
            if self.quantity < 0:
                raise MessageValidationError(
                    f"quantity: {self.quantity!r} must be >= 0"
                )
        if self.fillable_qty is not None:
            if self.fillable_qty < 0:
                raise MessageValidationError(
                    f"fillable_qty: {self.fillable_qty!r} must be >= 0"
                )
        if self.fillable_no_smp_qty is not None:
            if self.fillable_no_smp_qty < 0:
                raise MessageValidationError(
                    f"fillable_no_smp_qty: {self.fillable_no_smp_qty!r} must be >= 0"
                )
        if self.outcome is not None:
            if self.outcome not in _ENGINE_TRACE_OUTCOME_VALUES:
                raise MessageValidationError(
                    f"outcome: {self.outcome!r} is not one of {_ENGINE_TRACE_OUTCOME_VALUES!r}"
                )
        if self.other_order_id is not None:
            if len(self.other_order_id) > 64:
                raise MessageValidationError(
                    f"other_order_id: length {len(self.other_order_id)} exceeds max_len 64"
                )
        if self.smp_action is not None:
            if self.smp_action not in _ENGINE_TRACE_SMP_ACTION_VALUES:
                raise MessageValidationError(
                    f"smp_action: {self.smp_action!r} is not one of {_ENGINE_TRACE_SMP_ACTION_VALUES!r}"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "EngineTrace":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            kind=cast(EngineTraceKind, str(p["kind"])),
            order_id=None if p.get("order_id") is None else str(p["order_id"]),
            priority_seq=(
                None if p.get("priority_seq") is None else int(p["priority_seq"])
            ),
            displayed_qty=(
                None if p.get("displayed_qty") is None else int(p["displayed_qty"])
            ),
            tick_decimals=(
                None if p.get("tick_decimals") is None else int(p["tick_decimals"])
            ),
            stop_price_ticks=(
                None
                if p.get("stop_price_ticks") is None
                else int(p["stop_price_ticks"])
            ),
            last_price_ticks=(
                None
                if p.get("last_price_ticks") is None
                else int(p["last_price_ticks"])
            ),
            auction_id=None if p.get("auction_id") is None else str(p["auction_id"]),
            eq_price_ticks=(
                None if p.get("eq_price_ticks") is None else int(p["eq_price_ticks"])
            ),
            eq_qty=None if p.get("eq_qty") is None else int(p["eq_qty"]),
            surplus=None if p.get("surplus") is None else int(p["surplus"]),
            rule=(
                None if p.get("rule") is None else cast(EngineTraceRule, str(p["rule"]))
            ),
            tied_prices_ticks=[int(item) for item in p.get("tied_prices_ticks", [])],
            combo_id=None if p.get("combo_id") is None else str(p["combo_id"]),
            leg_index=None if p.get("leg_index") is None else int(p["leg_index"]),
            quantity=None if p.get("quantity") is None else int(p["quantity"]),
            fillable_qty=(
                None if p.get("fillable_qty") is None else int(p["fillable_qty"])
            ),
            fillable_no_smp_qty=(
                None
                if p.get("fillable_no_smp_qty") is None
                else int(p["fillable_no_smp_qty"])
            ),
            outcome=(
                None
                if p.get("outcome") is None
                else cast(EngineTraceOutcome, str(p["outcome"]))
            ),
            other_order_id=(
                None if p.get("other_order_id") is None else str(p["other_order_id"])
            ),
            smp_action=(
                None
                if p.get("smp_action") is None
                else cast(EngineTraceSmpAction, str(p["smp_action"]))
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "symbol": self.symbol,
            "kind": self.kind,
        }
        if self.order_id is not None:
            payload["order_id"] = self.order_id
        if self.priority_seq is not None:
            payload["priority_seq"] = self.priority_seq
        if self.displayed_qty is not None:
            payload["displayed_qty"] = self.displayed_qty
        if self.tick_decimals is not None:
            payload["tick_decimals"] = self.tick_decimals
        if self.stop_price_ticks is not None:
            payload["stop_price_ticks"] = self.stop_price_ticks
        if self.last_price_ticks is not None:
            payload["last_price_ticks"] = self.last_price_ticks
        if self.auction_id is not None:
            payload["auction_id"] = self.auction_id
        if self.eq_price_ticks is not None:
            payload["eq_price_ticks"] = self.eq_price_ticks
        if self.eq_qty is not None:
            payload["eq_qty"] = self.eq_qty
        if self.surplus is not None:
            payload["surplus"] = self.surplus
        if self.rule is not None:
            payload["rule"] = self.rule
        if self.tied_prices_ticks:
            payload["tied_prices_ticks"] = self.tied_prices_ticks
        if self.combo_id is not None:
            payload["combo_id"] = self.combo_id
        if self.leg_index is not None:
            payload["leg_index"] = self.leg_index
        if self.quantity is not None:
            payload["quantity"] = self.quantity
        if self.fillable_qty is not None:
            payload["fillable_qty"] = self.fillable_qty
        if self.fillable_no_smp_qty is not None:
            payload["fillable_no_smp_qty"] = self.fillable_no_smp_qty
        if self.outcome is not None:
            payload["outcome"] = self.outcome
        if self.other_order_id is not None:
            payload["other_order_id"] = self.other_order_id
        if self.smp_action is not None:
            payload["smp_action"] = self.smp_action
        return payload


def topic_engine_trace(symbol: str) -> str:
    """Build this message's topic without a string literal."""
    return f"engine.trace.{symbol}"


def match_engine_trace(topic: str) -> str | None:
    """Return ``symbol`` when ``topic`` matches, else None."""
    m = _ENGINE_TRACE_RE.fullmatch(topic)
    return m.group("symbol") if m else None


def make_engine_trace(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = EngineTrace.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_engine_trace(obj.symbol), obj.to_dict())


def make_engine_trace_unchecked(
    *,
    symbol: str,
    kind: EngineTraceKind,
    order_id: str | None = None,
    priority_seq: int | None = None,
    displayed_qty: int | None = None,
    tick_decimals: int | None = None,
    stop_price_ticks: int | None = None,
    last_price_ticks: int | None = None,
    auction_id: str | None = None,
    eq_price_ticks: int | None = None,
    eq_qty: int | None = None,
    surplus: int | None = None,
    rule: EngineTraceRule | None = None,
    tied_prices_ticks: list[int] = [],
    combo_id: str | None = None,
    leg_index: int | None = None,
    quantity: int | None = None,
    fillable_qty: int | None = None,
    fillable_no_smp_qty: int | None = None,
    outcome: EngineTraceOutcome | None = None,
    other_order_id: str | None = None,
    smp_action: EngineTraceSmpAction | None = None,
) -> list[bytes]:
    """Identical frames to ``make_engine_trace``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "symbol": str(symbol),
        "kind": str(kind),
    }
    if order_id is not None:
        payload["order_id"] = str(order_id)
    if priority_seq is not None:
        payload["priority_seq"] = int(priority_seq)
    if displayed_qty is not None:
        payload["displayed_qty"] = int(displayed_qty)
    if tick_decimals is not None:
        payload["tick_decimals"] = int(tick_decimals)
    if stop_price_ticks is not None:
        payload["stop_price_ticks"] = int(stop_price_ticks)
    if last_price_ticks is not None:
        payload["last_price_ticks"] = int(last_price_ticks)
    if auction_id is not None:
        payload["auction_id"] = str(auction_id)
    if eq_price_ticks is not None:
        payload["eq_price_ticks"] = int(eq_price_ticks)
    if eq_qty is not None:
        payload["eq_qty"] = int(eq_qty)
    if surplus is not None:
        payload["surplus"] = int(surplus)
    if rule is not None:
        payload["rule"] = str(rule)
    if tied_prices_ticks:
        payload["tied_prices_ticks"] = [int(item) for item in tied_prices_ticks]
    if combo_id is not None:
        payload["combo_id"] = str(combo_id)
    if leg_index is not None:
        payload["leg_index"] = int(leg_index)
    if quantity is not None:
        payload["quantity"] = int(quantity)
    if fillable_qty is not None:
        payload["fillable_qty"] = int(fillable_qty)
    if fillable_no_smp_qty is not None:
        payload["fillable_no_smp_qty"] = int(fillable_no_smp_qty)
    if outcome is not None:
        payload["outcome"] = str(outcome)
    if other_order_id is not None:
        payload["other_order_id"] = str(other_order_id)
    if smp_action is not None:
        payload["smp_action"] = str(smp_action)
    return [
        topic_engine_trace(symbol).encode(),
        _msg.dumps(payload),
    ]


def parse_engine_trace(frames: list[bytes]) -> "EngineTrace":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_engine_trace(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_ENGINE_TRACE!r}")
    payload = {**payload, "symbol": matched}
    obj = EngineTrace.from_dict(payload)
    obj.validate()
    return obj


def describe_engine_trace() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ENGINE_TRACE_FIELDS


TOPIC_ORDER_AMENDED = "order.amended.{gateway_id}"
PREFIX_ORDER_AMENDED = "order.amended."
_ORDER_AMENDED_RE = re.compile("order\\.amended\\.(?P<gateway_id>[^.]+)")


_ORDER_AMENDED_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "order_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Instrument this order belonged to. Same AR-0.2 rationale as order.cancelled.symbol above - the engine already has it at the publish site, it was simply never carried.",
        "constraints": {"max_len": 16},
    },
    {
        "name": "price",
        "type": "float",
        "unit": "display_price",
        "required": False,
        "doc": "New limit price, or null for an order that has none.",
    },
    {
        "name": "qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "",
    },
    {
        "name": "remaining_qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "",
    },
    {
        "name": "priority_reset",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "True when the amendment lost the order its time priority.",
    },
    {
        "name": "old_price",
        "type": "float",
        "unit": "display_price",
        "required": False,
        "doc": "The order's limit price immediately before this amendment, or null for an order that had none. Lets a post-mortem replay the amend without re-deriving the prior state from an earlier message. Absent on records written before this field existed.",
    },
    {
        "name": "old_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "The order's qty immediately before this amendment. Same replay rationale as old_price; absent on records written before this field existed.",
    },
    {
        "name": "client_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client correlation tag for the amended order.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "request_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client correlation tag for this amend request. Engine-initiated cancels publish with request_tag=null.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "tick_decimals",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "Decimal scale of the `*_ticks` prices in this message (1 tick = 10^-tick_decimals) -- the symbol's. Every message that carries a tick price carries its scale, so a reader of one line, or of a window of the trail that begins long after the book snapshot that declared it, can turn it into money without guessing. Absent when the message carries no tick price.",
        "constraints": {"ge": 0, "le": 9},
    },
    {
        "name": "price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "`price` in engine ticks. Canonical; the float beside it is for display. Scale: the symbol's tick_decimals.",
    },
    {
        "name": "priority_seq",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "The order's place in its book after the amendment (the book's arrival sequence): changed when `priority_reset`.",
        "constraints": {"ge": 0},
    },
)


@dataclass(frozen=True, slots=True)
class OrderAmended:
    """Confirm an accepted amendment and report the resulting order.

    price is nullable but always present: a MARKET order has no limit price, and the
    field says so with null rather than by being absent. This is the one message in the
    group that emits null rather than omitting - it is what the hand-written builder
    did.
    """

    gateway_id: str
    order_id: str
    qty: int  # unit: shares
    remaining_qty: int  # unit: shares
    priority_reset: bool
    symbol: str | None = None
    price: float | None = None  # unit: display_price
    old_price: float | None = None  # unit: display_price
    old_qty: int | None = None  # unit: shares
    client_tag: str | None = None
    request_tag: str | None = None
    tick_decimals: int | None = None  # unit: dimensionless
    price_ticks: int | None = None  # unit: ticks
    priority_seq: int | None = None  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if self.symbol is not None:
            if len(self.symbol) > 16:
                raise MessageValidationError(
                    f"symbol: length {len(self.symbol)} exceeds max_len 16"
                )
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )
        if self.request_tag is not None:
            if len(self.request_tag) > 64:
                raise MessageValidationError(
                    f"request_tag: length {len(self.request_tag)} exceeds max_len 64"
                )
        if self.tick_decimals is not None:
            if self.tick_decimals < 0:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be >= 0"
                )
            if self.tick_decimals > 9:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be <= 9"
                )
        if self.priority_seq is not None:
            if self.priority_seq < 0:
                raise MessageValidationError(
                    f"priority_seq: {self.priority_seq!r} must be >= 0"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderAmended":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            order_id=str(p["order_id"]),
            symbol=None if p.get("symbol") is None else str(p["symbol"]),
            price=None if p.get("price") is None else float(p["price"]),
            qty=int(p["qty"]),
            remaining_qty=int(p["remaining_qty"]),
            priority_reset=bool(p["priority_reset"]),
            old_price=None if p.get("old_price") is None else float(p["old_price"]),
            old_qty=None if p.get("old_qty") is None else int(p["old_qty"]),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
            request_tag=None if p.get("request_tag") is None else str(p["request_tag"]),
            tick_decimals=(
                None if p.get("tick_decimals") is None else int(p["tick_decimals"])
            ),
            price_ticks=None if p.get("price_ticks") is None else int(p["price_ticks"]),
            priority_seq=(
                None if p.get("priority_seq") is None else int(p["priority_seq"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
            "price": self.price,
            "qty": self.qty,
            "remaining_qty": self.remaining_qty,
            "priority_reset": self.priority_reset,
        }
        if self.symbol is not None:
            payload["symbol"] = self.symbol
        if self.old_price is not None:
            payload["old_price"] = self.old_price
        if self.old_qty is not None:
            payload["old_qty"] = self.old_qty
        if self.client_tag is not None:
            payload["client_tag"] = self.client_tag
        if self.request_tag is not None:
            payload["request_tag"] = self.request_tag
        if self.tick_decimals is not None:
            payload["tick_decimals"] = self.tick_decimals
        if self.price_ticks is not None:
            payload["price_ticks"] = self.price_ticks
        if self.priority_seq is not None:
            payload["priority_seq"] = self.priority_seq
        return payload


def topic_order_amended(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"order.amended.{gateway_id}"


def match_order_amended(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _ORDER_AMENDED_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_order_amended(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderAmended.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_order_amended(obj.gateway_id), obj.to_dict())


def make_order_amended_unchecked(
    *,
    gateway_id: str,
    order_id: str,
    qty: int,
    remaining_qty: int,
    priority_reset: bool,
    symbol: str | None = None,
    price: float | None = None,
    old_price: float | None = None,
    old_qty: int | None = None,
    client_tag: str | None = None,
    request_tag: str | None = None,
    tick_decimals: int | None = None,
    price_ticks: int | None = None,
    priority_seq: int | None = None,
) -> list[bytes]:
    """Identical frames to ``make_order_amended``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "order_id": str(order_id),
        "price": None if price is None else float(price),
        "qty": int(qty),
        "remaining_qty": int(remaining_qty),
        "priority_reset": bool(priority_reset),
    }
    if symbol is not None:
        payload["symbol"] = str(symbol)
    if old_price is not None:
        payload["old_price"] = float(old_price)
    if old_qty is not None:
        payload["old_qty"] = int(old_qty)
    if client_tag is not None:
        payload["client_tag"] = str(client_tag)
    if request_tag is not None:
        payload["request_tag"] = str(request_tag)
    if tick_decimals is not None:
        payload["tick_decimals"] = int(tick_decimals)
    if price_ticks is not None:
        payload["price_ticks"] = int(price_ticks)
    if priority_seq is not None:
        payload["priority_seq"] = int(priority_seq)
    return [
        topic_order_amended(gateway_id).encode(),
        _msg.dumps(payload),
    ]


def parse_order_amended(frames: list[bytes]) -> "OrderAmended":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_order_amended(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_ORDER_AMENDED!r}")
    payload = {**payload, "gateway_id": matched}
    obj = OrderAmended.from_dict(payload)
    obj.validate()
    return obj


def describe_order_amended() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_AMENDED_FIELDS


TOPIC_ORDER_NEW = "order.new"
_TOPIC_ORDER_NEW_BYTES = "order.new".encode()
_ORDER_NEW_SIDE_VALUES = ("BUY", "SELL")
OrderNewSide = Literal["BUY", "SELL"]
_ORDER_NEW_ORDER_TYPE_VALUES = (
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
)
OrderNewOrderType = Literal[
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
]
_ORDER_NEW_TIF_VALUES = ("DAY", "GTC", "ATO", "ATC")
OrderNewTif = Literal["DAY", "GTC", "ATO", "ATC"]
_ORDER_NEW_STATUS_VALUES = (
    "NEW",
    "PARTIAL",
    "FILLED",
    "CANCELLED",
    "REJECTED",
    "EXPIRED",
)
OrderNewStatus = Literal["NEW", "PARTIAL", "FILLED", "CANCELLED", "REJECTED", "EXPIRED"]
_ORDER_NEW_SMP_ACTION_VALUES = (
    "NONE",
    "CANCEL_AGGRESSOR",
    "CANCEL_RESTING",
    "CANCEL_BOTH",
)
OrderNewSmpAction = Literal["NONE", "CANCEL_AGGRESSOR", "CANCEL_RESTING", "CANCEL_BOTH"]
_ORDER_NEW_ORIGIN_VALUES = ("ORDER", "QUOTE", "IMPLIED")
OrderNewOrigin = Literal["ORDER", "QUOTE", "IMPLIED"]


_ORDER_NEW_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Engine order id; a UUID string.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "side",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "",
        "values": _ORDER_NEW_SIDE_VALUES,
    },
    {
        "name": "order_type",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "",
        "values": _ORDER_NEW_ORDER_TYPE_VALUES,
    },
    {
        "name": "tif",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "",
        "values": _ORDER_NEW_TIF_VALUES,
    },
    {
        "name": "quantity",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "Total original quantity.",
        "constraints": {"gt": 0},
    },
    {
        "name": "remaining_qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "Quantity yet to be filled; equals quantity on submission.",
        "constraints": {"ge": 0},
    },
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "tick_decimals",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Decimal scale for every `_ticks` field below; 1 tick = 10^-tick_decimals. Carried so a reader can turn a tick price into money from this message alone. Without it the scale has to be recovered from a `book` or `trade.executed` for the same symbol, which a reader of a *window* of the audit trail may not have - the snapshot that declared it is usually at session start, hours outside the window being read. The engine refuses an order with a tick price whose scale is not the symbol's configured one (`INVALID_VALUE`).",
        "constraints": {"ge": 0, "le": 8},
    },
    {
        "name": "trail_offset_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "TRAILING_STOP: fixed distance to trail the market price.",
    },
    {
        "name": "oco_group_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "ts_ns",
        "type": "int",
        "unit": "epoch_nanos",
        "required": True,
        "doc": "Client-supplied submission time. NOT what the book uses for time priority - see arrival_seq. BALF has no timestamp field on NEW_ORDER, so balf_gwy stamps one at ingress.",
        "constraints": {"ge": 0},
    },
    {
        "name": "status",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "Always NEW on submission; the enum is the full lifecycle.",
        "values": _ORDER_NEW_STATUS_VALUES,
    },
    {
        "name": "price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "Limit price in ticks. Null for MARKET, which has none.",
    },
    {
        "name": "stop_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "STOP / STOP_LIMIT / TRAILING_STOP trigger.",
    },
    {
        "name": "visible_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "ICEBERG: fixed peak size.",
    },
    {
        "name": "displayed_qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "ICEBERG: ignored on input; the engine sets the first slice from visible_qty.",
    },
    {
        "name": "smp_action",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "Self-match prevention. Null means the client did not specify SMP at all, which is distinct from an explicit NONE: the engine resolves null to the gateway's configured default. See SmpAction's docstring.",
        "values": _ORDER_NEW_SMP_ACTION_VALUES,
    },
    {
        "name": "combo_parent_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "leg_index",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "Position in the parent combo's legs, 0-based.",
    },
    {
        "name": "origin",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "Defaulted rather than nullable: from_dict supplies ORDER.",
        "values": _ORDER_NEW_ORIGIN_VALUES,
    },
    {
        "name": "is_seed",
        "type": "bool",
        "unit": None,
        "required": False,
        "doc": "True when this order was created by config-driven startup seeding rather than a live gateway submission. See OrderDisplay.is_seed for the full rationale.",
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "client_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client correlation tag, echoed on every lifecycle event.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "arrival_seq",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "Engine-assigned monotonic arrival sequence; time priority is keyed on this, not on timestamp, so a back-dated payload cannot jump the queue. Zero means unassigned, which is what a submission carries.",
    },
)


@dataclass(frozen=True, slots=True)
class OrderNew:
    """Submit a new order to the matching engine. Sent over PUSH/PULL rather than the
    pub bus, but it carries a topic so the audit log can classify it alongside
    everything else.

    The payload is exactly Order.to_dict(). Eleven fields are nullable and are emitted
    as null when unset rather than omitted - a MARKET order carries "price_ticks": null.
    The engine's Order.from_dict reads absent and null alike, so a producer that omits
    them is still accepted.
    """

    id: str
    symbol: str
    side: OrderNewSide
    order_type: OrderNewOrderType
    tif: OrderNewTif
    quantity: int  # unit: shares
    remaining_qty: int  # unit: shares
    gateway_id: str
    tick_decimals: int  # unit: dimensionless
    ts_ns: int  # unit: epoch_nanos
    status: OrderNewStatus
    trail_offset_ticks: int | None = None  # unit: ticks
    oco_group_id: str | None = None
    price_ticks: int | None = None  # unit: ticks
    stop_price_ticks: int | None = None  # unit: ticks
    visible_qty: int | None = None  # unit: shares
    displayed_qty: int | None = None  # unit: shares
    smp_action: OrderNewSmpAction | None = None
    combo_parent_id: str | None = None
    leg_index: int | None = None  # unit: dimensionless
    origin: OrderNewOrigin = "ORDER"
    is_seed: bool = False
    quote_id: str | None = None
    client_tag: str | None = None
    arrival_seq: int = 0  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.id) > 64:
            raise MessageValidationError(
                f"id: length {len(self.id)} exceeds max_len 64"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.side not in _ORDER_NEW_SIDE_VALUES:
            raise MessageValidationError(
                f"side: {self.side!r} is not one of {_ORDER_NEW_SIDE_VALUES!r}"
            )
        if self.order_type not in _ORDER_NEW_ORDER_TYPE_VALUES:
            raise MessageValidationError(
                f"order_type: {self.order_type!r} is not one of {_ORDER_NEW_ORDER_TYPE_VALUES!r}"
            )
        if self.tif not in _ORDER_NEW_TIF_VALUES:
            raise MessageValidationError(
                f"tif: {self.tif!r} is not one of {_ORDER_NEW_TIF_VALUES!r}"
            )
        if self.quantity <= 0:
            raise MessageValidationError(f"quantity: {self.quantity!r} must be > 0")
        if self.remaining_qty < 0:
            raise MessageValidationError(
                f"remaining_qty: {self.remaining_qty!r} must be >= 0"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if self.tick_decimals < 0:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be >= 0"
            )
        if self.tick_decimals > 8:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be <= 8"
            )
        if self.oco_group_id is not None:
            if len(self.oco_group_id) > 64:
                raise MessageValidationError(
                    f"oco_group_id: length {len(self.oco_group_id)} exceeds max_len 64"
                )
        if self.ts_ns < 0:
            raise MessageValidationError(f"ts_ns: {self.ts_ns!r} must be >= 0")
        if self.status not in _ORDER_NEW_STATUS_VALUES:
            raise MessageValidationError(
                f"status: {self.status!r} is not one of {_ORDER_NEW_STATUS_VALUES!r}"
            )
        if self.smp_action is not None:
            if self.smp_action not in _ORDER_NEW_SMP_ACTION_VALUES:
                raise MessageValidationError(
                    f"smp_action: {self.smp_action!r} is not one of {_ORDER_NEW_SMP_ACTION_VALUES!r}"
                )
        if self.combo_parent_id is not None:
            if len(self.combo_parent_id) > 64:
                raise MessageValidationError(
                    f"combo_parent_id: length {len(self.combo_parent_id)} exceeds max_len 64"
                )
        if self.origin not in _ORDER_NEW_ORIGIN_VALUES:
            raise MessageValidationError(
                f"origin: {self.origin!r} is not one of {_ORDER_NEW_ORIGIN_VALUES!r}"
            )
        if self.quote_id is not None:
            if len(self.quote_id) > 64:
                raise MessageValidationError(
                    f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
                )
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderNew":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            id=str(p["id"]),
            symbol=str(p["symbol"]),
            side=cast(OrderNewSide, str(p["side"])),
            order_type=cast(OrderNewOrderType, str(p["order_type"])),
            tif=cast(OrderNewTif, str(p["tif"])),
            quantity=int(p["quantity"]),
            remaining_qty=int(p["remaining_qty"]),
            gateway_id=str(p["gateway_id"]),
            tick_decimals=int(p["tick_decimals"]),
            trail_offset_ticks=(
                None
                if p.get("trail_offset_ticks") is None
                else int(p["trail_offset_ticks"])
            ),
            oco_group_id=(
                None if p.get("oco_group_id") is None else str(p["oco_group_id"])
            ),
            ts_ns=int(p["ts_ns"]),
            status=cast(OrderNewStatus, str(p["status"])),
            price_ticks=None if p.get("price_ticks") is None else int(p["price_ticks"]),
            stop_price_ticks=(
                None
                if p.get("stop_price_ticks") is None
                else int(p["stop_price_ticks"])
            ),
            visible_qty=None if p.get("visible_qty") is None else int(p["visible_qty"]),
            displayed_qty=(
                None if p.get("displayed_qty") is None else int(p["displayed_qty"])
            ),
            smp_action=(
                None
                if p.get("smp_action") is None
                else cast(OrderNewSmpAction, str(p["smp_action"]))
            ),
            combo_parent_id=(
                None if p.get("combo_parent_id") is None else str(p["combo_parent_id"])
            ),
            leg_index=None if p.get("leg_index") is None else int(p["leg_index"]),
            origin=cast(OrderNewOrigin, str(p.get("origin", "ORDER"))),
            is_seed=bool(p.get("is_seed", False)),
            quote_id=None if p.get("quote_id") is None else str(p["quote_id"]),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
            arrival_seq=int(p.get("arrival_seq", 0)),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "id": self.id,
            "symbol": self.symbol,
            "side": self.side,
            "order_type": self.order_type,
            "tif": self.tif,
            "quantity": self.quantity,
            "remaining_qty": self.remaining_qty,
            "gateway_id": self.gateway_id,
            "tick_decimals": self.tick_decimals,
            "trail_offset_ticks": self.trail_offset_ticks,
            "oco_group_id": self.oco_group_id,
            "ts_ns": self.ts_ns,
            "status": self.status,
            "price_ticks": self.price_ticks,
            "stop_price_ticks": self.stop_price_ticks,
            "visible_qty": self.visible_qty,
            "displayed_qty": self.displayed_qty,
            "smp_action": self.smp_action,
            "combo_parent_id": self.combo_parent_id,
            "leg_index": self.leg_index,
            "origin": self.origin,
            "is_seed": self.is_seed,
            "quote_id": self.quote_id,
            "client_tag": self.client_tag,
            "arrival_seq": self.arrival_seq,
        }


def is_order_new(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_ORDER_NEW


def make_order_new(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderNew.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_ORDER_NEW, obj.to_dict())


def make_order_new_unchecked(
    *,
    id: str,
    symbol: str,
    side: OrderNewSide,
    order_type: OrderNewOrderType,
    tif: OrderNewTif,
    quantity: int,
    remaining_qty: int,
    gateway_id: str,
    tick_decimals: int,
    ts_ns: int,
    status: OrderNewStatus,
    trail_offset_ticks: int | None = None,
    oco_group_id: str | None = None,
    price_ticks: int | None = None,
    stop_price_ticks: int | None = None,
    visible_qty: int | None = None,
    displayed_qty: int | None = None,
    smp_action: OrderNewSmpAction | None = None,
    combo_parent_id: str | None = None,
    leg_index: int | None = None,
    origin: OrderNewOrigin = "ORDER",
    is_seed: bool = False,
    quote_id: str | None = None,
    client_tag: str | None = None,
    arrival_seq: int = 0,
) -> list[bytes]:
    """Identical frames to ``make_order_new``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_ORDER_NEW_BYTES,
        _msg.dumps(
            {
                "id": str(id),
                "symbol": str(symbol),
                "side": str(side),
                "order_type": str(order_type),
                "tif": str(tif),
                "quantity": int(quantity),
                "remaining_qty": int(remaining_qty),
                "gateway_id": str(gateway_id),
                "tick_decimals": int(tick_decimals),
                "trail_offset_ticks": (
                    None if trail_offset_ticks is None else int(trail_offset_ticks)
                ),
                "oco_group_id": None if oco_group_id is None else str(oco_group_id),
                "ts_ns": int(ts_ns),
                "status": str(status),
                "price_ticks": None if price_ticks is None else int(price_ticks),
                "stop_price_ticks": (
                    None if stop_price_ticks is None else int(stop_price_ticks)
                ),
                "visible_qty": None if visible_qty is None else int(visible_qty),
                "displayed_qty": None if displayed_qty is None else int(displayed_qty),
                "smp_action": None if smp_action is None else str(smp_action),
                "combo_parent_id": (
                    None if combo_parent_id is None else str(combo_parent_id)
                ),
                "leg_index": None if leg_index is None else int(leg_index),
                "origin": str(origin),
                "is_seed": bool(is_seed),
                "quote_id": None if quote_id is None else str(quote_id),
                "client_tag": None if client_tag is None else str(client_tag),
                "arrival_seq": int(arrival_seq),
            }
        ),
    ]


def parse_order_new(frames: list[bytes]) -> "OrderNew":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = OrderNew.from_dict(payload)
    obj.validate()
    return obj


def describe_order_new() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_NEW_FIELDS


TOPIC_ORDER_CANCEL = "order.cancel"
_TOPIC_ORDER_CANCEL_BYTES = "order.cancel".encode()


_ORDER_CANCEL_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "order_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "request_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client correlation tag for this cancel request, echoed on the resulting cancellation event or rejection.",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class OrderCancel:
    """Request cancellation of one resting order by id."""

    order_id: str
    gateway_id: str
    request_tag: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if self.request_tag is not None:
            if len(self.request_tag) > 64:
                raise MessageValidationError(
                    f"request_tag: length {len(self.request_tag)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderCancel":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            order_id=str(p["order_id"]),
            gateway_id=str(p["gateway_id"]),
            request_tag=None if p.get("request_tag") is None else str(p["request_tag"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
            "gateway_id": self.gateway_id,
        }
        if self.request_tag is not None:
            payload["request_tag"] = self.request_tag
        return payload


def is_order_cancel(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_ORDER_CANCEL


def make_order_cancel(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderCancel.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_ORDER_CANCEL, obj.to_dict())


def make_order_cancel_unchecked(
    *,
    order_id: str,
    gateway_id: str,
    request_tag: str | None = None,
) -> list[bytes]:
    """Identical frames to ``make_order_cancel``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "order_id": str(order_id),
        "gateway_id": str(gateway_id),
    }
    if request_tag is not None:
        payload["request_tag"] = str(request_tag)
    return [
        _TOPIC_ORDER_CANCEL_BYTES,
        _msg.dumps(payload),
    ]


def parse_order_cancel(frames: list[bytes]) -> "OrderCancel":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = OrderCancel.from_dict(payload)
    obj.validate()
    return obj


def describe_order_cancel() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_CANCEL_FIELDS


TOPIC_ORDER_AMEND = "order.amend"
_TOPIC_ORDER_AMEND_BYTES = "order.amend".encode()


_ORDER_AMEND_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "order_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "price",
        "type": "float",
        "unit": "display_price",
        "required": False,
        "doc": "New limit price; absent means the price is unchanged.",
    },
    {
        "name": "qty",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "New quantity; absent means the quantity is unchanged.",
    },
    {
        "name": "request_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client correlation tag for this amend request, echoed on the resulting amendment event or rejection.",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class OrderAmend:
    """Request a price and/or quantity change to a resting order.

    price and qty are omitted when not being changed, and the engine reads that absence
    as "leave this alone" - so unlike order.new these two DO take omit_when_none.
    tests/test_messages.py pins the omission directly. price here is display money, not
    the ticks that order.new carries.
    """

    order_id: str
    gateway_id: str
    price: float | None = None  # unit: display_price
    qty: int | None = None  # unit: shares
    request_tag: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if self.request_tag is not None:
            if len(self.request_tag) > 64:
                raise MessageValidationError(
                    f"request_tag: length {len(self.request_tag)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderAmend":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            order_id=str(p["order_id"]),
            gateway_id=str(p["gateway_id"]),
            price=None if p.get("price") is None else float(p["price"]),
            qty=None if p.get("qty") is None else int(p["qty"]),
            request_tag=None if p.get("request_tag") is None else str(p["request_tag"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
            "gateway_id": self.gateway_id,
        }
        if self.price is not None:
            payload["price"] = self.price
        if self.qty is not None:
            payload["qty"] = self.qty
        if self.request_tag is not None:
            payload["request_tag"] = self.request_tag
        return payload


def is_order_amend(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_ORDER_AMEND


def make_order_amend(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderAmend.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_ORDER_AMEND, obj.to_dict())


def make_order_amend_unchecked(
    *,
    order_id: str,
    gateway_id: str,
    price: float | None = None,
    qty: int | None = None,
    request_tag: str | None = None,
) -> list[bytes]:
    """Identical frames to ``make_order_amend``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "order_id": str(order_id),
        "gateway_id": str(gateway_id),
    }
    if price is not None:
        payload["price"] = float(price)
    if qty is not None:
        payload["qty"] = int(qty)
    if request_tag is not None:
        payload["request_tag"] = str(request_tag)
    return [
        _TOPIC_ORDER_AMEND_BYTES,
        _msg.dumps(payload),
    ]


def parse_order_amend(frames: list[bytes]) -> "OrderAmend":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = OrderAmend.from_dict(payload)
    obj.validate()
    return obj


def describe_order_amend() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_AMEND_FIELDS


TOPIC_ORDER_COMBO_CANCEL = "order.combo_cancel"
_TOPIC_ORDER_COMBO_CANCEL_BYTES = "order.combo_cancel".encode()


_ORDER_COMBO_CANCEL_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "combo_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client-supplied combo label, not the internal UUID.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "request_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Echoed on combo.cancel_ack, so the caller can attribute the outcome.",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class OrderComboCancel:
    """Cancel a combo order and all of its resting child legs."""

    combo_id: str = ""
    gateway_id: str = ""
    request_tag: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.combo_id) > 64:
            raise MessageValidationError(
                f"combo_id: length {len(self.combo_id)} exceeds max_len 64"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.request_tag) > 64:
            raise MessageValidationError(
                f"request_tag: length {len(self.request_tag)} exceeds max_len 64"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderComboCancel":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            combo_id=str(p.get("combo_id", "")),
            gateway_id=str(p.get("gateway_id", "")),
            request_tag=str(p.get("request_tag", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "combo_id": self.combo_id,
            "gateway_id": self.gateway_id,
        }
        if self.request_tag:
            payload["request_tag"] = self.request_tag
        return payload


def is_order_combo_cancel(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_ORDER_COMBO_CANCEL


def make_order_combo_cancel(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderComboCancel.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_ORDER_COMBO_CANCEL, obj.to_dict())


def make_order_combo_cancel_unchecked(
    *,
    combo_id: str = "",
    gateway_id: str = "",
    request_tag: str = "",
) -> list[bytes]:
    """Identical frames to ``make_order_combo_cancel``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "combo_id": str(combo_id),
        "gateway_id": str(gateway_id),
    }
    if request_tag:
        payload["request_tag"] = str(request_tag)
    return [
        _TOPIC_ORDER_COMBO_CANCEL_BYTES,
        _msg.dumps(payload),
    ]


def parse_order_combo_cancel(frames: list[bytes]) -> "OrderComboCancel":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = OrderComboCancel.from_dict(payload)
    obj.validate()
    return obj


def describe_order_combo_cancel() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_COMBO_CANCEL_FIELDS


TOPIC_ORDER_COMBO = "order.combo"
_TOPIC_ORDER_COMBO_BYTES = "order.combo".encode()
_ORDER_COMBO_COMBO_TYPE_VALUES = ("AON",)
OrderComboComboType = Literal["AON"]
_ORDER_COMBO_TIF_VALUES = ("DAY", "GTC", "ATO", "ATC")
OrderComboTif = Literal["DAY", "GTC", "ATO", "ATC"]


_ORDER_COMBO_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "combo_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Client-supplied tracking label, not the engine's internal id.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "combo_type",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "All-or-none: the combo completes only when every leg fills.",
        "values": _ORDER_COMBO_COMBO_TYPE_VALUES,
    },
    {
        "name": "tif",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "",
        "values": _ORDER_COMBO_TIF_VALUES,
    },
    {
        "name": "legs",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "The child orders. The bounds below were previously enforced only by api_gateway's pydantic schema, which left the ALF console and gateway free to submit a one-legged combo.",
        "constraints": {"max_items": 10},
    },
    {
        "name": "client_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client correlation tag for this combo submission.",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class OrderCombo:
    """Submit a combo: two or more orders on different instruments that the engine
    posts together and tracks as one aggregate.

    This is the message the whole of design section 15 is about. It was unspecifiable
    for three separate reasons, and each turned out to be the wire being wrong rather
    than the IDL being short: leg prices whose unit depended on their runtime type
    (15.2), engine lifecycle state riding on a client submission (15.4), and finally the
    ordinary need for `nested` and `list[T]` (15.5). The payload below is `ComboOrder.
    to_submission_dict()` and carries no engine state at all.
    """

    combo_id: str
    gateway_id: str
    combo_type: OrderComboComboType
    tif: OrderComboTif
    legs: list[ComboLeg]
    client_tag: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.combo_id) > 64:
            raise MessageValidationError(
                f"combo_id: length {len(self.combo_id)} exceeds max_len 64"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if self.combo_type not in _ORDER_COMBO_COMBO_TYPE_VALUES:
            raise MessageValidationError(
                f"combo_type: {self.combo_type!r} is not one of {_ORDER_COMBO_COMBO_TYPE_VALUES!r}"
            )
        if self.tif not in _ORDER_COMBO_TIF_VALUES:
            raise MessageValidationError(
                f"tif: {self.tif!r} is not one of {_ORDER_COMBO_TIF_VALUES!r}"
            )
        if len(self.legs) < 2:
            raise MessageValidationError("legs: fewer than 2 item(s)")
        if len(self.legs) > 10:
            raise MessageValidationError("legs: more than 10 item(s)")
        for legs_item in self.legs:
            legs_item.validate()
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderCombo":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            combo_id=str(p["combo_id"]),
            gateway_id=str(p["gateway_id"]),
            combo_type=cast(OrderComboComboType, str(p["combo_type"])),
            tif=cast(OrderComboTif, str(p["tif"])),
            legs=[ComboLeg.from_dict(item) for item in p["legs"]],
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "combo_id": self.combo_id,
            "gateway_id": self.gateway_id,
            "combo_type": self.combo_type,
            "tif": self.tif,
            "legs": [item.to_dict() for item in self.legs],
        }
        if self.client_tag is not None:
            payload["client_tag"] = self.client_tag
        return payload


def is_order_combo(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_ORDER_COMBO


def make_order_combo(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderCombo.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_ORDER_COMBO, obj.to_dict())


def parse_order_combo(frames: list[bytes]) -> "OrderCombo":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = OrderCombo.from_dict(payload)
    obj.validate()
    return obj


def describe_order_combo() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_COMBO_FIELDS


TOPIC_ORDER_OCO = "order.oco"
_TOPIC_ORDER_OCO_BYTES = "order.oco".encode()
_ORDER_OCO_TIF_VALUES = ("DAY", "GTC", "ATO", "ATC")
OrderOcoTif = Literal["DAY", "GTC", "ATO", "ATC"]


_ORDER_OCO_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "oco_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client-supplied label for the pair, unique among the gateway's live pairs: a submit reusing one is refused. Free again once the pair is done.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Both legs trade this instrument.",
        "constraints": {"max_len": 16},
    },
    {
        "name": "tick_decimals",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "Decimal scale for both legs' `_ticks` prices; 1 tick = 10^-tick_decimals. One value for the pair rather than one per leg, because both legs trade the instrument named above. The engine refuses a pair whose scale is not the symbol's.",
        "constraints": {"ge": 0, "le": 8},
    },
    {
        "name": "quantity",
        "type": "int",
        "unit": "shares",
        "required": False,
        "doc": "Size of each leg; they are equal by construction.",
    },
    {
        "name": "tif",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "",
        "values": _ORDER_OCO_TIF_VALUES,
    },
    {
        "name": "leg1",
        "type": "nested",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "leg2",
        "type": "nested",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "client_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client correlation tag for this OCO submission.",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class OrderOco:
    """Submit a One-Cancels-Other pair: two orders on the same instrument, of which a
    fill on either cancels the other.

    The first message in any spec to use a nested record. Both legs are `OcoLeg`, and
    their prices are engine ticks at `tick_decimals` - the gateway converts. A leg omits
    a price it does not have rather than sending null, which is what the three producing
    gateways already do.
    """

    leg1: OcoLeg
    leg2: OcoLeg
    oco_id: str = ""
    gateway_id: str = ""
    symbol: str = ""
    tick_decimals: int = 0  # unit: dimensionless
    quantity: int = 0  # unit: shares
    tif: OrderOcoTif = "DAY"
    client_tag: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.oco_id) > 64:
            raise MessageValidationError(
                f"oco_id: length {len(self.oco_id)} exceeds max_len 64"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.tick_decimals < 0:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be >= 0"
            )
        if self.tick_decimals > 8:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be <= 8"
            )
        if self.tif not in _ORDER_OCO_TIF_VALUES:
            raise MessageValidationError(
                f"tif: {self.tif!r} is not one of {_ORDER_OCO_TIF_VALUES!r}"
            )
        self.leg1.validate()
        self.leg2.validate()
        if self.client_tag is not None:
            if len(self.client_tag) > 64:
                raise MessageValidationError(
                    f"client_tag: length {len(self.client_tag)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderOco":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            oco_id=str(p.get("oco_id", "")),
            gateway_id=str(p.get("gateway_id", "")),
            symbol=str(p.get("symbol", "")),
            tick_decimals=int(p.get("tick_decimals", 0)),
            quantity=int(p.get("quantity", 0)),
            tif=cast(OrderOcoTif, str(p.get("tif", "DAY"))),
            leg1=OcoLeg.from_dict(p["leg1"]),
            leg2=OcoLeg.from_dict(p["leg2"]),
            client_tag=None if p.get("client_tag") is None else str(p["client_tag"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "oco_id": self.oco_id,
            "gateway_id": self.gateway_id,
            "symbol": self.symbol,
            "tick_decimals": self.tick_decimals,
            "quantity": self.quantity,
            "tif": self.tif,
            "leg1": self.leg1.to_dict(),
            "leg2": self.leg2.to_dict(),
        }
        if self.client_tag is not None:
            payload["client_tag"] = self.client_tag
        return payload


def is_order_oco(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_ORDER_OCO


def make_order_oco(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderOco.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_ORDER_OCO, obj.to_dict())


def parse_order_oco(frames: list[bytes]) -> "OrderOco":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = OrderOco.from_dict(payload)
    obj.validate()
    return obj


def describe_order_oco() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_OCO_FIELDS


TOPIC_ORDER_OCO_CANCEL = "order.oco_cancel"
_TOPIC_ORDER_OCO_CANCEL_BYTES = "order.oco_cancel".encode()


_ORDER_OCO_CANCEL_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "oco_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Client-supplied OCO label. Names a pair of the sending gateway only.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "request_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Echoed on oco.cancel_ack, so the caller can attribute the outcome.",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class OrderOcoCancel:
    """Cancel an OCO pair and both of its legs."""

    oco_id: str = ""
    gateway_id: str = ""
    request_tag: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.oco_id) > 64:
            raise MessageValidationError(
                f"oco_id: length {len(self.oco_id)} exceeds max_len 64"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.request_tag) > 64:
            raise MessageValidationError(
                f"request_tag: length {len(self.request_tag)} exceeds max_len 64"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderOcoCancel":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            oco_id=str(p.get("oco_id", "")),
            gateway_id=str(p.get("gateway_id", "")),
            request_tag=str(p.get("request_tag", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "oco_id": self.oco_id,
            "gateway_id": self.gateway_id,
        }
        if self.request_tag:
            payload["request_tag"] = self.request_tag
        return payload


def is_order_oco_cancel(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_ORDER_OCO_CANCEL


def make_order_oco_cancel(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrderOcoCancel.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_ORDER_OCO_CANCEL, obj.to_dict())


def make_order_oco_cancel_unchecked(
    *,
    oco_id: str = "",
    gateway_id: str = "",
    request_tag: str = "",
) -> list[bytes]:
    """Identical frames to ``make_order_oco_cancel``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "oco_id": str(oco_id),
        "gateway_id": str(gateway_id),
    }
    if request_tag:
        payload["request_tag"] = str(request_tag)
    return [
        _TOPIC_ORDER_OCO_CANCEL_BYTES,
        _msg.dumps(payload),
    ]


def parse_order_oco_cancel(frames: list[bytes]) -> "OrderOcoCancel":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = OrderOcoCancel.from_dict(payload)
    obj.validate()
    return obj


def describe_order_oco_cancel() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDER_OCO_CANCEL_FIELDS


TOPIC_ORDERS_REQUEST = "order.orders_request"
_TOPIC_ORDERS_REQUEST_BYTES = "order.orders_request".encode()


_ORDERS_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Whose resting orders to return, and the reply's correlation key.",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class OrdersRequest:
    """Caller to engine: the resting (unfilled, non-cancelled) orders a gateway
    currently has on the books, across all symbols.
    """

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrdersRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_orders_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_ORDERS_REQUEST


def make_orders_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = OrdersRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_ORDERS_REQUEST, obj.to_dict())


def make_orders_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_orders_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_ORDERS_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_orders_request(frames: list[bytes]) -> "OrdersRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = OrdersRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_orders_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDERS_REQUEST_FIELDS


TOPIC_ORDERS = "order.orders.{gateway_id}"
PREFIX_ORDERS = "order.orders."
_ORDERS_RE = re.compile("order\\.orders\\.(?P<gateway_id>[^.]+)")
_ORDERS_STATUS_VALUES = ("OK", "NOT_CONNECTED", "UNKNOWN_GATEWAY")
OrdersStatus = Literal["OK", "NOT_CONNECTED", "UNKNOWN_GATEWAY"]


_ORDERS_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped from the body by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "orders",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Resting orders, as the engine iterates its books.",
    },
    {
        "name": "status",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "`OK`: the gateway is connected. `NOT_CONNECTED`: a configured participant that is logged off; the list is still its own, as the engine holds it. `UNKNOWN_GATEWAY`: no participant has this id, so the list is empty.",
        "values": _ORDERS_STATUS_VALUES,
    },
)


@dataclass(frozen=True, slots=True)
class Orders:
    """Engine to caller: the gateway's resting orders in display units, one
    OrderDisplay record each, connected or not; `status` says which. Empty when
    the gateway has none or no participant has the id.

    gateway_id names the caller in the topic and is dropped from the body by the default
    projection, so the body is a single `orders` list - the same shape system.symbols
    uses.
    """

    gateway_id: str
    orders: list[OrderDisplay]
    status: OrdersStatus = "OK"

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        for orders_item in self.orders:
            orders_item.validate()
        if self.status not in _ORDERS_STATUS_VALUES:
            raise MessageValidationError(
                f"status: {self.status!r} is not one of {_ORDERS_STATUS_VALUES!r}"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Orders":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            orders=[OrderDisplay.from_dict(item) for item in p["orders"]],
            status=cast(OrdersStatus, str(p.get("status", "OK"))),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "orders": [item.to_dict() for item in self.orders],
            "status": self.status,
        }


def topic_orders(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"order.orders.{gateway_id}"


def match_orders(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _ORDERS_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_orders(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = Orders.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_orders(obj.gateway_id), obj.to_dict())


def parse_orders(frames: list[bytes]) -> "Orders":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_orders(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_ORDERS!r}")
    payload = {**payload, "gateway_id": matched}
    obj = Orders.from_dict(payload)
    obj.validate()
    return obj


def describe_orders() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _ORDERS_FIELDS


TOPIC_PRICE_LEVEL_ORDERS_REQUEST = "order.price_level_orders_request"
_TOPIC_PRICE_LEVEL_ORDERS_REQUEST_BYTES = "order.price_level_orders_request".encode()


_PRICE_LEVEL_ORDERS_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "The ADMIN participant asking, and the reply's correlation key — not a filter on whose orders come back.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Instrument to inspect.",
        "constraints": {"max_len": 16},
    },
    {
        "name": "price",
        "type": "float",
        "unit": "display_price",
        "required": False,
        "doc": "Narrow to orders resting at exactly this price. Omitted or null returns every resting order for the symbol, across all price levels.",
    },
)


@dataclass(frozen=True, slots=True)
class PriceLevelOrdersRequest:
    """ADMIN to engine: every resting order for one symbol, across every gateway,
    optionally narrowed to a single price level. Rejected for any non-ADMIN
    participant (see order.price_level_orders' rejection note) since it exposes
    other participants' resting order detail that order.orders_request
    deliberately withholds.
    """

    gateway_id: str
    symbol: str
    price: float | None = None  # unit: display_price

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "PriceLevelOrdersRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            symbol=str(p["symbol"]),
            price=None if p.get("price") is None else float(p["price"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "gateway_id": self.gateway_id,
            "symbol": self.symbol,
        }
        if self.price is not None:
            payload["price"] = self.price
        return payload


def is_price_level_orders_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_PRICE_LEVEL_ORDERS_REQUEST


def make_price_level_orders_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = PriceLevelOrdersRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_PRICE_LEVEL_ORDERS_REQUEST, obj.to_dict())


def make_price_level_orders_request_unchecked(
    *,
    gateway_id: str,
    symbol: str,
    price: float | None = None,
) -> list[bytes]:
    """Identical frames to ``make_price_level_orders_request``, without
    ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "gateway_id": str(gateway_id),
        "symbol": str(symbol),
    }
    if price is not None:
        payload["price"] = float(price)
    return [
        _TOPIC_PRICE_LEVEL_ORDERS_REQUEST_BYTES,
        _msg.dumps(payload),
    ]


def parse_price_level_orders_request(frames: list[bytes]) -> "PriceLevelOrdersRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = PriceLevelOrdersRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_price_level_orders_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _PRICE_LEVEL_ORDERS_REQUEST_FIELDS


TOPIC_PRICE_LEVEL_ORDERS = "order.price_level_orders.{gateway_id}"
PREFIX_PRICE_LEVEL_ORDERS = "order.price_level_orders."
_PRICE_LEVEL_ORDERS_RE = re.compile(
    "order\\.price_level_orders\\.(?P<gateway_id>[^.]+)"
)


_PRICE_LEVEL_ORDERS_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped from the body by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "price",
        "type": "float",
        "unit": "display_price",
        "required": False,
        "doc": "Echoed from the request when it filtered to one level; omitted when the request asked for the whole symbol.",
    },
    {
        "name": "rejected",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "True when the requester was not ADMIN or the symbol is unknown; orders is then always empty.",
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Set only when rejected is true.",
        "constraints": {"max_len": 256},
    },
    {
        "name": "orders",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Matching resting orders, ordered by price then arrival_seq — empty when rejected, or when nothing rests at the requested level.",
    },
)


@dataclass(frozen=True, slots=True)
class PriceLevelOrders:
    """Engine to ADMIN caller: per-order detail (not just the aggregate {price, qty,
    count} book.* already carries) for every resting order matching the request —
    every gateway, ordered by price then by arrival_seq within a price level so
    time priority is visible. Empty, with rejected=true and a reason, when the
    requester is not an ADMIN participant or the symbol is unknown.
    """

    gateway_id: str
    symbol: str
    rejected: bool
    orders: list[PriceLevelOrder]
    price: float | None = None  # unit: display_price
    reason: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.reason is not None:
            if len(self.reason) > 256:
                raise MessageValidationError(
                    f"reason: length {len(self.reason)} exceeds max_len 256"
                )
        for orders_item in self.orders:
            orders_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "PriceLevelOrders":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            symbol=str(p["symbol"]),
            price=None if p.get("price") is None else float(p["price"]),
            rejected=bool(p["rejected"]),
            reason=None if p.get("reason") is None else str(p["reason"]),
            orders=[PriceLevelOrder.from_dict(item) for item in p["orders"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "symbol": self.symbol,
            "rejected": self.rejected,
            "orders": [item.to_dict() for item in self.orders],
        }
        if self.price is not None:
            payload["price"] = self.price
        if self.reason is not None:
            payload["reason"] = self.reason
        return payload


def topic_price_level_orders(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"order.price_level_orders.{gateway_id}"


def match_price_level_orders(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _PRICE_LEVEL_ORDERS_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_price_level_orders(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = PriceLevelOrders.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_price_level_orders(obj.gateway_id), obj.to_dict())


def parse_price_level_orders(frames: list[bytes]) -> "PriceLevelOrders":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_price_level_orders(topic)
    if matched is None:
        raise MessageValidationError(
            f"topic {topic!r} is not {TOPIC_PRICE_LEVEL_ORDERS!r}"
        )
    payload = {**payload, "gateway_id": matched}
    obj = PriceLevelOrders.from_dict(payload)
    obj.validate()
    return obj


def describe_price_level_orders() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _PRICE_LEVEL_ORDERS_FIELDS


FAMILY_TOPICS: tuple[str, ...] = (
    TOPIC_ORDER_ACK,
    TOPIC_ORDER_FILL,
    TOPIC_ORDER_CANCELLED,
    TOPIC_ORDER_EXPIRED,
    TOPIC_ORDER_TRIGGERED,
    TOPIC_ENGINE_TRACE,
    TOPIC_ORDER_AMENDED,
    TOPIC_ORDER_NEW,
    TOPIC_ORDER_CANCEL,
    TOPIC_ORDER_AMEND,
    TOPIC_ORDER_COMBO_CANCEL,
    TOPIC_ORDER_COMBO,
    TOPIC_ORDER_OCO,
    TOPIC_ORDER_OCO_CANCEL,
    TOPIC_ORDERS_REQUEST,
    TOPIC_ORDERS,
    TOPIC_PRICE_LEVEL_ORDERS_REQUEST,
    TOPIC_PRICE_LEVEL_ORDERS,
)
