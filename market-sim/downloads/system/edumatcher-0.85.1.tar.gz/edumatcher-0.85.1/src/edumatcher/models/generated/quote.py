# GENERATED FROM spec/messages/quote.yaml - DO NOT EDIT
#
# Regenerate with:  poetry run pm-msgen generate
"""Generated bindings for the ``quote`` message family.

Family version 1. Every symbol here is derived from ``spec/messages/quote.yaml``; edit
the spec, not this file.

``pm-msgen check`` fails the build if this file and the spec disagree. See
../../../../docs/books/architecture-and-development/part-4-developing/040-message-
generation.md.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, cast

from edumatcher.models import message as _msg
from edumatcher.models.generated._runtime import MessageValidationError

FAMILY = "quote"
FAMILY_VERSION = 1


TOPIC_QUOTE_NEW = "quote.new"
_TOPIC_QUOTE_NEW_BYTES = "quote.new".encode()
_QUOTE_NEW_TIF_VALUES = ("DAY", "GTC", "ATO", "ATC")
QuoteNewTif = Literal["DAY", "GTC", "ATO", "ATC"]


_QUOTE_NEW_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "tick_decimals",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Decimal scale for both `_ticks` prices; 1 tick = 10^-tick_decimals. Carried so a reader can turn a tick price into money from this message alone, rather than recovering the scale from a `book` for the same symbol that may be outside the window being read. The engine refuses a quote whose scale is not the symbol's configured one, naming both values.",
        "constraints": {"ge": 0, "le": 8},
    },
    {
        "name": "bid_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": True,
        "doc": "",
        "constraints": {"gt": 0},
    },
    {
        "name": "bid_qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "",
        "constraints": {"gt": 0},
    },
    {
        "name": "ask_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": True,
        "doc": "",
        "constraints": {"gt": 0},
    },
    {
        "name": "ask_qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "",
        "constraints": {"gt": 0},
    },
    {
        "name": "tif",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "Applies to both legs; the engine reads it once. Same four values as models/order.py::TIF and order.combo's own tif - a quote's legs are ordinary orders once they rest.",
        "values": _QUOTE_NEW_TIF_VALUES,
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class QuoteNew:
    """Market maker to engine: submit or replace a two-sided quote on one instrument.
    A quote is a bid and an ask posted as a pair; replacing one cancels the
    previous pair for that gateway and symbol.

    Prices are integer ticks. The engine rejects a float outright rather than converting
    it, because a display price of 150.0 accepted as 150 ticks would post the quote at
    1/100th of the intended level on a two-decimal instrument - silent, and in the wrong
    direction for the side that gets hit. `quote_id` is the client's own handle, echoed
    on every ack and status event. It is optional: a gateway that submits one quote per
    symbol can identify it by symbol alone, and the hand-written builders omitted the
    key entirely rather than sending "".
    """

    gateway_id: str
    symbol: str
    tick_decimals: int  # unit: dimensionless
    bid_price_ticks: int  # unit: ticks
    bid_qty: int  # unit: shares
    ask_price_ticks: int  # unit: ticks
    ask_qty: int  # unit: shares
    tif: QuoteNewTif = "DAY"
    quote_id: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.tick_decimals < 0:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be >= 0"
            )
        if self.tick_decimals > 8:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be <= 8"
            )
        if self.bid_price_ticks <= 0:
            raise MessageValidationError(
                f"bid_price_ticks: {self.bid_price_ticks!r} must be > 0"
            )
        if self.bid_qty <= 0:
            raise MessageValidationError(f"bid_qty: {self.bid_qty!r} must be > 0")
        if self.ask_price_ticks <= 0:
            raise MessageValidationError(
                f"ask_price_ticks: {self.ask_price_ticks!r} must be > 0"
            )
        if self.ask_qty <= 0:
            raise MessageValidationError(f"ask_qty: {self.ask_qty!r} must be > 0")
        if self.tif not in _QUOTE_NEW_TIF_VALUES:
            raise MessageValidationError(
                f"tif: {self.tif!r} is not one of {_QUOTE_NEW_TIF_VALUES!r}"
            )
        if len(self.quote_id) > 64:
            raise MessageValidationError(
                f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteNew":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            symbol=str(p["symbol"]),
            tick_decimals=int(p["tick_decimals"]),
            bid_price_ticks=int(p["bid_price_ticks"]),
            bid_qty=int(p["bid_qty"]),
            ask_price_ticks=int(p["ask_price_ticks"]),
            ask_qty=int(p["ask_qty"]),
            tif=cast(QuoteNewTif, str(p.get("tif", "DAY"))),
            quote_id=str(p.get("quote_id", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "gateway_id": self.gateway_id,
            "symbol": self.symbol,
            "tick_decimals": self.tick_decimals,
            "bid_price_ticks": self.bid_price_ticks,
            "bid_qty": self.bid_qty,
            "ask_price_ticks": self.ask_price_ticks,
            "ask_qty": self.ask_qty,
            "tif": self.tif,
        }
        if self.quote_id:
            payload["quote_id"] = self.quote_id
        return payload


def is_quote_new(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_QUOTE_NEW


def make_quote_new(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteNew.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_QUOTE_NEW, obj.to_dict())


def make_quote_new_unchecked(
    *,
    gateway_id: str,
    symbol: str,
    tick_decimals: int,
    bid_price_ticks: int,
    bid_qty: int,
    ask_price_ticks: int,
    ask_qty: int,
    tif: QuoteNewTif = "DAY",
    quote_id: str = "",
) -> list[bytes]:
    """Identical frames to ``make_quote_new``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "gateway_id": str(gateway_id),
        "symbol": str(symbol),
        "tick_decimals": int(tick_decimals),
        "bid_price_ticks": int(bid_price_ticks),
        "bid_qty": int(bid_qty),
        "ask_price_ticks": int(ask_price_ticks),
        "ask_qty": int(ask_qty),
        "tif": str(tif),
    }
    if quote_id:
        payload["quote_id"] = str(quote_id)
    return [
        _TOPIC_QUOTE_NEW_BYTES,
        _msg.dumps(payload),
    ]


def parse_quote_new(frames: list[bytes]) -> "QuoteNew":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = QuoteNew.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_new() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_NEW_FIELDS


TOPIC_QUOTE_CANCEL = "quote.cancel"
_TOPIC_QUOTE_CANCEL_BYTES = "quote.cancel".encode()


_QUOTE_CANCEL_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "request_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Echoed on quote.cancel_ack, so the caller can attribute the outcome.",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class QuoteCancel:
    """Market maker to engine: pull the active quote on one symbol.

    Addressed by symbol rather than by quote_id: a gateway has at most one active quote
    per instrument, so the pair identifies it. That is also why quote_id is optional on
    submission.
    """

    gateway_id: str
    symbol: str
    request_tag: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if len(self.request_tag) > 64:
            raise MessageValidationError(
                f"request_tag: length {len(self.request_tag)} exceeds max_len 64"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteCancel":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            symbol=str(p["symbol"]),
            request_tag=str(p.get("request_tag", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "gateway_id": self.gateway_id,
            "symbol": self.symbol,
        }
        if self.request_tag:
            payload["request_tag"] = self.request_tag
        return payload


def is_quote_cancel(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_QUOTE_CANCEL


def make_quote_cancel(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteCancel.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_QUOTE_CANCEL, obj.to_dict())


def make_quote_cancel_unchecked(
    *,
    gateway_id: str,
    symbol: str,
    request_tag: str = "",
) -> list[bytes]:
    """Identical frames to ``make_quote_cancel``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "gateway_id": str(gateway_id),
        "symbol": str(symbol),
    }
    if request_tag:
        payload["request_tag"] = str(request_tag)
    return [
        _TOPIC_QUOTE_CANCEL_BYTES,
        _msg.dumps(payload),
    ]


def parse_quote_cancel(frames: list[bytes]) -> "QuoteCancel":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = QuoteCancel.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_cancel() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_CANCEL_FIELDS


TOPIC_QUOTE_ACK = "quote.ack.{gateway_id}"
PREFIX_QUOTE_ACK = "quote.ack."
_QUOTE_ACK_RE = re.compile("quote\\.ack\\.(?P<gateway_id>[^.]+)")


_QUOTE_ACK_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "accepted",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Instrument the quote was for. `order.ack` has always carried this; `quote.ack` did not, which left every market-making client to work out for itself which symbol an ack belonged to -- the topic is per-gateway, not per-symbol. Empty only on a rejection raised before the symbol was known (a malformed payload, or a missing SYM).",
        "constraints": {"max_len": 16},
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 512},
    },
    {
        "name": "bid_order_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "ask_order_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class QuoteAck:
    """Engine to market maker: the quote was accepted or rejected.

    The two order ids are the engine's handles for the resting legs, and are what ties a
    subsequent order.fill to the quote that produced it. Both are always emitted, as ""
    on rejection - the hand-written builder put them in the base payload, and a rejected
    quote rests nothing.
    """

    gateway_id: str
    accepted: bool
    quote_id: str = ""
    symbol: str = ""
    reason: str = ""
    bid_order_id: str = ""
    ask_order_id: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.quote_id) > 64:
            raise MessageValidationError(
                f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if len(self.reason) > 512:
            raise MessageValidationError(
                f"reason: length {len(self.reason)} exceeds max_len 512"
            )
        if len(self.bid_order_id) > 64:
            raise MessageValidationError(
                f"bid_order_id: length {len(self.bid_order_id)} exceeds max_len 64"
            )
        if len(self.ask_order_id) > 64:
            raise MessageValidationError(
                f"ask_order_id: length {len(self.ask_order_id)} exceeds max_len 64"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteAck":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            quote_id=str(p.get("quote_id", "")),
            accepted=bool(p["accepted"]),
            symbol=str(p.get("symbol", "")),
            reason=str(p.get("reason", "")),
            bid_order_id=str(p.get("bid_order_id", "")),
            ask_order_id=str(p.get("ask_order_id", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "quote_id": self.quote_id,
            "accepted": self.accepted,
            "symbol": self.symbol,
            "reason": self.reason,
            "bid_order_id": self.bid_order_id,
            "ask_order_id": self.ask_order_id,
        }


def topic_quote_ack(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"quote.ack.{gateway_id}"


def match_quote_ack(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _QUOTE_ACK_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_quote_ack(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteAck.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_quote_ack(obj.gateway_id), obj.to_dict())


def make_quote_ack_unchecked(
    *,
    gateway_id: str,
    accepted: bool,
    quote_id: str = "",
    symbol: str = "",
    reason: str = "",
    bid_order_id: str = "",
    ask_order_id: str = "",
) -> list[bytes]:
    """Identical frames to ``make_quote_ack``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        topic_quote_ack(gateway_id).encode(),
        _msg.dumps(
            {
                "quote_id": str(quote_id),
                "accepted": bool(accepted),
                "symbol": str(symbol),
                "reason": str(reason),
                "bid_order_id": str(bid_order_id),
                "ask_order_id": str(ask_order_id),
            }
        ),
    ]


def parse_quote_ack(frames: list[bytes]) -> "QuoteAck":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_quote_ack(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_QUOTE_ACK!r}")
    payload = {**payload, "gateway_id": matched}
    obj = QuoteAck.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_ack() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_ACK_FIELDS


TOPIC_QUOTE_STATUS = "quote.status.{gateway_id}"
PREFIX_QUOTE_STATUS = "quote.status."
_QUOTE_STATUS_RE = re.compile("quote\\.status\\.(?P<gateway_id>[^.]+)")
_QUOTE_STATUS_STATUS_VALUES = (
    "ACTIVE",
    "INACTIVE_BID_FILLED",
    "INACTIVE_ASK_FILLED",
    "CANCELLED",
)
QuoteStatusStatus = Literal[
    "ACTIVE",
    "INACTIVE_BID_FILLED",
    "INACTIVE_ASK_FILLED",
    "CANCELLED",
]


_QUOTE_STATUS_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "status",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "Mirrors models/quote.py::QuoteState.",
        "values": _QUOTE_STATUS_STATUS_VALUES,
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 512},
    },
    {
        "name": "command_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The admin/kill-switch command_id (see system.admin_action) that caused this quote to leave the book, when one exists — same correlation purpose as order.cancelled.command_id. Null when the quote left for a reason with no originating command (participant cancel, replacement by a new quote, a leg fill).",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class QuoteStatus:
    """Engine to market maker: the quote left the book, and why.

    The two INACTIVE_* states say which side was hit, which a market maker needs in
    order to re-quote the other one. They are distinct states rather than one INACTIVE
    plus a side field because models/quote.py::QuoteState is what the engine actually
    holds, and a wire that renames its own state machine is a translation nobody asked
    for.
    """

    gateway_id: str
    status: QuoteStatusStatus
    quote_id: str = ""
    reason: str = ""
    command_id: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.quote_id) > 64:
            raise MessageValidationError(
                f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
            )
        if self.status not in _QUOTE_STATUS_STATUS_VALUES:
            raise MessageValidationError(
                f"status: {self.status!r} is not one of {_QUOTE_STATUS_STATUS_VALUES!r}"
            )
        if len(self.reason) > 512:
            raise MessageValidationError(
                f"reason: length {len(self.reason)} exceeds max_len 512"
            )
        if self.command_id is not None:
            if len(self.command_id) > 64:
                raise MessageValidationError(
                    f"command_id: length {len(self.command_id)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteStatus":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            quote_id=str(p.get("quote_id", "")),
            status=cast(QuoteStatusStatus, str(p["status"])),
            reason=str(p.get("reason", "")),
            command_id=None if p.get("command_id") is None else str(p["command_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "quote_id": self.quote_id,
            "status": self.status,
            "reason": self.reason,
        }
        if self.command_id is not None:
            payload["command_id"] = self.command_id
        return payload


def topic_quote_status(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"quote.status.{gateway_id}"


def match_quote_status(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _QUOTE_STATUS_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_quote_status(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteStatus.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_quote_status(obj.gateway_id), obj.to_dict())


def make_quote_status_unchecked(
    *,
    gateway_id: str,
    status: QuoteStatusStatus,
    quote_id: str = "",
    reason: str = "",
    command_id: str | None = None,
) -> list[bytes]:
    """Identical frames to ``make_quote_status``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "quote_id": str(quote_id),
        "status": str(status),
        "reason": str(reason),
    }
    if command_id is not None:
        payload["command_id"] = str(command_id)
    return [
        topic_quote_status(gateway_id).encode(),
        _msg.dumps(payload),
    ]


def parse_quote_status(frames: list[bytes]) -> "QuoteStatus":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_quote_status(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_QUOTE_STATUS!r}")
    payload = {**payload, "gateway_id": matched}
    obj = QuoteStatus.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_status() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_STATUS_FIELDS


TOPIC_QUOTE_CANCEL_ACK = "quote.cancel_ack.{gateway_id}"
PREFIX_QUOTE_CANCEL_ACK = "quote.cancel_ack."
_QUOTE_CANCEL_ACK_RE = re.compile("quote\\.cancel_ack\\.(?P<gateway_id>[^.]+)")


_QUOTE_CANCEL_ACK_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": 'The withdrawn quote\'s id; "" when there was none.',
        "constraints": {"max_len": 64},
    },
    {
        "name": "accepted",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 512},
    },
    {
        "name": "reject_code",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "On a refusal, a member of order.ack's `reject_code` vocabulary (ORDER_NOT_FOUND, ORDER_ALREADY_TERMINAL, GATEWAY_NOT_CONFIGURED, AUTH_REQUIRED); absent when accepted. A string rather than that enum only because the IDL has no shared enum type: the engine is held to the vocabulary by tests/test_engine_structure_cancel_acks.py.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "request_tag",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Echoed from the cancel request, so the caller can attribute the outcome.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "cancelled_order_ids",
        "type": "list",
        "unit": None,
        "required": False,
        "doc": "The engine order ids the cancel removed; empty on a refusal.",
    },
)


@dataclass(frozen=True, slots=True)
class QuoteCancelAck:
    """Engine to market maker: the outcome of a quote.cancel.

    Every cancel gets exactly one of these, accepted or refused, so a caller (REST's
    `?wait=ack`) can wait for its own outcome. Before WP-API17 a refusal rode the submit
    ack and a success had no group-level reply at all, so neither could be attributed to
    the request that asked.
    """

    gateway_id: str
    symbol: str
    accepted: bool
    quote_id: str = ""
    reason: str = ""
    reject_code: str = ""
    request_tag: str = ""
    cancelled_order_ids: list[str] = field(default_factory=list)

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if len(self.quote_id) > 64:
            raise MessageValidationError(
                f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
            )
        if len(self.reason) > 512:
            raise MessageValidationError(
                f"reason: length {len(self.reason)} exceeds max_len 512"
            )
        if len(self.reject_code) > 32:
            raise MessageValidationError(
                f"reject_code: length {len(self.reject_code)} exceeds max_len 32"
            )
        if len(self.request_tag) > 64:
            raise MessageValidationError(
                f"request_tag: length {len(self.request_tag)} exceeds max_len 64"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteCancelAck":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            symbol=str(p["symbol"]),
            quote_id=str(p.get("quote_id", "")),
            accepted=bool(p["accepted"]),
            reason=str(p.get("reason", "")),
            reject_code=str(p.get("reject_code", "")),
            request_tag=str(p.get("request_tag", "")),
            cancelled_order_ids=(
                [str(item) for item in p.get("cancelled_order_ids", [])]
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "symbol": self.symbol,
            "quote_id": self.quote_id,
            "accepted": self.accepted,
            "reason": self.reason,
            "cancelled_order_ids": self.cancelled_order_ids,
        }
        if self.reject_code:
            payload["reject_code"] = self.reject_code
        if self.request_tag:
            payload["request_tag"] = self.request_tag
        return payload


def topic_quote_cancel_ack(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"quote.cancel_ack.{gateway_id}"


def match_quote_cancel_ack(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _QUOTE_CANCEL_ACK_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_quote_cancel_ack(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteCancelAck.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_quote_cancel_ack(obj.gateway_id), obj.to_dict())


def make_quote_cancel_ack_unchecked(
    *,
    gateway_id: str,
    symbol: str,
    accepted: bool,
    quote_id: str = "",
    reason: str = "",
    reject_code: str = "",
    request_tag: str = "",
    cancelled_order_ids: list[str] = [],
) -> list[bytes]:
    """Identical frames to ``make_quote_cancel_ack``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "symbol": str(symbol),
        "quote_id": str(quote_id),
        "accepted": bool(accepted),
        "reason": str(reason),
        "cancelled_order_ids": [str(item) for item in cancelled_order_ids],
    }
    if reject_code:
        payload["reject_code"] = str(reject_code)
    if request_tag:
        payload["request_tag"] = str(request_tag)
    return [
        topic_quote_cancel_ack(gateway_id).encode(),
        _msg.dumps(payload),
    ]


def parse_quote_cancel_ack(frames: list[bytes]) -> "QuoteCancelAck":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_quote_cancel_ack(topic)
    if matched is None:
        raise MessageValidationError(
            f"topic {topic!r} is not {TOPIC_QUOTE_CANCEL_ACK!r}"
        )
    payload = {**payload, "gateway_id": matched}
    obj = QuoteCancelAck.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_cancel_ack() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_CANCEL_ACK_FIELDS


FAMILY_TOPICS: tuple[str, ...] = (
    TOPIC_QUOTE_NEW,
    TOPIC_QUOTE_CANCEL,
    TOPIC_QUOTE_ACK,
    TOPIC_QUOTE_STATUS,
    TOPIC_QUOTE_CANCEL_ACK,
)
