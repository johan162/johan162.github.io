"""
Domain models: Order, enums.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Optional

from edumatcher.models.clock import now_ns
from edumatcher.models.ids import new_order_id
from edumatcher.models.price import get_tick_decimals


class Side(str, Enum):
    BUY = "BUY"
    SELL = "SELL"


class OrderType(str, Enum):
    MARKET = "MARKET"
    LIMIT = "LIMIT"
    STOP = "STOP"
    STOP_LIMIT = "STOP_LIMIT"
    FOK = "FOK"
    ICEBERG = "ICEBERG"
    IOC = "IOC"  # Immediate-Or-Cancel: fill what you can, cancel rest
    TRAILING_STOP = (
        "TRAILING_STOP"  # Dynamic stop that trails market price by a fixed offset
    )


class TIF(str, Enum):
    DAY = "DAY"
    GTC = "GTC"
    ATO = "ATO"  # At-The-Open: valid only during opening auction, expires after
    ATC = "ATC"  # At-The-Close: valid only during closing auction, expires after


class OrderStatus(str, Enum):
    NEW = "NEW"
    PARTIAL = "PARTIAL"
    FILLED = "FILLED"
    CANCELLED = "CANCELLED"
    REJECTED = "REJECTED"
    EXPIRED = "EXPIRED"


class SmpAction(str, Enum):
    """
    Self Match Prevention action — applied when an incoming order would trade
    against a resting order from the same gateway.

    NONE             — explicitly disabled; self-trades are allowed
    CANCEL_AGGRESSOR — cancel the incoming order, resting order stays
    CANCEL_RESTING   — cancel the resting order, continue matching
    CANCEL_BOTH      — cancel both orders

    ``Order.smp_action`` (and ``ComboLeg.smp_action``) is typed
    ``SmpAction | None`` rather than defaulting to ``NONE`` outright: ``None``
    means the client did not specify ``SMP=`` at all, which is distinct from
    an *explicit* ``SMP=NONE`` (a deliberate request to allow self-trades).
    Client-facing processes (``alf_gwy``, ``alf_console``, ``api_gateway``)
    preserve that distinction when parsing the wire request; the engine
    resolves ``None`` to the order's gateway-configured default
    (``participants[].smp_action``, falling back to ``NONE`` itself if the
    gateway has none configured) before the order reaches the matching
    engine — see ``Engine._resolve_smp_action`` in ``engine/main.py``. Code
    that inspects ``Order.smp_action`` after that resolution point (e.g. the
    order book) can safely assume it is a concrete member, never ``None``.
    """

    NONE = "NONE"
    CANCEL_AGGRESSOR = "CANCEL_AGGRESSOR"
    CANCEL_RESTING = "CANCEL_RESTING"
    CANCEL_BOTH = "CANCEL_BOTH"


class OrderOrigin(str, Enum):
    """Source of the order in the matching engine."""

    ORDER = "ORDER"
    QUOTE = "QUOTE"
    IMPLIED = "IMPLIED"


# ---------------------------------------------------------------------------
# PERF improvement #5: Pre-built enum-by-value lookup dicts.
#
# Python's Enum(value) constructor iterates through all members doing string
# comparisons (~600-800ns per call).  A dict lookup is ~50ns.  With 6 enum
# constructions per Order.from_dict() call, this saves ~3-4µs per order on
# the hot path — a ~15-20% improvement for the deserialization step.
# ---------------------------------------------------------------------------
_SIDE_MAP: dict[str, Side] = {v.value: v for v in Side}
_TYPE_MAP: dict[str, OrderType] = {v.value: v for v in OrderType}
_TIF_MAP: dict[str, TIF] = {v.value: v for v in TIF}
_STATUS_MAP: dict[str, OrderStatus] = {v.value: v for v in OrderStatus}
_SMP_MAP: dict[str, SmpAction] = {v.value: v for v in SmpAction}
_ORIGIN_MAP: dict[str, OrderOrigin] = {v.value: v for v in OrderOrigin}

#: The integer fields ``Order.from_dict`` refuses in any other type; the four
#: optional ones may also be None.
_INT_FIELDS = (
    "quantity",
    "remaining_qty",
    "ts_ns",
    "tick_decimals",
    "price_ticks",
    "stop_price_ticks",
    "visible_qty",
    "trail_offset_ticks",
)


# ---------------------------------------------------------------------------
# PERF improvement #4: __slots__ on the Order dataclass.
#
# Without __slots__, each Order instance carries a __dict__ (hash table with
# 18 keys).  With __slots__, attributes are stored in a fixed-size C array,
# giving:
#   - ~30% faster attribute access (fixed offset vs. hash lookup)
#   - ~40% lower per-instance memory (no per-object dict overhead)
#   - Reduced GC pressure from thousands of resting orders on the book
#
# At 5+ attribute accesses per fill in the inner loop (remaining_qty, side,
# price, gateway_id, status), this saves ~1.5-2µs per aggressive order.
# ---------------------------------------------------------------------------
@dataclass(slots=True)
class Order:
    """One order, from the moment it arrives until it is filled or cancelled.

    The matching engine mutates this object IN PLACE as the order trades:
    the book changes ``remaining_qty`` and ``status`` and passes the very
    same object back to the engine to be reported.  Fields that matter most
    when reading ``engine/order_book.py``:

    * ``quantity``         the original size; never changes by trading.
    * ``remaining_qty``    what is still unfilled.  Hits 0 -> status FILLED.
    * ``status``           NEW -> PARTIAL -> FILLED, or CANCELLED / REJECTED /
                           EXPIRED.
                           Note a CANCELLED order usually still has
                           ``remaining_qty > 0``: always test ``status``.
    * ``price_ticks``      limit price as an INTEGER number of ticks (never a
                           float: no rounding error, exact dict keys).  None
                           for MARKET orders and plain stops.
    * ``stop_price_ticks`` the trigger price of a stop; see ``OrderBook``.
    * ``visible_qty`` / ``displayed_qty``  iceberg only: the fixed slice size
                           chosen by the client, and how much of the current
                           slice is still showing.
    * ``arrival_seq``      the engine-assigned queue position (time priority);
                           NOT the client's ``ts_ns``.
    * ``gateway_id``       the participant; the unit for self-match prevention.

    ``order_type`` is mutable on purpose: when a stop triggers it is
    rewritten to the order type it becomes (STOP -> MARKET, STOP_LIMIT ->
    LIMIT) and then matched like a new order.
    """

    id: str
    symbol: str
    side: Side
    order_type: OrderType
    tif: TIF
    quantity: int  # total original quantity
    remaining_qty: int  # quantity yet to be filled
    gateway_id: str
    ts_ns: int
    status: OrderStatus
    # Decimal scale of every `_ticks` field below. Stored rather than looked up
    # from the symbol registry at serialisation time, because a resting order
    # restored from persistence holds ticks at the scale in force when it was
    # written: deriving the current scale would silently reprice it if the
    # symbol's configuration ever changed.
    tick_decimals: int

    price_ticks: Optional[int] = (
        None  # limit / stop-limit / FOK / iceberg limit price (ticks)
    )
    # STOP / STOP_LIMIT / TRAILING_STOP trigger price
    stop_price_ticks: Optional[int] = None
    visible_qty: Optional[int] = None  # ICEBERG: fixed peak size
    displayed_qty: Optional[int] = None  # ICEBERG: current visible slice on book
    # Self-match prevention. None means "not yet resolved": either the client
    # omitted SMP= (engine should apply the gateway's configured default) or
    # this Order predates resolution (e.g. an unresolved ComboLeg). By the
    # time an Order reaches the matching engine / order book, this is always
    # a concrete SmpAction — see SmpAction's docstring.
    smp_action: Optional[SmpAction] = None

    # Trailing stop field
    trail_offset_ticks: Optional[int] = (
        None  # TRAILING_STOP: fixed distance to trail market price
    )

    # OCO-order field (shared group ID for two linked orders)
    oco_group_id: Optional[str] = None  # OCO pair group identifier

    # Combo-order fields (set only on child orders of a combo)
    combo_parent_id: Optional[str] = None  # parent ComboOrder.id
    leg_index: Optional[int] = None  # position in combo legs list (0-based)

    # Source metadata
    origin: OrderOrigin = OrderOrigin.ORDER
    quote_id: Optional[str] = None

    # True when this order was created by config-driven startup seeding
    # (market_maker_quotes / market_maker_combos in the engine config) rather
    # than a live gateway submission. Purely observational — nothing in the
    # engine branches on it; `origin` still governs routing (see
    # spec/messages/order.yaml::OrderDisplay.is_seed for the full rationale).
    is_seed: bool = False

    # Client-supplied order tag — echoed back on every lifecycle event
    # (ack, fill, cancelled, expired) so subscribers can correlate without
    # a FIFO matching scheme.  Optional; ignored when absent.
    client_tag: Optional[str] = None

    # Engine-assigned monotonic arrival sequence (finding H1).  Time priority
    # in the book is keyed on this, NOT on the client-supplied `ts_ns`,
    # so a back-dated payload timestamp cannot jump the price-time queue.
    # Assigned by OrderBook when the order is placed on a heap; 0 = unassigned.
    arrival_seq: int = 0
    # Σ price_ticks × qty of every fill so far: with quantity - remaining_qty,
    # the exact average price (order.fill.cum_notional_ticks). Engine state,
    # not part of the order a client sends: absent from to_dict() (order.new
    # is built from it), written by the persistence file and read back by
    # from_dict, so a restart does not reset it.
    cum_notional_ticks: int = 0

    # Why the *exchange* cancelled this order, set by OrderBook when it makes
    # that decision itself (self-match prevention, an unfillable MARKET/IOC
    # remainder) and read by the engine when it publishes order.cancelled.
    # Deliberately absent from to_dict(): it is a marker carried on the event
    # object between the book and the publisher for the duration of one
    # handler call, not part of the order's persisted or wire representation.
    # A client cancel leaves it None.
    cancel_reason: Optional[str] = None

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------
    @classmethod
    def create(
        cls,
        symbol: str,
        side: Side,
        order_type: OrderType,
        quantity: int,
        gateway_id: str,
        tif: TIF = TIF.DAY,
        price_ticks: Optional[int] = None,
        stop_price_ticks: Optional[int] = None,
        visible_qty: Optional[int] = None,
        smp_action: Optional[SmpAction] = None,
        trail_offset_ticks: Optional[int] = None,
        oco_group_id: Optional[str] = None,
        client_tag: Optional[str] = None,
        is_seed: bool = False,
        tick_decimals: Optional[int] = None,
    ) -> "Order":
        displayed = visible_qty if order_type == OrderType.ICEBERG else None
        return cls(
            id=new_order_id(),
            symbol=symbol,
            side=side,
            order_type=order_type,
            tif=tif,
            quantity=quantity,
            remaining_qty=quantity,
            gateway_id=gateway_id,
            ts_ns=now_ns(),
            status=OrderStatus.NEW,
            # Resolved from the symbol registry here, at the one moment the
            # order's ticks are chosen, and carried from then on.
            tick_decimals=(
                get_tick_decimals(symbol) if tick_decimals is None else tick_decimals
            ),
            price_ticks=price_ticks,
            stop_price_ticks=stop_price_ticks,
            visible_qty=visible_qty,
            displayed_qty=displayed,
            smp_action=smp_action,
            trail_offset_ticks=trail_offset_ticks,
            oco_group_id=oco_group_id,
            client_tag=client_tag,
            is_seed=is_seed,
        )

    # ------------------------------------------------------------------
    # Serialization helpers
    # ------------------------------------------------------------------
    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "symbol": self.symbol,
            "side": self.side.value,
            "order_type": self.order_type.value,
            "tif": self.tif.value,
            "quantity": self.quantity,
            "remaining_qty": self.remaining_qty,
            "gateway_id": self.gateway_id,
            "tick_decimals": self.tick_decimals,
            "trail_offset_ticks": self.trail_offset_ticks,
            "oco_group_id": self.oco_group_id,
            "ts_ns": self.ts_ns,
            "status": self.status.value,
            "price_ticks": self.price_ticks,
            "stop_price_ticks": self.stop_price_ticks,
            "visible_qty": self.visible_qty,
            "displayed_qty": self.displayed_qty,
            "smp_action": (
                self.smp_action.value if self.smp_action is not None else None
            ),
            "combo_parent_id": self.combo_parent_id,
            "leg_index": self.leg_index,
            "origin": self.origin.value,
            "is_seed": self.is_seed,
            "quote_id": self.quote_id,
            "client_tag": self.client_tag,
            "arrival_seq": self.arrival_seq,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Order":
        # PERF #5 + #10: Bypass the dataclass __init__ (which parses 19 kwargs)
        # and write slots directly via __new__.  Combined with pre-built enum
        # lookup dicts, this reduces Order.from_dict from ~1400ns to ~1000ns.
        #
        # The dataclass-generated __init__ uses LOAD_FAST for each of the 19
        # parameters, then STORE_ATTR for each slot — but the function call
        # overhead of 19 keyword arguments dominates (~400ns just for arg
        # dispatch).  __new__ + direct slot writes avoids this entirely.
        o = object.__new__(cls)
        o.id = d["id"]
        o.symbol = d["symbol"]
        o.side = _SIDE_MAP[d["side"]]
        o.order_type = _TYPE_MAP[d["order_type"]]
        o.tif = _TIF_MAP[d["tif"]]
        o.quantity = d["quantity"]
        o.remaining_qty = d["remaining_qty"]
        o.gateway_id = d["gateway_id"]
        o.ts_ns = d["ts_ns"]
        o.status = _STATUS_MAP[d["status"]]
        o.tick_decimals = d["tick_decimals"]
        o.price_ticks = d.get("price_ticks")
        o.stop_price_ticks = d.get("stop_price_ticks")
        o.visible_qty = d.get("visible_qty")
        o.displayed_qty = d.get("displayed_qty")
        # Absent key or explicit null both mean "client did not specify" —
        # preserved as None (see SmpAction's docstring), not silently
        # defaulted to SmpAction.NONE, so the engine can still tell the
        # difference from an explicit SMP=NONE and apply a gateway default.
        # Any other value must be a known action: a typo is not "omitted".
        _smp_raw = d.get("smp_action")
        if _smp_raw is None:
            o.smp_action = None
        elif _smp_raw in _SMP_MAP:
            o.smp_action = _SMP_MAP[_smp_raw]
        else:
            raise ValueError(f"unknown smp_action: {_smp_raw!r}")
        o.trail_offset_ticks = d.get("trail_offset_ticks")
        o.oco_group_id = d.get("oco_group_id")
        o.combo_parent_id = d.get("combo_parent_id")
        o.leg_index = d.get("leg_index")
        o.origin = _ORIGIN_MAP.get(d.get("origin", "ORDER"), OrderOrigin.ORDER)
        o.is_seed = bool(d.get("is_seed", False))
        o.quote_id = d.get("quote_id")
        o.client_tag = d.get("client_tag")
        o.arrival_seq = d.get("arrival_seq", 0)
        o.cum_notional_ticks = d.get("cum_notional_ticks", 0)
        # Not carried on the wire (see the field comment): __new__ bypasses the
        # dataclass default, so the slot must be initialised here or the first
        # read raises AttributeError.
        o.cancel_reason = None
        # This is the engine's decoder for order.new, and it copies values as
        # they arrive. A float tick count would rest off the grid and print as
        # a display price 10**tick_decimals too large; a float or string
        # quantity would break the book's arithmetic. One expression on the
        # path every order takes; the loop below only names the culprit.
        # `type(v) is int` also refuses bool, which is an int subclass.
        if not (
            type(o.quantity) is int
            and type(o.remaining_qty) is int
            and type(o.ts_ns) is int
            and type(o.tick_decimals) is int
            and (o.price_ticks is None or type(o.price_ticks) is int)
            and (o.stop_price_ticks is None or type(o.stop_price_ticks) is int)
            and (o.visible_qty is None or type(o.visible_qty) is int)
            and (o.trail_offset_ticks is None or type(o.trail_offset_ticks) is int)
        ):
            for name in _INT_FIELDS:
                value = getattr(o, name)
                if value is not None and type(value) is not int:
                    raise ValueError(f"{name} must be an integer, not {value!r}")
        return o
