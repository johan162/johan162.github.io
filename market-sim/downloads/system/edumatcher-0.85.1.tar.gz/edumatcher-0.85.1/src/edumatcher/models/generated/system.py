# GENERATED FROM spec/messages/system.yaml - DO NOT EDIT
#
# Regenerate with:  poetry run pm-msgen generate
"""Generated bindings for the ``system`` message family.

Family version 1. Every symbol here is derived from ``spec/messages/system.yaml``; edit
the spec, not this file.

``pm-msgen check`` fails the build if this file and the spec disagree. See
../../../../docs/books/architecture-and-development/part-4-developing/040-message-
generation.md.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Literal, Mapping, cast

from edumatcher.models import message as _msg
from edumatcher.models.generated._runtime import MessageValidationError

FAMILY = "system"
FAMILY_VERSION = 1


@dataclass(frozen=True, slots=True)
class SymbolInfo:
    """One tradable instrument, as the engine sees it for a given caller. What used
    to be one entry of `symbols` and one entry of `symbol_meta`, which were always
    the same instrument written twice. The market-maker fields are resolved per
    caller, not per symbol: the engine layers the gateway's own policy, the global
    per-symbol policy and the gateway's per-symbol override before publishing. Two
    gateways asking at the same moment get different values for the same
    instrument, which is why they travel on this reply rather than in the
    reference bundle.
    """

    symbol: str
    tick_decimals: int  # unit: dimensionless
    enforce_mm_obligation: bool | None = None
    mm_max_spread_ticks: int | None = None  # unit: ticks
    mm_min_qty: int | None = None  # unit: shares
    prev_close: float | None = None  # unit: display_price

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.tick_decimals < 0:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be >= 0"
            )
        if self.tick_decimals > 9:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be <= 9"
            )
        if self.mm_max_spread_ticks is not None:
            if self.mm_max_spread_ticks < 0:
                raise MessageValidationError(
                    f"mm_max_spread_ticks: {self.mm_max_spread_ticks!r} must be >= 0"
                )
        if self.mm_min_qty is not None:
            if self.mm_min_qty < 0:
                raise MessageValidationError(
                    f"mm_min_qty: {self.mm_min_qty!r} must be >= 0"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SymbolInfo":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            tick_decimals=int(p["tick_decimals"]),
            enforce_mm_obligation=(
                None
                if p.get("enforce_mm_obligation") is None
                else bool(p["enforce_mm_obligation"])
            ),
            mm_max_spread_ticks=(
                None
                if p.get("mm_max_spread_ticks") is None
                else int(p["mm_max_spread_ticks"])
            ),
            mm_min_qty=None if p.get("mm_min_qty") is None else int(p["mm_min_qty"]),
            prev_close=None if p.get("prev_close") is None else float(p["prev_close"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "symbol": self.symbol,
            "tick_decimals": self.tick_decimals,
        }
        if self.enforce_mm_obligation is not None:
            payload["enforce_mm_obligation"] = self.enforce_mm_obligation
        if self.mm_max_spread_ticks is not None:
            payload["mm_max_spread_ticks"] = self.mm_max_spread_ticks
        if self.mm_min_qty is not None:
            payload["mm_min_qty"] = self.mm_min_qty
        if self.prev_close is not None:
            payload["prev_close"] = self.prev_close
        return payload


@dataclass(frozen=True, slots=True)
class Collar:
    """Price-band configuration. The two bands `CollarConfig` reads; a deployment
    writing other keys under `collar:` in its YAML had them carried onto the wire
    and read by nothing, and they no longer travel.
    """

    static_band_pct: float  # unit: percent
    dynamic_band_pct: float  # unit: percent

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.static_band_pct < 0:
            raise MessageValidationError(
                f"static_band_pct: {self.static_band_pct!r} must be >= 0"
            )
        if self.dynamic_band_pct < 0:
            raise MessageValidationError(
                f"dynamic_band_pct: {self.dynamic_band_pct!r} must be >= 0"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Collar":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            static_band_pct=float(p["static_band_pct"]),
            dynamic_band_pct=float(p["dynamic_band_pct"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "static_band_pct": self.static_band_pct,
            "dynamic_band_pct": self.dynamic_band_pct,
        }


@dataclass(frozen=True, slots=True)
class OrderLimits:
    """Pre-trade order-size and notional caps, as configured on a symbol. Each cap is
    independently optional: an absent cap is not enforced, the same way an absent
    `collar` leaves a symbol uncollared.
    """

    max_order_qty: int | None = None  # unit: shares
    max_order_value: float | None = None  # unit: money

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.max_order_qty is not None:
            if self.max_order_qty <= 0:
                raise MessageValidationError(
                    f"max_order_qty: {self.max_order_qty!r} must be > 0"
                )
        if self.max_order_value is not None:
            if self.max_order_value <= 0:
                raise MessageValidationError(
                    f"max_order_value: {self.max_order_value!r} must be > 0"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "OrderLimits":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            max_order_qty=(
                None if p.get("max_order_qty") is None else int(p["max_order_qty"])
            ),
            max_order_value=(
                None
                if p.get("max_order_value") is None
                else float(p["max_order_value"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {}
        if self.max_order_qty is not None:
            payload["max_order_qty"] = self.max_order_qty
        if self.max_order_value is not None:
            payload["max_order_value"] = self.max_order_value
        return payload


@dataclass(frozen=True, slots=True)
class CircuitBreakerLevel:
    """One rung of a symbol's circuit-breaker ladder, as configured. `name` is the
    string `circuit_breaker.halt.level` and `admin.action.scope.level` carry
    onward, and is bounded here to match them.
    """

    name: str
    price_shift_pct: float  # unit: percent
    halt_duration_ns: int | None  # unit: duration_nanos

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.name) > 32:
            raise MessageValidationError(
                f"name: length {len(self.name)} exceeds max_len 32"
            )
        if self.price_shift_pct <= 0:
            raise MessageValidationError(
                f"price_shift_pct: {self.price_shift_pct!r} must be > 0"
            )
        if self.halt_duration_ns is not None:
            if self.halt_duration_ns < 0:
                raise MessageValidationError(
                    f"halt_duration_ns: {self.halt_duration_ns!r} must be >= 0"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "CircuitBreakerLevel":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            name=str(p["name"]),
            price_shift_pct=float(p["price_shift_pct"]),
            halt_duration_ns=(
                None
                if p.get("halt_duration_ns") is None
                else int(p["halt_duration_ns"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "name": self.name,
            "price_shift_pct": self.price_shift_pct,
            "halt_duration_ns": self.halt_duration_ns,
        }


@dataclass(frozen=True, slots=True)
class SymbolCircuitBreaker:
    """A symbol's configured circuit-breaker ladder and its lookback."""

    reference_window_ns: int  # unit: duration_nanos
    levels: list[CircuitBreakerLevel]

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.reference_window_ns < 0:
            raise MessageValidationError(
                f"reference_window_ns: {self.reference_window_ns!r} must be >= 0"
            )
        for levels_item in self.levels:
            levels_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SymbolCircuitBreaker":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            reference_window_ns=int(p["reference_window_ns"]),
            levels=[CircuitBreakerLevel.from_dict(item) for item in p["levels"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "reference_window_ns": self.reference_window_ns,
            "levels": [item.to_dict() for item in self.levels],
        }


_CHECKPOINT_ORDER_SIDE_VALUES = ("BUY", "SELL")
CheckpointOrderSide = Literal["BUY", "SELL"]
_CHECKPOINT_ORDER_ORDER_TYPE_VALUES = (
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
)
CheckpointOrderOrderType = Literal[
    "MARKET",
    "LIMIT",
    "STOP",
    "STOP_LIMIT",
    "FOK",
    "ICEBERG",
    "IOC",
    "TRAILING_STOP",
]
_CHECKPOINT_ORDER_TIF_VALUES = ("DAY", "GTC", "ATO", "ATC")
CheckpointOrderTif = Literal["DAY", "GTC", "ATO", "ATC"]


@dataclass(frozen=True, slots=True)
class CheckpointOrder:
    """One order as a book checkpoint holds it: enough to rebuild the book exactly --
    its place in the queue, hidden iceberg quantity, its stop and trailing
    triggers, and the links to its quote, OCO pair or combo.
    """

    order_id: str
    gateway_id: str
    side: CheckpointOrderSide
    order_type: CheckpointOrderOrderType
    tif: CheckpointOrderTif
    quantity: int  # unit: shares
    remaining_qty: int  # unit: shares
    price_ticks: int | None = None  # unit: ticks
    stop_price_ticks: int | None = None  # unit: ticks
    trail_offset_ticks: int | None = None  # unit: ticks
    visible_qty: int | None = None  # unit: shares
    displayed_qty: int | None = None  # unit: shares
    priority_seq: int | None = None  # unit: dimensionless
    smp_action: str | None = None
    oco_group_id: str | None = None
    quote_id: str | None = None
    combo_parent_id: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if self.side not in _CHECKPOINT_ORDER_SIDE_VALUES:
            raise MessageValidationError(
                f"side: {self.side!r} is not one of {_CHECKPOINT_ORDER_SIDE_VALUES!r}"
            )
        if self.order_type not in _CHECKPOINT_ORDER_ORDER_TYPE_VALUES:
            raise MessageValidationError(
                f"order_type: {self.order_type!r} is not one of {_CHECKPOINT_ORDER_ORDER_TYPE_VALUES!r}"
            )
        if self.tif not in _CHECKPOINT_ORDER_TIF_VALUES:
            raise MessageValidationError(
                f"tif: {self.tif!r} is not one of {_CHECKPOINT_ORDER_TIF_VALUES!r}"
            )
        if self.quantity < 0:
            raise MessageValidationError(f"quantity: {self.quantity!r} must be >= 0")
        if self.remaining_qty < 0:
            raise MessageValidationError(
                f"remaining_qty: {self.remaining_qty!r} must be >= 0"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "CheckpointOrder":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            order_id=str(p["order_id"]),
            gateway_id=str(p["gateway_id"]),
            side=cast(CheckpointOrderSide, str(p["side"])),
            order_type=cast(CheckpointOrderOrderType, str(p["order_type"])),
            tif=cast(CheckpointOrderTif, str(p["tif"])),
            quantity=int(p["quantity"]),
            remaining_qty=int(p["remaining_qty"]),
            price_ticks=None if p.get("price_ticks") is None else int(p["price_ticks"]),
            stop_price_ticks=(
                None
                if p.get("stop_price_ticks") is None
                else int(p["stop_price_ticks"])
            ),
            trail_offset_ticks=(
                None
                if p.get("trail_offset_ticks") is None
                else int(p["trail_offset_ticks"])
            ),
            visible_qty=None if p.get("visible_qty") is None else int(p["visible_qty"]),
            displayed_qty=(
                None if p.get("displayed_qty") is None else int(p["displayed_qty"])
            ),
            priority_seq=(
                None if p.get("priority_seq") is None else int(p["priority_seq"])
            ),
            smp_action=None if p.get("smp_action") is None else str(p["smp_action"]),
            oco_group_id=(
                None if p.get("oco_group_id") is None else str(p["oco_group_id"])
            ),
            quote_id=None if p.get("quote_id") is None else str(p["quote_id"]),
            combo_parent_id=(
                None if p.get("combo_parent_id") is None else str(p["combo_parent_id"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
            "gateway_id": self.gateway_id,
            "side": self.side,
            "order_type": self.order_type,
            "tif": self.tif,
            "quantity": self.quantity,
            "remaining_qty": self.remaining_qty,
        }
        if self.price_ticks is not None:
            payload["price_ticks"] = self.price_ticks
        if self.stop_price_ticks is not None:
            payload["stop_price_ticks"] = self.stop_price_ticks
        if self.trail_offset_ticks is not None:
            payload["trail_offset_ticks"] = self.trail_offset_ticks
        if self.visible_qty is not None:
            payload["visible_qty"] = self.visible_qty
        if self.displayed_qty is not None:
            payload["displayed_qty"] = self.displayed_qty
        if self.priority_seq is not None:
            payload["priority_seq"] = self.priority_seq
        if self.smp_action is not None:
            payload["smp_action"] = self.smp_action
        if self.oco_group_id is not None:
            payload["oco_group_id"] = self.oco_group_id
        if self.quote_id is not None:
            payload["quote_id"] = self.quote_id
        if self.combo_parent_id is not None:
            payload["combo_parent_id"] = self.combo_parent_id
        return payload


@dataclass(frozen=True, slots=True)
class LoadedFile:
    """One persistence file the engine read at startup, identified by its bytes: a
    replay can tell which state the run started from.
    """

    name: str
    entries: int  # unit: dimensionless
    sha256: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.name) > 64:
            raise MessageValidationError(
                f"name: length {len(self.name)} exceeds max_len 64"
            )
        if self.sha256 is not None:
            if len(self.sha256) > 64:
                raise MessageValidationError(
                    f"sha256: length {len(self.sha256)} exceeds max_len 64"
                )
        if self.entries < 0:
            raise MessageValidationError(f"entries: {self.entries!r} must be >= 0")

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "LoadedFile":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            name=str(p["name"]),
            sha256=None if p.get("sha256") is None else str(p["sha256"]),
            entries=int(p["entries"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "name": self.name,
            "sha256": self.sha256,
            "entries": self.entries,
        }


@dataclass(frozen=True, slots=True)
class ReferenceSymbol:
    """One instrument's static configuration. Distinct from `SymbolInfo`, which is
    the same instrument as a *caller* sees it: this record is identical for every
    caller and changes only on reload, which is why the bundle can be cached and
    hashed and the symbols reply cannot.
    """

    symbol: str
    tick_decimals: int  # unit: dimensionless
    level: str | None = None
    collar: Collar | None = None
    order_limits: OrderLimits | None = None
    circuit_breaker: SymbolCircuitBreaker | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.tick_decimals < 0:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be >= 0"
            )
        if self.tick_decimals > 9:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be <= 9"
            )
        if self.level is not None:
            if len(self.level) > 32:
                raise MessageValidationError(
                    f"level: length {len(self.level)} exceeds max_len 32"
                )
        if self.collar is not None:
            self.collar.validate()
        if self.order_limits is not None:
            self.order_limits.validate()
        if self.circuit_breaker is not None:
            self.circuit_breaker.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "ReferenceSymbol":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            tick_decimals=int(p["tick_decimals"]),
            level=None if p.get("level") is None else str(p["level"]),
            collar=None if p.get("collar") is None else Collar.from_dict(p["collar"]),
            order_limits=(
                None
                if p.get("order_limits") is None
                else OrderLimits.from_dict(p["order_limits"])
            ),
            circuit_breaker=(
                None
                if p.get("circuit_breaker") is None
                else SymbolCircuitBreaker.from_dict(p["circuit_breaker"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "symbol": self.symbol,
            "tick_decimals": self.tick_decimals,
        }
        if self.level is not None:
            payload["level"] = self.level
        if self.collar is not None:
            payload["collar"] = self.collar.to_dict()
        if self.order_limits is not None:
            payload["order_limits"] = self.order_limits.to_dict()
        if self.circuit_breaker is not None:
            payload["circuit_breaker"] = self.circuit_breaker.to_dict()
        return payload


@dataclass(frozen=True, slots=True)
class RiskLevel:
    """One named risk-control level. Was a map entry keyed by `name`; section 19.2's
    shape, with the key as a field.
    """

    name: str
    collar: Collar | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.name) > 32:
            raise MessageValidationError(
                f"name: length {len(self.name)} exceeds max_len 32"
            )
        if self.collar is not None:
            self.collar.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "RiskLevel":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            name=str(p["name"]),
            collar=None if p.get("collar") is None else Collar.from_dict(p["collar"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "name": self.name,
        }
        if self.collar is not None:
            payload["collar"] = self.collar.to_dict()
        return payload


@dataclass(frozen=True, slots=True)
class ReferenceRisk:
    """The risk-control ladder as configured, and which rung is the default."""

    levels: list[RiskLevel]
    default_level: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.default_level is not None:
            if len(self.default_level) > 32:
                raise MessageValidationError(
                    f"default_level: length {len(self.default_level)} exceeds max_len 32"
                )
        for levels_item in self.levels:
            levels_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "ReferenceRisk":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            default_level=(
                None if p.get("default_level") is None else str(p["default_level"])
            ),
            levels=[RiskLevel.from_dict(item) for item in p["levels"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "levels": [item.to_dict() for item in self.levels],
        }
        if self.default_level is not None:
            payload["default_level"] = self.default_level
        return payload


@dataclass(frozen=True, slots=True)
class SessionTimes:
    """The trading day's clock, as five wall-clock times. Carried by
    `system.session_schedule` and, nested inside `ReferenceSchedule`, by
    `system.reference` -- one shape declared once rather than two declarations
    that can drift apart. The values are strings because that is what the config
    file holds and what every consumer renders. Individually nullable at the wire
    level for structural uniformity, though in practice all five are always
    populated together: `config_loader` rejects a `schedule:` day block that
    defines some of the five keys but not all.
    """

    pre_open: str | None = None
    opening_auction_start: str | None = None
    continuous_start: str | None = None
    closing_auction_start: str | None = None
    closing_auction_end: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.pre_open is not None:
            if len(self.pre_open) > 32:
                raise MessageValidationError(
                    f"pre_open: length {len(self.pre_open)} exceeds max_len 32"
                )
        if self.opening_auction_start is not None:
            if len(self.opening_auction_start) > 32:
                raise MessageValidationError(
                    f"opening_auction_start: length {len(self.opening_auction_start)} exceeds max_len 32"
                )
        if self.continuous_start is not None:
            if len(self.continuous_start) > 32:
                raise MessageValidationError(
                    f"continuous_start: length {len(self.continuous_start)} exceeds max_len 32"
                )
        if self.closing_auction_start is not None:
            if len(self.closing_auction_start) > 32:
                raise MessageValidationError(
                    f"closing_auction_start: length {len(self.closing_auction_start)} exceeds max_len 32"
                )
        if self.closing_auction_end is not None:
            if len(self.closing_auction_end) > 32:
                raise MessageValidationError(
                    f"closing_auction_end: length {len(self.closing_auction_end)} exceeds max_len 32"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SessionTimes":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            pre_open=None if p.get("pre_open") is None else str(p["pre_open"]),
            opening_auction_start=(
                None
                if p.get("opening_auction_start") is None
                else str(p["opening_auction_start"])
            ),
            continuous_start=(
                None
                if p.get("continuous_start") is None
                else str(p["continuous_start"])
            ),
            closing_auction_start=(
                None
                if p.get("closing_auction_start") is None
                else str(p["closing_auction_start"])
            ),
            closing_auction_end=(
                None
                if p.get("closing_auction_end") is None
                else str(p["closing_auction_end"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "pre_open": self.pre_open,
            "opening_auction_start": self.opening_auction_start,
            "continuous_start": self.continuous_start,
            "closing_auction_start": self.closing_auction_start,
            "closing_auction_end": self.closing_auction_end,
        }


@dataclass(frozen=True, slots=True)
class NextTransition:
    """The next session transition: what the session moves to, and when. The same
    record as `session`'s NextTransition, declared again because a type cannot be
    shared across families; the wire shape is identical.
    """

    state: str
    at: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.state) > 32:
            raise MessageValidationError(
                f"state: length {len(self.state)} exceeds max_len 32"
            )
        if len(self.at) > 32:
            raise MessageValidationError(
                f"at: length {len(self.at)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "NextTransition":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            state=str(p["state"]),
            at=str(p["at"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "state": self.state,
            "at": self.at,
        }


@dataclass(frozen=True, slots=True)
class Holiday:
    """One bank holiday in the exchange's holiday calendar."""

    date: str
    name: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.date) > 10:
            raise MessageValidationError(
                f"date: length {len(self.date)} exceeds max_len 10"
            )
        if len(self.name) > 64:
            raise MessageValidationError(
                f"name: length {len(self.name)} exceeds max_len 64"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Holiday":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            date=str(p["date"]),
            name=str(p["name"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "date": self.date,
            "name": self.name,
        }


@dataclass(frozen=True, slots=True)
class WeeklySchedule:
    """A fully-resolved weekly session schedule: one `SessionTimes` per weekday
    (mon..sun, any of which may be null for CLOSED) plus a separate holidays
    entry, mirroring `edumatcher.engine.config_loader.ScheduleConfig`. The
    `weekdays`/ `weekend` shortcuts and per-day overrides in the YAML are already
    resolved by the time this is built -- every field here is one concrete day,
    never a shortcut. `today`/`today_is_holiday` are a server-computed
    convenience: the engine already runs the same `python-holidays` lookup for pm-
    scheduler, so it resolves "which entry applies right now" once and publishes
    the answer, rather than making every client (in particular a browser) carry
    its own holiday calendar just to answer that one question. `today` is still
    `SessionTimes | null` -- null means CLOSED today, exactly like any other day
    slot. "Today" is the business date in the session timezone
    (`locale.session_timezone`), resolved for each reply, so a long run never
    reports yesterday. `upcoming_holidays` answers the next question, "when is the
    exchange next on its holiday schedule", the same way. It is computed when the
    record is built and covers a year, so a client picks the first entry on or
    after its own today rather than trusting the list to start there.
    """

    today_is_holiday: bool
    upcoming_holidays: list[Holiday]
    mon: SessionTimes | None = None
    tue: SessionTimes | None = None
    wed: SessionTimes | None = None
    thu: SessionTimes | None = None
    fri: SessionTimes | None = None
    sat: SessionTimes | None = None
    sun: SessionTimes | None = None
    holidays: SessionTimes | None = None
    today: SessionTimes | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.mon is not None:
            self.mon.validate()
        if self.tue is not None:
            self.tue.validate()
        if self.wed is not None:
            self.wed.validate()
        if self.thu is not None:
            self.thu.validate()
        if self.fri is not None:
            self.fri.validate()
        if self.sat is not None:
            self.sat.validate()
        if self.sun is not None:
            self.sun.validate()
        if self.holidays is not None:
            self.holidays.validate()
        if self.today is not None:
            self.today.validate()
        if len(self.upcoming_holidays) > 64:
            raise MessageValidationError("upcoming_holidays: more than 64 item(s)")
        for upcoming_holidays_item in self.upcoming_holidays:
            upcoming_holidays_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "WeeklySchedule":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            mon=None if p.get("mon") is None else SessionTimes.from_dict(p["mon"]),
            tue=None if p.get("tue") is None else SessionTimes.from_dict(p["tue"]),
            wed=None if p.get("wed") is None else SessionTimes.from_dict(p["wed"]),
            thu=None if p.get("thu") is None else SessionTimes.from_dict(p["thu"]),
            fri=None if p.get("fri") is None else SessionTimes.from_dict(p["fri"]),
            sat=None if p.get("sat") is None else SessionTimes.from_dict(p["sat"]),
            sun=None if p.get("sun") is None else SessionTimes.from_dict(p["sun"]),
            holidays=(
                None
                if p.get("holidays") is None
                else SessionTimes.from_dict(p["holidays"])
            ),
            today=(
                None if p.get("today") is None else SessionTimes.from_dict(p["today"])
            ),
            today_is_holiday=bool(p["today_is_holiday"]),
            upcoming_holidays=(
                [Holiday.from_dict(item) for item in p["upcoming_holidays"]]
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "mon": None if self.mon is None else self.mon.to_dict(),
            "tue": None if self.tue is None else self.tue.to_dict(),
            "wed": None if self.wed is None else self.wed.to_dict(),
            "thu": None if self.thu is None else self.thu.to_dict(),
            "fri": None if self.fri is None else self.fri.to_dict(),
            "sat": None if self.sat is None else self.sat.to_dict(),
            "sun": None if self.sun is None else self.sun.to_dict(),
            "holidays": None if self.holidays is None else self.holidays.to_dict(),
            "today": None if self.today is None else self.today.to_dict(),
            "today_is_holiday": self.today_is_holiday,
            "upcoming_holidays": [item.to_dict() for item in self.upcoming_holidays],
        }


@dataclass(frozen=True, slots=True)
class ReferenceSchedule:
    """The venue's calendar configuration: whether sessions run at all, which
    country's holidays they observe, and the resolved weekly clock. `schedule` is
    nested rather than flattened beside its two siblings, which is a change to
    `GET /reference/schedule`. The alternative was declaring `WeeklySchedule`'s
    fields a second time inline, and a shape described twice is the drift section
    1 is about.
    """

    sessions_enabled: bool
    country: str | None = None
    schedule: WeeklySchedule | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.country is not None:
            if len(self.country) > 2:
                raise MessageValidationError(
                    f"country: length {len(self.country)} exceeds max_len 2"
                )
        if self.schedule is not None:
            self.schedule.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "ReferenceSchedule":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            sessions_enabled=bool(p["sessions_enabled"]),
            country=None if p.get("country") is None else str(p["country"]),
            schedule=(
                None
                if p.get("schedule") is None
                else WeeklySchedule.from_dict(p["schedule"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "sessions_enabled": self.sessions_enabled,
            "schedule": None if self.schedule is None else self.schedule.to_dict(),
        }
        if self.country is not None:
            payload["country"] = self.country
        return payload


@dataclass(frozen=True, slots=True)
class IndexDefinition:
    """One index as configured -- its membership and its starting level, not its
    current one. `GET /history/index-daily` serves the live value; see
    `index.rebalance`.
    """

    id: str
    base_value: float  # unit: dimensionless
    constituents: list[str]
    description: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.id) > 32:
            raise MessageValidationError(
                f"id: length {len(self.id)} exceeds max_len 32"
            )
        if len(self.description) > 128:
            raise MessageValidationError(
                f"description: length {len(self.description)} exceeds max_len 128"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "IndexDefinition":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            id=str(p["id"]),
            description=str(p.get("description", "")),
            base_value=float(p["base_value"]),
            constituents=[str(item) for item in p["constituents"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "id": self.id,
            "description": self.description,
            "base_value": self.base_value,
            "constituents": self.constituents,
        }


@dataclass(frozen=True, slots=True)
class EodBookLevel:
    """One aggregated price level of a closing book. The same three fields as
    `book.BookLevel`, redeclared because records are family-scoped and the IDL has
    no cross-family reference -- see design section 28.5 on why that stays a known
    duplication rather than becoming a shared-types construct on the strength of
    one instance. `price` is required here. `BookLevelPayload`, the hand-written
    dataclass this replaces, made it optional; the only producer is
    `OrderBook.snapshot()`, which has never emitted a level without one.
    """

    price: float  # unit: display_price
    qty: int  # unit: shares
    count: int  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        return None

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "EodBookLevel":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            price=float(p["price"]),
            qty=int(p["qty"]),
            count=int(p["count"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "price": self.price,
            "qty": self.qty,
            "count": self.count,
        }


@dataclass(frozen=True, slots=True)
class EodBook:
    """One symbol's closing book. A deliberately trimmed `book.book_snapshot`:
    `SystemEodPayload.from_dict` has always dropped `last_qty`, `last_buy_price`,
    `last_sell_price` and `recent_trades` from the snapshot it is handed, and this
    record says so rather than leaving it to a `from_dict` a reader has to go and
    find.
    """

    symbol: str
    tick_decimals: int  # unit: dimensionless
    bids: list[EodBookLevel]
    asks: list[EodBookLevel]
    last_price: float | None = None  # unit: display_price

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.tick_decimals < 0:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be >= 0"
            )
        if self.tick_decimals > 9:
            raise MessageValidationError(
                f"tick_decimals: {self.tick_decimals!r} must be <= 9"
            )
        for bids_item in self.bids:
            bids_item.validate()
        for asks_item in self.asks:
            asks_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "EodBook":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            tick_decimals=int(p["tick_decimals"]),
            bids=[EodBookLevel.from_dict(item) for item in p["bids"]],
            asks=[EodBookLevel.from_dict(item) for item in p["asks"]],
            last_price=None if p.get("last_price") is None else float(p["last_price"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "symbol": self.symbol,
            "tick_decimals": self.tick_decimals,
            "bids": [item.to_dict() for item in self.bids],
            "asks": [item.to_dict() for item in self.asks],
        }
        if self.last_price is not None:
            payload["last_price"] = self.last_price
        return payload


@dataclass(frozen=True, slots=True)
class HaltedSymbol:
    """One currently-halted instrument. The circuit-breaker detail is present only
    when a circuit breaker is what halted it: an ADMIN halt sets the flag without
    a breaker behind it, so the three fields travel together or not at all --
    section 16.2's combination, expressed as three regime-3 fields rather than a
    record because they are three independent CALF-side values and no reader holds
    them as a unit (section 26.2's reasoning, second application).
    """

    symbol: str
    resume_at_ns: int | None = None  # unit: epoch_nanos
    level: str | None = None
    halt_source: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.level is not None:
            if len(self.level) > 32:
                raise MessageValidationError(
                    f"level: length {len(self.level)} exceeds max_len 32"
                )
        if self.halt_source is not None:
            if len(self.halt_source) > 32:
                raise MessageValidationError(
                    f"halt_source: length {len(self.halt_source)} exceeds max_len 32"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "HaltedSymbol":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            resume_at_ns=(
                None if p.get("resume_at_ns") is None else int(p["resume_at_ns"])
            ),
            level=None if p.get("level") is None else str(p["level"]),
            halt_source=None if p.get("halt_source") is None else str(p["halt_source"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "symbol": self.symbol,
        }
        if self.resume_at_ns is not None:
            payload["resume_at_ns"] = self.resume_at_ns
        if self.level is not None:
            payload["level"] = self.level
        if self.halt_source is not None:
            payload["halt_source"] = self.halt_source
        return payload


@dataclass(frozen=True, slots=True)
class Position:
    """One instrument the gateway is not flat in. Only non-zero net positions are
    reported, so an empty list means flat everywhere.
    """

    symbol: str
    net_qty: int  # unit: shares
    avg_cost: float  # unit: display_price

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.avg_cost < 0:
            raise MessageValidationError(f"avg_cost: {self.avg_cost!r} must be >= 0")

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Position":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            net_qty=int(p["net_qty"]),
            avg_cost=float(p["avg_cost"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "symbol": self.symbol,
            "net_qty": self.net_qty,
            "avg_cost": self.avg_cost,
        }


@dataclass(frozen=True, slots=True)
class ActiveQuote:
    """One active two-sided quote, with both legs' live order state. What a market
    maker reads on reconnect to find out what it already has resting. A leg whose
    order is gone reports `MISSING` with zero quantities rather than being
    omitted: the quote still exists as far as the engine's index is concerned, and
    a bootstrap that silently dropped one side would let a bot re-quote into its
    own resting order.
    """

    quote_id: str
    gateway_id: str
    symbol: str
    state: str
    bid_order_id: str
    ask_order_id: str
    bid_qty: int  # unit: shares
    ask_qty: int  # unit: shares
    bid_remaining_qty: int  # unit: shares
    ask_remaining_qty: int  # unit: shares
    bid_status: str
    ask_status: str
    bid_price: float | None = None  # unit: display_price
    ask_price: float | None = None  # unit: display_price

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.quote_id) > 64:
            raise MessageValidationError(
                f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if len(self.state) > 32:
            raise MessageValidationError(
                f"state: length {len(self.state)} exceeds max_len 32"
            )
        if len(self.bid_order_id) > 64:
            raise MessageValidationError(
                f"bid_order_id: length {len(self.bid_order_id)} exceeds max_len 64"
            )
        if len(self.ask_order_id) > 64:
            raise MessageValidationError(
                f"ask_order_id: length {len(self.ask_order_id)} exceeds max_len 64"
            )
        if self.bid_qty < 0:
            raise MessageValidationError(f"bid_qty: {self.bid_qty!r} must be >= 0")
        if self.ask_qty < 0:
            raise MessageValidationError(f"ask_qty: {self.ask_qty!r} must be >= 0")
        if self.bid_remaining_qty < 0:
            raise MessageValidationError(
                f"bid_remaining_qty: {self.bid_remaining_qty!r} must be >= 0"
            )
        if self.ask_remaining_qty < 0:
            raise MessageValidationError(
                f"ask_remaining_qty: {self.ask_remaining_qty!r} must be >= 0"
            )
        if len(self.bid_status) > 32:
            raise MessageValidationError(
                f"bid_status: length {len(self.bid_status)} exceeds max_len 32"
            )
        if len(self.ask_status) > 32:
            raise MessageValidationError(
                f"ask_status: length {len(self.ask_status)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "ActiveQuote":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            quote_id=str(p["quote_id"]),
            gateway_id=str(p["gateway_id"]),
            symbol=str(p["symbol"]),
            state=str(p["state"]),
            bid_order_id=str(p["bid_order_id"]),
            ask_order_id=str(p["ask_order_id"]),
            bid_price=None if p.get("bid_price") is None else float(p["bid_price"]),
            ask_price=None if p.get("ask_price") is None else float(p["ask_price"]),
            bid_qty=int(p["bid_qty"]),
            ask_qty=int(p["ask_qty"]),
            bid_remaining_qty=int(p["bid_remaining_qty"]),
            ask_remaining_qty=int(p["ask_remaining_qty"]),
            bid_status=str(p["bid_status"]),
            ask_status=str(p["ask_status"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "quote_id": self.quote_id,
            "gateway_id": self.gateway_id,
            "symbol": self.symbol,
            "state": self.state,
            "bid_order_id": self.bid_order_id,
            "ask_order_id": self.ask_order_id,
            "bid_price": self.bid_price,
            "ask_price": self.ask_price,
            "bid_qty": self.bid_qty,
            "ask_qty": self.ask_qty,
            "bid_remaining_qty": self.bid_remaining_qty,
            "ask_remaining_qty": self.ask_remaining_qty,
            "bid_status": self.bid_status,
            "ask_status": self.ask_status,
        }


_QUOTE_LEG_LEG_SIDE_VALUES = ("BUY", "SELL")
QuoteLegLegSide = Literal["BUY", "SELL"]


@dataclass(frozen=True, slots=True)
class QuoteLeg:
    """One live leg of an active quote, with its order's current state."""

    quote_id: str
    order_id: str
    symbol: str
    leg_side: QuoteLegLegSide
    qty: int  # unit: shares
    remaining: int  # unit: shares
    filled: int  # unit: shares
    status: str
    quote_status: str
    price: float | None = None  # unit: display_price

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.quote_id) > 64:
            raise MessageValidationError(
                f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
            )
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.leg_side not in _QUOTE_LEG_LEG_SIDE_VALUES:
            raise MessageValidationError(
                f"leg_side: {self.leg_side!r} is not one of {_QUOTE_LEG_LEG_SIDE_VALUES!r}"
            )
        if self.qty < 0:
            raise MessageValidationError(f"qty: {self.qty!r} must be >= 0")
        if self.remaining < 0:
            raise MessageValidationError(f"remaining: {self.remaining!r} must be >= 0")
        if self.filled < 0:
            raise MessageValidationError(f"filled: {self.filled!r} must be >= 0")
        if len(self.status) > 32:
            raise MessageValidationError(
                f"status: length {len(self.status)} exceeds max_len 32"
            )
        if len(self.quote_status) > 32:
            raise MessageValidationError(
                f"quote_status: length {len(self.quote_status)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteLeg":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            quote_id=str(p["quote_id"]),
            order_id=str(p["order_id"]),
            symbol=str(p["symbol"]),
            leg_side=cast(QuoteLegLegSide, str(p["leg_side"])),
            price=None if p.get("price") is None else float(p["price"]),
            qty=int(p["qty"]),
            remaining=int(p["remaining"]),
            filled=int(p["filled"]),
            status=str(p["status"]),
            quote_status=str(p["quote_status"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "quote_id": self.quote_id,
            "order_id": self.order_id,
            "symbol": self.symbol,
            "leg_side": self.leg_side,
            "qty": self.qty,
            "remaining": self.remaining,
            "filled": self.filled,
            "status": self.status,
            "quote_status": self.quote_status,
        }
        if self.price is not None:
            payload["price"] = self.price
        return payload


@dataclass(frozen=True, slots=True)
class QuoteLegSnapshot:
    """A leg as it stood when its quote left the book. No live qty/remaining here in
    the sense the name suggests -- these are the final values, recorded at
    removal, because once an order leaves the book its state is not available
    anywhere in the engine.
    """

    order_id: str
    qty: int  # unit: shares
    remaining: int  # unit: shares
    filled: int  # unit: shares
    status: str
    price: float | None = None  # unit: display_price

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.order_id) > 64:
            raise MessageValidationError(
                f"order_id: length {len(self.order_id)} exceeds max_len 64"
            )
        if self.qty < 0:
            raise MessageValidationError(f"qty: {self.qty!r} must be >= 0")
        if self.remaining < 0:
            raise MessageValidationError(f"remaining: {self.remaining!r} must be >= 0")
        if self.filled < 0:
            raise MessageValidationError(f"filled: {self.filled!r} must be >= 0")
        if len(self.status) > 32:
            raise MessageValidationError(
                f"status: length {len(self.status)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteLegSnapshot":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            order_id=str(p["order_id"]),
            price=None if p.get("price") is None else float(p["price"]),
            qty=int(p["qty"]),
            remaining=int(p["remaining"]),
            filled=int(p["filled"]),
            status=str(p["status"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "order_id": self.order_id,
            "qty": self.qty,
            "remaining": self.remaining,
            "filled": self.filled,
            "status": self.status,
        }
        if self.price is not None:
            payload["price"] = self.price
        return payload


@dataclass(frozen=True, slots=True)
class RecentQuote:
    """One recently-removed quote, from the engine's bounded per-gateway inactivation
    history. A quote-level summary rather than a per-leg one. Does not survive an
    engine restart.
    """

    quote_id: str
    symbol: str
    bid_order_id: str
    ask_order_id: str
    quote_status: str
    reason: str
    removed_at_ns: int  # unit: epoch_nanos
    bid_leg: QuoteLegSnapshot | None = None
    ask_leg: QuoteLegSnapshot | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.quote_id) > 64:
            raise MessageValidationError(
                f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if len(self.bid_order_id) > 64:
            raise MessageValidationError(
                f"bid_order_id: length {len(self.bid_order_id)} exceeds max_len 64"
            )
        if len(self.ask_order_id) > 64:
            raise MessageValidationError(
                f"ask_order_id: length {len(self.ask_order_id)} exceeds max_len 64"
            )
        if len(self.quote_status) > 32:
            raise MessageValidationError(
                f"quote_status: length {len(self.quote_status)} exceeds max_len 32"
            )
        if len(self.reason) > 64:
            raise MessageValidationError(
                f"reason: length {len(self.reason)} exceeds max_len 64"
            )
        if self.bid_leg is not None:
            self.bid_leg.validate()
        if self.ask_leg is not None:
            self.ask_leg.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "RecentQuote":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            quote_id=str(p["quote_id"]),
            symbol=str(p["symbol"]),
            bid_order_id=str(p["bid_order_id"]),
            ask_order_id=str(p["ask_order_id"]),
            quote_status=str(p["quote_status"]),
            reason=str(p["reason"]),
            removed_at_ns=int(p["removed_at_ns"]),
            bid_leg=(
                None
                if p.get("bid_leg") is None
                else QuoteLegSnapshot.from_dict(p["bid_leg"])
            ),
            ask_leg=(
                None
                if p.get("ask_leg") is None
                else QuoteLegSnapshot.from_dict(p["ask_leg"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "quote_id": self.quote_id,
            "symbol": self.symbol,
            "bid_order_id": self.bid_order_id,
            "ask_order_id": self.ask_order_id,
            "quote_status": self.quote_status,
            "reason": self.reason,
            "removed_at_ns": self.removed_at_ns,
            "bid_leg": None if self.bid_leg is None else self.bid_leg.to_dict(),
            "ask_leg": None if self.ask_leg is None else self.ask_leg.to_dict(),
        }


@dataclass(frozen=True, slots=True)
class LiveCircuitBreaker:
    """A symbol's circuit breaker as it stands right now. The live counterpart to
    `ReferenceSymbol.circuit_breaker`, which is the configuration.
    """

    halted: bool
    reference_price: float | None = None  # unit: display_price
    trigger_price: float | None = None  # unit: display_price
    triggered_level: str | None = None
    expansion_index: int | None = None  # unit: dimensionless
    corridor_low: float | None = None  # unit: display_price
    corridor_high: float | None = None  # unit: display_price
    corridor_expansion: int | None = None  # unit: dimensionless
    resume_at_ns: int | None = None  # unit: epoch_nanos

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.triggered_level is not None:
            if len(self.triggered_level) > 32:
                raise MessageValidationError(
                    f"triggered_level: length {len(self.triggered_level)} exceeds max_len 32"
                )
        if self.expansion_index is not None:
            if self.expansion_index < 0:
                raise MessageValidationError(
                    f"expansion_index: {self.expansion_index!r} must be >= 0"
                )
        if self.corridor_expansion is not None:
            if self.corridor_expansion < 0:
                raise MessageValidationError(
                    f"corridor_expansion: {self.corridor_expansion!r} must be >= 0"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "LiveCircuitBreaker":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            halted=bool(p["halted"]),
            reference_price=(
                None
                if p.get("reference_price") is None
                else float(p["reference_price"])
            ),
            trigger_price=(
                None if p.get("trigger_price") is None else float(p["trigger_price"])
            ),
            triggered_level=(
                None if p.get("triggered_level") is None else str(p["triggered_level"])
            ),
            expansion_index=(
                None if p.get("expansion_index") is None else int(p["expansion_index"])
            ),
            corridor_low=(
                None if p.get("corridor_low") is None else float(p["corridor_low"])
            ),
            corridor_high=(
                None if p.get("corridor_high") is None else float(p["corridor_high"])
            ),
            corridor_expansion=(
                None
                if p.get("corridor_expansion") is None
                else int(p["corridor_expansion"])
            ),
            resume_at_ns=(
                None if p.get("resume_at_ns") is None else int(p["resume_at_ns"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "halted": self.halted,
            "reference_price": self.reference_price,
            "trigger_price": self.trigger_price,
            "triggered_level": self.triggered_level,
            "expansion_index": self.expansion_index,
            "corridor_low": self.corridor_low,
            "corridor_high": self.corridor_high,
            "corridor_expansion": self.corridor_expansion,
            "resume_at_ns": self.resume_at_ns,
        }


@dataclass(frozen=True, slots=True)
class SymbolRiskState:
    """One symbol's live risk state. Was a map entry keyed by symbol -- section
    19.2's shape for the twelfth time.
    """

    symbol: str
    collar_reference_price: float | None = None  # unit: display_price
    circuit_breaker: LiveCircuitBreaker | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.circuit_breaker is not None:
            self.circuit_breaker.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SymbolRiskState":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            collar_reference_price=(
                None
                if p.get("collar_reference_price") is None
                else float(p["collar_reference_price"])
            ),
            circuit_breaker=(
                None
                if p.get("circuit_breaker") is None
                else LiveCircuitBreaker.from_dict(p["circuit_breaker"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "symbol": self.symbol,
        }
        if self.collar_reference_price is not None:
            payload["collar_reference_price"] = self.collar_reference_price
        if self.circuit_breaker is not None:
            payload["circuit_breaker"] = self.circuit_breaker.to_dict()
        return payload


@dataclass(frozen=True, slots=True)
class GatewayInfo:
    """One configured participant, and whether it is connected right now."""

    id: str
    role: str
    connected: bool
    description: str = ""
    connected_since_ns: int | None = None  # unit: epoch_nanos

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.id) > 32:
            raise MessageValidationError(
                f"id: length {len(self.id)} exceeds max_len 32"
            )
        if len(self.role) > 32:
            raise MessageValidationError(
                f"role: length {len(self.role)} exceeds max_len 32"
            )
        if len(self.description) > 128:
            raise MessageValidationError(
                f"description: length {len(self.description)} exceeds max_len 128"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "GatewayInfo":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            id=str(p["id"]),
            role=str(p["role"]),
            description=str(p.get("description", "")),
            connected=bool(p["connected"]),
            connected_since_ns=(
                None
                if p.get("connected_since_ns") is None
                else int(p["connected_since_ns"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "id": self.id,
            "role": self.role,
            "description": self.description,
            "connected": self.connected,
        }
        if self.connected_since_ns is not None:
            payload["connected_since_ns"] = self.connected_since_ns
        return payload


@dataclass(frozen=True, slots=True)
class SymbolVolume:
    """One instrument's traded volume so far today. Was a map entry keyed by symbol;
    the key is a field now, as everywhere else in this family.
    """

    symbol: str
    qty: int  # unit: shares
    value: float  # unit: money
    trades: int  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.qty < 0:
            raise MessageValidationError(f"qty: {self.qty!r} must be >= 0")
        if self.value < 0:
            raise MessageValidationError(f"value: {self.value!r} must be >= 0")
        if self.trades < 0:
            raise MessageValidationError(f"trades: {self.trades!r} must be >= 0")

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SymbolVolume":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            qty=int(p["qty"]),
            value=float(p["value"]),
            trades=int(p["trades"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "symbol": self.symbol,
            "qty": self.qty,
            "value": self.value,
            "trades": self.trades,
        }


TOPIC_GATEWAY_CONNECT = "system.gateway_connect"
_TOPIC_GATEWAY_CONNECT_BYTES = "system.gateway_connect".encode()


_GATEWAY_CONNECT_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Who is connecting. The engine's PULL socket is a boundary of its own -- section 22.3 -- so this is clamped on arrival.",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class GatewayConnect:
    """Gateway to engine: authenticate this participant. Sent over PUSH/PULL rather
    than the pub bus; it carries a topic so the audit log can classify it
    alongside everything else.
    """

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "GatewayConnect":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_gateway_connect(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_GATEWAY_CONNECT


def make_gateway_connect(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = GatewayConnect.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_GATEWAY_CONNECT, obj.to_dict())


def make_gateway_connect_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_gateway_connect``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_GATEWAY_CONNECT_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_gateway_connect(frames: list[bytes]) -> "GatewayConnect":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = GatewayConnect.from_dict(payload)
    obj.validate()
    return obj


def describe_gateway_connect() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _GATEWAY_CONNECT_FIELDS


TOPIC_GATEWAY_AUTH = "system.gateway_auth.{gateway_id}"
PREFIX_GATEWAY_AUTH = "system.gateway_auth."
_GATEWAY_AUTH_RE = re.compile("system\\.gateway_auth\\.(?P<gateway_id>[^.]+)")


_GATEWAY_AUTH_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "accepted",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": 'Why it was rejected; "" on acceptance. Regime 1, because `GatewayAuthPayload.to_dict` has always emitted the key.',
        "constraints": {"max_len": 512},
    },
    {
        "name": "description",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The gateway's configured display name. Regime 1, as above.",
        "constraints": {"max_len": 128},
    },
)


@dataclass(frozen=True, slots=True)
class GatewayAuth:
    """Engine to all subscribers: a participant's connection was accepted or
    rejected. The PUB-side answer to `system.gateway_connect`, and the widest-read
    message in this half -- five consumers structurally, and it is in
    `PRIVATE_PREFIXES`.

    `gateway_id` is in the topic AND the body, and every consumer reads it from the body
    -- `balf_gwy` dispatches on the topic suffix and then reads the payload's copy. So
    the field is listed in `include:` explicitly. Section 26.4: `include: all` means
    "every field except the topic parameters", and taking the default here would have
    dropped the key from the wire with `pm-msgen check` still passing.
    """

    gateway_id: str
    accepted: bool
    reason: str = ""
    description: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.reason) > 512:
            raise MessageValidationError(
                f"reason: length {len(self.reason)} exceeds max_len 512"
            )
        if len(self.description) > 128:
            raise MessageValidationError(
                f"description: length {len(self.description)} exceeds max_len 128"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "GatewayAuth":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            accepted=bool(p["accepted"]),
            reason=str(p.get("reason", "")),
            description=str(p.get("description", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
            "accepted": self.accepted,
            "reason": self.reason,
            "description": self.description,
        }


def topic_gateway_auth(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.gateway_auth.{gateway_id}"


def match_gateway_auth(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _GATEWAY_AUTH_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_gateway_auth(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = GatewayAuth.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_gateway_auth(obj.gateway_id), obj.to_dict())


def make_gateway_auth_unchecked(
    *,
    gateway_id: str,
    accepted: bool,
    reason: str = "",
    description: str = "",
) -> list[bytes]:
    """Identical frames to ``make_gateway_auth``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        topic_gateway_auth(gateway_id).encode(),
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
                "accepted": bool(accepted),
                "reason": str(reason),
                "description": str(description),
            }
        ),
    ]


def parse_gateway_auth(frames: list[bytes]) -> "GatewayAuth":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_gateway_auth(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_GATEWAY_AUTH!r}")
    payload = {**payload, "gateway_id": matched}
    obj = GatewayAuth.from_dict(payload)
    obj.validate()
    return obj


def describe_gateway_auth() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _GATEWAY_AUTH_FIELDS


TOPIC_GATEWAY_REJECT = "system.gateway_reject"
_TOPIC_GATEWAY_REJECT_BYTES = "system.gateway_reject".encode()
_GATEWAY_REJECT_SOURCE_VALUES = ("ALF", "BALF", "REST")
GatewayRejectSource = Literal["ALF", "BALF", "REST"]
_GATEWAY_REJECT_REJECT_CODE_VALUES = (
    "AUTH_REQUIRED",
    "AUTH_FAILED",
    "ROLE_DENIED",
    "RATE_LIMITED",
)
GatewayRejectRejectCode = Literal[
    "AUTH_REQUIRED",
    "AUTH_FAILED",
    "ROLE_DENIED",
    "RATE_LIMITED",
]


_GATEWAY_REJECT_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "source",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "Which gateway refused the request.",
        "values": _GATEWAY_REJECT_SOURCE_VALUES,
    },
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": 'The participant the gateway believed it was talking to; "" before authentication. Claimed, not proven. Never an API key.',
        "constraints": {"max_len": 32},
    },
    {
        "name": "peer",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Remote address of the connection (host:port).",
        "constraints": {"max_len": 64},
    },
    {
        "name": "reject_code",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "The same codes `order.ack` uses for these refusals.",
        "values": _GATEWAY_REJECT_REJECT_CODE_VALUES,
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 256},
    },
    {
        "name": "count",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "Refusals this record stands for: itself plus those folded in since the last record for the same peer and code.",
        "constraints": {"ge": 1},
    },
    {
        "name": "ts_ns",
        "type": "int",
        "unit": "epoch_nanos",
        "required": True,
        "doc": "The gateway's clock when it refused.",
        "constraints": {"ge": 0},
    },
)


@dataclass(frozen=True, slots=True)
class GatewayReject:
    """Gateway to engine: I refused a participant's request myself, before the engine
    saw it. Authentication, role and rate-limit refusals are decided in the ALF,
    BALF and REST gateways and never reach the engine, so without this the
    exchange could neither show nor disprove "I sent it and you ignored it".
    PUSH/PULL like `gateway_connect`; the engine echoes it onto the bus like any
    command, which is how the audit trail comes to hold it. Malformed frames and
    field-validation refusals are deliberately not reported: they are counted by
    the gateway, and any one of them is unfalsifiable noise rather than a
    disputable decision.

    A gateway reports at most one record per peer host and reject code per second and
    carries the number it folded in as `count`, so a client flooding refused commands
    cannot flood the engine through this message, even with a new connection (source
    port) per request.
    """

    source: GatewayRejectSource
    reject_code: GatewayRejectRejectCode
    ts_ns: int  # unit: epoch_nanos
    gateway_id: str = ""
    peer: str = ""
    reason: str = ""
    count: int = 1  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.source not in _GATEWAY_REJECT_SOURCE_VALUES:
            raise MessageValidationError(
                f"source: {self.source!r} is not one of {_GATEWAY_REJECT_SOURCE_VALUES!r}"
            )
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.peer) > 64:
            raise MessageValidationError(
                f"peer: length {len(self.peer)} exceeds max_len 64"
            )
        if self.reject_code not in _GATEWAY_REJECT_REJECT_CODE_VALUES:
            raise MessageValidationError(
                f"reject_code: {self.reject_code!r} is not one of {_GATEWAY_REJECT_REJECT_CODE_VALUES!r}"
            )
        if len(self.reason) > 256:
            raise MessageValidationError(
                f"reason: length {len(self.reason)} exceeds max_len 256"
            )
        if self.count < 1:
            raise MessageValidationError(f"count: {self.count!r} must be >= 1")
        if self.ts_ns < 0:
            raise MessageValidationError(f"ts_ns: {self.ts_ns!r} must be >= 0")

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "GatewayReject":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            source=cast(GatewayRejectSource, str(p["source"])),
            gateway_id=str(p.get("gateway_id", "")),
            peer=str(p.get("peer", "")),
            reject_code=cast(GatewayRejectRejectCode, str(p["reject_code"])),
            reason=str(p.get("reason", "")),
            count=int(p.get("count", 1)),
            ts_ns=int(p["ts_ns"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "source": self.source,
            "gateway_id": self.gateway_id,
            "peer": self.peer,
            "reject_code": self.reject_code,
            "reason": self.reason,
            "count": self.count,
            "ts_ns": self.ts_ns,
        }


def is_gateway_reject(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_GATEWAY_REJECT


def make_gateway_reject(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = GatewayReject.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_GATEWAY_REJECT, obj.to_dict())


def make_gateway_reject_unchecked(
    *,
    source: GatewayRejectSource,
    reject_code: GatewayRejectRejectCode,
    ts_ns: int,
    gateway_id: str = "",
    peer: str = "",
    reason: str = "",
    count: int = 1,
) -> list[bytes]:
    """Identical frames to ``make_gateway_reject``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_GATEWAY_REJECT_BYTES,
        _msg.dumps(
            {
                "source": str(source),
                "gateway_id": str(gateway_id),
                "peer": str(peer),
                "reject_code": str(reject_code),
                "reason": str(reason),
                "count": int(count),
                "ts_ns": int(ts_ns),
            }
        ),
    ]


def parse_gateway_reject(frames: list[bytes]) -> "GatewayReject":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = GatewayReject.from_dict(payload)
    obj.validate()
    return obj


def describe_gateway_reject() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _GATEWAY_REJECT_FIELDS


TOPIC_GATEWAY_DISCONNECT = "system.gateway_disconnect"
_TOPIC_GATEWAY_DISCONNECT_BYTES = "system.gateway_disconnect".encode()


_GATEWAY_DISCONNECT_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 512},
    },
)


@dataclass(frozen=True, slots=True)
class GatewayDisconnect:
    """Gateway to engine: I am leaving cleanly. PUSH/PULL, like `gateway_connect`;
    the engine republishes it as `gateway_bye` so PUB subscribers hear about it at
    all.
    """

    gateway_id: str
    reason: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.reason) > 512:
            raise MessageValidationError(
                f"reason: length {len(self.reason)} exceeds max_len 512"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "GatewayDisconnect":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            reason=str(p.get("reason", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
            "reason": self.reason,
        }


def is_gateway_disconnect(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_GATEWAY_DISCONNECT


def make_gateway_disconnect(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = GatewayDisconnect.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_GATEWAY_DISCONNECT, obj.to_dict())


def make_gateway_disconnect_unchecked(
    *,
    gateway_id: str,
    reason: str = "",
) -> list[bytes]:
    """Identical frames to ``make_gateway_disconnect``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_GATEWAY_DISCONNECT_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
                "reason": str(reason),
            }
        ),
    ]


def parse_gateway_disconnect(frames: list[bytes]) -> "GatewayDisconnect":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = GatewayDisconnect.from_dict(payload)
    obj.validate()
    return obj


def describe_gateway_disconnect() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _GATEWAY_DISCONNECT_FIELDS


TOPIC_GATEWAY_HEARTBEAT = "system.gateway_heartbeat"
_TOPIC_GATEWAY_HEARTBEAT_BYTES = "system.gateway_heartbeat".encode()


_GATEWAY_HEARTBEAT_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "interval_sec",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Seconds between this sender's beats. Carried on every beat so the engine needs no per-client setting; the bound stops a client declaring an interval so long that its ID could never be reclaimed.",
        "constraints": {"ge": 1, "le": 3600},
    },
)


@dataclass(frozen=True, slots=True)
class GatewayHeartbeat:
    """Gateway to engine: this participant's process is still alive. A process that
    dies without sending `gateway_disconnect` (kill -9, a crashed host, a dropped
    network) would otherwise keep its ID marked connected for ever, and the engine
    refuses a second connect for an ID that is already connected. The engine
    counts the beats it expects -- one per `interval_sec` -- and disconnects the
    session, applying its `disconnect_behaviour`, after three consecutive misses.
    The clock starts at connect, at the default 60-second interval until the first
    beat carries the sender's own, so a session that never sends one is timed out
    too.
    """

    gateway_id: str
    interval_sec: int  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if self.interval_sec < 1:
            raise MessageValidationError(
                f"interval_sec: {self.interval_sec!r} must be >= 1"
            )
        if self.interval_sec > 3600:
            raise MessageValidationError(
                f"interval_sec: {self.interval_sec!r} must be <= 3600"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "GatewayHeartbeat":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            interval_sec=int(p["interval_sec"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
            "interval_sec": self.interval_sec,
        }


def is_gateway_heartbeat(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_GATEWAY_HEARTBEAT


def make_gateway_heartbeat(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = GatewayHeartbeat.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_GATEWAY_HEARTBEAT, obj.to_dict())


def make_gateway_heartbeat_unchecked(
    *,
    gateway_id: str,
    interval_sec: int,
) -> list[bytes]:
    """Identical frames to ``make_gateway_heartbeat``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_GATEWAY_HEARTBEAT_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
                "interval_sec": int(interval_sec),
            }
        ),
    ]


def parse_gateway_heartbeat(frames: list[bytes]) -> "GatewayHeartbeat":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = GatewayHeartbeat.from_dict(payload)
    obj.validate()
    return obj


def describe_gateway_heartbeat() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _GATEWAY_HEARTBEAT_FIELDS


TOPIC_GATEWAY_BYE = "system.gateway_bye.{gateway_id}"
PREFIX_GATEWAY_BYE = "system.gateway_bye."
_GATEWAY_BYE_RE = re.compile("system\\.gateway_bye\\.(?P<gateway_id>[^.]+)")


_GATEWAY_BYE_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "",
        "constraints": {"max_len": 512},
    },
)


@dataclass(frozen=True, slots=True)
class GatewayBye:
    """Engine to all subscribers: a participant has disconnected. The PUB-side
    counterpart to `gateway_auth`. The inbound `system.gateway_disconnect` is a
    PULL message and never reaches subscribers, so without this broadcast clearing
    could not close the matching session.

    `gateway_id` is in the topic and the body, and `clearing` -- the only structural
    reader -- takes it from the body. Enumerated for the same reason as `gateway_auth`.
    """

    gateway_id: str
    reason: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.reason) > 512:
            raise MessageValidationError(
                f"reason: length {len(self.reason)} exceeds max_len 512"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "GatewayBye":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            reason=str(p.get("reason", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
            "reason": self.reason,
        }


def topic_gateway_bye(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.gateway_bye.{gateway_id}"


def match_gateway_bye(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _GATEWAY_BYE_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_gateway_bye(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = GatewayBye.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_gateway_bye(obj.gateway_id), obj.to_dict())


def make_gateway_bye_unchecked(
    *,
    gateway_id: str,
    reason: str = "",
) -> list[bytes]:
    """Identical frames to ``make_gateway_bye``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        topic_gateway_bye(gateway_id).encode(),
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
                "reason": str(reason),
            }
        ),
    ]


def parse_gateway_bye(frames: list[bytes]) -> "GatewayBye":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_gateway_bye(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_GATEWAY_BYE!r}")
    payload = {**payload, "gateway_id": matched}
    obj = GatewayBye.from_dict(payload)
    obj.validate()
    return obj


def describe_gateway_bye() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _GATEWAY_BYE_FIELDS


TOPIC_EOD = "system.eod"
_TOPIC_EOD_BYTES = "system.eod".encode()


_EOD_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "books",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "One per instrument the engine had a book for, unordered.",
    },
    {
        "name": "last_trade_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The id of the last trade this engine run made, null for a run without trades. Trade ids restart with every run, so without it a subscriber cannot tell trades lost just before the stop from a clean end: one that holds an older id of this run lost the rest.",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class Eod:
    """Engine to all subscribers, once, before shutdown: the closing book of every
    instrument. Four consumers -- clearing, index, stats and the RALF gateway --
    which is the widest fan-out in this half, and the reason the record is
    declared rather than left to a `from_dict`.

    A broadcast with no request: nothing asks for end of day, the engine announces it.
    That is why it has no `_request` sibling and why it is in this half rather than
    6.1f's request/reply pairs.
    """

    books: list[EodBook]
    last_trade_id: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        for books_item in self.books:
            books_item.validate()
        if self.last_trade_id is not None:
            if len(self.last_trade_id) > 32:
                raise MessageValidationError(
                    f"last_trade_id: length {len(self.last_trade_id)} exceeds max_len 32"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Eod":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            books=[EodBook.from_dict(item) for item in p["books"]],
            last_trade_id=(
                None if p.get("last_trade_id") is None else str(p["last_trade_id"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "books": [item.to_dict() for item in self.books],
            "last_trade_id": self.last_trade_id,
        }


def is_eod(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_EOD


def make_eod(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = Eod.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_EOD, obj.to_dict())


def parse_eod(frames: list[bytes]) -> "Eod":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = Eod.from_dict(payload)
    obj.validate()
    return obj


def describe_eod() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _EOD_FIELDS


TOPIC_BOOK_CHECKPOINT = "system.book_checkpoint.{symbol}"
PREFIX_BOOK_CHECKPOINT = "system.book_checkpoint."
_BOOK_CHECKPOINT_RE = re.compile("system\\.book_checkpoint\\.(?P<symbol>[^.]+)")
_BOOK_CHECKPOINT_REASON_VALUES = ("STARTUP", "PHASE", "EOD")
BookCheckpointReason = Literal["STARTUP", "PHASE", "EOD"]


_BOOK_CHECKPOINT_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "reason",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "",
        "values": _BOOK_CHECKPOINT_REASON_VALUES,
    },
    {
        "name": "phase",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "The session state the book is in.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "bids",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "asks",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "buy_stops",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "sell_stops",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "trailing_stops",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "last_trade_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "",
    },
    {
        "name": "last_buy_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "",
    },
    {
        "name": "last_sell_price_ticks",
        "type": "ticks",
        "unit": "ticks",
        "required": False,
        "doc": "",
    },
    {
        "name": "last_trade_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The trade that set the last trade price.",
    },
    {
        "name": "tick_decimals",
        "type": "int",
        "unit": "dimensionless",
        "required": False,
        "doc": "Decimal scale of the `*_ticks` prices in this message (1 tick = 10^-tick_decimals) -- the symbol's. Every message that carries a tick price carries its scale, so a reader of one line, or of a window of the trail that begins long after the book snapshot that declared it, can turn it into money without guessing. Absent when the message carries no tick price.",
        "constraints": {"ge": 0, "le": 9},
    },
)


@dataclass(frozen=True, slots=True)
class BookCheckpoint:
    """One symbol's whole book, for the audit: every resting order in priority order
    with its hidden quantity, every armed stop with its current trigger, the last
    prices. Published for every symbol after startup (what the restore and the
    seeds made), after each session transition, and at shutdown. A replay can
    start from any of them -- an audit that begins mid-day, or continues after an
    engine restart -- and, where it already holds the book, compare order by
    order.

    `bids` and `asks` are in matching priority (best price first, then arrival);
    `buy_stops` and `sell_stops` in the order they would trigger; `trailing_stops` in
    the order they are checked.
    """

    symbol: str
    reason: BookCheckpointReason
    phase: str
    bids: list[CheckpointOrder]
    asks: list[CheckpointOrder]
    buy_stops: list[CheckpointOrder]
    sell_stops: list[CheckpointOrder]
    trailing_stops: list[CheckpointOrder]
    last_trade_price_ticks: int | None = None  # unit: ticks
    last_buy_price_ticks: int | None = None  # unit: ticks
    last_sell_price_ticks: int | None = None  # unit: ticks
    last_trade_id: str | None = None
    tick_decimals: int | None = None  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.reason not in _BOOK_CHECKPOINT_REASON_VALUES:
            raise MessageValidationError(
                f"reason: {self.reason!r} is not one of {_BOOK_CHECKPOINT_REASON_VALUES!r}"
            )
        if len(self.phase) > 32:
            raise MessageValidationError(
                f"phase: length {len(self.phase)} exceeds max_len 32"
            )
        for bids_item in self.bids:
            bids_item.validate()
        for asks_item in self.asks:
            asks_item.validate()
        for buy_stops_item in self.buy_stops:
            buy_stops_item.validate()
        for sell_stops_item in self.sell_stops:
            sell_stops_item.validate()
        for trailing_stops_item in self.trailing_stops:
            trailing_stops_item.validate()
        if self.tick_decimals is not None:
            if self.tick_decimals < 0:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be >= 0"
                )
            if self.tick_decimals > 9:
                raise MessageValidationError(
                    f"tick_decimals: {self.tick_decimals!r} must be <= 9"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "BookCheckpoint":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            symbol=str(p["symbol"]),
            reason=cast(BookCheckpointReason, str(p["reason"])),
            phase=str(p["phase"]),
            bids=[CheckpointOrder.from_dict(item) for item in p["bids"]],
            asks=[CheckpointOrder.from_dict(item) for item in p["asks"]],
            buy_stops=[CheckpointOrder.from_dict(item) for item in p["buy_stops"]],
            sell_stops=[CheckpointOrder.from_dict(item) for item in p["sell_stops"]],
            trailing_stops=(
                [CheckpointOrder.from_dict(item) for item in p["trailing_stops"]]
            ),
            last_trade_price_ticks=(
                None
                if p.get("last_trade_price_ticks") is None
                else int(p["last_trade_price_ticks"])
            ),
            last_buy_price_ticks=(
                None
                if p.get("last_buy_price_ticks") is None
                else int(p["last_buy_price_ticks"])
            ),
            last_sell_price_ticks=(
                None
                if p.get("last_sell_price_ticks") is None
                else int(p["last_sell_price_ticks"])
            ),
            last_trade_id=(
                None if p.get("last_trade_id") is None else str(p["last_trade_id"])
            ),
            tick_decimals=(
                None if p.get("tick_decimals") is None else int(p["tick_decimals"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "symbol": self.symbol,
            "reason": self.reason,
            "phase": self.phase,
            "bids": [item.to_dict() for item in self.bids],
            "asks": [item.to_dict() for item in self.asks],
            "buy_stops": [item.to_dict() for item in self.buy_stops],
            "sell_stops": [item.to_dict() for item in self.sell_stops],
            "trailing_stops": [item.to_dict() for item in self.trailing_stops],
        }
        if self.last_trade_price_ticks is not None:
            payload["last_trade_price_ticks"] = self.last_trade_price_ticks
        if self.last_buy_price_ticks is not None:
            payload["last_buy_price_ticks"] = self.last_buy_price_ticks
        if self.last_sell_price_ticks is not None:
            payload["last_sell_price_ticks"] = self.last_sell_price_ticks
        if self.last_trade_id is not None:
            payload["last_trade_id"] = self.last_trade_id
        if self.tick_decimals is not None:
            payload["tick_decimals"] = self.tick_decimals
        return payload


def topic_book_checkpoint(symbol: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.book_checkpoint.{symbol}"


def match_book_checkpoint(topic: str) -> str | None:
    """Return ``symbol`` when ``topic`` matches, else None."""
    m = _BOOK_CHECKPOINT_RE.fullmatch(topic)
    return m.group("symbol") if m else None


def make_book_checkpoint(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = BookCheckpoint.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_book_checkpoint(obj.symbol), obj.to_dict())


def parse_book_checkpoint(frames: list[bytes]) -> "BookCheckpoint":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_book_checkpoint(topic)
    if matched is None:
        raise MessageValidationError(
            f"topic {topic!r} is not {TOPIC_BOOK_CHECKPOINT!r}"
        )
    payload = {**payload, "symbol": matched}
    obj = BookCheckpoint.from_dict(payload)
    obj.validate()
    return obj


def describe_book_checkpoint() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _BOOK_CHECKPOINT_FIELDS


TOPIC_STARTUP = "system.startup"
_TOPIC_STARTUP_BYTES = "system.startup".encode()


_STARTUP_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "format_version",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Version of this message's meaning; 1 at EduMatcher 1.0.",
        "constraints": {"ge": 1},
    },
    {
        "name": "engine_version",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "The installed edumatcher package version.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "git_commit",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": '`git describe --always --dirty` of the source the engine runs from; "unknown" for an installed wheel. The package version stays put between releases, the commit does not.',
        "constraints": {"max_len": 64},
    },
    {
        "name": "python_version",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "run_seq",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "The engine-run sequence this start took (trade id prefix).",
        "constraints": {"ge": 0},
    },
    {
        "name": "config_sha256",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "SHA-256 of the compiled config artifact; null when none is deployed.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "config",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The compiled config artifact, verbatim JSON text; null when the engine runs on a YAML config or none.",
    },
    {
        "name": "loaded",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "The persistence files the restore reads: orders, combos, book statistics.",
        "constraints": {"max_items": 8},
    },
)


@dataclass(frozen=True, slots=True)
class Startup:
    """Engine to all subscribers, the first message of every start, before the
    restore: which engine, which configuration and which persisted state this run
    began from. Makes an audit trail self-describing -- a replay rebuilds the
    engine from this message alone, years later, without the data dir's
    `ref_data/` (which the next deploy overwrites) or a guess at the engine
    version. Also the marker of an engine start: every per-topic `seq` begins
    again after it.

    `config` is the compiled artifact as `pm-config-deploy` wrote it, verbatim (about
    250 KB for 300 symbols), so `config_sha256` is the artifact file's hash and
    `config_artifact.decode(config)` gives back exactly what the engine loaded.
    """

    format_version: int  # unit: dimensionless
    engine_version: str
    git_commit: str
    python_version: str
    run_seq: int  # unit: dimensionless
    loaded: list[LoadedFile]
    config_sha256: str | None = None
    config: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.format_version < 1:
            raise MessageValidationError(
                f"format_version: {self.format_version!r} must be >= 1"
            )
        if len(self.engine_version) > 64:
            raise MessageValidationError(
                f"engine_version: length {len(self.engine_version)} exceeds max_len 64"
            )
        if len(self.git_commit) > 64:
            raise MessageValidationError(
                f"git_commit: length {len(self.git_commit)} exceeds max_len 64"
            )
        if len(self.python_version) > 32:
            raise MessageValidationError(
                f"python_version: length {len(self.python_version)} exceeds max_len 32"
            )
        if self.run_seq < 0:
            raise MessageValidationError(f"run_seq: {self.run_seq!r} must be >= 0")
        if self.config_sha256 is not None:
            if len(self.config_sha256) > 64:
                raise MessageValidationError(
                    f"config_sha256: length {len(self.config_sha256)} exceeds max_len 64"
                )
        if len(self.loaded) > 8:
            raise MessageValidationError("loaded: more than 8 item(s)")
        for loaded_item in self.loaded:
            loaded_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Startup":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            format_version=int(p["format_version"]),
            engine_version=str(p["engine_version"]),
            git_commit=str(p["git_commit"]),
            python_version=str(p["python_version"]),
            run_seq=int(p["run_seq"]),
            config_sha256=(
                None if p.get("config_sha256") is None else str(p["config_sha256"])
            ),
            config=None if p.get("config") is None else str(p["config"]),
            loaded=[LoadedFile.from_dict(item) for item in p["loaded"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "format_version": self.format_version,
            "engine_version": self.engine_version,
            "git_commit": self.git_commit,
            "python_version": self.python_version,
            "run_seq": self.run_seq,
            "config_sha256": self.config_sha256,
            "config": self.config,
            "loaded": [item.to_dict() for item in self.loaded],
        }


def is_startup(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_STARTUP


def make_startup(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = Startup.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_STARTUP, obj.to_dict())


def parse_startup(frames: list[bytes]) -> "Startup":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = Startup.from_dict(payload)
    obj.validate()
    return obj


def describe_startup() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _STARTUP_FIELDS


TOPIC_STARTUP_RECOVERY = "system.startup_recovery"
_TOPIC_STARTUP_RECOVERY_BYTES = "system.startup_recovery".encode()


_STARTUP_RECOVERY_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "restored_orders",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "GTC/same-day-DAY orders successfully restored to their book.",
        "constraints": {"ge": 0},
    },
    {
        "name": "discarded_stale_day_orders",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "TIF=DAY orders discarded because the business day rolled over.",
        "constraints": {"ge": 0},
    },
    {
        "name": "discarded_unconfigured_orders",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Orders the deployed configuration no longer allows: their symbol or participant is not configured, or they are a seed quote whose market maker and symbol have no seed in it (a seed belongs to the configuration that declared it).",
        "constraints": {"ge": 0},
    },
    {
        "name": "failed_orders",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Persisted orders that raised during restore and were skipped.",
        "constraints": {"ge": 0},
    },
    {
        "name": "quote_remnants_restored",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Restored quote-origin legs whose sibling did not survive, so they rest as plain orders rather than being rejoined into QuoteIndex.",
        "constraints": {"ge": 0},
    },
    {
        "name": "rebuilt_quotes",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Active QuoteIndex entries rebuilt from both-legs-restored quotes.",
        "constraints": {"ge": 0},
    },
    {
        "name": "restored_combos",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "GTC combos restored from the previous session.",
        "constraints": {"ge": 0},
    },
    {
        "name": "failed_book_stats",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "Symbols whose persisted book statistics (`book_stats.json`) were corrupt: the entry skipped, or only its circuit-breaker window dropped. An unreadable file counts as one. The file is kept aside as `book_stats.json.corrupt-<UTC stamp>`.",
        "constraints": {"ge": 0},
    },
)


@dataclass(frozen=True, slots=True)
class StartupRecovery:
    """Engine to all subscribers, once, right after `_restore_gtc()` and before the
    config-seed step runs: how much of the previous session's resting state came
    back. Every one of these counts previously only reached `log.info`/`log.error`
    — invisible to `pm-audit`, which is a bare PUB subscriber and sees nothing
    that is not published (see ../../docs/books/operator-guide/part-6-observe-and-
    recover/020-audit-trail.md). A post-mortem investigating "why does the book
    look different after a restart" needs this the same way it needs
    `order.cancelled` for a live cancel.

    A broadcast with no request, like `system.eod` — nothing asks for a recovery
    summary, the engine announces it once at startup.
    """

    restored_orders: int  # unit: dimensionless
    discarded_stale_day_orders: int  # unit: dimensionless
    discarded_unconfigured_orders: int  # unit: dimensionless
    failed_orders: int  # unit: dimensionless
    quote_remnants_restored: int  # unit: dimensionless
    rebuilt_quotes: int  # unit: dimensionless
    restored_combos: int  # unit: dimensionless
    failed_book_stats: int  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.restored_orders < 0:
            raise MessageValidationError(
                f"restored_orders: {self.restored_orders!r} must be >= 0"
            )
        if self.discarded_stale_day_orders < 0:
            raise MessageValidationError(
                f"discarded_stale_day_orders: {self.discarded_stale_day_orders!r} must be >= 0"
            )
        if self.discarded_unconfigured_orders < 0:
            raise MessageValidationError(
                f"discarded_unconfigured_orders: {self.discarded_unconfigured_orders!r} must be >= 0"
            )
        if self.failed_orders < 0:
            raise MessageValidationError(
                f"failed_orders: {self.failed_orders!r} must be >= 0"
            )
        if self.quote_remnants_restored < 0:
            raise MessageValidationError(
                f"quote_remnants_restored: {self.quote_remnants_restored!r} must be >= 0"
            )
        if self.rebuilt_quotes < 0:
            raise MessageValidationError(
                f"rebuilt_quotes: {self.rebuilt_quotes!r} must be >= 0"
            )
        if self.restored_combos < 0:
            raise MessageValidationError(
                f"restored_combos: {self.restored_combos!r} must be >= 0"
            )
        if self.failed_book_stats < 0:
            raise MessageValidationError(
                f"failed_book_stats: {self.failed_book_stats!r} must be >= 0"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "StartupRecovery":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            restored_orders=int(p["restored_orders"]),
            discarded_stale_day_orders=int(p["discarded_stale_day_orders"]),
            discarded_unconfigured_orders=int(p["discarded_unconfigured_orders"]),
            failed_orders=int(p["failed_orders"]),
            quote_remnants_restored=int(p["quote_remnants_restored"]),
            rebuilt_quotes=int(p["rebuilt_quotes"]),
            restored_combos=int(p["restored_combos"]),
            failed_book_stats=int(p["failed_book_stats"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "restored_orders": self.restored_orders,
            "discarded_stale_day_orders": self.discarded_stale_day_orders,
            "discarded_unconfigured_orders": self.discarded_unconfigured_orders,
            "failed_orders": self.failed_orders,
            "quote_remnants_restored": self.quote_remnants_restored,
            "rebuilt_quotes": self.rebuilt_quotes,
            "restored_combos": self.restored_combos,
            "failed_book_stats": self.failed_book_stats,
        }


def is_startup_recovery(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_STARTUP_RECOVERY


def make_startup_recovery(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = StartupRecovery.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_STARTUP_RECOVERY, obj.to_dict())


def make_startup_recovery_unchecked(
    *,
    restored_orders: int,
    discarded_stale_day_orders: int,
    discarded_unconfigured_orders: int,
    failed_orders: int,
    quote_remnants_restored: int,
    rebuilt_quotes: int,
    restored_combos: int,
    failed_book_stats: int,
) -> list[bytes]:
    """Identical frames to ``make_startup_recovery``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_STARTUP_RECOVERY_BYTES,
        _msg.dumps(
            {
                "restored_orders": int(restored_orders),
                "discarded_stale_day_orders": int(discarded_stale_day_orders),
                "discarded_unconfigured_orders": int(discarded_unconfigured_orders),
                "failed_orders": int(failed_orders),
                "quote_remnants_restored": int(quote_remnants_restored),
                "rebuilt_quotes": int(rebuilt_quotes),
                "restored_combos": int(restored_combos),
                "failed_book_stats": int(failed_book_stats),
            }
        ),
    ]


def parse_startup_recovery(frames: list[bytes]) -> "StartupRecovery":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = StartupRecovery.from_dict(payload)
    obj.validate()
    return obj


def describe_startup_recovery() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _STARTUP_RECOVERY_FIELDS


TOPIC_RECOVERY_ITEM = "system.recovery_item"
_TOPIC_RECOVERY_ITEM_BYTES = "system.recovery_item".encode()
_RECOVERY_ITEM_KIND_VALUES = ("ORDER", "COMBO")
RecoveryItemKind = Literal["ORDER", "COMBO"]
_RECOVERY_ITEM_OUTCOME_VALUES = (
    "RESTORED",
    "DISCARDED_STALE_DAY",
    "DISCARDED_UNCONFIGURED",
    "FAILED",
    "QUOTE_REMNANT",
)
RecoveryItemOutcome = Literal[
    "RESTORED",
    "DISCARDED_STALE_DAY",
    "DISCARDED_UNCONFIGURED",
    "FAILED",
    "QUOTE_REMNANT",
]


_RECOVERY_ITEM_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "entity_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "The order id (ORDER) or combo id (COMBO) this line is about.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "kind",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "What restore_gtc() was processing.",
        "values": _RECOVERY_ITEM_KIND_VALUES,
    },
    {
        "name": "outcome",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "RESTORED/DISCARDED_STALE_DAY/DISCARDED_UNCONFIGURED/FAILED come from the main GTC-order (or GTC-combo) restore pass and are mutually exclusive per entity. DISCARDED_UNCONFIGURED is an order the deployed configuration no longer allows (see `startup_recovery.discarded_unconfigured_orders`). QUOTE_REMNANT is a second, additional line for a RESTORED quote-origin order whose sibling leg did not come back — see the example_note above. COMBO-kind lines are always RESTORED today: `load_gtc_combos()` has no per-combo guard, so there is no combo failure path to report yet.",
        "values": _RECOVERY_ITEM_OUTCOME_VALUES,
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The instrument, for an ORDER-kind line. Null for COMBO, which may span more than one symbol across its legs and has none of its own.",
        "constraints": {"max_len": 16},
    },
    {
        "name": "detail",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Free text, when there is something worth saying beyond kind and outcome — the exception message for a FAILED order, in particular.",
        "constraints": {"max_len": 512},
    },
)


@dataclass(frozen=True, slots=True)
class RecoveryItem:
    """Engine to all subscribers: one restored, discarded or failed entity from
    `_restore_gtc()` (AR-0.5). `startup_recovery`'s order and combo counts say
    *how many*; this says *which ones* — "which order failed to restore?" was
    unanswerable from either the counts alone or the process log, since a post-
    mortem investigating a startup only sees what was published (see
    ../../docs/books/operator-guide/part-6-observe-and-recover/020-audit-
    trail.md). Published once per entity, before the single summary
    `startup_recovery` broadcast, so the counts there are the cross-check:
    `restored_orders + discarded_stale_day_orders + discarded_unconfigured_orders
    + failed_orders` must equal the number of ORDER-kind recovery_item lines whose
    outcome is RESTORED, DISCARDED_STALE_DAY, DISCARDED_UNCONFIGURED or FAILED
    respectively, and `restored_combos` must equal the number of COMBO-kind lines.

    `QUOTE_REMNANT` is deliberately not exclusive with `RESTORED`: a quote-origin order
    whose sibling leg did not survive is *both* one of `restored_orders` (it rests on
    the book, ordinarily) *and* one of `quote_remnants_restored` (it is not quote-
    managed going forward) — `_restore_gtc()` has always counted it in both totals, so
    it gets two recovery_item lines with the same entity_id, not one that overwrites the
    other. `rebuilt_quotes` — an active QuoteIndex entry rebuilt once *both* legs of a
    quote survive — is deliberately not an entity here. It is a pairing of two already-
    reported order ids, not a persisted thing with an id of its own to fail or be
    discarded; the summary count on `startup_recovery` is the whole story for it, same
    as it always was.
    """

    entity_id: str
    kind: RecoveryItemKind
    outcome: RecoveryItemOutcome
    symbol: str | None = None
    detail: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.entity_id) > 64:
            raise MessageValidationError(
                f"entity_id: length {len(self.entity_id)} exceeds max_len 64"
            )
        if self.kind not in _RECOVERY_ITEM_KIND_VALUES:
            raise MessageValidationError(
                f"kind: {self.kind!r} is not one of {_RECOVERY_ITEM_KIND_VALUES!r}"
            )
        if self.outcome not in _RECOVERY_ITEM_OUTCOME_VALUES:
            raise MessageValidationError(
                f"outcome: {self.outcome!r} is not one of {_RECOVERY_ITEM_OUTCOME_VALUES!r}"
            )
        if self.symbol is not None:
            if len(self.symbol) > 16:
                raise MessageValidationError(
                    f"symbol: length {len(self.symbol)} exceeds max_len 16"
                )
        if len(self.detail) > 512:
            raise MessageValidationError(
                f"detail: length {len(self.detail)} exceeds max_len 512"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "RecoveryItem":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            entity_id=str(p["entity_id"]),
            kind=cast(RecoveryItemKind, str(p["kind"])),
            outcome=cast(RecoveryItemOutcome, str(p["outcome"])),
            symbol=None if p.get("symbol") is None else str(p["symbol"]),
            detail=str(p.get("detail", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "entity_id": self.entity_id,
            "kind": self.kind,
            "outcome": self.outcome,
        }
        if self.symbol is not None:
            payload["symbol"] = self.symbol
        if self.detail:
            payload["detail"] = self.detail
        return payload


def is_recovery_item(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_RECOVERY_ITEM


def make_recovery_item(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = RecoveryItem.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_RECOVERY_ITEM, obj.to_dict())


def make_recovery_item_unchecked(
    *,
    entity_id: str,
    kind: RecoveryItemKind,
    outcome: RecoveryItemOutcome,
    symbol: str | None = None,
    detail: str = "",
) -> list[bytes]:
    """Identical frames to ``make_recovery_item``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "entity_id": str(entity_id),
        "kind": str(kind),
        "outcome": str(outcome),
    }
    if symbol is not None:
        payload["symbol"] = str(symbol)
    if detail:
        payload["detail"] = str(detail)
    return [
        _TOPIC_RECOVERY_ITEM_BYTES,
        _msg.dumps(payload),
    ]


def parse_recovery_item(frames: list[bytes]) -> "RecoveryItem":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = RecoveryItem.from_dict(payload)
    obj.validate()
    return obj


def describe_recovery_item() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _RECOVERY_ITEM_FIELDS


TOPIC_QUOTE_SEED_SKIPPED = "system.quote_seed_skipped"
_TOPIC_QUOTE_SEED_SKIPPED_BYTES = "system.quote_seed_skipped".encode()
_QUOTE_SEED_SKIPPED_REASON_VALUES = ("ACTIVE_QUOTE_RESTORED",)
QuoteSeedSkippedReason = Literal["ACTIVE_QUOTE_RESTORED"]


_QUOTE_SEED_SKIPPED_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "The market maker the seed is configured for.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 16},
    },
    {
        "name": "quote_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "The seed's quote id: the one that was not injected.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "reason",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "`seed_once` is set and an active quote was restored.",
        "values": _QUOTE_SEED_SKIPPED_REASON_VALUES,
    },
)


@dataclass(frozen=True, slots=True)
class QuoteSeedSkipped:
    """Engine to all subscribers: a configured seed quote the engine did not inject
    at startup because `seed_once` is set and the gateway already has an active
    quote in that symbol, restored from the persisted orders. A seed that fires
    leaves its own legs' acks; one that does not left no trace but a line in the
    process log, so a post-mortem asking "why is MM01's quote in this book not the
    configured seed?" could only infer it from the seed's absence.
    """

    gateway_id: str
    symbol: str
    quote_id: str
    reason: QuoteSeedSkippedReason

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if len(self.quote_id) > 64:
            raise MessageValidationError(
                f"quote_id: length {len(self.quote_id)} exceeds max_len 64"
            )
        if self.reason not in _QUOTE_SEED_SKIPPED_REASON_VALUES:
            raise MessageValidationError(
                f"reason: {self.reason!r} is not one of {_QUOTE_SEED_SKIPPED_REASON_VALUES!r}"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteSeedSkipped":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            symbol=str(p["symbol"]),
            quote_id=str(p["quote_id"]),
            reason=cast(QuoteSeedSkippedReason, str(p["reason"])),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
            "symbol": self.symbol,
            "quote_id": self.quote_id,
            "reason": self.reason,
        }


def is_quote_seed_skipped(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_QUOTE_SEED_SKIPPED


def make_quote_seed_skipped(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteSeedSkipped.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_QUOTE_SEED_SKIPPED, obj.to_dict())


def make_quote_seed_skipped_unchecked(
    *,
    gateway_id: str,
    symbol: str,
    quote_id: str,
    reason: QuoteSeedSkippedReason,
) -> list[bytes]:
    """Identical frames to ``make_quote_seed_skipped``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_QUOTE_SEED_SKIPPED_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
                "symbol": str(symbol),
                "quote_id": str(quote_id),
                "reason": str(reason),
            }
        ),
    ]


def parse_quote_seed_skipped(frames: list[bytes]) -> "QuoteSeedSkipped":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = QuoteSeedSkipped.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_seed_skipped() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_SEED_SKIPPED_FIELDS


TOPIC_DIAGNOSTIC = "system.diagnostic"
_TOPIC_DIAGNOSTIC_BYTES = "system.diagnostic".encode()
_DIAGNOSTIC_COMPONENT_VALUES = (
    "MAINTENANCE_FLUSH",
    "DISPATCH_ERROR",
    "UNDECODABLE_MESSAGE",
    "UNROUTED_TOPIC",
)
DiagnosticComponent = Literal[
    "MAINTENANCE_FLUSH",
    "DISPATCH_ERROR",
    "UNDECODABLE_MESSAGE",
    "UNROUTED_TOPIC",
]


_DIAGNOSTIC_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "component",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "Which internal area this diagnostic came from.",
        "values": _DIAGNOSTIC_COMPONENT_VALUES,
    },
    {
        "name": "detail",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "What within component — the flush function name, the message topic, or empty when there is no finer-grained name (an undecodable message has no topic to report).",
        "constraints": {"max_len": 256},
    },
    {
        "name": "error",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The exception text, when this diagnostic came from one.",
        "constraints": {"max_len": 512},
    },
    {
        "name": "count",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "This component's running occurrence count for the process lifetime — the same counter the log line already reports, carried onto the wire so a subscriber can tell a first occurrence from a recurring one without correlating timestamps against the log.",
        "constraints": {"ge": 0},
    },
)


@dataclass(frozen=True, slots=True)
class Diagnostic:
    """Engine to all subscribers: an internal failure or anomaly that the engine
    absorbed and kept running past, so trading was not interrupted but the event
    still happened and a post-mortem needs to see it. Before this existed, a
    maintenance-flush exception, a handler crash, an undecodable inbound message,
    or a message on an unhandled topic reached only the process log — `pm-audit`'s
    bare PUB subscription on the engine's :5556 socket (see
    ../../docs/books/operator-guide/part-6-observe-and-recover/020-audit-trail.md)
    never saw any of them, so a bug that only ever showed up as "the book snapshot
    stopped updating" or "an order silently never got a reply" had no trail to
    replay. This does not replace logging (the process log keeps the full
    traceback); it is the wire-visible marker that something in `component`
    happened, with enough detail to go find the log line.

    Deliberately generic — a `component`/`detail`/`error` triple rather than one message
    type per failure mode, because the failure modes (a maintenance flush, a dispatch-
    handler crash, an undecodable pull message, an unrouted topic) share nothing
    structural beyond "engine kept running, something still needs recording."
    """

    component: DiagnosticComponent
    detail: str
    count: int  # unit: dimensionless
    error: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if self.component not in _DIAGNOSTIC_COMPONENT_VALUES:
            raise MessageValidationError(
                f"component: {self.component!r} is not one of {_DIAGNOSTIC_COMPONENT_VALUES!r}"
            )
        if len(self.detail) > 256:
            raise MessageValidationError(
                f"detail: length {len(self.detail)} exceeds max_len 256"
            )
        if len(self.error) > 512:
            raise MessageValidationError(
                f"error: length {len(self.error)} exceeds max_len 512"
            )
        if self.count < 0:
            raise MessageValidationError(f"count: {self.count!r} must be >= 0")

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Diagnostic":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            component=cast(DiagnosticComponent, str(p["component"])),
            detail=str(p["detail"]),
            error=str(p.get("error", "")),
            count=int(p["count"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "component": self.component,
            "detail": self.detail,
            "error": self.error,
            "count": self.count,
        }


def is_diagnostic(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_DIAGNOSTIC


def make_diagnostic(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = Diagnostic.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_DIAGNOSTIC, obj.to_dict())


def make_diagnostic_unchecked(
    *,
    component: DiagnosticComponent,
    detail: str,
    count: int,
    error: str = "",
) -> list[bytes]:
    """Identical frames to ``make_diagnostic``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_DIAGNOSTIC_BYTES,
        _msg.dumps(
            {
                "component": str(component),
                "detail": str(detail),
                "error": str(error),
                "count": int(count),
            }
        ),
    ]


def parse_diagnostic(frames: list[bytes]) -> "Diagnostic":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = Diagnostic.from_dict(payload)
    obj.validate()
    return obj


def describe_diagnostic() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _DIAGNOSTIC_FIELDS


TOPIC_SYMBOLS_REQUEST = "system.symbols_request"
_TOPIC_SYMBOLS_REQUEST_BYTES = "system.symbols_request".encode()


_SYMBOLS_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Both the correlation key for the reply topic and the identity the market-maker fields are resolved against.",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class SymbolsRequest:
    """Caller to engine: which instruments are tradable, and on what terms for me."""

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SymbolsRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_symbols_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_SYMBOLS_REQUEST


def make_symbols_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = SymbolsRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_SYMBOLS_REQUEST, obj.to_dict())


def make_symbols_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_symbols_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_SYMBOLS_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_symbols_request(frames: list[bytes]) -> "SymbolsRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = SymbolsRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_symbols_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _SYMBOLS_REQUEST_FIELDS


TOPIC_SYMBOLS = "system.symbols.{gateway_id}"
PREFIX_SYMBOLS = "system.symbols."
_SYMBOLS_RE = re.compile("system\\.symbols\\.(?P<gateway_id>[^.]+)")


_SYMBOLS_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped from the body by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbols",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Sorted by symbol, as the engine iterates its books.",
    },
)


@dataclass(frozen=True, slots=True)
class Symbols:
    """Engine to caller: the tradable instruments, with the tick scale and this
    caller's market-making terms for each.

    The default projection is right here: `gateway_id` names the caller in the topic and
    has never been in the body. Verified against the producer rather than assumed --
    section 26.4 is the case where assuming cost five wires a field. One collection, not
    two. The old payload carried `symbols` as a list of strings beside `symbol_meta` as
    a map from those same strings to their metadata, built in the same loop; nine
    readers joined them back together. The join is gone.
    """

    gateway_id: str
    symbols: list[SymbolInfo]

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        for symbols_item in self.symbols:
            symbols_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Symbols":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            symbols=[SymbolInfo.from_dict(item) for item in p["symbols"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "symbols": [item.to_dict() for item in self.symbols],
        }


def topic_symbols(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.symbols.{gateway_id}"


def match_symbols(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _SYMBOLS_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_symbols(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = Symbols.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_symbols(obj.gateway_id), obj.to_dict())


def parse_symbols(frames: list[bytes]) -> "Symbols":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_symbols(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_SYMBOLS!r}")
    payload = {**payload, "gateway_id": matched}
    obj = Symbols.from_dict(payload)
    obj.validate()
    return obj


def describe_symbols() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _SYMBOLS_FIELDS


TOPIC_REFERENCE_REQUEST = "system.reference_request"
_TOPIC_REFERENCE_REQUEST_BYTES = "system.reference_request".encode()


_REFERENCE_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Correlation key only. The API gateway passes an API key here for read-only callers, since the bundle does not vary by caller and this only has to be unique.",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class ReferenceRequest:
    """Any caller to engine: the compiled reference-data bundle. Static configuration
    only -- nothing that changes during a session.
    """

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "ReferenceRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_reference_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_REFERENCE_REQUEST


def make_reference_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = ReferenceRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_REFERENCE_REQUEST, obj.to_dict())


def make_reference_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_reference_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_REFERENCE_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_reference_request(frames: list[bytes]) -> "ReferenceRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = ReferenceRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_reference_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _REFERENCE_REQUEST_FIELDS


TOPIC_REFERENCE = "system.reference.{gateway_id}"
PREFIX_REFERENCE = "system.reference."
_REFERENCE_RE = re.compile("system\\.reference\\.(?P<gateway_id>[^.]+)")


_REFERENCE_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped from the body by the default projection. Bounded at 64 rather than 32 because the API gateway passes an API key here for read-only callers.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "symbols",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Sorted by symbol. Was a map keyed by it.",
    },
    {
        "name": "risk",
        "type": "nested",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "indexes",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Already a list of records before this phase.",
    },
    {
        "name": "schedule",
        "type": "nested",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "config_version",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Truncated SHA-256 of the bundle, without the schedule's per-day fields (`today`, `today_is_holiday`, `upcoming_holidays`), so the same configuration has the same version every day. Null before a config is loaded, which is the only remaining difference between the two states the old two-shape reply used to distinguish. Regime 2: every consumer compares it, so the key has to be there to compare.",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class Reference:
    """Engine to caller: every piece of static venue configuration in one round trip
    -- tick scales, risk levels, circuit-breaker ladders, index definitions and
    the calendar -- with a hash that changes when any of it does.

    The whole payload was a `dict[str, Any]` passed to `encode` unread. One producer
    builds it -- `_rebuild_reference_cache` -- with five fixed top-level keys, so it was
    a record nobody had written down. ONE SHAPE, ALWAYS. Before an engine config is
    loaded the reply used to be `{"config_version": null}` and nothing else: a second
    payload shape for the same topic, which every slicing endpoint compensated for with
    a `.get(key, {})` default. The bundle is now always complete, with empty collections
    and a null version, and the compensating defaults go with it. REST-VISIBLE.
    `api_gateway/routers/reference.py` returns slices of this bundle verbatim, so
    `reference.symbols` becoming a list of records and `reference.schedule` gaining a
    level of nesting change `GET /reference/symbols` and `GET /reference/schedule`.
    Sanctioned, and the better JSON in both cases -- a list of objects each carrying its
    own `symbol` is what a client can iterate without knowing the keys.
    `../../docs/books/operator-guide/part-5-gateways/050-api-gateway.md` moves with it.
    """

    gateway_id: str
    symbols: list[ReferenceSymbol]
    risk: ReferenceRisk
    indexes: list[IndexDefinition]
    schedule: ReferenceSchedule
    config_version: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 64:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 64"
            )
        for symbols_item in self.symbols:
            symbols_item.validate()
        self.risk.validate()
        for indexes_item in self.indexes:
            indexes_item.validate()
        self.schedule.validate()
        if self.config_version is not None:
            if len(self.config_version) > 64:
                raise MessageValidationError(
                    f"config_version: length {len(self.config_version)} exceeds max_len 64"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Reference":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            symbols=[ReferenceSymbol.from_dict(item) for item in p["symbols"]],
            risk=ReferenceRisk.from_dict(p["risk"]),
            indexes=[IndexDefinition.from_dict(item) for item in p["indexes"]],
            schedule=ReferenceSchedule.from_dict(p["schedule"]),
            config_version=(
                None if p.get("config_version") is None else str(p["config_version"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "symbols": [item.to_dict() for item in self.symbols],
            "risk": self.risk.to_dict(),
            "indexes": [item.to_dict() for item in self.indexes],
            "schedule": self.schedule.to_dict(),
            "config_version": self.config_version,
        }


def topic_reference(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.reference.{gateway_id}"


def match_reference(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _REFERENCE_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_reference(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = Reference.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_reference(obj.gateway_id), obj.to_dict())


def parse_reference(frames: list[bytes]) -> "Reference":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_reference(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_REFERENCE!r}")
    payload = {**payload, "gateway_id": matched}
    obj = Reference.from_dict(payload)
    obj.validate()
    return obj


def describe_reference() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _REFERENCE_FIELDS


TOPIC_REFERENCE_RELOAD = "system.reference_reload"
_TOPIC_REFERENCE_RELOAD_BYTES = "system.reference_reload".encode()


_REFERENCE_RELOAD_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "command_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Correlated by the ack. Read off the wire unclamped before this phase, and quoted straight into a bounded ack field -- section 22.3's silent non-answer, four reply paths.",
        "constraints": {"max_len": 64},
    },
)


@dataclass(frozen=True, slots=True)
class ReferenceReload:
    """ADMIN to engine: re-read static reference data from disk. Deliberately
    narrower than a startup load -- it never re-seeds quotes, creates or removes
    books, or touches session and halt state, so a reload that changed the symbol
    set is rejected rather than partially applied. The engine also rejects reloads
    when the active config cannot be reconstructed from the audit trail: compiled
    artifacts have no reloadable source file, and YAML fallback config is not
    recorded in system.startup. Deploy a compiled artifact and restart to apply
    config changes without making the audit trail ambiguous.
    """

    gateway_id: str
    command_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.command_id) > 64:
            raise MessageValidationError(
                f"command_id: length {len(self.command_id)} exceeds max_len 64"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "ReferenceReload":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            command_id=str(p["command_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
            "command_id": self.command_id,
        }


def is_reference_reload(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_REFERENCE_RELOAD


def make_reference_reload(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = ReferenceReload.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_REFERENCE_RELOAD, obj.to_dict())


def make_reference_reload_unchecked(
    *,
    gateway_id: str,
    command_id: str,
) -> list[bytes]:
    """Identical frames to ``make_reference_reload``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_REFERENCE_RELOAD_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
                "command_id": str(command_id),
            }
        ),
    ]


def parse_reference_reload(frames: list[bytes]) -> "ReferenceReload":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = ReferenceReload.from_dict(payload)
    obj.validate()
    return obj


def describe_reference_reload() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _REFERENCE_RELOAD_FIELDS


TOPIC_REFERENCE_RELOAD_ACK = "system.reference_reload_ack.{gateway_id}"
PREFIX_REFERENCE_RELOAD_ACK = "system.reference_reload_ack."
_REFERENCE_RELOAD_ACK_RE = re.compile(
    "system\\.reference_reload_ack\\.(?P<gateway_id>[^.]+)"
)


_REFERENCE_RELOAD_ACK_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped from the body by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "command_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 64},
    },
    {
        "name": "accepted",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "config_version",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Present on acceptance.",
        "constraints": {"max_len": 64},
    },
    {
        "name": "reason",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "Present on rejection.",
        "constraints": {"max_len": 512},
    },
)


@dataclass(frozen=True, slots=True)
class ReferenceReloadAck:
    """Engine to ADMIN: the reload verdict, and the new configuration hash when it
    took.

    The default projection is right: `gateway_id` is topic-only and has never been in
    the body. `config_version` and `reason` are the two halves of the verdict and never
    travel together -- an accepted reload carries the version, a rejected one carries
    the reason.
    """

    gateway_id: str
    command_id: str
    accepted: bool
    config_version: str | None = None
    reason: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.command_id) > 64:
            raise MessageValidationError(
                f"command_id: length {len(self.command_id)} exceeds max_len 64"
            )
        if self.config_version is not None:
            if len(self.config_version) > 64:
                raise MessageValidationError(
                    f"config_version: length {len(self.config_version)} exceeds max_len 64"
                )
        if self.reason is not None:
            if len(self.reason) > 512:
                raise MessageValidationError(
                    f"reason: length {len(self.reason)} exceeds max_len 512"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "ReferenceReloadAck":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            command_id=str(p["command_id"]),
            accepted=bool(p["accepted"]),
            config_version=(
                None if p.get("config_version") is None else str(p["config_version"])
            ),
            reason=None if p.get("reason") is None else str(p["reason"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "command_id": self.command_id,
            "accepted": self.accepted,
        }
        if self.config_version is not None:
            payload["config_version"] = self.config_version
        if self.reason is not None:
            payload["reason"] = self.reason
        return payload


def topic_reference_reload_ack(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.reference_reload_ack.{gateway_id}"


def match_reference_reload_ack(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _REFERENCE_RELOAD_ACK_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_reference_reload_ack(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = ReferenceReloadAck.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_reference_reload_ack(obj.gateway_id), obj.to_dict())


def make_reference_reload_ack_unchecked(
    *,
    gateway_id: str,
    command_id: str,
    accepted: bool,
    config_version: str | None = None,
    reason: str | None = None,
) -> list[bytes]:
    """Identical frames to ``make_reference_reload_ack``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    payload: dict[str, Any] = {
        "command_id": str(command_id),
        "accepted": bool(accepted),
    }
    if config_version is not None:
        payload["config_version"] = str(config_version)
    if reason is not None:
        payload["reason"] = str(reason)
    return [
        topic_reference_reload_ack(gateway_id).encode(),
        _msg.dumps(payload),
    ]


def parse_reference_reload_ack(frames: list[bytes]) -> "ReferenceReloadAck":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_reference_reload_ack(topic)
    if matched is None:
        raise MessageValidationError(
            f"topic {topic!r} is not {TOPIC_REFERENCE_RELOAD_ACK!r}"
        )
    payload = {**payload, "gateway_id": matched}
    obj = ReferenceReloadAck.from_dict(payload)
    obj.validate()
    return obj


def describe_reference_reload_ack() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _REFERENCE_RELOAD_ACK_FIELDS


TOPIC_SESSION_STATE_REQUEST = "system.session_state_request"
_TOPIC_SESSION_STATE_REQUEST_BYTES = "system.session_state_request".encode()


_SESSION_STATE_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class SessionStateRequest:
    """Caller to engine: what session are we in, without advancing it. The scheduler
    is the dominant producer -- it asks rather than assuming, because it is not
    the only thing that can move the session.
    """

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SessionStateRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_session_state_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_SESSION_STATE_REQUEST


def make_session_state_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = SessionStateRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_SESSION_STATE_REQUEST, obj.to_dict())


def make_session_state_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_session_state_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_SESSION_STATE_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_session_state_request(frames: list[bytes]) -> "SessionStateRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = SessionStateRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_session_state_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _SESSION_STATE_REQUEST_FIELDS


TOPIC_SESSION_STATUS = "system.session_status.{gateway_id}"
PREFIX_SESSION_STATUS = "system.session_status."
_SESSION_STATUS_RE = re.compile("system\\.session_status\\.(?P<gateway_id>[^.]+)")


_SESSION_STATUS_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped from the body by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "state",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Same values as `session.state.state`.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "state_since",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "UTC instant the engine entered `state` -- its last accepted transition, else its start -- as `YYYY-MM-DDTHH:MM:SS.mmmZ`. Lets a caller tell a state left over from an earlier day, such as a `CONTINUOUS` whose close never came, from the same state entered today.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "sessions_enabled",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "False when the deployment runs continuously with no session schedule at all, which makes `state` advisory.",
    },
    {
        "name": "next",
        "type": "nested",
        "unit": None,
        "required": False,
        "doc": "The countdown target the engine holds, as `session.state.next` last carried it or `session.next` announced it. Lets a caller that missed the last transition still count down to the next one.",
    },
    {
        "name": "last_trade_id",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": "The id of the last trade this engine run has made so far, null before its first: what `system.eod` will name if the run ends now.",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class SessionStatus:
    """Engine to caller: the current session state, on request. The polled answer to
    the `session.state` broadcast, for a caller that has just started and missed
    the last transition.

    Default projection: `gateway_id` is topic-only. `state` is a plain bounded string
    rather than an enum, matching `session.state.state` -- the value set lives in the
    session machine, and enumerating it in two specs would be two places to update.
    """

    gateway_id: str
    state: str
    state_since: str
    sessions_enabled: bool
    next: NextTransition | None = None
    last_trade_id: str | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.state) > 32:
            raise MessageValidationError(
                f"state: length {len(self.state)} exceeds max_len 32"
            )
        if len(self.state_since) > 32:
            raise MessageValidationError(
                f"state_since: length {len(self.state_since)} exceeds max_len 32"
            )
        if self.next is not None:
            self.next.validate()
        if self.last_trade_id is not None:
            if len(self.last_trade_id) > 32:
                raise MessageValidationError(
                    f"last_trade_id: length {len(self.last_trade_id)} exceeds max_len 32"
                )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SessionStatus":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            state=str(p["state"]),
            state_since=str(p["state_since"]),
            sessions_enabled=bool(p["sessions_enabled"]),
            next=None if p.get("next") is None else NextTransition.from_dict(p["next"]),
            last_trade_id=(
                None if p.get("last_trade_id") is None else str(p["last_trade_id"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        payload: dict[str, Any] = {
            "state": self.state,
            "state_since": self.state_since,
            "sessions_enabled": self.sessions_enabled,
            "last_trade_id": self.last_trade_id,
        }
        if self.next is not None:
            payload["next"] = self.next.to_dict()
        return payload


def topic_session_status(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.session_status.{gateway_id}"


def match_session_status(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _SESSION_STATUS_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_session_status(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = SessionStatus.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_session_status(obj.gateway_id), obj.to_dict())


def parse_session_status(frames: list[bytes]) -> "SessionStatus":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_session_status(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_SESSION_STATUS!r}")
    payload = {**payload, "gateway_id": matched}
    obj = SessionStatus.from_dict(payload)
    obj.validate()
    return obj


def describe_session_status() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _SESSION_STATUS_FIELDS


TOPIC_SESSION_SCHEDULE_REQUEST = "system.session_schedule_request"
_TOPIC_SESSION_SCHEDULE_REQUEST_BYTES = "system.session_schedule_request".encode()


_SESSION_SCHEDULE_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class SessionScheduleRequest:
    """Operator to engine: the configured session schedule."""

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SessionScheduleRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_session_schedule_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_SESSION_SCHEDULE_REQUEST


def make_session_schedule_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = SessionScheduleRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_SESSION_SCHEDULE_REQUEST, obj.to_dict())


def make_session_schedule_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_session_schedule_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_SESSION_SCHEDULE_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_session_schedule_request(frames: list[bytes]) -> "SessionScheduleRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = SessionScheduleRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_session_schedule_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _SESSION_SCHEDULE_REQUEST_FIELDS


TOPIC_SESSION_SCHEDULE = "system.session_schedule.{gateway_id}"
PREFIX_SESSION_SCHEDULE = "system.session_schedule."
_SESSION_SCHEDULE_RE = re.compile("system\\.session_schedule\\.(?P<gateway_id>[^.]+)")


_SESSION_SCHEDULE_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped from the body by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "sessions_enabled",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "schedule",
        "type": "nested",
        "unit": None,
        "required": False,
        "doc": "Null when no `schedule:` block is configured.",
    },
)


@dataclass(frozen=True, slots=True)
class SessionSchedule:
    """Engine to operator: the trading day's clock as configured. The same
    `SessionTimes` record `system.reference` carries, which is what forced these
    two topics into one phase.

    Default projection: `gateway_id` is topic-only. Both readers -- `commands/client.py`
    and `GET /admin/schedule` -- pass the payload through to a caller without touching a
    key, so nothing structural constrains the presence regime here; `schedule` is regime
    2 to match the copy inside `ReferenceSchedule` rather than because a reader needs
    it. It was `schedule or {}` before, so an unconfigured venue sent an empty object
    where it now sends null.
    """

    gateway_id: str
    sessions_enabled: bool
    schedule: WeeklySchedule | None = None

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if self.schedule is not None:
            self.schedule.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "SessionSchedule":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            sessions_enabled=bool(p["sessions_enabled"]),
            schedule=(
                None
                if p.get("schedule") is None
                else WeeklySchedule.from_dict(p["schedule"])
            ),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "sessions_enabled": self.sessions_enabled,
            "schedule": None if self.schedule is None else self.schedule.to_dict(),
        }


def topic_session_schedule(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.session_schedule.{gateway_id}"


def match_session_schedule(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _SESSION_SCHEDULE_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_session_schedule(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = SessionSchedule.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_session_schedule(obj.gateway_id), obj.to_dict())


def parse_session_schedule(frames: list[bytes]) -> "SessionSchedule":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_session_schedule(topic)
    if matched is None:
        raise MessageValidationError(
            f"topic {topic!r} is not {TOPIC_SESSION_SCHEDULE!r}"
        )
    payload = {**payload, "gateway_id": matched}
    obj = SessionSchedule.from_dict(payload)
    obj.validate()
    return obj


def describe_session_schedule() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _SESSION_SCHEDULE_FIELDS


TOPIC_HALT_STATUS_REQUEST = "system.halt_status_request"
_TOPIC_HALT_STATUS_REQUEST_BYTES = "system.halt_status_request".encode()


_HALT_STATUS_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class HaltStatusRequest:
    """Any process to engine: which instruments are halted now."""

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "HaltStatusRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_halt_status_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_HALT_STATUS_REQUEST


def make_halt_status_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = HaltStatusRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_HALT_STATUS_REQUEST, obj.to_dict())


def make_halt_status_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_halt_status_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_HALT_STATUS_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_halt_status_request(frames: list[bytes]) -> "HaltStatusRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = HaltStatusRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_halt_status_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _HALT_STATUS_REQUEST_FIELDS


TOPIC_HALT_STATUS = "system.halt_status.{gateway_id}"
PREFIX_HALT_STATUS = "system.halt_status."
_HALT_STATUS_RE = re.compile("system\\.halt_status\\.(?P<gateway_id>[^.]+)")


_HALT_STATUS_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "halted",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "",
    },
)


@dataclass(frozen=True, slots=True)
class HaltStatus:
    """Engine to caller: every currently-halted instrument, with the breaker state
    behind it where a breaker is what halted it. The polled answer to the
    `circuit_breaker.halt` broadcast, for a caller that has just started and
    missed it.

    An empty list means nothing is halted, which is the normal reply. The three optional
    fields are present together or not at all: an ADMIN halt sets the flag with no
    breaker behind it.
    """

    gateway_id: str
    halted: list[HaltedSymbol]

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        for halted_item in self.halted:
            halted_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "HaltStatus":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            halted=[HaltedSymbol.from_dict(item) for item in p["halted"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "halted": [item.to_dict() for item in self.halted],
        }


def topic_halt_status(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.halt_status.{gateway_id}"


def match_halt_status(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _HALT_STATUS_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_halt_status(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = HaltStatus.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_halt_status(obj.gateway_id), obj.to_dict())


def parse_halt_status(frames: list[bytes]) -> "HaltStatus":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_halt_status(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_HALT_STATUS!r}")
    payload = {**payload, "gateway_id": matched}
    obj = HaltStatus.from_dict(payload)
    obj.validate()
    return obj


def describe_halt_status() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _HALT_STATUS_FIELDS


TOPIC_POSITION_REQUEST = "system.position_request"
_TOPIC_POSITION_REQUEST_BYTES = "system.position_request".encode()


_POSITION_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Both the correlation key and the account being asked about. Any caller may ask about any gateway (`POS|GW=`, the admin REST endpoint): the handler answers from `_gateway_positions[gateway_id]` and nothing else.",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class PositionRequest:
    """Gateway to engine: what am I holding."""

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "PositionRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_position_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_POSITION_REQUEST


def make_position_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = PositionRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_POSITION_REQUEST, obj.to_dict())


def make_position_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_position_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_POSITION_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_position_request(frames: list[bytes]) -> "PositionRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = PositionRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_position_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _POSITION_REQUEST_FIELDS


TOPIC_POSITION_SNAPSHOT = "system.position_snapshot.{gateway_id}"
PREFIX_POSITION_SNAPSHOT = "system.position_snapshot."
_POSITION_SNAPSHOT_RE = re.compile("system\\.position_snapshot\\.(?P<gateway_id>[^.]+)")
_POSITION_SNAPSHOT_STATUS_VALUES = ("OK", "NOT_CONNECTED", "UNKNOWN_GATEWAY")
PositionSnapshotStatus = Literal["OK", "NOT_CONNECTED", "UNKNOWN_GATEWAY"]


_POSITION_SNAPSHOT_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "positions",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "",
    },
    {
        "name": "status",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "`OK`: the gateway is connected. `NOT_CONNECTED`: a configured participant that is logged off; the list is still its own, as the engine holds it. `UNKNOWN_GATEWAY`: no participant has this id, so the list is empty.",
        "values": _POSITION_SNAPSHOT_STATUS_VALUES,
    },
)


@dataclass(frozen=True, slots=True)
class PositionSnapshot:
    """Engine to gateway: per-symbol net position and average cost, for the asking
    gateway only.

    Any configured participant is answered, connected or not, and `status` tells "logged
    off" and "no such id" apart from "flat". A logged-off trader keeps its position, so
    an empty list for it would be wrong rather than discreet; and whether an id exists
    is no secret (a refused logon names it). pm-mm-bot asks for its own gateway's
    snapshot at start-up and seeds each symbol's tracked position from it, so
    `inventory_skew` does not restart flat while the gateway holds inventory.
    """

    gateway_id: str
    positions: list[Position]
    status: PositionSnapshotStatus = "OK"

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        for positions_item in self.positions:
            positions_item.validate()
        if self.status not in _POSITION_SNAPSHOT_STATUS_VALUES:
            raise MessageValidationError(
                f"status: {self.status!r} is not one of {_POSITION_SNAPSHOT_STATUS_VALUES!r}"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "PositionSnapshot":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            positions=[Position.from_dict(item) for item in p["positions"]],
            status=cast(PositionSnapshotStatus, str(p.get("status", "OK"))),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "positions": [item.to_dict() for item in self.positions],
            "status": self.status,
        }


def topic_position_snapshot(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.position_snapshot.{gateway_id}"


def match_position_snapshot(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _POSITION_SNAPSHOT_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_position_snapshot(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = PositionSnapshot.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_position_snapshot(obj.gateway_id), obj.to_dict())


def parse_position_snapshot(frames: list[bytes]) -> "PositionSnapshot":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_position_snapshot(topic)
    if matched is None:
        raise MessageValidationError(
            f"topic {topic!r} is not {TOPIC_POSITION_SNAPSHOT!r}"
        )
    payload = {**payload, "gateway_id": matched}
    obj = PositionSnapshot.from_dict(payload)
    obj.validate()
    return obj


def describe_position_snapshot() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _POSITION_SNAPSHOT_FIELDS


TOPIC_QUOTE_BOOTSTRAP_REQUEST = "system.quote_bootstrap_request"
_TOPIC_QUOTE_BOOTSTRAP_REQUEST_BYTES = "system.quote_bootstrap_request".encode()


_QUOTE_BOOTSTRAP_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": 'Narrows the reply to one instrument. "" means all.',
        "constraints": {"max_len": 16},
    },
)


@dataclass(frozen=True, slots=True)
class QuoteBootstrapRequest:
    """Market maker to engine, on reconnect: what quotes do I already have resting.
    Without it a bot cannot tell a fresh start from a reconnect and will quote
    into its own orders.
    """

    gateway_id: str
    symbol: str = ""

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteBootstrapRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            symbol=str(p.get("symbol", "")),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
            "symbol": self.symbol,
        }


def is_quote_bootstrap_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_QUOTE_BOOTSTRAP_REQUEST


def make_quote_bootstrap_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteBootstrapRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_QUOTE_BOOTSTRAP_REQUEST, obj.to_dict())


def make_quote_bootstrap_request_unchecked(
    *,
    gateway_id: str,
    symbol: str = "",
) -> list[bytes]:
    """Identical frames to ``make_quote_bootstrap_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_QUOTE_BOOTSTRAP_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
                "symbol": str(symbol),
            }
        ),
    ]


def parse_quote_bootstrap_request(frames: list[bytes]) -> "QuoteBootstrapRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = QuoteBootstrapRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_bootstrap_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_BOOTSTRAP_REQUEST_FIELDS


TOPIC_QUOTE_BOOTSTRAP = "system.quote_bootstrap.{gateway_id}"
PREFIX_QUOTE_BOOTSTRAP = "system.quote_bootstrap."
_QUOTE_BOOTSTRAP_RE = re.compile("system\\.quote_bootstrap\\.(?P<gateway_id>[^.]+)")


_QUOTE_BOOTSTRAP_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "quotes",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "",
    },
)


@dataclass(frozen=True, slots=True)
class QuoteBootstrap:
    """Engine to market maker: the active quotes it already holds."""

    gateway_id: str
    quotes: list[ActiveQuote]

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        for quotes_item in self.quotes:
            quotes_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteBootstrap":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            quotes=[ActiveQuote.from_dict(item) for item in p["quotes"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "quotes": [item.to_dict() for item in self.quotes],
        }


def topic_quote_bootstrap(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.quote_bootstrap.{gateway_id}"


def match_quote_bootstrap(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _QUOTE_BOOTSTRAP_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_quote_bootstrap(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteBootstrap.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_quote_bootstrap(obj.gateway_id), obj.to_dict())


def parse_quote_bootstrap(frames: list[bytes]) -> "QuoteBootstrap":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_quote_bootstrap(topic)
    if matched is None:
        raise MessageValidationError(
            f"topic {topic!r} is not {TOPIC_QUOTE_BOOTSTRAP!r}"
        )
    payload = {**payload, "gateway_id": matched}
    obj = QuoteBootstrap.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_bootstrap() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_BOOTSTRAP_FIELDS


TOPIC_QUOTE_LEGS_REQUEST = "system.quote_legs_request"
_TOPIC_QUOTE_LEGS_REQUEST_BYTES = "system.quote_legs_request".encode()
_QUOTE_LEGS_REQUEST_SHOW_VALUES = ("ACTIVE", "RECENT", "ALL")
QuoteLegsRequestShow = Literal["ACTIVE", "RECENT", "ALL"]


_QUOTE_LEGS_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbol",
        "type": "string",
        "unit": None,
        "required": False,
        "doc": 'Narrows the reply to one instrument. "" means all.',
        "constraints": {"max_len": 16},
    },
    {
        "name": "show",
        "type": "enum",
        "unit": None,
        "required": False,
        "doc": "Which half to return. `ACTIVE` is live legs, `RECENT` is the removal history, `ALL` is both. Enumerated rather than a free string because the handler branches on exactly these three and treats anything else as `ACTIVE` -- a typo currently answers, quietly, with the wrong half.",
        "values": _QUOTE_LEGS_REQUEST_SHOW_VALUES,
    },
)


@dataclass(frozen=True, slots=True)
class QuoteLegsRequest:
    """Operator or market maker to engine: the per-leg detail behind this gateway's
    quotes, live and recently removed. What `QLEGS` asks for.
    """

    gateway_id: str
    symbol: str = ""
    show: QuoteLegsRequestShow = "ALL"

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        if len(self.symbol) > 16:
            raise MessageValidationError(
                f"symbol: length {len(self.symbol)} exceeds max_len 16"
            )
        if self.show not in _QUOTE_LEGS_REQUEST_SHOW_VALUES:
            raise MessageValidationError(
                f"show: {self.show!r} is not one of {_QUOTE_LEGS_REQUEST_SHOW_VALUES!r}"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteLegsRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
            symbol=str(p.get("symbol", "")),
            show=cast(QuoteLegsRequestShow, str(p.get("show", "ALL"))),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
            "symbol": self.symbol,
            "show": self.show,
        }


def is_quote_legs_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_QUOTE_LEGS_REQUEST


def make_quote_legs_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteLegsRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_QUOTE_LEGS_REQUEST, obj.to_dict())


def make_quote_legs_request_unchecked(
    *,
    gateway_id: str,
    symbol: str = "",
    show: QuoteLegsRequestShow = "ALL",
) -> list[bytes]:
    """Identical frames to ``make_quote_legs_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_QUOTE_LEGS_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
                "symbol": str(symbol),
                "show": str(show),
            }
        ),
    ]


def parse_quote_legs_request(frames: list[bytes]) -> "QuoteLegsRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = QuoteLegsRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_legs_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_LEGS_REQUEST_FIELDS


TOPIC_QUOTE_LEGS = "system.quote_legs.{gateway_id}"
PREFIX_QUOTE_LEGS = "system.quote_legs."
_QUOTE_LEGS_RE = re.compile("system\\.quote_legs\\.(?P<gateway_id>[^.]+)")
_QUOTE_LEGS_SHOW_REQUESTED_VALUES = ("ACTIVE", "RECENT", "ALL")
QuoteLegsShowRequested = Literal["ACTIVE", "RECENT", "ALL"]


_QUOTE_LEGS_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "legs",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Live legs. Empty unless `show` was `ACTIVE` or `ALL`.",
    },
    {
        "name": "show_requested",
        "type": "enum",
        "unit": None,
        "required": True,
        "doc": "Echo of the request's `show`, so replies can be told apart.",
        "values": _QUOTE_LEGS_SHOW_REQUESTED_VALUES,
    },
    {
        "name": "complete",
        "type": "bool",
        "unit": None,
        "required": True,
        "doc": "False when the reply could not fully answer what was asked. Always true today; kept because the recent-history buffer is bounded and a truncated answer needs a way to say so.",
    },
    {
        "name": "recent",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Removal history. Empty unless `show` was `RECENT` or `ALL`.",
    },
)


@dataclass(frozen=True, slots=True)
class QuoteLegs:
    """Engine to caller: live quote legs, recently-removed quotes, or both.

    `legs` and `recent` are both always present, empty when the requested half does not
    include them. Regime 4 would be the IDL's default instinct -- absent and `[]` are
    the same value to `alf_gwy`, the only structural reader -- but `GET /quotes/legs`
    returns this payload verbatim, and a REST client should not have to guess whether a
    key exists. `[]` is a true statement here rather than an invented one: both halves
    always mean something on this message. `show_requested` echoes what was asked, so a
    caller that pipelined two requests can tell the replies apart.
    """

    gateway_id: str
    legs: list[QuoteLeg]
    show_requested: QuoteLegsShowRequested
    complete: bool
    recent: list[RecentQuote]

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        for legs_item in self.legs:
            legs_item.validate()
        if self.show_requested not in _QUOTE_LEGS_SHOW_REQUESTED_VALUES:
            raise MessageValidationError(
                f"show_requested: {self.show_requested!r} is not one of {_QUOTE_LEGS_SHOW_REQUESTED_VALUES!r}"
            )
        for recent_item in self.recent:
            recent_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "QuoteLegs":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            legs=[QuoteLeg.from_dict(item) for item in p["legs"]],
            show_requested=cast(QuoteLegsShowRequested, str(p["show_requested"])),
            complete=bool(p["complete"]),
            recent=[RecentQuote.from_dict(item) for item in p["recent"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "legs": [item.to_dict() for item in self.legs],
            "show_requested": self.show_requested,
            "complete": self.complete,
            "recent": [item.to_dict() for item in self.recent],
        }


def topic_quote_legs(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.quote_legs.{gateway_id}"


def match_quote_legs(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _QUOTE_LEGS_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_quote_legs(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = QuoteLegs.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_quote_legs(obj.gateway_id), obj.to_dict())


def parse_quote_legs(frames: list[bytes]) -> "QuoteLegs":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_quote_legs(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_QUOTE_LEGS!r}")
    payload = {**payload, "gateway_id": matched}
    obj = QuoteLegs.from_dict(payload)
    obj.validate()
    return obj


def describe_quote_legs() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _QUOTE_LEGS_FIELDS


TOPIC_RISK_STATE_REQUEST = "system.risk_state_request"
_TOPIC_RISK_STATE_REQUEST_BYTES = "system.risk_state_request".encode()


_RISK_STATE_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class RiskStateRequest:
    """ADMIN to engine: the live collar and circuit-breaker state of every symbol
    that has either configured, halted or not.
    """

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "RiskStateRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_risk_state_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_RISK_STATE_REQUEST


def make_risk_state_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = RiskStateRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_RISK_STATE_REQUEST, obj.to_dict())


def make_risk_state_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_risk_state_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_RISK_STATE_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_risk_state_request(frames: list[bytes]) -> "RiskStateRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = RiskStateRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_risk_state_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _RISK_STATE_REQUEST_FIELDS


TOPIC_RISK_STATE = "system.risk_state.{gateway_id}"
PREFIX_RISK_STATE = "system.risk_state."
_RISK_STATE_RE = re.compile("system\\.risk_state\\.(?P<gateway_id>[^.]+)")


_RISK_STATE_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbols",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Sorted by symbol. Was a map keyed by it.",
    },
)


@dataclass(frozen=True, slots=True)
class RiskState:
    """Engine to ADMIN: live risk state per symbol. The counterpart to
    `reference.risk`, which is the static definitions, and to `halt_status`, which
    is only the symbols currently halted.

    The fourth `symbols` field in this family and the fourth different thing: a list of
    `SymbolInfo` on `system.symbols`, of `ReferenceSymbol` on `reference`, of
    `SymbolRiskState` here and of `SymbolVolume` on `volume`. Same name, four types, no
    relationship -- which is why a find-and-replace across them would be the worst
    available mistake.
    """

    gateway_id: str
    symbols: list[SymbolRiskState]

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        for symbols_item in self.symbols:
            symbols_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "RiskState":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            symbols=[SymbolRiskState.from_dict(item) for item in p["symbols"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "symbols": [item.to_dict() for item in self.symbols],
        }


def topic_risk_state(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.risk_state.{gateway_id}"


def match_risk_state(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _RISK_STATE_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_risk_state(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = RiskState.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_risk_state(obj.gateway_id), obj.to_dict())


def parse_risk_state(frames: list[bytes]) -> "RiskState":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_risk_state(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_RISK_STATE!r}")
    payload = {**payload, "gateway_id": matched}
    obj = RiskState.from_dict(payload)
    obj.validate()
    return obj


def describe_risk_state() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _RISK_STATE_FIELDS


TOPIC_GATEWAYS_REQUEST = "system.gateways_request"
_TOPIC_GATEWAYS_REQUEST_BYTES = "system.gateways_request".encode()


_GATEWAYS_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class GatewaysRequest:
    """Operator to engine: which participants exist, and who is on."""

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "GatewaysRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_gateways_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_GATEWAYS_REQUEST


def make_gateways_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = GatewaysRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_GATEWAYS_REQUEST, obj.to_dict())


def make_gateways_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_gateways_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_GATEWAYS_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_gateways_request(frames: list[bytes]) -> "GatewaysRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = GatewaysRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_gateways_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _GATEWAYS_REQUEST_FIELDS


TOPIC_GATEWAYS = "system.gateways.{gateway_id}"
PREFIX_GATEWAYS = "system.gateways."
_GATEWAYS_RE = re.compile("system\\.gateways\\.(?P<gateway_id>[^.]+)")


_GATEWAYS_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "gateways",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Sorted by id. Empty when no config is loaded.",
    },
)


@dataclass(frozen=True, slots=True)
class Gateways:
    """Engine to operator: every configured participant with its role and current
    connection status. The polled counterpart to the `gateway_auth` /
    `gateway_bye` broadcasts.
    """

    gateway_id: str
    gateways: list[GatewayInfo]

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        for gateways_item in self.gateways:
            gateways_item.validate()

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Gateways":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            gateways=[GatewayInfo.from_dict(item) for item in p["gateways"]],
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateways": [item.to_dict() for item in self.gateways],
        }


def topic_gateways(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.gateways.{gateway_id}"


def match_gateways(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _GATEWAYS_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_gateways(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = Gateways.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_gateways(obj.gateway_id), obj.to_dict())


def parse_gateways(frames: list[bytes]) -> "Gateways":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_gateways(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_GATEWAYS!r}")
    payload = {**payload, "gateway_id": matched}
    obj = Gateways.from_dict(payload)
    obj.validate()
    return obj


def describe_gateways() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _GATEWAYS_FIELDS


TOPIC_VOLUME_REQUEST = "system.volume_request"
_TOPIC_VOLUME_REQUEST_BYTES = "system.volume_request".encode()


_VOLUME_REQUEST_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "",
        "constraints": {"max_len": 32},
    },
)


@dataclass(frozen=True, slots=True)
class VolumeRequest:
    """Operator to engine: how much has traded today."""

    gateway_id: str

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "VolumeRequest":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p["gateway_id"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "gateway_id": self.gateway_id,
        }


def is_volume_request(topic: str) -> bool:
    """True when ``topic`` is this message's topic."""
    return topic == TOPIC_VOLUME_REQUEST


def make_volume_request(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = VolumeRequest.from_dict(kw)
    obj.validate()
    return _msg.encode(TOPIC_VOLUME_REQUEST, obj.to_dict())


def make_volume_request_unchecked(
    *,
    gateway_id: str,
) -> list[bytes]:
    """Identical frames to ``make_volume_request``, without ``validate()``.

    For measured hot paths only; every other caller should use the validating
    constructor. Builds the payload directly rather than via the dataclass, which is
    what makes it cheap enough to be worth having — see the generator's _unchecked_block
    docstring for the measurements.

    Coerces exactly as ``make_*`` does, so for any input the two emit byte-identical
    frames.
    """
    return [
        _TOPIC_VOLUME_REQUEST_BYTES,
        _msg.dumps(
            {
                "gateway_id": str(gateway_id),
            }
        ),
    ]


def parse_volume_request(frames: list[bytes]) -> "VolumeRequest":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    _topic, payload = _msg.decode(frames)
    obj = VolumeRequest.from_dict(payload)
    obj.validate()
    return obj


def describe_volume_request() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _VOLUME_REQUEST_FIELDS


TOPIC_VOLUME = "system.volume.{gateway_id}"
PREFIX_VOLUME = "system.volume."
_VOLUME_RE = re.compile("system\\.volume\\.(?P<gateway_id>[^.]+)")


_VOLUME_FIELDS: tuple[dict[str, Any], ...] = (
    {
        "name": "gateway_id",
        "type": "string",
        "unit": None,
        "required": True,
        "doc": "Topic-only; dropped by the default projection.",
        "constraints": {"max_len": 32},
    },
    {
        "name": "symbols",
        "type": "list",
        "unit": None,
        "required": True,
        "doc": "Sorted by symbol. Was a map keyed by it.",
    },
    {
        "name": "total_qty",
        "type": "int",
        "unit": "shares",
        "required": True,
        "doc": "",
        "constraints": {"ge": 0},
    },
    {
        "name": "total_value",
        "type": "float",
        "unit": "money",
        "required": True,
        "doc": "",
        "constraints": {"ge": 0},
    },
    {
        "name": "total_trades",
        "type": "int",
        "unit": "dimensionless",
        "required": True,
        "doc": "",
        "constraints": {"ge": 0},
    },
)


@dataclass(frozen=True, slots=True)
class Volume:
    """Engine to operator: traded quantity, notional and trade count, per instrument
    and exchange-wide.

    The totals are carried rather than left to the caller to sum. That is redundant on
    the wire and load-bearing off it: they are the engine's own running counters, not a
    sum of the rows, so a caller adding up `symbols` would silently disagree with the
    engine about any instrument whose book was removed mid-session.
    """

    gateway_id: str
    symbols: list[SymbolVolume]
    total_qty: int  # unit: shares
    total_value: float  # unit: money
    total_trades: int  # unit: dimensionless

    def validate(self) -> None:
        """Raise MessageValidationError if any declared rule fails.

        The only strictness gate: ``from_dict`` coerces but never validates, so a reader
        of historical data can opt out of the rules by calling ``from_dict`` alone
        (design section 5.1.1).
        """
        if len(self.gateway_id) > 32:
            raise MessageValidationError(
                f"gateway_id: length {len(self.gateway_id)} exceeds max_len 32"
            )
        for symbols_item in self.symbols:
            symbols_item.validate()
        if self.total_qty < 0:
            raise MessageValidationError(f"total_qty: {self.total_qty!r} must be >= 0")
        if self.total_value < 0:
            raise MessageValidationError(
                f"total_value: {self.total_value!r} must be >= 0"
            )
        if self.total_trades < 0:
            raise MessageValidationError(
                f"total_trades: {self.total_trades!r} must be >= 0"
            )

    @classmethod
    def from_dict(cls, p: Mapping[str, Any]) -> "Volume":
        """Coerce a payload mapping into this message. Does NOT validate.

        Mirrors the hand-written payload's coercion exactly, including its lenient
        fallbacks, so it is a drop-in replacement for readers of already-published data
        (design section 5.1.1).
        """
        return cls(
            gateway_id=str(p.get("gateway_id", "")),
            symbols=[SymbolVolume.from_dict(item) for item in p["symbols"]],
            total_qty=int(p["total_qty"]),
            total_value=float(p["total_value"]),
            total_trades=int(p["total_trades"]),
        )

    def to_dict(self) -> dict[str, Any]:
        """Return the bus payload, in the spec's declared field order."""
        return {
            "symbols": [item.to_dict() for item in self.symbols],
            "total_qty": self.total_qty,
            "total_value": self.total_value,
            "total_trades": self.total_trades,
        }


def topic_volume(gateway_id: str) -> str:
    """Build this message's topic without a string literal."""
    return f"system.volume.{gateway_id}"


def match_volume(topic: str) -> str | None:
    """Return ``gateway_id`` when ``topic`` matches, else None."""
    m = _VOLUME_RE.fullmatch(topic)
    return m.group("gateway_id") if m else None


def make_volume(**kw: Any) -> list[bytes]:
    """Coerce, validate, and return the TWO bus frames [topic, payload].

    The per-topic sequence third frame is NOT added here; it is appended by
    SequencedPublisher.send_multipart() at publish time (edumatcher/messaging/bus.py).

    Routes through ``from_dict`` rather than the dataclass constructor, so a caller
    passing ``price=100`` puts a float on the wire rather than an int (design section
    5.1.1).
    """
    obj = Volume.from_dict(kw)
    obj.validate()
    return _msg.encode(topic_volume(obj.gateway_id), obj.to_dict())


def parse_volume(frames: list[bytes]) -> "Volume":
    """Decode bus frames into a validated message.

    Raises MessageValidationError if the payload breaks a declared rule. Call
    ``from_dict`` on a decoded payload instead to read without validating.
    """
    topic, payload = _msg.decode(frames)
    matched = match_volume(topic)
    if matched is None:
        raise MessageValidationError(f"topic {topic!r} is not {TOPIC_VOLUME!r}")
    payload = {**payload, "gateway_id": matched}
    obj = Volume.from_dict(payload)
    obj.validate()
    return obj


def describe_volume() -> tuple[dict[str, Any], ...]:
    """Return field metadata, for spy tools and runtime pretty-printing."""
    return _VOLUME_FIELDS


FAMILY_TOPICS: tuple[str, ...] = (
    TOPIC_GATEWAY_CONNECT,
    TOPIC_GATEWAY_AUTH,
    TOPIC_GATEWAY_REJECT,
    TOPIC_GATEWAY_DISCONNECT,
    TOPIC_GATEWAY_HEARTBEAT,
    TOPIC_GATEWAY_BYE,
    TOPIC_EOD,
    TOPIC_BOOK_CHECKPOINT,
    TOPIC_STARTUP,
    TOPIC_STARTUP_RECOVERY,
    TOPIC_RECOVERY_ITEM,
    TOPIC_QUOTE_SEED_SKIPPED,
    TOPIC_DIAGNOSTIC,
    TOPIC_SYMBOLS_REQUEST,
    TOPIC_SYMBOLS,
    TOPIC_REFERENCE_REQUEST,
    TOPIC_REFERENCE,
    TOPIC_REFERENCE_RELOAD,
    TOPIC_REFERENCE_RELOAD_ACK,
    TOPIC_SESSION_STATE_REQUEST,
    TOPIC_SESSION_STATUS,
    TOPIC_SESSION_SCHEDULE_REQUEST,
    TOPIC_SESSION_SCHEDULE,
    TOPIC_HALT_STATUS_REQUEST,
    TOPIC_HALT_STATUS,
    TOPIC_POSITION_REQUEST,
    TOPIC_POSITION_SNAPSHOT,
    TOPIC_QUOTE_BOOTSTRAP_REQUEST,
    TOPIC_QUOTE_BOOTSTRAP,
    TOPIC_QUOTE_LEGS_REQUEST,
    TOPIC_QUOTE_LEGS,
    TOPIC_RISK_STATE_REQUEST,
    TOPIC_RISK_STATE,
    TOPIC_GATEWAYS_REQUEST,
    TOPIC_GATEWAYS,
    TOPIC_VOLUME_REQUEST,
    TOPIC_VOLUME,
)
