"""
Trade dataclass — produced by the matching engine when two orders cross.
"""

from __future__ import annotations

import itertools
from dataclasses import dataclass
from typing import Any

from edumatcher.models.clock import now_ns
from edumatcher.models.price import from_ticks, get_tick_decimals

# The engine sets this once at startup from a durable, fail-loud counter. The
# per-run counter stays the hot-path id source; the prefix makes ids globally
# unique and lexicographically sortable across restarts.
_run_seq: int | None = None
_trade_counter = itertools.count(1)
#: The id of the newest trade this run minted: ``system.eod`` and the session
#: status name it, so a subscriber can tell it received the whole run (L022).
_last_trade_id: str | None = None


def current_run_seq() -> int | None:
    """The engine-run sequence set by ``set_run_seq`` (None before it)."""
    return _run_seq


def last_trade_id() -> str | None:
    """The id of the newest trade this engine run minted (None before one)."""
    return _last_trade_id


def set_run_seq(run_seq: int) -> None:
    """Set the durable engine-run sequence before the first trade is minted."""
    global _run_seq
    if _run_seq is not None:
        raise RuntimeError("run sequence already set")
    if run_seq < 0 or run_seq > 999_999:
        raise ValueError("run sequence must be between 0 and 999999")
    _run_seq = run_seq


def reset_trade_ids_for_tests() -> None:
    """Reset module-global id state for tests that exercise startup ordering."""
    global _run_seq, _trade_counter, _last_trade_id
    _run_seq = None
    _trade_counter = itertools.count(1)
    _last_trade_id = None


# ---------------------------------------------------------------------------
# PERF improvement #4: __slots__ on the Trade dataclass.
#
# Trade objects are created on every fill and passed through the event pipeline.
# With __slots__, attribute access is ~30% faster (fixed C-struct offset vs.
# hash-table lookup), and each instance uses ~40% less memory (no per-object
# __dict__).  The to_wire() method accesses 16 attributes — slots saves ~0.5µs
# per trade on serialization alone.
# ---------------------------------------------------------------------------
@dataclass(slots=True)
class Trade:
    id: str
    symbol: str
    buy_order_id: str
    sell_order_id: str
    buy_gateway_id: str
    sell_gateway_id: str
    price: int
    quantity: int
    aggressor_side: str
    ts_ns: int  # unit: epoch_nanos
    tick_decimals: int
    run_seq: int | None = None
    #: How the trade came about (spec: trade.executed.match_type). The engine
    #: stamps an uncross's prints; everything else is continuous matching.
    match_type: str = "CONTINUOUS"
    #: The uncross this print belongs to (auction.result.auction_id).
    auction_id: str | None = None
    #: The aggressor, when it is a stop that has triggered.
    trigger_order_id: str | None = None

    # ------------------------------------------------------------------
    # Factory
    # ------------------------------------------------------------------
    @classmethod
    def create(
        cls,
        symbol: str,
        buy_order_id: str,
        sell_order_id: str,
        buy_gateway_id: str,
        sell_gateway_id: str,
        price: int,
        quantity: int,
        aggressor_side: str,
        tick_decimals: int,
        # PERF #3: Accept a pre-computed timestamp from the caller instead of
        # calling time.time() independently.  The engine computes one timestamp
        # per incoming order and passes it through the entire processing chain,
        # eliminating 2-4 redundant syscalls per aggressive order (~1-1.5µs saved).
        now: int | None = None,
        trigger_order_id: str | None = None,
    ) -> "Trade":
        global _last_trade_id
        if _run_seq is None:
            raise RuntimeError("trade id requested before set_run_seq()")
        trade_seq = next(_trade_counter)
        if trade_seq > 999_999_999:
            raise RuntimeError("trade sequence exhausted for this engine run")
        _last_trade_id = f"{_run_seq:06d}-{trade_seq:09d}"
        return cls(
            id=_last_trade_id,
            symbol=symbol,
            buy_order_id=buy_order_id,
            sell_order_id=sell_order_id,
            buy_gateway_id=buy_gateway_id,
            sell_gateway_id=sell_gateway_id,
            price=price,
            quantity=quantity,
            aggressor_side=aggressor_side,
            ts_ns=now if now is not None else now_ns(),
            tick_decimals=tick_decimals,
            run_seq=_run_seq,
            trigger_order_id=trigger_order_id,
        )

    def to_wire(self) -> dict[str, Any]:
        """This trade as a ``trade.executed`` payload.

        Use this for anything that goes on the bus. It is the *only* correct
        way to publish a Trade, because ``price`` is **ticks** on the model and
        **display money** on the wire -- the one place the two shapes still
        disagree, now that the match instant is ``ts_ns`` on both.

        The price is converted at the symbol's registered scale, which is the
        scale the book minted this trade at (``self.tick_decimals``): the
        engine registers every symbol's scale once at start-up and refuses an
        order at any other (``Engine._tick_scale_mismatch``).
        """
        return {
            "id": self.id,
            "run_seq": self.run_seq,
            "symbol": self.symbol,
            "buy_order_id": self.buy_order_id,
            "sell_order_id": self.sell_order_id,
            "buy_gateway_id": self.buy_gateway_id,
            "sell_gateway_id": self.sell_gateway_id,
            "price": from_ticks(self.price, self.symbol),
            "price_ticks": self.price,
            "quantity": self.quantity,
            "aggressor_side": self.aggressor_side,
            "ts_ns": self.ts_ns,
            "tick_decimals": get_tick_decimals(self.symbol),
            "match_type": self.match_type,
            "auction_id": self.auction_id,
            "trigger_order_id": self.trigger_order_id,
        }

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "Trade":
        return cls(
            id=d["id"],
            symbol=d["symbol"],
            buy_order_id=d["buy_order_id"],
            sell_order_id=d["sell_order_id"],
            buy_gateway_id=d["buy_gateway_id"],
            sell_gateway_id=d["sell_gateway_id"],
            price=d["price"],
            quantity=d["quantity"],
            aggressor_side=d.get("aggressor_side", ""),
            ts_ns=d["ts_ns"],
            tick_decimals=int(d.get("tick_decimals", 2)),
            run_seq=(None if d.get("run_seq") is None else int(d["run_seq"])),
            match_type=str(d.get("match_type") or "CONTINUOUS"),
            auction_id=d.get("auction_id"),
            trigger_order_id=d.get("trigger_order_id"),
        )
