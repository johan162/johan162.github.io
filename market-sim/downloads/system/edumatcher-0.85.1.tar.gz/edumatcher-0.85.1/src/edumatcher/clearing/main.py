"""
pm-clearing v2 — SQLite-backed trade clearing process.

Architecture
------------
One subscriber thread receives ``trade.executed`` messages from the engine and
appends them to an in-memory buffer.  A separate timer thread flushes the
buffer to SQLite every ``FLUSH_INTERVAL_SEC`` seconds even when the buffer is
partially filled.  The buffer is also flushed immediately when it reaches
``FLUSH_SIZE`` trades.

The flush transaction atomically writes:
1. raw trade rows  (INSERT OR IGNORE into trade_events)
2. current position snapshots  (UPSERT into gateway_symbol_positions)
3. incremental daily deltas    (UPSERT into gateway_daily_summary)

On startup, at every close of the market (``session.state`` CLOSED) and at
every ``system.eod``, the process prunes trade_events rows and close
snapshots older than ``--retention-days`` (90; the newest close snapshot is
always kept) and logs the count of deleted rows.

A failed write keeps the buffer and is retried every flush interval, logged
once per outage and counted in the ``clearing.flush_failures`` beacon metric;
trades still unwritten at shutdown are logged at CRITICAL and the process
exits 1. The first trade after a start is compared with the newest archived
trade id, so trades made while pm-clearing was down are recorded as a feed
gap.

Health endpoint
---------------
Binds a REP socket (CLEARING_HEALTH_BIND_ADDR) that answers
``pm-clearing-cli health``'s ping with the current UTC time, from the receive
loop itself, proving that loop is alive and pumping rather than just the OS
process existing.

Timestamp semantics
-------------------
Session/gateway lifecycle rows written by this process (EOD markers and
gateway connect/disconnect events) are stamped with local ``now_ns()`` at
ingest time.  They represent clearing-observed timing, not exchange-event
timestamps.
"""

from __future__ import annotations

import argparse
import copy
import errno
import json
import logging
import signal
import sys
import threading
import time
from collections import OrderedDict
from datetime import timezone, tzinfo
from pathlib import Path
from typing import Any

import zmq
from rich.console import Console
from rich.table import Table

from edumatcher.config_artifact import exit_on_config_error
from edumatcher.health import HealthReporter, counter
from edumatcher.models.generated.health import MetricSample
from edumatcher.clearing.ledger import Ledger, trade_date
from edumatcher.clearing.store import (
    TradeEventRow,
    close_latest_gateway_session,
    close_snapshot_is_final,
    fetch_all_positions,
    flush_batch,
    latest_trade_seq,
    open_writer_connection,
    prune_close_snapshots,
    prune_old_events,
    reconcile_session_timezone,
    record_gateway_connect,
    record_session_event,
    write_close_snapshot,
)
from edumatcher.log_srv.config import (
    load_default_log_client_config,
    load_default_log_server_config,
    resolve_host_default,
)
from edumatcher.logclient.discovery import resolve_handler
from edumatcher.config import CLEARING_HEALTH_BIND_ADDR
from edumatcher.healthcheck import answer_health_ping
from edumatcher.messaging.bus import make_replier, make_subscriber
from edumatcher.models.clock import now_ns  # used in _flush
from edumatcher.models.generated import system as _gen_system
from edumatcher.models.generated.session import SessionState, TOPIC_SESSION_STATE
from edumatcher.models.feed_schema import (
    TradeExecutedPayload,
)
from edumatcher.models.message import decode, decode_envelope
from edumatcher.models.trade import Trade
from edumatcher.models.generated.trade import TOPIC_TRADE_EXECUTED
from edumatcher.models.generated.system import (
    PREFIX_GATEWAY_AUTH,
    PREFIX_GATEWAY_BYE,
    TOPIC_EOD,
)

FLUSH_SIZE: int = 100
FLUSH_INTERVAL_SEC: float = 5.0
_TIMER_POLL_SEC: float = 0.5
_DRAIN_POLL_MS: int = 250
#: Ids per ``trade_events`` lookup (SQLite's bound-variable limit is 999 on old builds).
_ID_LOOKUP_CHUNK: int = 500
_RETENTION_DAYS: int = 90
#: The trade subscriber's receive high-water mark. ZMQ's default of 1 000
#: queued messages drops silently past it; pm-stats and pm-audit raised
#: theirs for the same feed (clearing review C10).
_SUB_RCVHWM: int = 100_000
#: No console table by default: it is drawn on the receive thread, and at
#: 6 000 positions one draw takes about 4 s (clearing review P1).
_PRINT_EVERY: int = 0
_DEBUG_SUMMARY_INTERVAL_SEC: float = 5.0
# trade.executed carries `ts_ns`: integer Unix epoch NANOSECONDS, the engine's
# own clock reading, unscaled. The magnitude guard that used to live here
# (finding CL-M6) is gone with the float `timestamp` it was guarding: an
# integer field whose name states its unit cannot be mistaken for seconds or
# millis, so there is nothing left to guess at.

_CLIENT_NAME = "pm-clearing"
_LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s - %(message)s"

console = Console()
log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Trade → TradeEventRow conversion
# ---------------------------------------------------------------------------


def _to_trade_event_row(
    trade: Trade,
    ingest_ts_ns: int,
    tz: tzinfo = timezone.utc,
    msg_id: str | None = None,
) -> TradeEventRow:
    """Convert a Trade model to the DB row type, deriving trade_date from ts_ns."""
    return TradeEventRow(
        id=trade.id,
        ts_ns=trade.ts_ns,
        trade_date=trade_date(trade.ts_ns, tz),
        symbol=trade.symbol,
        quantity=trade.quantity,
        price=trade.price,
        tick_decimals=trade.tick_decimals,
        buy_order_id=trade.buy_order_id or None,
        sell_order_id=trade.sell_order_id or None,
        buy_gateway_id=trade.buy_gateway_id,
        sell_gateway_id=trade.sell_gateway_id,
        aggressor_side=trade.aggressor_side or None,
        ingest_ts_ns=ingest_ts_ns,
        match_type=trade.match_type,
        msg_id=msg_id,
    )


def _parse_tick_decimals(payload: dict[str, Any]) -> int:
    raw = payload.get("tick_decimals", 2)
    try:
        parsed = int(raw)
    except TypeError, ValueError:
        return 2
    return parsed if 0 <= parsed <= 8 else 2


def _trade_from_payload(payload: dict[str, Any]) -> Trade:
    typed = TradeExecutedPayload.from_dict(payload)

    normalized = typed.to_dict()
    tick_decimals = _parse_tick_decimals(normalized)
    scale = 10**tick_decimals

    # trade.executed.price is a DISPLAY value by contract; convert to ticks
    # unconditionally rather than treating an integer as if it were already ticks
    # (finding CL-M6).
    price_raw = typed.price
    normalized["price"] = int(round(float(price_raw) * scale))

    normalized["tick_decimals"] = tick_decimals
    return Trade.from_dict(normalized)


# ---------------------------------------------------------------------------
# Main process class
# ---------------------------------------------------------------------------


class ClearingProcess:
    """
    Buffered clearing process — subscribe, buffer, and flush to SQLite.

    Parameters
    ----------
    pub_addr:
        ZMQ PUB address to subscribe to.
    db_path:
        Path to the SQLite clearing database.
    flush_size:
        Maximum number of buffered trades before an immediate flush.
    flush_interval_sec:
        Maximum seconds between flushes when buffer is non-empty.
    print_every:
        Print a P&L summary table to the console every N trades (0 = never).
    retention_days:
        Trade events older than this many days are pruned on startup, at
        every close (``session.state`` CLOSED) and at every ``system.eod``.
    """

    def __init__(
        self,
        pub_addr: str,
        db_path: Path,
        *,
        flush_size: int = FLUSH_SIZE,
        flush_interval_sec: float = FLUSH_INTERVAL_SEC,
        print_every: int = _PRINT_EVERY,
        retention_days: int = _RETENTION_DAYS,
        session_tz: tzinfo = timezone.utc,
        sql_trace: bool = False,
    ) -> None:
        self._pub_addr = pub_addr
        self._db_path = Path(db_path)
        self._flush_size = flush_size
        self._flush_interval_sec = flush_interval_sec
        self._print_every = print_every
        self._retention_days = retention_days
        self._sql_trace = bool(sql_trace)
        # Exchange session timezone used to bucket trades into a trading day
        # (finding CL-M3); defaults to UTC.
        self._tz = session_tz

        self._buffer: list[Trade] = []
        #: The audit message id of each buffered trade (trade_events.msg_id).
        self._msg_ids: dict[str, str] = {}
        self._ledger = Ledger(tz=session_tz)
        #: A failed flush could not rebuild the ledger; see _rollback_ledger.
        self._ledger_stale = False
        self._trade_count = 0

        # Idempotency, decided ONCE for both the ledger and the archive
        # (finding CL-M1).  A trade is keyed by its id alone — the archive's
        # primary key — so a duplicate delivery (retransmit / replay, whatever
        # its timestamp) never double-counts a position.  The bounded LRU of
        # recent ids is only a fast path; ``_flush`` checks ``trade_events``
        # (K4), which survives restarts and eviction.
        self._seen_keys: OrderedDict[str, None] = OrderedDict()
        self._seen_cap = 200_000
        self._dup_count = 0

        # Gap detection (finding CL-H1).  trade.executed carries no sequence
        # number, but the suffix of the durable trade id is a per-run monotonic
        # counter, so a forward jump in it means the lossy PUB/SUB transport
        # dropped one or more trades. A run-prefix change is a restart, not a
        # gap.
        self._last_seq: tuple[int, int] | None = None
        #: The first trade after a start is compared with the newest archived
        #: id, so trades published while pm-clearing was down are a gap too
        #: (clearing review H2); later ones with the previous trade.
        self._gap_reason = "restart"
        self._gap_count = 0

        self._running = False
        # Health beacon (operator dashboard §8.5), attached by main(); ticked
        # in the main receive loop. trades_settled is written under _lock by
        # whichever thread flushes and read on the loop thread: an int.
        self._reporter: HealthReporter | None = None
        self._trades_settled = 0
        #: The latest connect time per gateway seen by this process. Nothing
        #: here reads it (gateway_sessions is the record, CL-M5); the test
        #: harness uses it as its readiness probe.
        self._gw_connect_ts: dict[str, int] = {}
        #: Failed flush attempts since start (beacon), and whether the latest
        #: one failed: an outage is logged once, not once per trade (C1).
        self._flush_failures = 0
        self._flush_failing = False
        #: Trades still buffered when run() ended; main() exits non-zero.
        self.unwritten_trades = 0
        self._lock = threading.RLock()
        self._last_flush_mono = time.monotonic()

        self._debug_counts: OrderedDict[str, int] = OrderedDict()
        self._debug_last_summary = time.monotonic()

        self._conn = open_writer_connection(self._db_path, sql_trace=self._sql_trace)
        reconcile_session_timezone(self._conn, self._db_path, str(session_tz))
        log.info("opened clearing DB connection path=%s", self._db_path.resolve())
        if self._sql_trace:
            log.info("SQLite SQL trace enabled for clearing writer connection")

        # Warm start: rebuild the ledger from durable position state before any
        # trades arrive, so a restart accumulates onto the persisted positions
        # rather than overwriting them from flat (finding CL-C4).
        self._hydrate_ledger()
        self._last_seq = latest_trade_seq(self._conn)

    def _dbg_count(self, key: str, amount: int = 1) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        self._debug_counts[key] = self._debug_counts.get(key, 0) + amount
        self._flush_debug_summary()

    def _flush_debug_summary(self, force: bool = False) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        now = time.monotonic()
        if not force and now - self._debug_last_summary < _DEBUG_SUMMARY_INTERVAL_SEC:
            return
        if not self._debug_counts:
            self._debug_last_summary = now
            return
        summary = ", ".join(
            f"{key}={value}" for key, value in self._debug_counts.items()
        )
        log.debug("clearing flow summary: %s", summary)
        self._debug_counts.clear()
        self._debug_last_summary = now

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def _hydrate_ledger(self) -> None:
        """
        Restore in-memory positions from ``gateway_symbol_positions``.

        A failure is fatal (K5): carrying on with an empty ledger would make
        the next flush UPSERT flat positions over the persisted ones. The
        constructor raises, and ``main()`` exits non-zero.
        """
        try:
            rows = fetch_all_positions(self._conn)
            self._ledger.restore(rows)
        except Exception as exc:
            log.error("warm-start hydration failed, refusing to start: %s", exc)
            self._conn.close()
            raise
        if rows:
            log.info("warm start: restored %d position(s) from the database", len(rows))
        log.debug("warm start restored positions=%d", len(rows))

    def _prune(self) -> int:
        """Apply ``--retention-days`` to ``trade_events`` and to the close
        snapshots (L019); returns the ``trade_events`` rows deleted."""
        pruned = prune_old_events(self._conn, retention_days=self._retention_days)
        snapshots = prune_close_snapshots(
            self._conn, retention_days=self._retention_days
        )
        if snapshots:
            log.info(
                "pruned %d close-snapshot row(s) older than %d days",
                snapshots,
                self._retention_days,
            )
        return pruned

    def run(self) -> None:
        """Start the clearing process; blocks until stop() is called."""
        pruned = 0
        if self._retention_days > 0:
            pruned = self._prune()
        log.info(
            "starting clearing runtime db=%s flush_size=%d flush_interval=%ss retention_days=%d",
            self._db_path,
            self._flush_size,
            self._flush_interval_sec,
            self._retention_days,
        )
        if pruned:
            log.info(
                "pruned %d trade_events rows older than %d days",
                pruned,
                self._retention_days,
            )

        log.info(
            "clearing db=%s flush policy: size=%d interval=%ss",
            self._db_path,
            self._flush_size,
            self._flush_interval_sec,
        )
        log.info("pm-clearing waiting for pm-engine events")

        # Signal handlers may only be installed from the main thread.
        # When run() is called from a test thread, skip graceful-signal setup.
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, lambda *_: self.stop())
            signal.signal(signal.SIGTERM, lambda *_: self.stop())

        self._running = True
        log.debug("clearing receive/timer loops enabled")

        timer = threading.Thread(
            target=self._timer_loop, daemon=True, name="clearing-timer"
        )
        timer.start()

        sub = make_subscriber(
            self._pub_addr,
            TOPIC_TRADE_EXECUTED,
            TOPIC_EOD,
            # Session-phase transitions — recorded as PHASE rows in
            # session_events (finding CL-M7) so operators can bucket activity by
            # session phase and the advertised PHASE filter is real.
            TOPIC_SESSION_STATE,
            # The engine broadcasts gateway lifecycle on PUB as
            # ``system.gateway_auth.{id}`` (models/message.py make_gateway_auth_msg,
            # engine/main.py _handle_gateway_connect).  ``system.gateway_connect``
            # / ``system.gateway_disconnect`` are gateway→engine PULL topics that
            # never reach this subscriber (finding CL-C3), so subscribe to the
            # auth-broadcast prefix as the real "gateway connected" signal.
            PREFIX_GATEWAY_AUTH,
            # Disconnect broadcast — the PUB counterpart to gateway_auth
            # (engine/main.py _handle_gateway_disconnect → make_gateway_bye_msg).
            PREFIX_GATEWAY_BYE,
            # Not system.gateway_connect / system.gateway_disconnect: the
            # engine echoes every inbound command onto PUB for the audit trail
            # (Engine._echo_command), so subscribing to them as well recorded
            # each session twice, and a refused connect as a session.
            rcvhwm=_SUB_RCVHWM,
        )
        health_rep: zmq.Socket[bytes] | None = None
        try:
            # Bound, not connected: pm-clearing-cli health's ZMQ ping is the
            # only thing that speaks to this socket, proving the receive loop
            # itself is alive rather than just the OS process.
            health_rep = make_replier(CLEARING_HEALTH_BIND_ADDR)
            log.debug("clearing health socket bound at %s", CLEARING_HEALTH_BIND_ADDR)
            self._receive_loop(sub, health_rep)
        finally:
            if self._reporter is not None:
                self._reporter.stop()
            sub.close()
            if health_rep is not None:
                health_rep.close()
            self._shutdown()

    def _shutdown(self) -> None:
        """Write what is buffered and close the database.

        Trades that cannot be written are lost with the process: they are
        logged at CRITICAL with their id range, ``unwritten_trades`` makes
        main() exit non-zero, and the next start reports the range as a feed
        gap (clearing review C1).
        """
        with self._lock:
            try:
                self._flush()
            except Exception as exc:
                ids = [t.id for t in self._buffer]
                self.unwritten_trades = len(ids)
                log.critical(
                    "pm-clearing stopped with %d trade(s) not written (ids %s .. %s): %s",
                    len(ids),
                    ids[0],
                    ids[-1],
                    exc,
                )
        self._flush_debug_summary(force=True)
        self._conn.close()
        log.info("clearing DB connection closed")
        log.info("shutdown complete")

    def attach_reporter(self, reporter: HealthReporter) -> None:
        """Ship this process's health beacon through ``reporter`` (main())."""
        self._reporter = reporter

    def metric_samples(self) -> list[MetricSample]:
        """Design §8.5: trades persisted to clearing.db since start."""
        return [
            counter("clearing.trades_settled", self._trades_settled),
            counter("clearing.flush_failures", self._flush_failures),
        ]

    def stop(self) -> None:
        """Signal the receive loop to exit cleanly."""
        log.info("stop requested")
        self._running = False

    def replay(self, frames: list[bytes]) -> None:
        """Handle one message as if it came off the feed, without a receive
        loop: ``pm-clearing-cli rebuild`` replays the audit trail through it."""
        self._handle_message(frames)

    @property
    def gap_count(self) -> int:
        """Feed gaps recorded since this process started."""
        return self._gap_count

    def close_db(self) -> None:
        """Close the database connection of a process that never ran."""
        self._conn.close()

    def flush_now(self) -> int:
        """
        Flush the current buffer immediately.  Returns the number of trades flushed.
        Thread-safe; may be called from tests.
        """
        with self._lock:
            return self._flush()

    # ------------------------------------------------------------------
    # Receive loop
    # ------------------------------------------------------------------

    def _receive_loop(
        self,
        sub: zmq.Socket,  # type: ignore[type-arg]
        health_rep: zmq.Socket[bytes] | None = None,
    ) -> None:
        poller = zmq.Poller()
        poller.register(sub, zmq.POLLIN)
        if health_rep is not None:
            poller.register(health_rep, zmq.POLLIN)

        reporter = self._reporter
        while True:
            # After stop(), keep reading until the feed has been quiet for one
            # poll: what the engine published before it exited is already in
            # the socket, and dropping it leaves clearing short of the tape.
            draining = not self._running
            if reporter is not None:
                reporter.tick_and_publish(self.metric_samples)
            try:
                socks = dict(poller.poll(timeout=_DRAIN_POLL_MS if draining else 300))
            except zmq.ZMQError as exc:
                if exc.errno != errno.EINTR:
                    raise
                # A signal: its handler has run, and stop() is what ends the
                # loop (C9).
                continue

            if health_rep is not None and health_rep in socks:
                answer_health_ping(health_rep)

            if sub not in socks:
                if draining:
                    break
                continue

            self._handle_message(sub.recv_multipart())

    def _handle_message(self, frames: list[bytes]) -> None:
        """Decode and act on one message from the feed."""
        try:
            topic, payload = decode(frames)
        except Exception as exc:
            log.warning("failed to decode frame: %s", exc)
            return

        self._dbg_count("messages_received")

        # One bad message, whatever its topic, must not take the loop down:
        # a decodable payload can still hold a value a handler rejects.
        try:
            self._dispatch(topic, payload, frames)
        except Exception as exc:
            log.warning("error handling %s: %s", topic, exc)

    def _dispatch(
        self, topic: str, payload: dict[str, Any], frames: list[bytes]
    ) -> None:
        if topic == TOPIC_TRADE_EXECUTED:
            try:
                trade = _trade_from_payload(payload)
            except Exception as exc:
                log.error("failed to parse trade: %s", exc)
                return

            with self._lock:
                # Count every observed trade message (used for progress /
                # print cadence), then dedup before buffering so a replay
                # is neither re-applied to the ledger nor re-archived.
                self._trade_count += 1
                if self._is_duplicate(trade):
                    self._dup_count += 1
                    self._dbg_count("duplicates")
                else:
                    self._check_sequence_gap(trade)
                    self._buffer.append(trade)
                    env = decode_envelope(frames)
                    if env is not None:
                        self._msg_ids[trade.id] = env.msg_id
                    self._dbg_count("trades_buffered")
                    # While writes fail, the timer retries; retrying on every
                    # trade only repeats the failure (C1).
                    if (
                        len(self._buffer) >= self._flush_size
                        and not self._flush_failing
                    ):
                        self._try_flush()
                print_now = (
                    self._print_every > 0 and self._trade_count % self._print_every == 0
                )
                if print_now:
                    # Positions only change when the buffer is applied, so
                    # flush first: the table must include this trade.
                    self._try_flush()

            if print_now:
                self._print_pnl_table()

        elif topic == TOPIC_EOD:
            self._dbg_count("eod_topics")
            self._handle_eod(payload)

        elif topic == TOPIC_SESSION_STATE:
            self._dbg_count("phase_topics")
            self._handle_session_state(payload)

        elif topic.startswith(PREFIX_GATEWAY_AUTH):
            self._dbg_count("gateway_auth_topics")
            self._handle_gateway_auth(payload)

        elif topic.startswith(PREFIX_GATEWAY_BYE):
            self._dbg_count("gateway_bye_topics")
            self._handle_gateway_bye(payload)

    # ------------------------------------------------------------------
    # Timer loop
    # ------------------------------------------------------------------

    def _timer_loop(self) -> None:
        while self._running:
            time.sleep(_TIMER_POLL_SEC)
            with self._lock:
                elapsed = time.monotonic() - self._last_flush_mono
                if elapsed >= self._flush_interval_sec and self._buffer:
                    self._dbg_count("timer_flushes")
                    # A failed flush keeps its buffer for the next interval;
                    # the thread must survive to make that retry.
                    self._try_flush()

    # ------------------------------------------------------------------
    # Flush (must be called with self._lock held)
    # ------------------------------------------------------------------

    def _is_duplicate(self, trade: Trade) -> bool:
        """
        Fast-path duplicate filter (must be called with ``self._lock`` held).

        Keyed on the trade id alone, the archive's identity: a replay that
        carries a different ``ts_ns`` is still the same execution. First
        sightings are recorded in a bounded LRU, so this only catches *recent*
        repeats; the authority is ``trade_events``, consulted at flush time by
        ``_unarchived``.
        """
        key = trade.id
        if key in self._seen_keys:
            self._seen_keys.move_to_end(key)
            return True
        self._seen_keys[key] = None
        if len(self._seen_keys) > self._seen_cap:
            self._seen_keys.popitem(last=False)
        return False

    def _unarchived(self, trades: list[Trade]) -> list[Trade]:
        """
        The trades of *trades* that are not yet in ``trade_events``, each id
        once (must be called with ``self._lock`` held).

        This is the durable duplicate check: the ledger is applied only to
        what this returns, so a trade replayed after a restart, after LRU
        eviction, or with a changed timestamp can never be counted twice.
        One indexed lookup per chunk, not per trade.
        """
        archived: set[str] = set()
        ids = list({t.id for t in trades})
        for start in range(0, len(ids), _ID_LOOKUP_CHUNK):
            chunk = ids[start : start + _ID_LOOKUP_CHUNK]
            marks = ",".join("?" * len(chunk))
            archived.update(
                row[0]
                for row in self._conn.execute(
                    f"SELECT id FROM trade_events WHERE id IN ({marks})", chunk
                )
            )
        fresh: list[Trade] = []
        for trade in trades:
            if trade.id in archived:
                continue
            archived.add(trade.id)
            fresh.append(trade)
        return fresh

    def _rollback_ledger(self) -> None:
        """
        Rebuild the in-memory ledger from the committed positions.

        A failed flush has already mutated the ledger; the database did not
        commit. Starting over from what *is* committed makes the retry apply
        each buffered trade exactly once.

        The ledger stays marked stale until the rebuild succeeds, and
        ``_flush`` rebuilds a stale ledger before using it: if the re-read
        fails too, neither the half-applied ledger nor an empty one may ever
        be written over the persisted positions.
        """
        self._ledger_stale = True
        ledger = Ledger(tz=self._tz)
        ledger.restore(fetch_all_positions(self._conn))
        self._ledger = ledger
        self._ledger_stale = False

    def _check_sequence_gap(self, trade: Trade) -> None:
        """
        Detect a dropped-trade gap from the engine's durable trade id suffix and
        record a durable ``GAP`` alarm in ``session_events`` (must be called
        with ``self._lock`` held).

        Legacy or synthetic ids disable sequencing rather than false-alarm. A
        run-prefix change resets the tracker without alarming.
        """
        try:
            run_text, seq_text = trade.id.split("-", 1)
            current = (int(run_text), int(seq_text))
        except TypeError, ValueError:
            self._last_seq = None
            return

        last = self._last_seq
        self._last_seq = current
        reason, self._gap_reason = self._gap_reason, "feed"
        if last is None:
            return
        last_run, last_seq = last
        run_seq, seq = current
        if run_seq != last_run or seq <= last_seq:
            return
        if seq > last_seq + 1:
            self._record_gap(run_seq, last_seq, seq, reason, trade.ts_ns)

    def _check_run_end(self, last_trade_id: str | None, ts_ns: int) -> None:
        """Compare the run's last trade, as ``system.eod`` names it, with the
        last one received: trades lost just before the engine stopped have no
        later trade of their run to reveal them (L022). Lock held."""
        if last_trade_id is None:
            return
        try:
            run_text, seq_text = last_trade_id.split("-", 1)
            run_seq, final = int(run_text), int(seq_text)
        except ValueError:
            return
        last = self._last_seq
        # None of this run's trades arrived: every one is missing.
        last_seq = last[1] if last is not None and last[0] == run_seq else 0
        if final > last_seq:
            self._record_gap(run_seq, last_seq, final + 1, "end_of_run", ts_ns)
            self._last_seq = (run_seq, final)

    def _record_gap(
        self, run_seq: int, last_seq: int, next_seq: int, reason: str, ts_ns: int
    ) -> None:
        """Record trades ``last_seq + 1 .. next_seq - 1`` of *run_seq* as a
        durable ``GAP`` in ``session_events``."""
        missing = next_seq - last_seq - 1
        self._gap_count += 1
        try:
            record_session_event(
                self._conn,
                event_type="GAP",
                ts_ns=ts_ns,
                trade_date=trade_date(ts_ns, self._tz),
                payload_json=json.dumps(
                    {
                        "run_seq": run_seq,
                        "last_seq": last_seq,
                        "next_seq": next_seq,
                        "missing_trades": missing,
                        "reason": reason,
                    }
                ),
            )
            log.error(
                "trade feed gap — %d trade(s) missing between id %s and %s (%s)",
                missing,
                last_seq,
                next_seq,
                reason,
            )
        except Exception as exc:
            log.warning("failed to record feed gap: %s", exc)

    def _flush(self) -> int:
        """Flush the buffer to SQLite. Returns the number of trades written."""
        if self._ledger_stale:
            self._rollback_ledger()
        if not self._buffer:
            return 0

        self._dbg_count("flush_calls")

        updated_ts = now_ns()

        fresh = self._unarchived(self._buffer)
        self._dup_count += len(self._buffer) - len(fresh)

        try:
            trade_rows = [
                _to_trade_event_row(t, updated_ts, self._tz, self._msg_ids.get(t.id))
                for t in fresh
            ]

            for trade in fresh:
                self._ledger.apply_trade(
                    symbol=trade.symbol,
                    buy_gateway_id=trade.buy_gateway_id,
                    sell_gateway_id=trade.sell_gateway_id,
                    price=trade.price,
                    tick_decimals=trade.tick_decimals,
                    quantity=trade.quantity,
                    ts_ns=trade.ts_ns,
                    ingest_ts_ns=updated_ts,
                )

            position_rows, daily_rows = self._ledger.get_flush_rows(
                updated_ts_ns=updated_ts
            )

            flush_batch(self._conn, trade_rows, position_rows, daily_rows)
        except Exception:
            # The buffer is kept for the retry; the ledger must not keep what
            # the database refused.
            self._rollback_ledger()
            raise

        if self._flush_failing:
            self._flush_failing = False
            log.info(
                "clearing writes recovered after %d failed attempt(s)",
                self._flush_failures,
            )
        count = len(fresh)
        self._trades_settled += count
        self._buffer.clear()
        self._msg_ids.clear()
        self._ledger.clear_batch()
        self._last_flush_mono = time.monotonic()

        self._dbg_count("flushed_trades", count)
        self._dbg_count("position_rows_written", len(position_rows))
        self._dbg_count("daily_rows_written", len(daily_rows))

        return count

    def _try_flush(self) -> None:
        """``_flush``, with a failure kept for the retry instead of raised
        (must be called with ``self._lock`` held).

        An outage is one ERROR and a recovery one INFO; every failed attempt
        counts in ``clearing.flush_failures``. A failure also restarts the
        flush interval, so the timer retries once per interval (C1).
        """
        try:
            self._flush()
        except Exception as exc:
            self._flush_failures += 1
            self._last_flush_mono = time.monotonic()
            if not self._flush_failing:
                self._flush_failing = True
                log.error(
                    "clearing write failed; %d trade(s) kept in memory and retried: %s",
                    len(self._buffer),
                    exc,
                )

    # ------------------------------------------------------------------
    # Secondary event handlers
    # ------------------------------------------------------------------

    def _handle_eod(self, payload: dict[str, Any]) -> None:
        """
        Handle system.eod — engine end-of-day shutdown event.

        Actions:
        1. Flush any buffered trades, then compare the run's last trade id
           with the last one received: the difference is a ``GAP``
           (``end_of_run``).
        2. Mark every position to its book's last trade price (or bid/ask mid
           if it never traded), at the book's precision, and write the
           re-marked positions.
        3. Take the day's close snapshot unless the day's real close already
           took a final one (no scheduler: the shutdown is the close).
        4. Write an EOD sentinel row to session_events.
        5. Prune trade_events and close snapshots past the retention window.
        """
        try:
            ts_ns = now_ns()
            eod_trade_date = trade_date(ts_ns, self._tz)

            # Parse EOD marks before acquiring the lock.
            #
            # The engine sends ``book.snapshot()`` dicts (models/message.py
            # make_eod_msg, engine/order_book.py snapshot): the keys are
            # ``last_price`` (a DISPLAY float) and ``bids`` / ``asks`` (lists of
            # {price, qty, count} with display-float prices) — NOT the old
            # ``last_trade_price`` / ``best_bid`` / ``best_ask`` this handler used
            # to look for (finding CL-C2, which left eod_marks permanently empty).
            # Everything downstream stores marks in integer ticks, so convert at
            # this ingress boundary (CL-M4: keeps mark and avg_cost in the same
            # unit) -- at the scale the book states. Nothing registers tick
            # precision in pm-clearing, so the registry's answer would be 2 for
            # every symbol (clearing review H1).
            eod_marks: dict[str, int] = {}
            mark_decimals: dict[str, int] = {}
            eod_payload = _gen_system.Eod.from_dict(payload)
            for book in eod_payload.books:
                sym = book.symbol
                if not sym:
                    continue
                scale = 10**book.tick_decimals
                last_price = book.last_price
                bids = book.bids
                asks = book.asks
                if last_price is not None:
                    eod_marks[sym] = round(last_price * scale)
                elif bids and asks:
                    # `EodBookLevel.price` is required, so no None guard: the
                    # dataclass this replaced made it optional and the only
                    # producer, OrderBook.snapshot(), has never omitted it.
                    eod_marks[sym] = (
                        round(bids[0].price * scale) + round(asks[0].price * scale)
                    ) // 2
                else:
                    continue
                mark_decimals[sym] = book.tick_decimals

            with self._lock:
                # 1. Flush all buffered trades first.
                self._flush()
                self._check_run_end(eod_payload.last_trade_id, ts_ns)

                # 2. EOD mark-to-market: update mark_price from EOD snapshot.
                if eod_marks:
                    marked_keys: set[tuple[str, str]] = set()
                    for sym, mark in eod_marks.items():
                        marked_keys |= self._ledger.mark_symbol(
                            sym, mark, mark_decimals[sym]
                        )
                    # Flush only the re-marked position snapshots (CL-M9); the
                    # mark pass runs outside the batch-delta accumulator, so pass
                    # the touched keys explicitly.
                    if marked_keys:
                        position_rows, _ = self._ledger.get_flush_rows(
                            updated_ts_ns=ts_ns, position_keys=marked_keys
                        )
                        flush_batch(self._conn, [], position_rows, [])
                        log.debug(
                            "EOD mark-to-market applied position_rows=%d",
                            len(position_rows),
                        )
                    self._ledger.clear_batch()

                # Without a scheduler no CLOSED is ever announced, so the
                # shutdown is the only close there is: take the close snapshot
                # now, replacing an earlier shutdown's of the same day.  A
                # snapshot from the day's real CLOSED is final and kept.
                if not close_snapshot_is_final(self._conn, eod_trade_date):
                    write_close_snapshot(self._conn, eod_trade_date)

                # 3. Write EOD sentinel row.
                record_session_event(
                    self._conn,
                    event_type="EOD",
                    ts_ns=ts_ns,
                    trade_date=eod_trade_date,
                    payload_json=json.dumps(
                        {
                            "eod_marks": eod_marks,
                            "symbols_count": len(eod_marks),
                        }
                    ),
                )

                # CL-L7: also prune retention-window raw rows on EOD so a
                # long-running process does not only prune at startup.
                pruned = 0
                if self._retention_days > 0:
                    pruned = self._prune()
            log.info(
                "EOD received — %d symbol mark(s) applied, session_events row written for %s",
                len(eod_marks),
                eod_trade_date,
            )
            if pruned:
                log.info(
                    "EOD prune removed %d trade_events row(s) older than %d days",
                    pruned,
                    self._retention_days,
                )
        except Exception as exc:
            log.warning("error handling system.eod: %s", exc)

    def _handle_session_state(self, payload: dict[str, Any]) -> None:
        """
        Handle session.state — record a PHASE row in session_events (CL-M7).

        The engine broadcasts session-phase transitions on PUB
        (``{state, prev_state}``).  Recording them makes the advertised
        ``event_type='PHASE'`` filter real and lets operators align trade
        activity with the session phase it occurred in.
        """
        try:
            typed = SessionState.from_dict(payload)
            state = typed.state.upper()
            if not state:
                return
            ts_ns = now_ns()
            day = trade_date(ts_ns, self._tz)
            pruned = 0
            with self._lock:
                # Judged before this row is recorded: a CLOSED that follows the
                # day's CLOSED (an engine restart after the close) must not
                # replace a snapshot pm-eod may already have settled.
                final = state == "CLOSED" and close_snapshot_is_final(self._conn, day)
                record_session_event(
                    self._conn,
                    event_type="PHASE",
                    ts_ns=ts_ns,
                    trade_date=day,
                    payload_json=json.dumps(
                        {
                            "state": state,
                            "prev_state": typed.prev_state,
                        }
                    ),
                )
                # The close is the day boundary of a process that never
                # restarts: system.eod comes only when the engine shuts down,
                # so without this a weeks-long run never pruned at all.
                if state == "CLOSED":
                    # Closing-auction trades may still be buffered.  Open
                    # positions are already marked to the last trade price
                    # (Ledger._remark_symbol), so copying them is the close.
                    self._flush()
                    if final:
                        log.info("close snapshot for %s is final; kept", day)
                    else:
                        snapshot_rows = write_close_snapshot(self._conn, day)
                        log.info("close snapshot: %d position(s)", snapshot_rows)
                if state == "CLOSED" and self._retention_days > 0:
                    pruned = self._prune()
            if pruned:
                log.info(
                    "close prune removed %d trade_events row(s) older than %d days",
                    pruned,
                    self._retention_days,
                )
        except Exception as exc:
            log.warning("error handling session.state: %s", exc)

    def _handle_gateway_auth(self, payload: dict[str, Any]) -> None:
        """
        Handle system.gateway_auth.{id} — the engine's PUB broadcast emitted when
        a gateway completes (or is refused) the connect handshake.

        An *accepted* auth is the observable "gateway connected" event on the
        public feed, so record it exactly as a connect.  A refused auth carries
        ``accepted=False`` and is ignored (no session opened).
        """
        typed = _gen_system.GatewayAuth.from_dict(payload)
        if not typed.accepted:
            return
        self._handle_gateway_connect(typed.to_dict())

    def _handle_gateway_bye(self, payload: dict[str, Any]) -> None:
        """
        Handle system.gateway_bye.{id} — the engine's PUB broadcast emitted when
        a gateway disconnects.  Record it exactly as a disconnect (the inbound
        system.gateway_disconnect topic is PULL-only and never reaches here).
        """
        typed = _gen_system.GatewayBye.from_dict(payload)
        self._handle_gateway_disconnect(typed.to_dict())

    def _handle_gateway_connect(self, payload: dict[str, Any]) -> None:
        """
        Handle system.gateway_connect — record connect timestamp in DB.
        """
        try:
            gateway_id = str(payload.get("gateway_id", "")).upper()
            if not gateway_id:
                return
            ts_ns = now_ns()
            self._gw_connect_ts[gateway_id] = ts_ns
            with self._lock:
                record_gateway_connect(
                    self._conn,
                    gateway_id=gateway_id,
                    connected_at_ns=ts_ns,
                )
            log.info("gateway connected gateway_id=%s", gateway_id)
        except Exception as exc:
            log.warning("error handling gateway_connect: %s", exc)

    def _handle_gateway_disconnect(self, payload: dict[str, Any]) -> None:
        """
        Handle system.gateway_disconnect — close the gateway's open session
        with the disconnect timestamp and reason, after writing what is
        buffered so the session's trades are on disk when it is marked closed.
        """
        try:
            gateway_id = str(payload.get("gateway_id", "")).upper()
            if not gateway_id:
                return

            ts_ns = now_ns()
            reason = payload.get("reason") or payload.get("disconnect_reason")
            self._gw_connect_ts.pop(gateway_id, None)

            with self._lock:
                self._flush()
                # Close the latest open session in SQL (MAX open connected_at_ns)
                # rather than relying on the in-memory dict — so a clearing
                # restart does not orphan a session opened before the restart.
                close_latest_gateway_session(
                    self._conn,
                    gateway_id=gateway_id,
                    disconnected_at_ns=ts_ns,
                    reason=str(reason) if reason else None,
                )
            log.info(
                "gateway disconnected gateway_id=%s reason=%s",
                gateway_id,
                reason,
            )
        except Exception as exc:
            log.warning("error handling gateway_disconnect: %s", exc)

    # ------------------------------------------------------------------
    # Console P&L table
    # ------------------------------------------------------------------

    def _print_pnl_table(self) -> None:
        # CL-M2: this runs on the receive thread while the timer thread mutates
        # _positions inside _flush.  Snapshot the positions under the lock (each
        # a shallow copy, so field values are captured atomically) before
        # iterating/printing — otherwise the read can tear a row or raise
        # "dictionary changed size during iteration" and kill the receive loop.
        with self._lock:
            positions = [copy.copy(p) for p in self._ledger.all_positions()]
        if not positions:
            return

        t = Table(title="[bold]P&L Summary[/bold]", show_lines=True)
        t.add_column("Gateway", style="cyan")
        t.add_column("Symbol", style="bold")
        t.add_column("Net Qty", justify="right")
        t.add_column("Avg Cost", justify="right")
        t.add_column("Mark", justify="right")
        t.add_column("Realized", justify="right")
        t.add_column("Unrealized", justify="right")
        t.add_column("Total P&L", justify="right")

        for pos in sorted(positions, key=lambda p: (p.gateway_id, p.symbol)):
            scale = float(10**pos.tick_decimals)
            real = pos.realized_pnl / scale
            unreal = pos.unrealized_pnl / scale
            total = real + unreal
            colour = "green" if total >= 0 else "red"
            mark = (
                f"{(pos.mark_price / scale):.{pos.tick_decimals}f}"
                if pos.mark_price is not None
                else "—"
            )
            avg_cost = (
                f"{(pos.avg_cost / scale):.{pos.tick_decimals}f}"
                if pos.avg_cost
                else "—"
            )
            t.add_row(
                pos.gateway_id,
                pos.symbol,
                f"{pos.net_qty:+d}",
                avg_cost,
                mark,
                f"[{colour}]{real:+.2f}[/{colour}]",
                f"[{colour}]{unreal:+.2f}[/{colour}]",
                f"[bold {colour}]{total:+.2f}[/bold {colour}]",
            )

        console.print(t)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def _resolve_timezone(name: str) -> tzinfo | None:
    """
    Resolve a timezone name to a ``tzinfo``, or ``None`` if it is unknown.

    ``UTC`` maps to the builtin ``timezone.utc`` (no tzdata dependency); any
    other name is looked up via ``zoneinfo`` and falls back to ``None`` when the
    IANA database is missing or the name is invalid.
    """
    if name.upper() == "UTC":
        return timezone.utc
    try:
        from zoneinfo import ZoneInfo

        return ZoneInfo(name)
    except Exception:
        return None


def _enable_sql_trace_logging() -> None:
    """Install a dedicated handler for verbose SQLite statement tracing."""
    sql_logger = logging.getLogger("edumatcher.clearing.sql")
    sql_logger.setLevel(logging.DEBUG)
    sql_logger.propagate = False
    if sql_logger.handlers:
        return
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.DEBUG)
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(levelname)s %(name)s - %(message)s")
    )
    sql_logger.addHandler(handler)


def build_parser() -> argparse.ArgumentParser:
    from edumatcher.cli_version import add_version_argument

    parser = argparse.ArgumentParser(
        prog="pm-clearing",
        description="EduMatcher clearing process — SQLite-backed trade P&L tracker",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    add_version_argument(parser, "pm-clearing")

    parser.add_argument(
        "--datapath",
        metavar="PATH",
        default=None,
        help="Data directory or explicit .db file path",
    )
    parser.add_argument(
        "--db-name",
        metavar="NAME",
        default="clearing.db",
        help="SQLite filename within data directory (default: clearing.db)",
    )
    parser.add_argument(
        "--flush-size",
        type=int,
        default=FLUSH_SIZE,
        metavar="N",
        help=f"Max buffered trades before flush (1..100, default: {FLUSH_SIZE})",
    )
    parser.add_argument(
        "--flush-interval",
        type=float,
        default=FLUSH_INTERVAL_SEC,
        metavar="SEC",
        help=f"Max seconds between flushes (>=0.1, default: {FLUSH_INTERVAL_SEC})",
    )
    parser.add_argument(
        "--print-every",
        type=int,
        default=_PRINT_EVERY,
        metavar="N",
        help=(
            "Print a P&L table of every position every N trades (0 = never, "
            "the default); drawn on the receive thread, so keep it for small "
            "classroom ledgers"
        ),
    )
    parser.add_argument(
        "--retention-days",
        type=int,
        default=_RETENTION_DAYS,
        metavar="N",
        help=(
            f"Delete trade_events rows and close snapshots older than N days"
            f" on startup and at every close; the newest close snapshot is"
            f" kept (default: {_RETENTION_DAYS}; 0 = disable pruning)"
        ),
    )
    parser.add_argument(
        "--sql-trace",
        action="store_true",
        help="Log executed SQLite statements from the clearing writer connection",
    )
    parser.add_argument(
        "--log-level",
        choices=["CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"],
        help="Logging level override (default: WARNING)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase log verbosity (-v: INFO, -vv: DEBUG)",
    )
    parser.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help=(
            "Explicit WARNING log level (the default); -v and --log-level take precedence"
        ),
    )
    parser.add_argument(
        "--log-target",
        choices=["server", "stdout", "file"],
        default=None,
        help=(
            "Where this process's own operational log records go: "
            "server (default, auto-detected pm-log-srv), stdout, or file"
        ),
    )
    parser.add_argument(
        "--log-file",
        default=None,
        metavar="PATH",
        help="Operational log file path — required when --log-target file",
    )
    parser.add_argument(
        "--log-failover-timeout",
        type=float,
        default=None,
        metavar="SECONDS",
        help=(
            "Grace window before falling back to a local log file once "
            "pm-log-srv becomes unreachable (default: 30, from config)"
        ),
    )
    return parser


def _configure_logging(args: argparse.Namespace) -> int:
    if args.log_level:
        level_name = str(args.log_level).upper()
        level = getattr(logging, level_name, logging.WARNING)
    elif args.verbose >= 2:
        level = logging.DEBUG
    elif args.verbose == 1:
        level = logging.INFO
    elif args.quiet:
        level = logging.WARNING
    else:
        level = logging.WARNING

    client_config = load_default_log_client_config()
    server_config = load_default_log_server_config()
    failover_timeout = getattr(args, "log_failover_timeout", None)
    handler = resolve_handler(
        log_target=getattr(args, "log_target", None),
        log_file=getattr(args, "log_file", None),
        client_name=_CLIENT_NAME,
        instance=None,
        host=resolve_host_default(),
        port=server_config.port,
        connect_timeout_sec=client_config.connect_timeout_sec,
        failover_timeout_sec=(
            failover_timeout
            if failover_timeout is not None
            else client_config.failover_timeout_sec
        ),
        failover_dir=client_config.failover_dir,
    )
    logging.basicConfig(level=level, format=_LOG_FORMAT, handlers=[handler])
    return int(level)


@exit_on_config_error
def main() -> None:
    from edumatcher.config import DATA_DIR, ENGINE_PUB_ADDR, resolve_data_path

    parser = build_parser()
    args = parser.parse_args()

    level = _configure_logging(args)
    if args.sql_trace:
        _enable_sql_trace_logging()
    log.info("starting pm-clearing with log level %s", logging.getLevelName(level))

    if not (1 <= args.flush_size <= 100):
        parser.error("--flush-size must be 1..100")
    if args.flush_interval < 0.1:
        parser.error("--flush-interval must be >= 0.1")
    if args.retention_days < 0:
        parser.error("--retention-days must be >= 0")

    from edumatcher.config_artifact import load_compiled_config
    from edumatcher.engine.config_loader import DEFAULT_SESSION_TIMEZONE

    compiled = load_compiled_config()
    session_tz_name = (
        DEFAULT_SESSION_TIMEZONE
        if compiled is None
        else compiled.engine.locale.session_timezone
    )
    session_tz = _resolve_timezone(session_tz_name)
    if session_tz is None:
        parser.error(
            f"engine config locale.session_timezone: unknown timezone {session_tz_name!r}"
        )

    if args.datapath is not None:
        dp = resolve_data_path(args.datapath)
        db_path = dp if dp.suffix == ".db" else dp / args.db_name
    else:
        db_path = DATA_DIR / args.db_name

    try:
        process = ClearingProcess(
            pub_addr=ENGINE_PUB_ADDR,
            db_path=db_path,
            flush_size=args.flush_size,
            flush_interval_sec=args.flush_interval,
            print_every=args.print_every,
            retention_days=args.retention_days,
            session_tz=session_tz,
            sql_trace=args.sql_trace,
        )
    except Exception as exc:
        log.critical("fatal startup error: %s", exc)
        raise SystemExit(1) from exc

    reporter = HealthReporter.start_from_compiled_config(_CLIENT_NAME)
    if reporter is not None:
        process.attach_reporter(reporter)
    process.run()
    if process.unwritten_trades:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
