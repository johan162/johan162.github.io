"""pm-clearing-cli — read-only query interface for the clearing SQLite database."""

from __future__ import annotations

import argparse
import contextlib
import csv
import json
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, TypedDict
from urllib.parse import quote

from edumatcher.cli_pipe import pipe_safe
from edumatcher.clearing.query import (
    day_bounds_ns,
    open_readonly_connection,
    session_timezone,
)
from edumatcher.clearing.store import (
    count_summary_days,
    require_trade_events_id_primary_key,
    open_writer_connection as _open_writer,
    prune_close_snapshots,
    prune_old_events,
    query_daily,
    query_dates,
    query_close_snapshots,
    query_exposure,
    query_feed_gaps,
    query_gateways,
    query_health,
    query_pnl,
    query_positions,
    query_reconcile,
    query_session_events,
    query_sessions,
    query_symbols,
    query_retained_from,
    query_trades,
)
from edumatcher.stats.query import validate_date
from edumatcher.config import CLEARING_HEALTH_ADDR
from edumatcher.healthcheck import (
    PING_TIMEOUT_MS,
    find_process_pids,
    format_bytes,
    ping_health_endpoint,
    run_with_timeout,
)

_FORMATS = ("table", "json", "csv")

# Column lists for each verb — determines output order.
_GATEWAYS_COLS = [
    "gateway_id",
    "realized_pnl_total",
    "unrealized_pnl_total",
    "total_pnl",
    "net_qty_total",
]
_POSITIONS_COLS = [
    "gateway_id",
    "symbol",
    "net_qty",
    "avg_cost",
    "mark_price",
    "tick_decimals",
    "realized_pnl",
    "unrealized_pnl",
    "buy_qty",
    "sell_qty",
    "buy_notional",
    "sell_notional",
    "last_trade_ts_ns",
    "updated_ts_ns",
]
_PNL_COLS = [
    "gateway_id",
    "symbol",
    "realized_pnl",
    "unrealized_pnl",
    "total_pnl",
    "net_qty",
    "mark_price",
    "tick_decimals",
]
_DAILY_COLS = [
    "trade_date",
    "gateway_id",
    "symbol",
    "traded_qty",
    "traded_notional",
    "buy_qty",
    "sell_qty",
    "buy_notional",
    "sell_notional",
    "net_amount",
    "realized_pnl",
    "end_net_qty",
    "end_avg_cost",
    "end_unrealized_pnl",
    "tick_decimals",
    "last_trade_ts_ns",
    "updated_ts_ns",
]
_TRADES_COLS = [
    "id",
    "ts_ns",
    "trade_date",
    "symbol",
    "quantity",
    "price",
    "tick_decimals",
    "buy_order_id",
    "sell_order_id",
    "buy_gateway_id",
    "sell_gateway_id",
    "aggressor_side",
    "ingest_ts_ns",
    "match_type",
    "msg_id",
]
_EXPOSURE_COLS = [
    "gateway_id",
    "symbol",
    "net_qty",
    "mark_price",
    "tick_decimals",
    "net_notional",
    "gross_notional",
    "realized_pnl",
    "unrealized_pnl",
    "total_pnl",
]
_SYMBOLS_COLS = [
    "symbol",
    "traded_qty",
    "traded_notional",
    "realized_pnl",
    "tick_decimals",
    "open_net_qty",
    "open_unrealized_pnl",
]
_DATES_COLS = ["trade_date"]
_DATES_TOTALS_COLS = [
    "trade_date",
    "traded_qty_total",
    "traded_notional_total",
    "net_amount_total",
]
# The integrity/read-write check does a full-file PRAGMA quick_check, which on
# a large clearing.db can run well past a few seconds -- opt-in via
# --extended rather than in every health call, and bounded so a check that
# never returns cannot hang the CLI indefinitely.
_EXTENDED_HEALTH_TIMEOUT_SEC = 45.0

# The tables pm-clearing's flush transaction writes; a database missing any
# of them is not one pm-clearing could be recording into.
_CLEARING_TABLES = (
    "trade_events",
    "gateway_symbol_positions",
    "gateway_daily_summary",
)


class _HealthProcessReport(TypedDict):
    healthy: bool
    pids: list[int]
    detail: str


class _HealthDatabaseStats(TypedDict):
    size_bytes: int
    row_counts: dict[str, int]
    last_trade_ts_ns: int | None
    last_flush_ts_ns: int | None
    wal_mode: str


class _HealthDatabaseReport(TypedDict):
    healthy: bool
    path: str
    detail: str
    checked: bool
    stats: _HealthDatabaseStats | None


class _HealthZmqReport(TypedDict):
    healthy: bool
    detail: str


class _HealthReport(TypedDict):
    healthy: bool
    process: _HealthProcessReport
    database: _HealthDatabaseReport
    zmq: _HealthZmqReport


_RECONCILE_COLS = [
    "side",
    "trade_date",
    "gateway_id",
    "symbol",
    "raw_qty",
    "summary_qty",
    "qty_diff",
    "raw_notional",
    "summary_notional",
    "notional_diff",
    "tick_decimals",
]
_SESSION_EVENTS_COLS = [
    "id",
    "event_type",
    "ts_ns",
    "trade_date",
    "payload_json",
]
_FEED_GAPS_COLS = [
    "trade_date",
    "ts_ns",
    "run_seq",
    "last_seq",
    "next_seq",
    "missing_trades",
    "reason",
]
_SNAPSHOTS_COLS = [
    "trade_date",
    "gateway_id",
    "symbol",
    "net_qty",
    "mark_price",
    "tick_decimals",
    "realized_pnl",
    "unrealized_pnl",
]
_SESSIONS_COLS = [
    "gateway_id",
    "connect_date",
    "connected_at_ns",
    "disconnected_at_ns",
    "disconnect_reason",
]

_NORMALIZE_FIELDS: dict[str, tuple[str, ...]] = {
    # These columns hold tick-unit values (some REAL because of VWAP/P&L
    # division, but still *in ticks*) and are divided by the symbol's tick scale
    # for display.  avg_cost is fractional ticks (ledger sets avg_cost from an
    # int tick price), so it MUST be normalized too — omitting it rendered
    # avg_cost 100x off next to mark_price (finding CL-H3).
    "positions": (
        "avg_cost",
        "mark_price",
        "realized_pnl",
        "unrealized_pnl",
        "buy_notional",
        "sell_notional",
    ),
    "pnl": ("mark_price", "realized_pnl", "unrealized_pnl", "total_pnl"),
    "daily": (
        "traded_notional",
        "buy_notional",
        "sell_notional",
        "net_amount",
        "realized_pnl",
        "end_avg_cost",
        "end_unrealized_pnl",
    ),
    "trades": ("price",),
    "exposure": (
        "mark_price",
        "net_notional",
        "gross_notional",
        "realized_pnl",
        "unrealized_pnl",
        "total_pnl",
    ),
    "symbols": ("traded_notional", "realized_pnl", "open_unrealized_pnl"),
    "snapshots": ("mark_price", "realized_pnl", "unrealized_pnl"),
    "reconcile": ("raw_notional", "summary_notional", "notional_diff"),
}


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pm-clearing-cli",
        description="Query EduMatcher clearing DB without writing SQL",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-clearing-cli")

    parser.add_argument(
        "--datapath",
        default=None,
        metavar="PATH",
        help="Data directory or explicit .db file path",
    )
    parser.add_argument(
        "--db-name",
        default="clearing.db",
        metavar="NAME",
        help="SQLite filename within data directory (default: clearing.db)",
    )
    parser.add_argument(
        "--format",
        default="table",
        choices=_FORMATS,
        help="Output format: table, json, csv (default: table)",
    )
    parser.add_argument(
        "--no-header",
        action="store_true",
        help="Suppress the header row (table and csv output)",
    )
    parser.add_argument(
        "--raw-output",
        action="store_true",
        help="Show raw tick-unit values instead of normalized display values",
    )

    sub = parser.add_subparsers(dest="command", required=True, metavar="COMMAND")

    # gateways
    gw = sub.add_parser("gateways", help="List gateways with P&L totals")
    gw.add_argument("--gateway", metavar="GW_ID")
    gw.add_argument("--limit", type=int, default=1000, metavar="N")

    # positions
    pos = sub.add_parser("positions", help="Current positions by gateway/symbol")
    pos.add_argument("--gateway", metavar="GW_ID")
    pos.add_argument("--symbol", metavar="SYMBOL")
    pos.add_argument("--limit", type=int, default=10000, metavar="N")

    # pnl
    pnl = sub.add_parser("pnl", help="Realized/unrealized/total P&L")
    pnl.add_argument("--gateway", metavar="GW_ID")
    pnl.add_argument("--symbol", metavar="SYMBOL")
    pnl.add_argument("--limit", type=int, default=10000, metavar="N")

    # daily
    daily = sub.add_parser("daily", help="Daily rollup summaries")
    daily.add_argument("--gateway", metavar="GW_ID")
    daily.add_argument("--symbol", metavar="SYMBOL")
    daily.add_argument("--date", metavar="YYYY-MM-DD")
    daily.add_argument("--from", dest="from_date", metavar="YYYY-MM-DD")
    daily.add_argument("--to", dest="to_date", metavar="YYYY-MM-DD")
    daily.add_argument("--limit", type=int, default=1000, metavar="N")

    # trades
    trades = sub.add_parser("trades", help="Raw trade events")
    trades.add_argument("--gateway", metavar="GW_ID")
    trades.add_argument("--symbol", metavar="SYMBOL")
    trades.add_argument("--date", metavar="YYYY-MM-DD")
    trades.add_argument("--from", dest="from_date", metavar="YYYY-MM-DD")
    trades.add_argument("--to", dest="to_date", metavar="YYYY-MM-DD")
    trades.add_argument("--limit", type=int, default=200, metavar="N")

    # exposure
    exp = sub.add_parser("exposure", help="Net/gross notional exposure")
    exp.add_argument("--gateway", metavar="GW_ID")
    exp.add_argument("--symbol", metavar="SYMBOL")
    exp.add_argument("--sort", default="gross_notional", metavar="FIELD")
    exp.add_argument("--limit", type=int, default=1000, metavar="N")

    # symbols
    syms = sub.add_parser("symbols", help="Symbol-level clearing totals")
    syms.add_argument("--date", metavar="YYYY-MM-DD")
    syms.add_argument("--from", dest="from_date", metavar="YYYY-MM-DD")
    syms.add_argument("--to", dest="to_date", metavar="YYYY-MM-DD")
    syms.add_argument("--sort", default="symbol", metavar="FIELD")
    syms.add_argument("--limit", type=int, default=1000, metavar="N")

    # dates
    dates = sub.add_parser("dates", help="Available trading dates")
    dates.add_argument("--gateway", metavar="GW_ID")
    dates.add_argument("--symbol", metavar="SYMBOL")
    dates.add_argument("--from", dest="from_date", metavar="YYYY-MM-DD")
    dates.add_argument("--to", dest="to_date", metavar="YYYY-MM-DD")
    dates.add_argument(
        "--with-totals",
        action="store_true",
        help="Include per-date quantity and net-amount totals",
    )
    dates.add_argument("--limit", type=int, default=1000, metavar="N")

    # snapshots
    snaps = sub.add_parser(
        "snapshots",
        help="Position snapshots taken at each session close (basis for settlement)",
    )
    snaps.add_argument("--gateway", metavar="GW_ID")
    snaps.add_argument("--symbol", metavar="SYMBOL")
    snaps.add_argument("--date", metavar="YYYY-MM-DD")
    snaps.add_argument("--from", dest="from_date", metavar="YYYY-MM-DD")
    snaps.add_argument("--to", dest="to_date", metavar="YYYY-MM-DD")
    snaps.add_argument("--limit", type=int, default=10000, metavar="N")

    # health
    health = sub.add_parser(
        "health",
        help="Check the pm-clearing process and clearing database read/write health",
    )
    health.add_argument(
        "-q",
        "--quiet",
        action="store_true",
        help="Print nothing; exit 0 when healthy, 1 otherwise",
    )
    health.add_argument(
        "--extended",
        action="store_true",
        help=(
            "Also check clearing.db integrity and read/write access (PRAGMA "
            f"quick_check); allowed up to {_EXTENDED_HEALTH_TIMEOUT_SEC:.0f}s "
            "for a large database"
        ),
    )
    health.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help=(
            "Describe exactly what was checked, plus database size, row counts, "
            "last trade/flush time and WAL mode when combined with --extended"
        ),
    )

    # reconcile
    rec = sub.add_parser(
        "reconcile",
        help="Compare raw trade_events against gateway_daily_summary aggregates",
    )
    rec.add_argument("--gateway", metavar="GW_ID")
    rec.add_argument("--symbol", metavar="SYMBOL")
    rec.add_argument("--from", dest="from_date", metavar="YYYY-MM-DD")
    rec.add_argument("--to", dest="to_date", metavar="YYYY-MM-DD")
    rec.add_argument(
        "--retention-days",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Ignore dates older than N days (match pm-clearing --retention-days)"
            " so pruned-raw days are not reported as false positives"
        ),
    )

    # sessions
    ses = sub.add_parser(
        "sessions",
        help="Gateway connection and disconnection history",
    )
    ses.add_argument("--gateway", metavar="GW_ID", help="Filter to one gateway")
    ses.add_argument(
        "--from",
        dest="from_date",
        metavar="YYYY-MM-DD",
        help="Inclusive first trading day of the connect (session timezone)",
    )
    ses.add_argument(
        "--to",
        dest="to_date",
        metavar="YYYY-MM-DD",
        help="Inclusive last trading day of the connect (session timezone)",
    )
    ses.add_argument(
        "--connected-only",
        action="store_true",
        help="Show only sessions without a recorded disconnect",
    )
    ses.add_argument("--limit", type=int, default=500, metavar="N")

    # eod
    eod = sub.add_parser(
        "eod",
        help="End-of-day sentinel events written by pm-clearing on system.eod",
    )
    eod.add_argument("--from", dest="from_date", metavar="YYYY-MM-DD")
    eod.add_argument("--to", dest="to_date", metavar="YYYY-MM-DD")
    eod.add_argument("--limit", type=int, default=100, metavar="N")

    # gaps
    gaps = sub.add_parser(
        "gaps",
        help="Trade-feed gaps: trades pm-clearing never received, so never booked",
    )
    gaps.add_argument("--from", dest="from_date", metavar="YYYY-MM-DD")
    gaps.add_argument("--to", dest="to_date", metavar="YYYY-MM-DD")
    gaps.add_argument("--limit", type=int, default=500, metavar="N")

    # rebuild
    rebuild = sub.add_parser(
        "rebuild",
        help=(
            "Replay the audit trail into a new clearing DB and list the positions "
            "that differ from this one (exit 3 when any do)"
        ),
        description=(
            "Rebuild the ledger from pm-audit's trade.executed lines, in order, "
            "into a NEW database (the live one is only read), copy its close "
            "snapshots over, and list every gateway/symbol position that differs. "
            "The audit trail must reach back to the live ledger's first trading "
            "day. Exit 0: no difference; 3: differences listed; 1: refused."
        ),
    )
    rebuild.add_argument(
        "--from-audit",
        required=True,
        type=Path,
        metavar="DATA_DIR",
        help="Data directory holding pm-audit's audit.log and audit/ archives",
    )
    rebuild.add_argument(
        "--output",
        required=True,
        type=Path,
        metavar="PATH",
        help="The new database to write; must not exist",
    )

    # prune
    prune = sub.add_parser(
        "prune",
        help=(
            "Delete trade_events rows and close snapshots older than N days "
            "(default: 90; the newest close snapshot is kept); the file keeps "
            "its size, SQLite reuses the freed pages"
        ),
    )
    prune.add_argument(
        "--days",
        type=int,
        default=90,
        metavar="N",
        help="Retention window in days (default: 90)",
    )
    prune.add_argument(
        "--dry-run",
        action="store_true",
        help="Show how many rows would be deleted without actually deleting",
    )

    return parser


# ---------------------------------------------------------------------------
# Argument validation
# ---------------------------------------------------------------------------


def _validate_args(args: argparse.Namespace) -> None:
    if hasattr(args, "limit") and args.limit <= 0:
        raise ValueError("--limit must be > 0")

    for attr in ("date", "from_date", "to_date"):
        val = getattr(args, attr, None)
        if val is not None:
            validate_date(str(val))


# ---------------------------------------------------------------------------
# Output rendering (shared with pm-stats-cli style)
# ---------------------------------------------------------------------------


def _stringify(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float):
        # 15 significant digits: %g printed 12345.67 as 12345.7 (C4).
        return f"{value:.15g}"
    return str(value)


def _render_table(
    rows: list[dict[str, Any]], columns: list[str], no_header: bool
) -> None:
    if not rows:
        print("No rows found.")
        return

    widths: list[int] = []
    for col in columns:
        content_w = max((len(_stringify(row.get(col))) for row in rows), default=0)
        widths.append(max(len(col), content_w))

    def _line(values: list[str]) -> str:
        return " | ".join(v.ljust(w) for v, w in zip(values, widths, strict=True))

    if not no_header:
        print(_line(columns))
        print("-+-".join("-" * w for w in widths))

    for row in rows:
        print(_line([_stringify(row.get(col)) for col in columns]))


def _render_json(rows: list[dict[str, Any]], columns: list[str]) -> None:
    projected = [{col: row.get(col) for col in columns} for row in rows]
    print(json.dumps(projected, indent=2))


def _render_csv(
    rows: list[dict[str, Any]], columns: list[str], no_header: bool
) -> None:
    writer = csv.DictWriter(sys.stdout, fieldnames=columns)
    if not no_header:
        writer.writeheader()
    for row in rows:
        writer.writerow({col: row.get(col) for col in columns})


def _normalize_rows(command: str, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    fields = _NORMALIZE_FIELDS.get(command)
    if not fields:
        return rows

    out: list[dict[str, Any]] = []
    for row in rows:
        tick_decimals = row.get("tick_decimals")
        if tick_decimals is None:
            out.append(row)
            continue

        decimals = int(tick_decimals)
        scale = float(10**decimals)
        normalized = dict(row)
        for field in fields:
            val = normalized.get(field)
            if isinstance(val, (int, float)):
                normalized[field] = float(val) / scale
        out.append(normalized)
    return out


# ---------------------------------------------------------------------------
# Query dispatch
# ---------------------------------------------------------------------------


def _run_query(
    conn: object,
    args: argparse.Namespace,
    db_path: Path,
) -> tuple[list[str], list[dict[str, Any]]]:
    assert isinstance(conn, sqlite3.Connection)

    cmd = args.command

    if cmd == "gateways":
        rows = query_gateways(
            conn,
            gateway=_upper(getattr(args, "gateway", None)),
            limit=args.limit,
        )
        return _GATEWAYS_COLS, rows

    if cmd == "positions":
        rows = query_positions(
            conn,
            gateway=_upper(args.gateway),
            symbol=_upper(args.symbol),
            limit=args.limit,
        )
        return _POSITIONS_COLS, rows

    if cmd == "pnl":
        rows = query_pnl(
            conn,
            gateway=_upper(args.gateway),
            symbol=_upper(args.symbol),
            limit=args.limit,
        )
        return _PNL_COLS, rows

    if cmd == "daily":
        rows = query_daily(
            conn,
            gateway=_upper(args.gateway),
            symbol=_upper(args.symbol),
            date_value=args.date,
            from_date=args.from_date,
            to_date=args.to_date,
            limit=args.limit,
        )
        return _DAILY_COLS, rows

    if cmd == "trades":
        rows = query_trades(
            conn,
            gateway=_upper(args.gateway),
            symbol=_upper(args.symbol),
            date_value=args.date,
            from_date=args.from_date,
            to_date=args.to_date,
            limit=args.limit,
        )
        return _TRADES_COLS, rows

    if cmd == "exposure":
        rows = query_exposure(
            conn,
            gateway=_upper(args.gateway),
            symbol=_upper(args.symbol),
            sort=args.sort,
            limit=args.limit,
        )
        return _EXPOSURE_COLS, rows

    if cmd == "symbols":
        rows = query_symbols(
            conn,
            date_value=args.date,
            from_date=args.from_date,
            to_date=args.to_date,
            sort=args.sort,
            limit=args.limit,
        )
        return _SYMBOLS_COLS, rows

    if cmd == "dates":
        rows = query_dates(
            conn,
            gateway=_upper(getattr(args, "gateway", None)),
            symbol=_upper(getattr(args, "symbol", None)),
            from_date=args.from_date,
            to_date=args.to_date,
            with_totals=args.with_totals,
            limit=args.limit,
        )
        cols = _DATES_TOTALS_COLS if args.with_totals else _DATES_COLS
        return cols, rows

    if cmd == "snapshots":
        rows = query_close_snapshots(
            conn,
            gateway=_upper(getattr(args, "gateway", None)),
            symbol=_upper(getattr(args, "symbol", None)),
            date_value=args.date,
            from_date=args.from_date,
            to_date=args.to_date,
            limit=args.limit,
        )
        return _SNAPSHOTS_COLS, rows

    if cmd == "sessions":
        # Trading days and connect_date are the venue's, in the session
        # timezone pm-clearing recorded -- the same rows the API selects.
        from_ns, to_ns = day_bounds_ns(conn, args.from_date, args.to_date)
        rows = query_sessions(
            conn,
            gateway=_upper(getattr(args, "gateway", None)),
            connected_only=getattr(args, "connected_only", False),
            limit=args.limit,
            from_ns=from_ns,
            to_ns=to_ns,
        )
        tz = session_timezone(conn)
        for row in rows:
            seconds = row["connected_at_ns"] // 1_000_000_000
            connected = datetime.fromtimestamp(seconds, tz)
            row["connect_date"] = connected.date().isoformat()
        return _SESSIONS_COLS, rows

    if cmd == "eod":
        rows = query_session_events(
            conn,
            event_type="EOD",
            from_date=args.from_date,
            to_date=args.to_date,
            limit=args.limit,
        )
        return _SESSION_EVENTS_COLS, rows

    if cmd == "gaps":
        rows = query_feed_gaps(
            conn, from_date=args.from_date, to_date=args.to_date, limit=args.limit
        )
        return _FEED_GAPS_COLS, rows

    assert (
        cmd == "reconcile"
    ), f"Unhandled command: {cmd}"  # prune handled before _run_query
    # Days whose raw trades were pruned cannot be compared: start at the
    # oldest retained raw date, as pm-api-gwy does, and say what was skipped
    # rather than report every pruned day as a discrepancy (C2).
    retained = query_retained_from(conn)
    start = None if retained is None else max(args.from_date or retained, retained)
    rows = (
        []
        if start is None or (args.to_date is not None and start > args.to_date)
        else query_reconcile(
            conn,
            gateway=_upper(getattr(args, "gateway", None)),
            symbol=_upper(getattr(args, "symbol", None)),
            from_date=start,
            to_date=args.to_date,
            retention_days=getattr(args, "retention_days", None),
        )
    )
    pruned = count_summary_days(
        conn, before=retained, from_date=args.from_date, to_date=args.to_date
    )
    # Status lines go to stdout only for the table; json/csv stay parseable.
    status = sys.stdout if args.format == "table" else sys.stderr
    if not rows:
        print("OK — no discrepancies found.", file=status)
    if pruned:
        before = f" before {retained}" if retained else ""
        print(
            f"{pruned} day(s){before} not reconciled (raw trades pruned).",
            file=status,
        )
    return _RECONCILE_COLS, rows


def _upper(val: str | None) -> str | None:
    return val.upper() if val else None


def _run_rebuild(db_path: Path, args: argparse.Namespace) -> None:
    """Rebuild into ``--output`` and print the positions that differ."""
    from edumatcher.clearing.rebuild import RebuildError, rebuild_from_audit

    if not db_path.exists():
        print(f"[ERROR] Clearing DB not found: {db_path}", file=sys.stderr)
        raise SystemExit(1)
    try:
        report = rebuild_from_audit(args.from_audit, db_path, args.output)
    except (RebuildError, sqlite3.Error) as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    rows = report.differences
    columns = list(rows[0]) if rows else ["gateway_id", "symbol"]
    if args.format == "json":
        _render_json(rows, columns)
    elif args.format == "csv":
        _render_csv(rows, columns, no_header=args.no_header)
    else:
        print(
            f"Rebuilt {args.output} from {report.trades} audited trade(s); "
            f"{len(rows)} position(s) differ from {db_path}.",
            file=sys.stderr,
        )
        if report.gaps:
            print(
                f"The audit trail itself misses trades: {report.gaps} gap(s), "
                f"see `pm-clearing-cli --datapath {args.output} gaps`.",
                file=sys.stderr,
            )
        _render_table(rows, columns, no_header=args.no_header)
    if rows:
        raise SystemExit(3)


def _run_prune(db_path: Path, args: argparse.Namespace) -> None:
    """Execute or dry-run the retention prune of an existing clearing DB."""
    days: int = args.days
    if days < 1:
        print("[ERROR] --days must be >= 1", file=sys.stderr)
        raise SystemExit(2)
    # The writer would create the file (and its directory): a mistyped
    # --datapath must not become a fresh, empty ledger (C6).
    if not db_path.exists():
        print(f"[ERROR] Clearing DB not found: {db_path}", file=sys.stderr)
        raise SystemExit(1)

    try:
        conn = _open_writer(db_path)
    except Exception as exc:
        print(f"[ERROR] Could not open clearing DB: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc

    with contextlib.closing(conn):
        try:
            if args.dry_run:
                count = conn.execute(
                    "SELECT COUNT(*) FROM trade_events WHERE trade_date < date('now', ?)",
                    (f"-{days} days",),
                ).fetchone()[0]
                snapshots = conn.execute(
                    "SELECT COUNT(*) FROM position_close_snapshot"
                    " WHERE trade_date < date('now', ?) AND trade_date <"
                    " (SELECT MAX(trade_date) FROM position_close_snapshot)",
                    (f"-{days} days",),
                ).fetchone()[0]
                print(
                    f"DRY RUN: {count} trade_events rows would be deleted (>{days} days old)."
                )
                print(
                    f"DRY RUN: {snapshots} close-snapshot rows would be deleted"
                    f" (>{days} days old; the newest close is kept)."
                )
            else:
                deleted = prune_old_events(conn, retention_days=days)
                print(f"Pruned {deleted} trade_events rows older than {days} days.")
                snapshots = prune_close_snapshots(conn, retention_days=days)
                print(
                    f"Pruned {snapshots} close-snapshot rows older than {days} days"
                    " (the newest close is kept)."
                )
        except sqlite3.Error as exc:
            print(f"[ERROR] Prune failed: {exc}", file=sys.stderr)
            raise SystemExit(1) from exc


# ---------------------------------------------------------------------------
# Health check
# ---------------------------------------------------------------------------


def _find_clearing_pids() -> list[int]:
    """Find pm-clearing processes without matching this pm-clearing-cli process."""
    return find_process_pids("pm-clearing")


def _format_ts_ns(ts_ns: int | None) -> str:
    if ts_ns is None:
        return "(none)"
    return datetime.fromtimestamp(ts_ns / 1e9, tz=timezone.utc).isoformat()


def _collect_db_stats(conn: sqlite3.Connection, db_path: Path) -> _HealthDatabaseStats:
    """File size plus the `query_health` metadata, for --extended --verbose."""
    row = query_health(conn, db_path)[0]
    return {
        "size_bytes": db_path.stat().st_size,
        "row_counts": {
            table: int(row[f"{table}_rows"] or 0) for table in _CLEARING_TABLES
        },
        "last_trade_ts_ns": row["last_trade_ts_ns"],
        "last_flush_ts_ns": row["last_flush_ts_ns"],
        "wal_mode": str(row["wal_mode"]),
    }


def _check_database_health(
    db_path: Path, *, collect_stats: bool = False
) -> tuple[bool, str, _HealthDatabaseStats | None]:
    """Check integrity, schema, and a rolled-back write transaction."""
    if not db_path.exists():
        return False, f"database not found: {db_path}", None
    conn: sqlite3.Connection | None = None
    try:
        # mode=rw: never create the file, unlike a plain connect. The path is
        # percent-encoded: a '?' in it would otherwise end the path (C7).
        conn = sqlite3.connect(
            f"file:{quote(str(db_path.resolve()))}?mode=rw", uri=True, timeout=2.0
        )
        conn.row_factory = sqlite3.Row
        quick_check = str(conn.execute("PRAGMA quick_check").fetchone()[0])
        if quick_check != "ok":
            return False, f"integrity check failed: {quick_check}", None
        present = {
            str(r[0])
            for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")
        }
        missing = [t for t in _CLEARING_TABLES if t not in present]
        if missing:
            return False, f"missing table(s): {', '.join(missing)}", None
        require_trade_events_id_primary_key(conn)
        # Take clearing.db's own write lock and write a row, then roll back:
        # a TEMP table never touched the file, so a read-only file passed (C8).
        conn.execute("BEGIN IMMEDIATE")
        conn.execute(
            "INSERT INTO clearing_meta (key, value) VALUES ('health_check', '1')"
            " ON CONFLICT(key) DO NOTHING"
        )
        conn.rollback()
        stats = _collect_db_stats(conn, db_path) if collect_stats else None
    except RuntimeError as exc:
        return False, str(exc), None
    except (OSError, sqlite3.Error, TypeError, ValueError) as exc:
        return False, f"database read/write check failed: {exc}", None
    finally:
        if conn is not None:
            conn.close()
    return True, "read/write and integrity checks passed", stats


def _run_extended_database_check(
    db_path: Path,
    *,
    collect_stats: bool = False,
    timeout_sec: float = _EXTENDED_HEALTH_TIMEOUT_SEC,
) -> tuple[bool, str, _HealthDatabaseStats | None]:
    """Run `_check_database_health`, bounded by `timeout_sec`."""
    try:
        return run_with_timeout(
            lambda: _check_database_health(db_path, collect_stats=collect_stats),
            timeout_sec,
        )
    except TimeoutError as exc:
        return False, f"database check {exc}", None


def _check_zmq_health(timeout_ms: int = PING_TIMEOUT_MS) -> tuple[bool, str]:
    """Ping pm-clearing's health REP socket and confirm it replies."""
    return ping_health_endpoint(CLEARING_HEALTH_ADDR, timeout_ms)


def _health_report(
    db_path: Path, *, extended: bool = False, collect_stats: bool = False
) -> tuple[bool, _HealthReport]:
    pids = _find_clearing_pids()
    zmq_ok, zmq_detail = _check_zmq_health()
    if extended:
        db_ok, db_detail, db_stats = _run_extended_database_check(
            db_path, collect_stats=collect_stats
        )
        db_checked = True
    else:
        db_ok, db_detail, db_stats = (
            True,
            "skipped (pass --extended to check integrity and read/write access)",
            None,
        )
        db_checked = False
    report: _HealthReport = {
        "healthy": bool(pids) and db_ok and zmq_ok,
        "process": {
            "healthy": bool(pids),
            "pids": pids,
            "detail": (
                "pm-clearing is running" if pids else "pm-clearing process not found"
            ),
        },
        "database": {
            "healthy": db_ok,
            "path": str(db_path),
            "detail": db_detail,
            "checked": db_checked,
            "stats": db_stats,
        },
        "zmq": {"healthy": zmq_ok, "detail": zmq_detail},
    }
    return bool(report["healthy"]), report


def _handle_health(args: argparse.Namespace, db_path: Path) -> None:
    try:
        healthy, report = _health_report(
            db_path,
            extended=args.extended,
            collect_stats=args.extended and args.verbose,
        )
    except (OSError, ValueError) as exc:
        healthy = False
        report = _HealthReport(
            healthy=False,
            process={"healthy": False, "pids": [], "detail": str(exc)},
            database={
                "healthy": False,
                "path": str(db_path),
                "detail": "health check could not run",
                "checked": False,
                "stats": None,
            },
            zmq={"healthy": False, "detail": "health check could not run"},
        )
    if args.quiet:
        raise SystemExit(0 if healthy else 1)
    if args.format == "json":
        print(json.dumps(report, indent=2, sort_keys=True))
    else:
        process = report["process"]
        database = report["database"]
        zmq_report = report["zmq"]
        print(
            f"pm-clearing process: {'OK' if process['healthy'] else 'FAIL'} - {process['detail']}"
        )
        print(
            f"clearing database:   {'OK' if database['healthy'] else 'FAIL'} - {database['detail']}"
        )
        print(
            f"clearing ZMQ ping:   {'OK' if zmq_report['healthy'] else 'FAIL'} - {zmq_report['detail']}"
        )
        print(f"health: {'OK' if healthy else 'FAIL'}")
        if args.verbose:
            print()
            print("Checks performed:")
            print("  pm-clearing process (pgrep):   yes")
            print("  ZMQ health ping:                yes")
            print(
                "  Database integrity/read-write: "
                + ("yes" if database["checked"] else "no (pass --extended)")
            )
            stats = database["stats"]
            if stats is not None:
                print()
                print("Database stats:")
                print(f"  path: {database['path']}")
                print(f"  size: {format_bytes(stats['size_bytes'])}")
                for table, count in stats["row_counts"].items():
                    print(f"  {table} rows: {count}")
                print(f"  last trade: {_format_ts_ns(stats['last_trade_ts_ns'])}")
                print(f"  last flush: {_format_ts_ns(stats['last_flush_ts_ns'])}")
                print(f"  journal mode: {stats['wal_mode']}")
    raise SystemExit(0 if healthy else 1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


@pipe_safe
def main() -> None:
    from edumatcher.config import DATA_DIR, resolve_data_path

    parser = build_parser()
    args = parser.parse_args()

    try:
        _validate_args(args)
    except ValueError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(2) from exc

    if args.datapath is not None:
        dp = resolve_data_path(args.datapath)
        db_path = dp if dp.suffix == ".db" else dp / args.db_name
    else:
        db_path = DATA_DIR / args.db_name

    # health reports a missing database itself (under --extended) rather than
    # refusing to run, and needs no connection unless --extended asks for one.
    if args.command == "health":
        _handle_health(args, db_path)

    # prune needs write access; all other verbs are read-only.
    if args.command == "prune":
        _run_prune(db_path, args)
        return
    if args.command == "rebuild":
        _run_rebuild(db_path, args)
        return
    try:
        conn = open_readonly_connection(db_path)
    except FileNotFoundError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    except sqlite3.Error as exc:
        print(f"[ERROR] Could not open clearing DB: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc

    try:
        columns, rows = _run_query(conn, args, db_path)
    except (sqlite3.Error, ValueError) as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    finally:
        conn.close()

    if not args.raw_output:
        rows = _normalize_rows(args.command, rows)

    if args.format == "json":
        _render_json(rows, columns)
        return

    if args.format == "csv":
        _render_csv(rows, columns, no_header=args.no_header)
        return

    _render_table(rows, columns, no_header=args.no_header)


if __name__ == "__main__":
    main()
