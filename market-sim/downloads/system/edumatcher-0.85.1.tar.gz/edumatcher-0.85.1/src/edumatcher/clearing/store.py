"""
SQLite schema, DDL helpers, write operations, and read-only queries
for the pm-clearing v2 process.

Separation of concerns
-----------------------
- ``apply_schema``         — idempotent DDL: create tables, indexes, views
- ``open_writer_connection``  — connection used by pm-clearing (read/write)
- ``open_readonly_connection``  — connection used by pm-clearing-cli
- ``flush_batch``          — atomic write of one buffer-worth of trades
- ``prune_old_events``     — delete trade_events rows older than N days
- ``query_*``              — read-only SELECT helpers for each CLI verb

Price note
----------
``trade.executed.price`` is a display float; pm-clearing converts it to
integer ticks of the trade's ``tick_decimals`` at ingress. All price-derived
columns (``price``, ``mark_price``, ``traded_notional``, ``buy_notional``,
``sell_notional``, ``net_amount``) are stored as INTEGER ticks of the row's
``tick_decimals``.  Columns derived from weighted-average math (``avg_cost``,
``realized_pnl``, ``unrealized_pnl`` and their end-of-day variants) are REAL.

Ingest timestamp note
---------------------
``trade_events.ingest_ts_ns`` is the clearing-local ingest/write timestamp
recorded when the flush transaction is built.  It is not an exchange event
clock and should be interpreted as local pipeline timing metadata.

Aggressor-side note
-------------------
``trade_events.aggressor_side`` mirrors the engine payload as-is.  For auction
trades the upstream engine can mark buyer aggressor by construction, so this
column should not be treated as an authoritative aggressor signal for auction
analytics.
"""

from __future__ import annotations

import json
import logging
import re
import sqlite3
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

_sql_log = logging.getLogger("edumatcher.clearing.sql")


class IncompatibleClearingDatabaseError(Exception):
    """The clearing DB was recorded with a session timezone that no longer matches."""


# ---------------------------------------------------------------------------
# Pragmas — applied to every new connection.
# ---------------------------------------------------------------------------
_PRAGMAS = """
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA foreign_keys = ON;
PRAGMA temp_store = MEMORY;
"""

# ---------------------------------------------------------------------------
# Schema DDL — idempotent: safe to run on every startup.
# ---------------------------------------------------------------------------
SCHEMA = """
CREATE TABLE IF NOT EXISTS trade_events (
  -- The engine's durable trade id is the sole execution identity.
  id               TEXT    NOT NULL,
  ts_ns            INTEGER NOT NULL,
  trade_date       TEXT    NOT NULL,
  symbol           TEXT    NOT NULL,
  quantity         INTEGER NOT NULL,
  price            INTEGER NOT NULL,
    tick_decimals    INTEGER NOT NULL DEFAULT 2,
  buy_order_id     TEXT,
  sell_order_id    TEXT,
  buy_gateway_id   TEXT    NOT NULL,
  sell_gateway_id  TEXT    NOT NULL,
  -- Mirrored from the engine payload verbatim.  See module docstring note:
  -- auction trades can carry a biased aggressor marker upstream.
  aggressor_side   TEXT,
  ingest_ts_ns     INTEGER NOT NULL,
  -- How the trade came about (trade.executed.match_type), and the audit's
  -- message id of the print: joins a row to its audit line.
  match_type       TEXT,
  msg_id           TEXT,
  PRIMARY KEY (id)
);

-- One trading day in query_trades' order: a day's page reads its own range
-- instead of walking every newer day (clearing review P2); its trade_date
-- prefix serves every other day-scoped read and the prune.
CREATE INDEX IF NOT EXISTS ix_trade_events_date_ts
  ON trade_events(trade_date, ts_ns, ingest_ts_ns, id);
CREATE INDEX IF NOT EXISTS ix_trade_events_symbol_date
  ON trade_events(symbol, trade_date);
CREATE INDEX IF NOT EXISTS ix_trade_events_buy_gw_date
  ON trade_events(buy_gateway_id, trade_date);
CREATE INDEX IF NOT EXISTS ix_trade_events_sell_gw_date
  ON trade_events(sell_gateway_id, trade_date);
-- query_trades' sort key, newest first: a page walks this index and stops
-- at its LIMIT instead of sorting every retained trade (clearing GUI F2).
CREATE INDEX IF NOT EXISTS ix_trade_events_ts
  ON trade_events(ts_ns, ingest_ts_ns, id);

CREATE TABLE IF NOT EXISTS gateway_symbol_positions (
  gateway_id       TEXT    NOT NULL,
  symbol           TEXT    NOT NULL,
  net_qty          INTEGER NOT NULL,
  avg_cost         REAL    NOT NULL,
  realized_pnl     REAL    NOT NULL,
  unrealized_pnl   REAL    NOT NULL,
  mark_price       INTEGER,
    tick_decimals    INTEGER NOT NULL DEFAULT 2,
  buy_qty          INTEGER NOT NULL,
  sell_qty         INTEGER NOT NULL,
  buy_notional     INTEGER NOT NULL,
  sell_notional    INTEGER NOT NULL,
  last_trade_ts_ns INTEGER,
  updated_ts_ns    INTEGER NOT NULL,
  PRIMARY KEY (gateway_id, symbol)
);

CREATE INDEX IF NOT EXISTS ix_gsp_gateway
  ON gateway_symbol_positions(gateway_id);
CREATE INDEX IF NOT EXISTS ix_gsp_symbol
  ON gateway_symbol_positions(symbol);

CREATE TABLE IF NOT EXISTS gateway_daily_summary (
  trade_date         TEXT    NOT NULL,
  gateway_id         TEXT    NOT NULL,
  symbol             TEXT    NOT NULL,
  traded_qty         INTEGER NOT NULL,
  traded_notional    INTEGER NOT NULL,
  buy_qty            INTEGER NOT NULL,
  sell_qty           INTEGER NOT NULL,
  buy_notional       INTEGER NOT NULL,
  sell_notional      INTEGER NOT NULL,
  net_amount         INTEGER NOT NULL,
  realized_pnl       REAL    NOT NULL,
  end_net_qty        INTEGER NOT NULL,
  end_avg_cost       REAL    NOT NULL,
  end_unrealized_pnl REAL    NOT NULL,
    tick_decimals      INTEGER NOT NULL DEFAULT 2,
  last_trade_ts_ns   INTEGER,
  updated_ts_ns      INTEGER NOT NULL,
  PRIMARY KEY (trade_date, gateway_id, symbol)
);

CREATE INDEX IF NOT EXISTS ix_gds_gateway_date
  ON gateway_daily_summary(gateway_id, trade_date);
CREATE INDEX IF NOT EXISTS ix_gds_symbol_date
  ON gateway_daily_summary(symbol, trade_date);

-- P&L / notional are stored in tick units, and one tick is a different amount
-- of currency per symbol (100 ticks = $1.00 at 2 decimals but $0.01 at 4).
-- Summing raw ticks across symbols with different tick_decimals is meaningless
-- (finding CL-H2), and these totals views expose no tick_decimals column for
-- the CLI to normalize with — so normalize to display currency *inside* the
-- view, per row, before aggregating.  Quantities (net_qty, traded_qty) are
-- share counts, not tick-scaled, so they are summed raw.  DROP+CREATE (rather
-- than IF NOT EXISTS) keeps the definition current on pre-existing databases.
DROP VIEW IF EXISTS gateway_pnl_totals;
CREATE VIEW gateway_pnl_totals AS
SELECT
  gateway_id,
  SUM(realized_pnl / scale)                    AS realized_pnl_total,
  SUM(unrealized_pnl / scale)                  AS unrealized_pnl_total,
  SUM((realized_pnl + unrealized_pnl) / scale) AS total_pnl,
  SUM(net_qty)                                 AS net_qty_total
FROM (
  SELECT
    gateway_id, net_qty, realized_pnl, unrealized_pnl,
    CASE tick_decimals
      WHEN 0 THEN 1.0        WHEN 1 THEN 10.0
      WHEN 2 THEN 100.0      WHEN 3 THEN 1000.0
      WHEN 4 THEN 10000.0    WHEN 5 THEN 100000.0
      WHEN 6 THEN 1000000.0  WHEN 7 THEN 10000000.0
      WHEN 8 THEN 100000000.0 ELSE 100.0
    END AS scale
  FROM gateway_symbol_positions
)
GROUP BY gateway_id;

DROP VIEW IF EXISTS daily_exchange_totals;
CREATE VIEW daily_exchange_totals AS
SELECT
  trade_date,
  SUM(traded_qty)               AS traded_qty_total,
  SUM(traded_notional / scale)  AS traded_notional_total,
  SUM(net_amount / scale)       AS net_amount_total,
  SUM(realized_pnl / scale)     AS realized_pnl_total
FROM (
  SELECT
    trade_date, traded_qty, traded_notional, net_amount, realized_pnl,
    CASE tick_decimals
      WHEN 0 THEN 1.0        WHEN 1 THEN 10.0
      WHEN 2 THEN 100.0      WHEN 3 THEN 1000.0
      WHEN 4 THEN 10000.0    WHEN 5 THEN 100000.0
      WHEN 6 THEN 1000000.0  WHEN 7 THEN 10000000.0
      WHEN 8 THEN 100000000.0 ELSE 100.0
    END AS scale
  FROM gateway_daily_summary
)
GROUP BY trade_date;

CREATE TABLE IF NOT EXISTS session_events (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  event_type   TEXT    NOT NULL,
  ts_ns        INTEGER NOT NULL,
  trade_date   TEXT    NOT NULL,
  payload_json TEXT
);

CREATE INDEX IF NOT EXISTS ix_session_events_date
  ON session_events(trade_date);
CREATE INDEX IF NOT EXISTS ix_session_events_type
  ON session_events(event_type);

CREATE TABLE IF NOT EXISTS gateway_sessions (
  gateway_id        TEXT    NOT NULL,
  connected_at_ns   INTEGER NOT NULL,
  disconnected_at_ns INTEGER,
  disconnect_reason TEXT,
  PRIMARY KEY (gateway_id, connected_at_ns)
);

CREATE INDEX IF NOT EXISTS ix_gateway_sessions_gateway
  ON gateway_sessions(gateway_id);

-- One row per position at each session close, whether or not it traded that
-- day (gateway_daily_summary only has rows for symbols that traded, so it
-- cannot show the P&L of a position that was merely held while the price
-- moved).  Cumulative realized + unrealized at the closing mark; the
-- difference between two consecutive closes is a day's mark-to-market P&L.
-- Not pruned with trade_events: the rows are small and settlement reads them.
CREATE TABLE IF NOT EXISTS position_close_snapshot (
  trade_date     TEXT    NOT NULL,
  gateway_id     TEXT    NOT NULL,
  symbol         TEXT    NOT NULL,
  net_qty        INTEGER NOT NULL,
  realized_pnl   REAL    NOT NULL,
  unrealized_pnl REAL    NOT NULL,
  mark_price     INTEGER,
  tick_decimals  INTEGER NOT NULL DEFAULT 2,
  PRIMARY KEY (trade_date, gateway_id, symbol)
);

CREATE TABLE IF NOT EXISTS clearing_meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
"""

# ---------------------------------------------------------------------------
# Row dataclasses used by the flush pipeline.
# ---------------------------------------------------------------------------


@dataclass
class TradeEventRow:
    """One row to INSERT into trade_events."""

    id: str
    ts_ns: int
    trade_date: str
    symbol: str
    quantity: int
    price: int
    buy_order_id: str | None
    sell_order_id: str | None
    buy_gateway_id: str
    sell_gateway_id: str
    aggressor_side: str | None
    ingest_ts_ns: int
    tick_decimals: int = 2
    match_type: str | None = None
    msg_id: str | None = None


@dataclass
class PositionRow:
    """Full current state for one (gateway_id, symbol) — replaces the existing row."""

    gateway_id: str
    symbol: str
    net_qty: int
    avg_cost: float
    realized_pnl: float
    unrealized_pnl: float
    mark_price: int | None
    buy_qty: int
    sell_qty: int
    buy_notional: int
    sell_notional: int
    last_trade_ts_ns: int | None
    updated_ts_ns: int
    tick_decimals: int = 2


@dataclass
class DailySummaryRow:
    """
    Incremental delta amounts + end-of-day snapshot for one
    (trade_date, gateway_id, symbol) key within the current flush batch.
    """

    trade_date: str
    gateway_id: str
    symbol: str
    # deltas — accumulated for all fills in this batch
    delta_traded_qty: int
    delta_traded_notional: int
    delta_buy_qty: int
    delta_sell_qty: int
    delta_buy_notional: int
    delta_sell_notional: int
    delta_net_amount: int
    delta_realized_pnl: float
    # snapshots — latest position state after this batch
    end_net_qty: int
    end_avg_cost: float
    end_unrealized_pnl: float
    last_trade_ts_ns: int | None
    updated_ts_ns: int
    tick_decimals: int = 2


# ---------------------------------------------------------------------------
# Connection helpers
# ---------------------------------------------------------------------------


def apply_schema(conn: sqlite3.Connection) -> None:
    """Apply WAL pragmas and create all tables, indexes, and views."""
    conn.executescript(_PRAGMAS)
    require_trade_events_id_primary_key(conn)
    conn.executescript(SCHEMA)
    _add_column_if_missing(
        conn, "trade_events", "tick_decimals", "INTEGER NOT NULL DEFAULT 2"
    )
    _add_column_if_missing(
        conn,
        "gateway_symbol_positions",
        "tick_decimals",
        "INTEGER NOT NULL DEFAULT 2",
    )
    _add_column_if_missing(
        conn,
        "gateway_daily_summary",
        "tick_decimals",
        "INTEGER NOT NULL DEFAULT 2",
    )
    # A random id per database file, written once.  pm-eod keeps the id each
    # date was settled from, so it can tell this file from a replacement
    # (pm-opctl-cli clear --state) that happens to have the same dates.
    conn.execute(
        "INSERT OR IGNORE INTO clearing_meta (key, value) VALUES ('instance_id', ?)",
        (uuid.uuid4().hex,),
    )
    conn.commit()


def clearing_instance(conn: sqlite3.Connection) -> str | None:
    """This database file's ``instance_id`` (see :func:`apply_schema`)."""
    row = conn.execute(
        "SELECT value FROM clearing_meta WHERE key = 'instance_id'"
    ).fetchone()
    return None if row is None else str(row[0])


def require_trade_events_id_primary_key(conn: sqlite3.Connection) -> None:
    """Reject clearing databases that predate durable trade identity."""
    info = list(conn.execute("PRAGMA table_info(trade_events)"))
    if not info:
        return
    pk_columns = {row[1] for row in info if row[5]}  # row[5] = pk position (>0)
    if pk_columns != {"id"}:
        raise RuntimeError(
            "unsupported clearing schema: trade_events must use id as its "
            "sole primary key; delete the existing database and restart"
        )
    if "msg_id" not in {row[1] for row in info}:
        raise RuntimeError(
            "unsupported clearing schema: trade_events predates match_type and "
            "msg_id (EduMatcher 1.0); delete the existing database and restart"
        )


def _add_column_if_missing(
    conn: sqlite3.Connection,
    table: str,
    column: str,
    column_ddl: str,
) -> None:
    existing = {
        row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()
    }
    if column in existing:
        return
    conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {column_ddl}")


def _configure_sql_trace(conn: sqlite3.Connection, enabled: bool) -> None:
    """Enable/disable SQLite statement trace logging for this connection."""
    if not enabled:
        conn.set_trace_callback(None)
        return

    def _trace(statement: str) -> None:
        stmt = statement.strip()
        if not stmt:
            return
        _sql_log.debug("sqlite: %s", stmt)

    conn.set_trace_callback(_trace)


def open_writer_connection(
    db_path: Path, *, sql_trace: bool = False
) -> sqlite3.Connection:
    """
    Open (or create) the clearing DB for read/write access.

    The returned connection is created with ``check_same_thread=False`` so the
    receive thread and timer thread can share one handle.  This is safe only
    because all write paths in ``ClearingProcess`` serialize DB access under
    its process lock; callers must preserve that invariant.
    """
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    try:
        apply_schema(conn)
        _configure_sql_trace(conn, enabled=sql_trace)
    except Exception:
        conn.close()
        raise
    return conn


_UPSERT_CLEARING_META = """
INSERT INTO clearing_meta (key, value) VALUES (?,?)
ON CONFLICT(key) DO UPDATE SET value = excluded.value
"""


def reconcile_session_timezone(
    conn: sqlite3.Connection, db_path: Path, session_tz_name: str
) -> None:
    """Record the session timezone, or refuse if it contradicts the file.

    The session timezone determines which trading date every trade is bucketed
    under (finding CL-M3), so it cannot change part-way through a database's
    life without making ``trade_date`` mean two different things.
    """
    row = conn.execute(
        "SELECT value FROM clearing_meta WHERE key = 'session_timezone'"
    ).fetchone()
    if row is not None and row[0] != session_tz_name:
        raise IncompatibleClearingDatabaseError(
            f"{db_path} was recorded with session timezone {row[0]!r}, but "
            f"engine config now says {session_tz_name!r}. Its trade_date column "
            f"would then mean two different things. Fix engine config's "
            f"locale.session_timezone back to {row[0]!r}, or record into a "
            f"different DB."
        )
    conn.execute(_UPSERT_CLEARING_META, ("session_timezone", session_tz_name))
    conn.commit()


def open_readonly_connection(db_path: Path) -> sqlite3.Connection:
    """Open an existing clearing DB read-only (pm-clearing-cli, pm-eod).

    The one implementation is ``query.open_readonly_connection``: it
    percent-encodes the path into the URI and waits out a checkpoint lock
    (clearing review C7).
    """
    from edumatcher.clearing.query import open_readonly_connection as _open

    return _open(db_path)


# ---------------------------------------------------------------------------
# Write operations
# ---------------------------------------------------------------------------

_INSERT_TRADE = """
INSERT OR IGNORE INTO trade_events (
  id, ts_ns, trade_date, symbol, quantity, price,
    tick_decimals,
  buy_order_id, sell_order_id,
  buy_gateway_id, sell_gateway_id,
  aggressor_side, ingest_ts_ns, match_type, msg_id
) VALUES (
  :id, :ts_ns, :trade_date, :symbol, :quantity, :price,
    :tick_decimals,
  :buy_order_id, :sell_order_id,
  :buy_gateway_id, :sell_gateway_id,
  :aggressor_side, :ingest_ts_ns, :match_type, :msg_id
)
"""

_UPSERT_POSITION = """
INSERT INTO gateway_symbol_positions (
  gateway_id, symbol,
  net_qty, avg_cost, realized_pnl, unrealized_pnl, mark_price,
    tick_decimals,
  buy_qty, sell_qty, buy_notional, sell_notional,
  last_trade_ts_ns, updated_ts_ns
) VALUES (
  :gateway_id, :symbol,
  :net_qty, :avg_cost, :realized_pnl, :unrealized_pnl, :mark_price,
    :tick_decimals,
  :buy_qty, :sell_qty, :buy_notional, :sell_notional,
  :last_trade_ts_ns, :updated_ts_ns
)
ON CONFLICT(gateway_id, symbol) DO UPDATE SET
  net_qty          = excluded.net_qty,
  avg_cost         = excluded.avg_cost,
  realized_pnl     = excluded.realized_pnl,
  unrealized_pnl   = excluded.unrealized_pnl,
  mark_price       = excluded.mark_price,
    tick_decimals    = excluded.tick_decimals,
  buy_qty          = excluded.buy_qty,
  sell_qty         = excluded.sell_qty,
  buy_notional     = excluded.buy_notional,
  sell_notional    = excluded.sell_notional,
  last_trade_ts_ns = excluded.last_trade_ts_ns,
  updated_ts_ns    = excluded.updated_ts_ns
"""


_OPTIONAL_FILTER = re.compile(r"\(:(\w+)\s+IS NULL OR ([^()]+?)\)")


def _drop_unset_filters(sql: str, params: Mapping[str, object]) -> str:
    """Resolve each ``(:x IS NULL OR <condition>)`` before SQLite plans it.

    SQLite plans that form as a full scan whatever ``:x`` turns out to be, so
    a one-day read walked the whole table.  An unset filter becomes ``1`` and
    a set one its bare condition, which can use an index; the rows returned
    are the same.  Conditions containing parentheses are left as they are.
    """
    return _OPTIONAL_FILTER.sub(
        lambda m: "1" if params.get(m.group(1)) is None else f"({m.group(2)})", sql
    )


def _pow10(column: str) -> str:
    """``10.0 ** column`` for a ``tick_decimals`` column, in plain SQL.

    SQLite's POWER() exists only in builds compiled with math functions; on
    any other build every daily upsert -- every clearing flush -- would fail.
    ``tick_decimals`` is 0..8 (``models/price.py``), so the scale is spelled
    out instead.
    """
    whens = " ".join(f"WHEN {d} THEN {10**d}.0" for d in range(9))
    return f"(CASE {column} {whens} END)"


def _rescaled(value: str, to_decimals: str, from_decimals: str) -> str:
    """*value*, in ticks of *from_decimals*, as ticks of *to_decimals*."""
    return f"{value} * {_pow10(to_decimals)} / {_pow10(from_decimals)}"


def _to_incoming(column: str) -> str:
    """A stored daily-row money *column* in the incoming row's precision."""
    return _rescaled(column, "excluded.tick_decimals", "tick_decimals")


_UPSERT_DAILY = f"""
INSERT INTO gateway_daily_summary (
  trade_date, gateway_id, symbol,
  traded_qty, traded_notional,
  buy_qty, sell_qty, buy_notional, sell_notional, net_amount,
  realized_pnl,
  end_net_qty, end_avg_cost, end_unrealized_pnl,
    tick_decimals,
  last_trade_ts_ns, updated_ts_ns
) VALUES (
  :trade_date, :gateway_id, :symbol,
  :delta_traded_qty, :delta_traded_notional,
  :delta_buy_qty, :delta_sell_qty,
  :delta_buy_notional, :delta_sell_notional, :delta_net_amount,
  :delta_realized_pnl,
  :end_net_qty, :end_avg_cost, :end_unrealized_pnl,
    :tick_decimals,
  :last_trade_ts_ns, :updated_ts_ns
)
ON CONFLICT(trade_date, gateway_id, symbol) DO UPDATE SET
  traded_qty         = traded_qty         + excluded.traded_qty,
  -- Money columns are ticks of the row's tick_decimals; a symbol whose
  -- precision changed since the row was last written is converted to the
  -- incoming precision before the increment is added (K6).
  traded_notional    = ROUND({_to_incoming("traded_notional")})
                       + excluded.traded_notional,
  buy_qty            = buy_qty            + excluded.buy_qty,
  sell_qty           = sell_qty           + excluded.sell_qty,
  buy_notional       = ROUND({_to_incoming("buy_notional")})
                       + excluded.buy_notional,
  sell_notional      = ROUND({_to_incoming("sell_notional")})
                       + excluded.sell_notional,
  net_amount         = (ROUND({_to_incoming("buy_notional")})
                        + excluded.buy_notional)
                       - (ROUND({_to_incoming("sell_notional")})
                          + excluded.sell_notional),
  realized_pnl       = {_to_incoming("realized_pnl")}
                       + excluded.realized_pnl,
  end_net_qty        = excluded.end_net_qty,
  end_avg_cost       = excluded.end_avg_cost,
  end_unrealized_pnl = excluded.end_unrealized_pnl,
    tick_decimals      = excluded.tick_decimals,
  last_trade_ts_ns   = MAX(last_trade_ts_ns, excluded.last_trade_ts_ns),
  updated_ts_ns      = excluded.updated_ts_ns
"""


def flush_batch(
    conn: sqlite3.Connection,
    trades: list[TradeEventRow],
    positions: list[PositionRow],
    daily_rows: list[DailySummaryRow],
) -> None:
    """
    Atomically persist one buffer-worth of trades in a single transaction.

     Steps:
     1. INSERT OR IGNORE trade_events (idempotent on durable id)
     2. UPSERT gateway_symbol_positions (full replace with current state)
     3. UPSERT gateway_daily_summary (increment deltas, update snapshots)
     4. COMMIT
    """
    with conn:
        conn.executemany(
            _INSERT_TRADE,
            [_trade_row_to_dict(t) for t in trades],
        )
        conn.executemany(
            _UPSERT_POSITION,
            [_position_row_to_dict(p) for p in positions],
        )
        conn.executemany(
            _UPSERT_DAILY,
            [_daily_row_to_dict(d) for d in daily_rows],
        )


def fetch_all_positions(conn: sqlite3.Connection) -> list[dict[str, Any]]:
    """
    Return every persisted row of ``gateway_symbol_positions`` as a dict.

    Used at clearing startup to warm-start the in-memory ledger (finding CL-C4)
    so a restart accumulates onto durable position state instead of overwriting
    it from flat.  Every column the ledger needs to reconstruct a position is
    already stored, so no ``trade_events`` replay is required.
    """
    rows = conn.execute(
        "SELECT gateway_id, symbol, net_qty, avg_cost, realized_pnl,"
        " unrealized_pnl, mark_price, tick_decimals,"
        " buy_qty, sell_qty, buy_notional, sell_notional, last_trade_ts_ns"
        " FROM gateway_symbol_positions"
    ).fetchall()
    return [dict(r) for r in rows]


def latest_trade_seq(conn: sqlite3.Connection) -> tuple[int, int] | None:
    """The ``(run_seq, seq)`` of the newest archived engine trade id, or None.

    Engine ids are ``{run_seq:06d}-{seq:09d}``, so their text order is their
    numeric order and the primary key answers this from its last entry. Ids of
    another shape (tests, hand-made rows) are skipped.
    """
    row = conn.execute(
        "SELECT id FROM trade_events"
        " WHERE id GLOB '[0-9][0-9][0-9][0-9][0-9][0-9]-[0-9]*'"
        " ORDER BY id DESC LIMIT 1"
    ).fetchone()
    if row is None:
        return None
    run_text, seq_text = str(row[0]).split("-", 1)
    return int(run_text), int(seq_text)


def prune_old_events(conn: sqlite3.Connection, retention_days: int = 90) -> int:
    """
    Delete trade_events rows older than ``retention_days`` days (UTC).

    Aggregate tables (gateway_daily_summary, gateway_symbol_positions) are
    NOT pruned — they remain for long-running reporting beyond the raw window.
    Close snapshots follow the same retention: :func:`prune_close_snapshots`.

    Returns the number of rows deleted.
    """
    cur = conn.execute(
        "DELETE FROM trade_events WHERE trade_date < date('now', ?)",
        (f"-{retention_days} days",),
    )
    conn.commit()
    return cur.rowcount


def prune_close_snapshots(conn: sqlite3.Connection, retention_days: int = 90) -> int:
    """
    Delete ``position_close_snapshot`` dates older than ``retention_days`` days
    (L019), never the newest snapshot date: pm-eod settles the next day from
    it, however long ago it was.

    Returns the number of rows deleted.
    """
    cur = conn.execute(
        "DELETE FROM position_close_snapshot WHERE trade_date < date('now', ?)"
        " AND trade_date < (SELECT MAX(trade_date) FROM position_close_snapshot)",
        (f"-{retention_days} days",),
    )
    conn.commit()
    return cur.rowcount


# ---------------------------------------------------------------------------
# Session-event and gateway-lifecycle write helpers
# ---------------------------------------------------------------------------


def record_session_event(
    conn: sqlite3.Connection,
    *,
    event_type: str,
    ts_ns: int,
    trade_date: str,
    payload_json: str | None = None,
) -> None:
    """Insert one row into session_events (EOD marker, phase transition, etc.)."""
    conn.execute(
        "INSERT INTO session_events (event_type, ts_ns, trade_date, payload_json)"
        " VALUES (?, ?, ?, ?)",
        (event_type, ts_ns, trade_date, payload_json),
    )
    conn.commit()


def write_close_snapshot(conn: sqlite3.Connection, trade_date: str) -> int:
    """
    Copy every row of ``gateway_symbol_positions`` into
    ``position_close_snapshot`` under ``trade_date`` and return the row count.

    Replaces any rows already written for that date, so a second CLOSED in the
    same trading day leaves one consistent snapshot.  Flat positions are kept:
    their cumulative realized P&L is part of the equity series.
    """
    with conn:
        conn.execute(
            "DELETE FROM position_close_snapshot WHERE trade_date = ?",
            (trade_date,),
        )
        cur = conn.execute(
            "INSERT INTO position_close_snapshot"
            " (trade_date, gateway_id, symbol, net_qty, realized_pnl,"
            "  unrealized_pnl, mark_price, tick_decimals)"
            " SELECT ?, gateway_id, symbol, net_qty, realized_pnl,"
            "  unrealized_pnl, mark_price, tick_decimals"
            " FROM gateway_symbol_positions",
            (trade_date,),
        )
    return cur.rowcount


def closed_trade_dates(
    conn: sqlite3.Connection, trade_date: str | None = None
) -> set[str]:
    """
    Trading dates that have closed (all, or just ``trade_date`` if it has).

    A date has closed when its latest ``PHASE`` row is CLOSED **and** the
    market was open earlier that day (some other phase was recorded).  An
    engine announces CLOSED when it starts, so a date whose only phase is that
    announcement (the exchange started before the open) has not closed: it has
    not traded yet.  A CLOSED after trading resumed (a mid-day restart) is not
    the close either, because a later phase follows it.
    """
    rows = conn.execute(
        "SELECT trade_date, payload_json FROM session_events"
        " WHERE event_type = 'PHASE' AND (:day IS NULL OR trade_date = :day)"
        " ORDER BY ts_ns DESC",
        {"day": trade_date},
    )
    latest: dict[str, str] = {}
    opened: set[str] = set()
    for day, payload in rows:
        state = json.loads(payload or "{}").get("state", "")
        latest.setdefault(day, state)  # newest first
        if state != "CLOSED":
            opened.add(day)
    return {day for day, state in latest.items() if state == "CLOSED"} & opened


def close_snapshot_is_final(conn: sqlite3.Connection, trade_date: str) -> bool:
    """
    True when ``trade_date`` has a close snapshot taken at its real close.

    That is: the date has closed (:func:`closed_trade_dates`) and a snapshot
    exists.  Nothing may replace such a snapshot — not an engine restart after
    the close (which re-announces CLOSED after the shutdown re-marked
    positions) and not the shutdown itself — because pm-eod may already have
    settled it.  Any other snapshot is provisional: the boot-time CLOSED before
    the open or of a day that went on trading, or a shutdown without sessions,
    where the last one counts.
    """
    if not closed_trade_dates(conn, trade_date):
        return False
    return bool(query_close_snapshots(conn, date_value=trade_date, limit=1))


def record_gateway_connect(
    conn: sqlite3.Connection,
    *,
    gateway_id: str,
    connected_at_ns: int,
) -> None:
    """Insert a connect row into gateway_sessions."""
    conn.execute(
        "INSERT OR IGNORE INTO gateway_sessions"
        " (gateway_id, connected_at_ns)"
        " VALUES (?, ?)",
        (gateway_id, connected_at_ns),
    )
    conn.commit()


def record_gateway_disconnect(
    conn: sqlite3.Connection,
    *,
    gateway_id: str,
    connected_at_ns: int,
    disconnected_at_ns: int,
    reason: str | None,
) -> None:
    """Update the matching connect row (exact ``connected_at_ns``) with the
    disconnect timestamp and reason."""
    conn.execute(
        "UPDATE gateway_sessions"
        " SET disconnected_at_ns = ?, disconnect_reason = ?"
        " WHERE gateway_id = ? AND connected_at_ns = ?",
        (disconnected_at_ns, reason, gateway_id, connected_at_ns),
    )
    conn.commit()


def close_latest_gateway_session(
    conn: sqlite3.Connection,
    *,
    gateway_id: str,
    disconnected_at_ns: int,
    reason: str | None,
) -> int:
    """
    Close the most recent still-open session for ``gateway_id`` (finding CL-M5).

    Matches on ``MAX(connected_at_ns)`` among the gateway's rows whose
    ``disconnected_at_ns IS NULL``, so a disconnect is recorded from durable SQL
    state alone — even after a clearing restart that lost the in-memory connect
    timestamp.  No-op (returns 0) when the gateway has no open session.
    Returns the number of rows updated.
    """
    cur = conn.execute(
        "UPDATE gateway_sessions"
        " SET disconnected_at_ns = ?, disconnect_reason = ?"
        " WHERE gateway_id = ? AND connected_at_ns = ("
        "   SELECT MAX(connected_at_ns) FROM gateway_sessions"
        "   WHERE gateway_id = ? AND disconnected_at_ns IS NULL"
        " )",
        (disconnected_at_ns, reason, gateway_id, gateway_id),
    )
    conn.commit()
    return cur.rowcount


# ---------------------------------------------------------------------------
# Private dict conversion helpers
# ---------------------------------------------------------------------------


def _trade_row_to_dict(t: TradeEventRow) -> dict[str, Any]:
    return {
        "id": t.id,
        "ts_ns": t.ts_ns,
        "trade_date": t.trade_date,
        "symbol": t.symbol,
        "quantity": t.quantity,
        "price": t.price,
        "tick_decimals": t.tick_decimals,
        "buy_order_id": t.buy_order_id,
        "sell_order_id": t.sell_order_id,
        "buy_gateway_id": t.buy_gateway_id,
        "sell_gateway_id": t.sell_gateway_id,
        "aggressor_side": t.aggressor_side,
        "ingest_ts_ns": t.ingest_ts_ns,
        "match_type": t.match_type,
        "msg_id": t.msg_id,
    }


def _position_row_to_dict(p: PositionRow) -> dict[str, Any]:
    return {
        "gateway_id": p.gateway_id,
        "symbol": p.symbol,
        "net_qty": p.net_qty,
        "avg_cost": p.avg_cost,
        "realized_pnl": p.realized_pnl,
        "unrealized_pnl": p.unrealized_pnl,
        "mark_price": p.mark_price,
        "tick_decimals": p.tick_decimals,
        "buy_qty": p.buy_qty,
        "sell_qty": p.sell_qty,
        "buy_notional": p.buy_notional,
        "sell_notional": p.sell_notional,
        "last_trade_ts_ns": p.last_trade_ts_ns,
        "updated_ts_ns": p.updated_ts_ns,
    }


def _daily_row_to_dict(d: DailySummaryRow) -> dict[str, Any]:
    return {
        "trade_date": d.trade_date,
        "gateway_id": d.gateway_id,
        "symbol": d.symbol,
        "delta_traded_qty": d.delta_traded_qty,
        "delta_traded_notional": d.delta_traded_notional,
        "delta_buy_qty": d.delta_buy_qty,
        "delta_sell_qty": d.delta_sell_qty,
        "delta_buy_notional": d.delta_buy_notional,
        "delta_sell_notional": d.delta_sell_notional,
        "delta_net_amount": d.delta_net_amount,
        "delta_realized_pnl": d.delta_realized_pnl,
        "end_net_qty": d.end_net_qty,
        "end_avg_cost": d.end_avg_cost,
        "end_unrealized_pnl": d.end_unrealized_pnl,
        "tick_decimals": d.tick_decimals,
        "last_trade_ts_ns": d.last_trade_ts_ns,
        "updated_ts_ns": d.updated_ts_ns,
    }


# ---------------------------------------------------------------------------
# Read-only query helpers (used by pm-clearing-cli)
# ---------------------------------------------------------------------------


def query_gateways(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    limit: int = 1000,
) -> list[dict[str, Any]]:
    sql = (
        "SELECT gateway_id, realized_pnl_total, unrealized_pnl_total,"
        " total_pnl, net_qty_total"
        " FROM gateway_pnl_totals"
        " WHERE (:gateway IS NULL OR gateway_id = :gateway)"
        " ORDER BY gateway_id ASC"
        " LIMIT :limit"
    )
    rows = conn.execute(sql, {"gateway": gateway, "limit": limit}).fetchall()
    return [dict(r) for r in rows]


def query_participants(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    limit: int = 1000,
) -> list[dict[str, Any]]:
    """Per gateway: P&L in display currency, position counts, latest update.

    Each position's ticks are divided by its own ``10**tick_decimals`` before
    the sum, as in ``gateway_pnl_totals``: raw ticks of symbols with
    different precision do not add up.
    """
    scale = _pow10("tick_decimals")
    sql = (
        "SELECT gateway_id,"
        f" SUM(realized_pnl / {scale}) AS realized_pnl,"
        f" SUM(unrealized_pnl / {scale}) AS unrealized_pnl,"
        f" SUM((realized_pnl + unrealized_pnl) / {scale}) AS total_pnl,"
        " COUNT(*) AS position_count,"
        " SUM(CASE WHEN net_qty != 0 THEN 1 ELSE 0 END) AS open_position_count,"
        " MAX(updated_ts_ns) AS last_update_ts_ns"
        " FROM gateway_symbol_positions"
        " WHERE (:gateway IS NULL OR gateway_id = :gateway)"
        " GROUP BY gateway_id"
        " ORDER BY gateway_id ASC"
        " LIMIT :limit"
    )
    rows = conn.execute(sql, {"gateway": gateway, "limit": limit}).fetchall()
    return [dict(r) for r in rows]


def query_positions(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    symbol: str | None = None,
    limit: int = 10000,
) -> list[dict[str, Any]]:
    sql = (
        "SELECT gateway_id, symbol, net_qty, avg_cost, mark_price,"
        " tick_decimals,"
        " realized_pnl, unrealized_pnl,"
        " buy_qty, sell_qty, buy_notional, sell_notional,"
        " last_trade_ts_ns, updated_ts_ns"
        " FROM gateway_symbol_positions"
        " WHERE (:gateway IS NULL OR gateway_id = :gateway)"
        "   AND (:symbol IS NULL OR symbol = :symbol)"
        " ORDER BY gateway_id ASC, symbol ASC"
        " LIMIT :limit"
    )
    rows = conn.execute(
        sql, {"gateway": gateway, "symbol": symbol, "limit": limit}
    ).fetchall()
    return [dict(r) for r in rows]


def query_pnl(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    symbol: str | None = None,
    limit: int = 10000,
) -> list[dict[str, Any]]:
    sql = (
        "SELECT gateway_id, symbol, realized_pnl, unrealized_pnl,"
        " (realized_pnl + unrealized_pnl) AS total_pnl,"
        " net_qty, mark_price, tick_decimals"
        " FROM gateway_symbol_positions"
        " WHERE (:gateway IS NULL OR gateway_id = :gateway)"
        "   AND (:symbol IS NULL OR symbol = :symbol)"
        " ORDER BY gateway_id ASC, symbol ASC"
        " LIMIT :limit"
    )
    rows = conn.execute(
        sql, {"gateway": gateway, "symbol": symbol, "limit": limit}
    ).fetchall()
    return [dict(r) for r in rows]


def query_daily(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    symbol: str | None = None,
    date_value: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = 1000,
) -> list[dict[str, Any]]:
    sql = (
        "SELECT trade_date, gateway_id, symbol,"
        " traded_qty, traded_notional,"
        " buy_qty, sell_qty, buy_notional, sell_notional, net_amount,"
        " realized_pnl, end_net_qty, end_avg_cost, end_unrealized_pnl,"
        " tick_decimals,"
        " last_trade_ts_ns, updated_ts_ns"
        " FROM gateway_daily_summary"
        " WHERE (:gateway IS NULL OR gateway_id = :gateway)"
        "   AND (:symbol IS NULL OR symbol = :symbol)"
        "   AND (:date_value IS NULL OR trade_date = :date_value)"
        "   AND (:from_date IS NULL OR trade_date >= :from_date)"
        "   AND (:to_date IS NULL OR trade_date <= :to_date)"
        " ORDER BY trade_date DESC, gateway_id ASC, symbol ASC"
        " LIMIT :limit"
    )
    rows = conn.execute(
        sql,
        {
            "gateway": gateway,
            "symbol": symbol,
            "date_value": date_value,
            "from_date": from_date,
            "to_date": to_date,
            "limit": limit,
        },
    ).fetchall()
    return [dict(r) for r in rows]


def query_trades(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    symbol: str | None = None,
    date_value: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = 200,
    after: tuple[int, int, str] | None = None,
) -> list[dict[str, Any]]:
    """Retained trades, newest first.

    Ordered by ``(ts_ns, ingest_ts_ns, id)`` descending: for one exchange
    timestamp the latest ingest first (CL-L3), and ``id`` (the primary key)
    makes the order total, so ``after`` -- that key of the last row already
    seen -- continues exactly where a previous page stopped even when prints
    share a timestamp.
    """
    after_ts, after_ingest, after_id = (
        after if after is not None else (None, None, None)
    )
    sql = (
        "SELECT id, ts_ns, trade_date, symbol, quantity, price, tick_decimals,"
        " buy_order_id, sell_order_id,"
        " buy_gateway_id, sell_gateway_id,"
        " aggressor_side, ingest_ts_ns, match_type, msg_id"
        " FROM trade_events"
        " WHERE (:symbol IS NULL OR symbol = :symbol)"
        "   AND (:gateway IS NULL OR buy_gateway_id = :gateway"
        "       OR sell_gateway_id = :gateway)"
        "   AND (:date_value IS NULL OR trade_date = :date_value)"
        "   AND (:from_date IS NULL OR trade_date >= :from_date)"
        "   AND (:to_date IS NULL OR trade_date <= :to_date)"
        "   AND (:after_ts IS NULL OR ts_ns < :after_ts"
        "       OR (ts_ns = :after_ts AND (ingest_ts_ns < :after_ingest"
        "           OR (ingest_ts_ns = :after_ingest AND id < :after_id))))"
        " ORDER BY ts_ns DESC, ingest_ts_ns DESC, id DESC"
        " LIMIT :limit"
    )
    params = {
        "gateway": gateway,
        "symbol": symbol,
        "date_value": date_value,
        "from_date": from_date,
        "to_date": to_date,
        "after_ts": after_ts,
        "after_ingest": after_ingest,
        "after_id": after_id,
        "limit": limit,
    }
    # One day: unset filters are resolved before planning so the date reaches
    # ix_trade_events_date_ts, which holds the day in page order (clearing
    # review P2). Otherwise the optional form stays: a newest-first page walks
    # ix_trade_events_ts and stops at LIMIT, where a resolved gateway filter
    # or a date range would sort every matching trade (clearing GUI F2).
    if date_value is not None:
        sql = _drop_unset_filters(sql, params)
    rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def count_summary_days(
    conn: sqlite3.Connection,
    *,
    before: str | None,
    from_date: str | None = None,
    to_date: str | None = None,
) -> int:
    """Trading days with daily summaries before ``before`` (all of them when
    ``before`` is None) within ``from_date..to_date``: the days whose raw
    trades were pruned, so a reconciliation cannot compare them."""
    sql = (
        "SELECT COUNT(DISTINCT trade_date) FROM gateway_daily_summary"
        " WHERE (:before IS NULL OR trade_date < :before)"
        "   AND (:from_date IS NULL OR trade_date >= :from_date)"
        "   AND (:to_date IS NULL OR trade_date <= :to_date)"
    )
    params = {"before": before, "from_date": from_date, "to_date": to_date}
    return int(conn.execute(_drop_unset_filters(sql, params), params).fetchone()[0])


#: A gateway's net below this (display currency) is zero: a day's buys and
#: sells that balance can sum to a float residue rather than exactly 0.
_NET_ZERO = 1e-9


def query_latest_trade_date(conn: sqlite3.Connection) -> str | None:
    """The newest ``trade_date`` with a daily row; ``None`` when there is none."""
    row = conn.execute("SELECT MAX(trade_date) FROM gateway_daily_summary").fetchone()
    return row[0] if row else None


def _day_trade_count(conn: sqlite3.Connection, trade_date: str, gateway: str) -> int:
    """Trades *gateway* was a side of on *trade_date*, a trade with itself once,
    read from the buyer and seller indexes."""
    p = {"day": trade_date, "gateway": gateway}
    bought, sold, itself = (
        conn.execute(
            f"SELECT COUNT(*) FROM trade_events WHERE {where} AND trade_date = :day",
            p,
        ).fetchone()[0]
        for where in (
            "buy_gateway_id = :gateway",
            "sell_gateway_id = :gateway",
            "buy_gateway_id = :gateway AND sell_gateway_id = :gateway",
        )
    )
    return int(bought) + int(sold) - int(itself)


def query_netting(
    conn: sqlite3.Connection, *, trade_date: str, gateway: str | None = None
) -> dict[str, Any]:
    """One trading day's trades against what each gateway is left with.

    Per gateway (one, or every gateway when *gateway* is ``None``), from the
    daily rows, every symbol converted to display currency before the sum:
    ``bought_value``, ``sold_value`` and ``net_amount`` (bought − sold:
    positive is what the gateway pays for the day's trades, negative what it
    receives). The totals count each trade once: in the venue every trade has
    one buyer, so they are the buy side; for one gateway, its buys and sells.

    Trade counts come from the raw trades, which retention prunes while the
    daily rows stay: for a pruned day ``trades_retained`` is false and every
    count is ``None``. This is the cash the trades net to, not pm-eod's
    settlement, which moves the day's change in P&L.
    """
    scale = _pow10("tick_decimals")
    rows = conn.execute(
        "SELECT gateway_id,"
        " SUM(buy_qty) AS bought_qty, SUM(sell_qty) AS sold_qty,"
        f" SUM(buy_notional / {scale}) AS bought_value,"
        f" SUM(sell_notional / {scale}) AS sold_value,"
        f" SUM(net_amount / {scale}) AS net_amount"
        " FROM gateway_daily_summary"
        " WHERE trade_date = :day AND (:gateway IS NULL OR gateway_id = :gateway)"
        " GROUP BY gateway_id ORDER BY gateway_id ASC",
        {"day": trade_date, "gateway": gateway},
    ).fetchall()
    retained_from = query_retained_from(conn)
    retained = not rows or (retained_from is not None and trade_date >= retained_from)
    counts: dict[str, int] = {}
    total_count: int | None = None
    if retained:
        # Each gateway's count from its own index entries: this is polled,
        # and walking the whole day's trades instead cost 150 ms on a
        # 100 000-trade day (review of CG25-CG32, P1).
        counts = {
            str(r["gateway_id"]): _day_trade_count(
                conn, trade_date, str(r["gateway_id"])
            )
            for r in rows
        }
        if gateway is None:
            total_count = conn.execute(
                "SELECT COUNT(*) FROM trade_events WHERE trade_date = ?", (trade_date,)
            ).fetchone()[0]
        else:
            total_count = counts.get(gateway, 0)
    gateways = [
        {
            "gateway_id": r["gateway_id"],
            "bought_value": r["bought_value"],
            "sold_value": r["sold_value"],
            "net_amount": r["net_amount"],
            "trade_count": counts.get(r["gateway_id"], 0) if retained else None,
        }
        for r in rows
    ]
    nets = [float(r["net_amount"]) for r in rows]
    own = gateway is not None
    return {
        "trade_date": trade_date,
        "trades_retained": retained,
        "trade_count": total_count,
        "traded_qty": sum(
            r["bought_qty"] + (r["sold_qty"] if own else 0) for r in rows
        ),
        "gross_value": sum(
            r["bought_value"] + (r["sold_value"] if own else 0.0) for r in rows
        ),
        "payment_count": sum(1 for n in nets if abs(n) > _NET_ZERO),
        "net_paid": sum(n for n in nets if n > _NET_ZERO),
        "net_received": -sum(n for n in nets if n < -_NET_ZERO),
        "gateways": gateways,
    }


def query_flows(
    conn: sqlite3.Connection, *, trade_date: str, symbol: str | None = None
) -> dict[str, Any]:
    """Who bought from whom on one trading day: per (buyer, seller) gateway
    pair, its trades, shares and value (display currency, each trade converted
    with its own precision), largest value first.

    Read from the raw trades, so a day retention has pruned (it has daily rows
    but is older than the retained trades) has ``trades_retained: false`` and
    no pairs.
    """
    params = {"day": trade_date, "symbol": symbol}
    has_rows = (
        conn.execute(
            "SELECT 1 FROM gateway_daily_summary WHERE trade_date = :day"
            " AND (:symbol IS NULL OR symbol = :symbol) LIMIT 1",
            params,
        ).fetchone()
        is not None
    )
    retained_from = query_retained_from(conn)
    retained = not has_rows or (
        retained_from is not None and trade_date >= retained_from
    )
    pairs: list[dict[str, Any]] = []
    if retained:
        scale = _pow10("tick_decimals")
        pairs = [
            dict(r)
            for r in conn.execute(
                "SELECT buy_gateway_id AS buyer, sell_gateway_id AS seller,"
                " COUNT(*) AS trades, SUM(quantity) AS quantity,"
                f" SUM(quantity * price / {scale}) AS value"
                " FROM trade_events WHERE trade_date = :day"
                " AND (:symbol IS NULL OR symbol = :symbol)"
                " GROUP BY buy_gateway_id, sell_gateway_id"
                " ORDER BY value DESC, buyer ASC, seller ASC",
                params,
            )
        ]
    return {
        "trade_date": trade_date,
        "symbol": symbol,
        "trades_retained": retained,
        "pairs": pairs,
    }


def query_retained_from(conn: sqlite3.Connection) -> str | None:
    """The oldest ``trade_date`` still in ``trade_events``; ``None`` when empty.

    Raw trades older than the retention window are pruned while the daily
    summaries stay, so this is where a raw-trade audit (or a reconciliation)
    can start.
    """
    row = conn.execute("SELECT MIN(trade_date) FROM trade_events").fetchone()
    return row[0] if row else None


# A plain ``trade_date = ?`` so the planner uses ix_trade_events_date_ts; the
# optional-filter form of query_trades scans the whole retained table.
DAY_TRADES_SQL = (
    "SELECT id, ts_ns, symbol, quantity, price, tick_decimals,"
    " buy_gateway_id, sell_gateway_id"
    " FROM trade_events WHERE trade_date = ?"
    " ORDER BY ts_ns ASC, ingest_ts_ns ASC"
)


def query_day_trades(conn: sqlite3.Connection, trade_date: str) -> list[dict[str, Any]]:
    """Every trade of one trading date, oldest first."""
    return [dict(r) for r in conn.execute(DAY_TRADES_SQL, (trade_date,))]


# Sort-field whitelists — map CLI string to ORDER BY clause.
# Ranked in currency: a position's money columns are ticks of its own
# tick_decimals, so raw values of symbols with different precision do not compare.
_CCY = _pow10("tick_decimals")
_EXPOSURE_SORT: dict[str, str] = {
    "gross_notional": f"ABS(net_qty * mark_price) / {_CCY} DESC, gateway_id ASC, symbol ASC",
    "net_notional": f"(net_qty * mark_price) / {_CCY} DESC, gateway_id ASC, symbol ASC",
    "realized_pnl": f"realized_pnl / {_CCY} DESC, gateway_id ASC, symbol ASC",
    "unrealized_pnl": f"unrealized_pnl / {_CCY} DESC, gateway_id ASC, symbol ASC",
    "total_pnl": f"(realized_pnl + unrealized_pnl) / {_CCY} DESC, gateway_id ASC, symbol ASC",
}

_SYMBOLS_SORT: dict[str, str] = {
    "symbol": "d.symbol ASC",
    "traded_qty": "d.traded_qty DESC, d.symbol ASC",
    "traded_notional": f"d.traded_notional / {_pow10('d.tick_decimals')} DESC, d.symbol ASC",
    "realized_pnl": f"d.realized_pnl / {_pow10('d.tick_decimals')} DESC, d.symbol ASC",
    "open_net_qty": "o.open_net_qty DESC, d.symbol ASC",
}


def query_exposure(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    symbol: str | None = None,
    sort: str = "gross_notional",
    limit: int = 1000,
) -> list[dict[str, Any]]:
    if sort not in _EXPOSURE_SORT:
        raise ValueError(
            f"Invalid --sort value {sort!r}. Allowed: {sorted(_EXPOSURE_SORT)}"
        )
    order_by = _EXPOSURE_SORT[sort]
    sql = (
        "SELECT gateway_id, symbol, net_qty, mark_price, tick_decimals,"
        " (net_qty * mark_price) AS net_notional,"
        " ABS(net_qty * mark_price) AS gross_notional,"
        " realized_pnl, unrealized_pnl,"
        " (realized_pnl + unrealized_pnl) AS total_pnl"
        " FROM gateway_symbol_positions"
        " WHERE (:gateway IS NULL OR gateway_id = :gateway)"
        "   AND (:symbol IS NULL OR symbol = :symbol)"
        f" ORDER BY {order_by}"
        " LIMIT :limit"
    )
    rows = conn.execute(
        sql, {"gateway": gateway, "symbol": symbol, "limit": limit}
    ).fetchall()
    return [dict(r) for r in rows]


def query_symbols(
    conn: sqlite3.Connection,
    *,
    date_value: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    sort: str = "symbol",
    limit: int = 1000,
) -> list[dict[str, Any]]:
    if sort not in _SYMBOLS_SORT:
        raise ValueError(
            f"Invalid --sort value {sort!r}. Allowed: {sorted(_SYMBOLS_SORT)}"
        )
    order_by = _SYMBOLS_SORT[sort]
    sql = (
        "WITH symbol_scale AS ("
        "  SELECT symbol, MAX(tick_decimals) AS tick_decimals"
        "  FROM gateway_daily_summary"
        "  WHERE (:date_value IS NULL OR trade_date = :date_value)"
        "    AND (:from_date IS NULL OR trade_date >= :from_date)"
        "    AND (:to_date IS NULL OR trade_date <= :to_date)"
        "  GROUP BY symbol"
        "),"
        # Money is summed in the symbol's finest precision: days (and
        # positions) recorded at another precision are converted first.
        "daily_totals AS ("
        "  SELECT g.symbol,"
        "    SUM(g.traded_qty) AS traded_qty,"
        f"    SUM({_rescaled('g.traded_notional', 's.tick_decimals', 'g.tick_decimals')})"
        "      AS traded_notional,"
        f"    SUM({_rescaled('g.realized_pnl', 's.tick_decimals', 'g.tick_decimals')})"
        "      AS realized_pnl,"
        "    s.tick_decimals AS tick_decimals"
        "  FROM gateway_daily_summary g"
        "  JOIN symbol_scale s ON s.symbol = g.symbol"
        "  WHERE (:date_value IS NULL OR g.trade_date = :date_value)"
        "    AND (:from_date IS NULL OR g.trade_date >= :from_date)"
        "    AND (:to_date IS NULL OR g.trade_date <= :to_date)"
        "  GROUP BY g.symbol"
        "),"
        "open_totals AS ("
        "  SELECT p.symbol,"
        "    SUM(p.net_qty) AS open_net_qty,"
        "    SUM(MAX(p.net_qty, 0)) AS open_long_qty,"
        "    SUM(MAX(-p.net_qty, 0)) AS open_short_qty,"
        "    SUM(p.net_qty > 0) AS long_holders,"
        "    SUM(p.net_qty < 0) AS short_holders,"
        f"    SUM({_rescaled('p.unrealized_pnl', 's.tick_decimals', 'p.tick_decimals')})"
        "      AS open_unrealized_pnl"
        "  FROM gateway_symbol_positions p"
        "  JOIN symbol_scale s ON s.symbol = p.symbol"
        "  GROUP BY p.symbol"
        ")"
        " SELECT d.symbol, d.traded_qty, d.traded_notional, d.realized_pnl,"
        "  d.tick_decimals,"
        "  COALESCE(o.open_net_qty, 0) AS open_net_qty,"
        "  COALESCE(o.open_long_qty, 0) AS open_long_qty,"
        "  COALESCE(o.open_short_qty, 0) AS open_short_qty,"
        "  COALESCE(o.long_holders, 0) AS long_holders,"
        "  COALESCE(o.short_holders, 0) AS short_holders,"
        "  COALESCE(o.open_unrealized_pnl, 0.0) AS open_unrealized_pnl"
        " FROM daily_totals d"
        " LEFT JOIN open_totals o ON o.symbol = d.symbol"
        f" ORDER BY {order_by}"
        " LIMIT :limit"
    )
    rows = conn.execute(
        sql,
        {
            "date_value": date_value,
            "from_date": from_date,
            "to_date": to_date,
            "limit": limit,
        },
    ).fetchall()
    return [dict(r) for r in rows]


def query_dates(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    symbol: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    with_totals: bool = False,
    limit: int = 1000,
) -> list[dict[str, Any]]:
    if with_totals:
        sql = (
            "SELECT trade_date, traded_qty_total,"
            " traded_notional_total, net_amount_total"
            " FROM daily_exchange_totals"
            " WHERE (:from_date IS NULL OR trade_date >= :from_date)"
            "   AND (:to_date IS NULL OR trade_date <= :to_date)"
            " ORDER BY trade_date DESC"
            " LIMIT :limit"
        )
        rows = conn.execute(
            sql, {"from_date": from_date, "to_date": to_date, "limit": limit}
        ).fetchall()
    else:
        sql = (
            "SELECT DISTINCT trade_date"
            " FROM trade_events"
            " WHERE (:symbol IS NULL OR symbol = :symbol)"
            "   AND (:gateway IS NULL OR buy_gateway_id = :gateway"
            "       OR sell_gateway_id = :gateway)"
            "   AND (:from_date IS NULL OR trade_date >= :from_date)"
            "   AND (:to_date IS NULL OR trade_date <= :to_date)"
            " ORDER BY trade_date DESC"
            " LIMIT :limit"
        )
        rows = conn.execute(
            sql,
            {
                "symbol": symbol,
                "gateway": gateway,
                "from_date": from_date,
                "to_date": to_date,
                "limit": limit,
            },
        ).fetchall()
    return [dict(r) for r in rows]


def query_health(
    conn: sqlite3.Connection,
    db_path: Path,
) -> list[dict[str, Any]]:
    wal_mode_row = conn.execute("PRAGMA journal_mode").fetchone()
    wal_mode = wal_mode_row[0] if wal_mode_row else "unknown"

    row = conn.execute("""
        WITH
        trade_rows AS (
          SELECT COUNT(*) AS c, MAX(ts_ns) AS max_ts FROM trade_events
        ),
        gsp_rows AS (
          SELECT COUNT(*) AS c FROM gateway_symbol_positions
        ),
        gds_rows AS (
          SELECT COUNT(*) AS c, MAX(updated_ts_ns) AS max_flush
          FROM gateway_daily_summary
        )
        SELECT
          trade_rows.c    AS trade_events_rows,
          gsp_rows.c      AS gateway_symbol_positions_rows,
          gds_rows.c      AS gateway_daily_summary_rows,
          trade_rows.max_ts   AS last_trade_ts_ns,
          gds_rows.max_flush  AS last_flush_ts_ns
        FROM trade_rows, gsp_rows, gds_rows
        """).fetchone()

    result = dict(row) if row else {}
    result["db_path"] = str(db_path)
    result["wal_mode"] = wal_mode
    return [result]


def query_freshness(conn: sqlite3.Connection) -> dict[str, int | None]:
    """The newest trade and the latest write the position rows record.

    Cheap enough to poll: ``gateway_symbol_positions`` has one row per
    gateway and symbol, while ``query_health`` scans ``trade_events``.
    """
    row = conn.execute(
        "SELECT MAX(last_trade_ts_ns), MAX(updated_ts_ns)"
        " FROM gateway_symbol_positions"
    ).fetchone()
    return {"last_trade_ts_ns": row[0], "last_flush_ts_ns": row[1]}


def query_session_events(
    conn: sqlite3.Connection,
    *,
    event_type: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = 500,
) -> list[dict[str, Any]]:
    """
    Return rows from session_events (EOD markers, phase transitions).

    Filtering by event_type allows targeted queries such as:
      event_type='EOD'   — end-of-day markers only
      event_type='PHASE' — session-phase transitions only
    """
    sql = (
        "SELECT id, event_type, ts_ns, trade_date, payload_json"
        " FROM session_events"
        " WHERE (:event_type IS NULL OR event_type = :event_type)"
        "   AND (:from_date IS NULL OR trade_date >= :from_date)"
        "   AND (:to_date IS NULL OR trade_date <= :to_date)"
        " ORDER BY ts_ns DESC, id DESC"
        " LIMIT :limit"
    )
    rows = conn.execute(
        sql,
        {
            "event_type": event_type,
            "from_date": from_date,
            "to_date": to_date,
            "limit": limit,
        },
    ).fetchall()
    return [dict(r) for r in rows]


def query_feed_gaps(
    conn: sqlite3.Connection,
    *,
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = 500,
) -> list[dict[str, Any]]:
    """Return the trade-feed gaps pm-clearing recorded, newest first.

    Each gap is a ``GAP`` row in session_events; its payload is spread into
    columns so the missing trade ids can be read off directly.
    """
    rows = query_session_events(
        conn, event_type="GAP", from_date=from_date, to_date=to_date, limit=limit
    )
    gaps = []
    for r in rows:
        payload = json.loads(r["payload_json"])
        gaps.append(
            {
                "trade_date": r["trade_date"],
                "ts_ns": r["ts_ns"],
                "run_seq": payload.get("run_seq"),
                "last_seq": payload.get("last_seq"),
                "next_seq": payload.get("next_seq"),
                "missing_trades": payload.get("missing_trades"),
                "reason": payload.get("reason"),
            }
        )
    return gaps


def query_close_snapshots(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    symbol: str | None = None,
    date_value: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    limit: int = 10000,
) -> list[dict[str, Any]]:
    sql = (
        "SELECT trade_date, gateway_id, symbol, net_qty, realized_pnl,"
        " unrealized_pnl, mark_price, tick_decimals"
        " FROM position_close_snapshot"
        " WHERE (:gateway IS NULL OR gateway_id = :gateway)"
        "   AND (:symbol IS NULL OR symbol = :symbol)"
        "   AND (:date_value IS NULL OR trade_date = :date_value)"
        "   AND (:from_date IS NULL OR trade_date >= :from_date)"
        "   AND (:to_date IS NULL OR trade_date <= :to_date)"
        " ORDER BY trade_date DESC, gateway_id ASC, symbol ASC"
        " LIMIT :limit"
    )
    params = {
        "gateway": gateway,
        "symbol": symbol,
        "date_value": date_value,
        "from_date": from_date,
        "to_date": to_date,
        "limit": limit,
    }
    rows = conn.execute(_drop_unset_filters(sql, params), params).fetchall()
    return [dict(r) for r in rows]


def query_close_snapshot_dates(conn: sqlite3.Connection) -> list[str]:
    """Dates that have a close snapshot, oldest first (reads the primary key)."""
    rows = conn.execute(
        "SELECT DISTINCT trade_date FROM position_close_snapshot ORDER BY trade_date"
    )
    return [r[0] for r in rows]


def query_sessions(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    connected_only: bool = False,
    limit: int = 500,
    from_ns: int | None = None,
    to_ns: int | None = None,
) -> list[dict[str, Any]]:
    """
    Return gateway connection/disconnection history from gateway_sessions.

    connected_only=True filters to sessions where disconnected_at_ns IS NULL
    (gateways still connected or whose disconnect was not recorded).

    ``from_ns`` (inclusive) and ``to_ns`` (exclusive) bound the connect time;
    the caller resolves trading days in the session timezone
    (``clearing.query.day_bounds_ns``), never the UTC date.
    """
    sql = (
        "SELECT gateway_id, connected_at_ns, disconnected_at_ns, disconnect_reason"
        " FROM gateway_sessions"
        " WHERE (:gateway IS NULL OR gateway_id = :gateway)"
        "   AND (:connected_only = 0 OR disconnected_at_ns IS NULL)"
        "   AND (:from_ns IS NULL OR connected_at_ns >= :from_ns)"
        "   AND (:to_ns IS NULL OR connected_at_ns < :to_ns)"
        " ORDER BY connected_at_ns DESC, gateway_id ASC"
        " LIMIT :limit"
    )
    rows = conn.execute(
        sql,
        {
            "gateway": gateway,
            "connected_only": 1 if connected_only else 0,
            "from_ns": from_ns,
            "to_ns": to_ns,
            "limit": limit,
        },
    ).fetchall()
    return [dict(r) for r in rows]


def query_reconcile(
    conn: sqlite3.Connection,
    *,
    gateway: str | None = None,
    symbol: str | None = None,
    from_date: str | None = None,
    to_date: str | None = None,
    retention_days: int | None = None,
) -> list[dict[str, Any]]:
    """
    Compare raw trade_events totals against gateway_daily_summary aggregates
    for both the buy side and the sell side.

    Returns rows only where a discrepancy is found.  Zero rows means the
    dataset is internally consistent for all (trade_date, gateway_id, symbol)
    keys on both sides.

    Output columns:
      side              — 'BUY' or 'SELL'
      trade_date        — date bucket
      gateway_id        — gateway identifier
      symbol            — instrument
      raw_qty           — quantity counted directly from trade_events
      summary_qty       — quantity stored in gateway_daily_summary
      qty_diff          — raw_qty - summary_qty (non-zero = discrepancy)
      raw_notional      — notional counted directly from trade_events, each
                          trade converted to the summary row's precision
      summary_notional  — notional stored in gateway_daily_summary
      notional_diff     — raw_notional - summary_notional
      tick_decimals     — precision of the notionals (the summary row's)
    """
    sql = f"""
    WITH
    -- Summary aggregates for buy and sell sides from gateway_daily_summary
    summary_buy AS (
      SELECT
        'BUY'        AS side,
        trade_date,
        gateway_id,
        symbol,
        buy_qty      AS summary_qty,
        buy_notional AS summary_notional,
        tick_decimals
      FROM gateway_daily_summary
      WHERE (:from_date IS NULL OR trade_date >= :from_date)
        AND (:to_date   IS NULL OR trade_date <= :to_date)
        AND (:gateway   IS NULL OR gateway_id = :gateway)
        AND (:symbol    IS NULL OR symbol = :symbol)
    ),
    summary_sell AS (
      SELECT
        'SELL'        AS side,
        trade_date,
        gateway_id,
        symbol,
        sell_qty      AS summary_qty,
        sell_notional AS summary_notional,
        tick_decimals
      FROM gateway_daily_summary
      WHERE (:from_date IS NULL OR trade_date >= :from_date)
        AND (:to_date   IS NULL OR trade_date <= :to_date)
        AND (:gateway   IS NULL OR gateway_id = :gateway)
        AND (:symbol    IS NULL OR symbol = :symbol)
    ),
    summary_all AS (
      SELECT * FROM summary_buy
      UNION ALL
      SELECT * FROM summary_sell
    ),
    -- Raw counts from trade_events per side and per trade precision
    raw_by_precision AS (
      SELECT
        'BUY'            AS side,
        trade_date,
        buy_gateway_id   AS gateway_id,
        symbol,
        tick_decimals,
        SUM(quantity)            AS qty,
        SUM(quantity * price)    AS notional
      FROM trade_events
      WHERE (:from_date IS NULL OR trade_date >= :from_date)
        AND (:to_date   IS NULL OR trade_date <= :to_date)
        AND (:gateway   IS NULL OR buy_gateway_id = :gateway)
        AND (:symbol    IS NULL OR symbol = :symbol)
      GROUP BY trade_date, buy_gateway_id, symbol, tick_decimals
      UNION ALL
      SELECT
        'SELL'           AS side,
        trade_date,
        sell_gateway_id  AS gateway_id,
        symbol,
        tick_decimals,
        SUM(quantity)            AS qty,
        SUM(quantity * price)    AS notional
      FROM trade_events
      WHERE (:from_date IS NULL OR trade_date >= :from_date)
        AND (:to_date   IS NULL OR trade_date <= :to_date)
        AND (:gateway   IS NULL OR sell_gateway_id = :gateway)
        AND (:symbol    IS NULL OR symbol = :symbol)
      GROUP BY trade_date, sell_gateway_id, symbol, tick_decimals
    ),
    -- Each raw notional in ticks of the key's daily row: K6 converts that
    -- row to the latest trade's precision, while every raw trade keeps its
    -- own (CG13 / F9).  Converted like the upsert converts the row, rounded
    -- once per precision; a key with no daily row uses its finest precision.
    raw_targeted AS (
      SELECT
        b.*,
        COALESCE(
          s.tick_decimals,
          MAX(b.tick_decimals) OVER (
            PARTITION BY b.side, b.trade_date, b.gateway_id, b.symbol
          )
        ) AS target
      FROM raw_by_precision b
      LEFT JOIN summary_all s
        ON  s.side       = b.side
        AND s.trade_date = b.trade_date
        AND s.gateway_id = b.gateway_id
        AND s.symbol     = b.symbol
    ),
    raw_all AS (
      SELECT
        side,
        trade_date,
        gateway_id,
        symbol,
        SUM(qty)                 AS raw_qty,
        SUM(
          CASE WHEN tick_decimals = target THEN notional
          ELSE CAST(ROUND({_rescaled("notional", "target", "tick_decimals")})
                    AS INTEGER)
          END
        )                        AS raw_notional,
        MAX(target)              AS tick_decimals
      FROM raw_targeted
      GROUP BY side, trade_date, gateway_id, symbol
    ),
    -- Full set of (side, date, gateway, symbol) keys present on EITHER side.
    -- Driving the comparison from raw_all alone (a LEFT JOIN) made keys that
    -- exist ONLY in the summaries invisible — precisely the total-raw-loss
    -- shape CL-C1 produces for a whole day (finding CL-H4).  The UNION anchor
    -- makes it a full outer comparison so a summary-only key surfaces too.
    keys AS (
      SELECT side, trade_date, gateway_id, symbol FROM raw_all
      UNION
      SELECT side, trade_date, gateway_id, symbol FROM summary_all
    )
    SELECT
      k.side,
      k.trade_date,
      k.gateway_id,
      k.symbol,
      COALESCE(r.raw_qty, 0)          AS raw_qty,
      COALESCE(s.summary_qty, 0)      AS summary_qty,
      (COALESCE(r.raw_qty, 0) - COALESCE(s.summary_qty, 0))          AS qty_diff,
      COALESCE(r.raw_notional, 0)     AS raw_notional,
      COALESCE(s.summary_notional, 0) AS summary_notional,
      -- qty and notional are both INTEGER ticks, so an exact difference is the
      -- right test (no float epsilon needed).
      (COALESCE(r.raw_notional, 0) - COALESCE(s.summary_notional, 0))
                                      AS notional_diff,
      COALESCE(s.tick_decimals, r.tick_decimals) AS tick_decimals
    FROM keys k
    LEFT JOIN raw_all r
      ON  r.side       = k.side
      AND r.trade_date = k.trade_date
      AND r.gateway_id = k.gateway_id
      AND r.symbol     = k.symbol
    LEFT JOIN summary_all s
      ON  s.side       = k.side
      AND s.trade_date = k.trade_date
      AND s.gateway_id = k.gateway_id
      AND s.symbol     = k.symbol
    WHERE (
        ABS(COALESCE(r.raw_qty, 0) - COALESCE(s.summary_qty, 0)) > 0
        OR ABS(COALESCE(r.raw_notional, 0) - COALESCE(s.summary_notional, 0)) > 0
      )
      -- Optional retention guard: once raw rows are pruned (prune_old_events
      -- keeps summaries) a two-sided compare would flag every pruned day as a
      -- false positive.  When the CLI passes its retention window, exclude
      -- dates older than it.  NULL = no guard (used by direct callers/tests).
      AND (
        :retention_days IS NULL
        OR k.trade_date >= date('now', '-' || :retention_days || ' days')
      )
    ORDER BY k.trade_date ASC, k.side ASC, k.gateway_id ASC, k.symbol ASC
    """
    params = {
        "from_date": from_date,
        "to_date": to_date,
        "gateway": gateway,
        "symbol": symbol,
        "retention_days": retention_days,
    }
    rows = conn.execute(_drop_unset_filters(sql, params), params).fetchall()
    return [dict(r) for r in rows]
