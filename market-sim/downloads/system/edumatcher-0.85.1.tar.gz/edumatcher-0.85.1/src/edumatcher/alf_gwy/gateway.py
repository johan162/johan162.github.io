"""ALF TCP gateway runtime.

This process accepts ALF text commands over TCP, validates them defensively,
and bridges traffic to/from the engine ZMQ bus.
"""

from __future__ import annotations

import errno
import logging
import re
import resource
import selectors
import signal
import socket
import threading
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Any, cast

import zmq

from edumatcher.health import HealthReporter
from edumatcher.health.samples import gateway_stats_samples
from edumatcher.models.generated.health import MetricSample
from edumatcher.alf_gwy.config import AlfGatewayConfig
from edumatcher.alf_gwy.protocol import (
    AlfProtocolError,
    ValidationError,
    build_line,
    iso_utc,
    parse_alf_line,
    safe_float,
    safe_int,
    validate_hello_fields,
)
from edumatcher.messaging.bus import PushSocket, make_pusher, make_subscriber
from edumatcher.messaging.reject_report import RejectReporter
from edumatcher.models.combo import ComboLeg, ComboOrder, ComboType
from edumatcher.models.message import (
    decode,
    decode_sequence,
    make_combo_cancel_msg,
    make_combo_order_msg,
    make_gateway_connect_msg,
    make_gateway_disconnect_msg,
    make_gateway_heartbeat_msg,
    make_gateways_request_msg,
    make_kill_switch_msg,
    make_oco_cancel_msg,
    make_oco_order_msg,
    make_order_amend_msg,
    make_order_cancel_msg,
    make_order_new_unchecked_msg,
    make_orders_request_msg,
    make_position_request_msg,
    make_quote_bootstrap_request_msg,
    make_quote_cancel_msg,
    make_quote_legs_request_msg,
    make_quote_new_msg,
    make_session_state_request_msg,
    make_symbols_request_msg,
)
from edumatcher.models.order import Order, OrderType, Side, SmpAction, TIF
from edumatcher.models.order_fields import (
    COMBO_LEG_FIELDS,
    OCO_LEG_FIELDS,
    ORDER_FIELDS,
    check_type_fields,
)
from edumatcher.models.price import (
    TickViolation,
    format_price_ticks,
    get_tick_decimals,
    register_tick_decimals,
    to_ticks_exact,
)
from edumatcher.models.reject import RejectCode
from edumatcher.models.generated.trade import TOPIC_TRADE_EXECUTED
from edumatcher.models.generated.order import (
    PREFIX_ORDER_ACK,
    PREFIX_ORDER_AMENDED,
    PREFIX_ORDER_CANCELLED,
    PREFIX_ORDER_EXPIRED,
    PREFIX_ORDER_FILL,
    PREFIX_ORDER_TRIGGERED,
    PREFIX_ORDERS,
)
from edumatcher.models.generated.session import TOPIC_SESSION_STATE
from edumatcher.models.generated.drop_copy import PREFIX_DROP_COPY_EVENT
from edumatcher.models.generated.circuit_breaker import (
    PREFIX_CIRCUIT_BREAKER_HALT,
    PREFIX_CIRCUIT_BREAKER_RESUME,
)
from edumatcher.models.generated.risk import (
    PREFIX_KILL_SWITCH_ACK,
)
from edumatcher.models.generated.structure import (
    PREFIX_COMBO_ACK,
    PREFIX_COMBO_CANCEL_ACK,
    PREFIX_COMBO_STATUS,
    PREFIX_OCO_ACK,
    PREFIX_OCO_CANCEL_ACK,
    PREFIX_OCO_CANCELLED,
)
from edumatcher.models.generated.quote import (
    PREFIX_QUOTE_ACK,
    PREFIX_QUOTE_CANCEL_ACK,
    PREFIX_QUOTE_STATUS,
)
from edumatcher.models.generated.system import (
    PREFIX_GATEWAY_AUTH,
    PREFIX_GATEWAYS,
    PREFIX_POSITION_SNAPSHOT,
    PREFIX_QUOTE_BOOTSTRAP,
    PREFIX_QUOTE_LEGS,
    PREFIX_SESSION_STATUS,
    PREFIX_SYMBOLS,
    TOPIC_STARTUP_RECOVERY,
)

_MAX_LINE_BYTES = 4096
#: Lines a client may send behind HELLO before WELCOME; see held_lines.
_MAX_HELD_LINES = 64

#: ``errno`` values that mean this socket will never work again. Anything
#: else (``EINTR``, ``ENOBUFS``, ...) is transient and worth retrying, so the
#: two are kept apart rather than both being swallowed by a bare ``OSError``.
_PEER_GONE_ERRNOS = frozenset(
    {
        errno.ECONNRESET,
        errno.ECONNABORTED,
        errno.EPIPE,
        errno.ENOTCONN,
        errno.EBADF,
        errno.ESHUTDOWN,
        errno.ETIMEDOUT,
    }
)


_MAX_EINTR_RETRIES = 3


def _is_peer_gone(exc: OSError) -> bool:
    return exc.errno in _PEER_GONE_ERRNOS


#: Seconds between the engine heartbeats sent for each session. Shorter than
#: the 60 s other processes use: one gateway holds hundreds of IDs, and if it
#: dies they must be free again within ~3x this so the clients can log back
#: on through the restarted gateway.
_ENGINE_HEARTBEAT_SEC = 5
#: How often the gateway asks the engine which participants it holds, to
#: catch sessions the engine has lost (a restart whose startup broadcast was
#: missed, an expiry). The reply topic carries the probe's id.
_SESSION_PROBE_SEC = 5.0
_PROBE_ID_PREFIX = "ALF-PROBE-"
#: Receive high-water mark of both SUB sockets. Past it the engine's PUB
#: drops for this subscriber without a trace, and the main socket carries
#: every gateway's private events, not only this one's: ZMQ's default of
#: 1000 is gone in a fraction of a second when the loop stalls.
_SUB_RCVHWM = 200_000
#: Event families that change a session's order state, each topic scoped to
#: one gateway (``<prefix><GW>``). A sequence gap on one of these is a lost
#: fill, ack or cancel, and the session is told (see _check_sequence).
_PRIVATE_EVENT_PREFIXES = (
    PREFIX_ORDER_ACK,
    PREFIX_ORDER_FILL,
    PREFIX_ORDER_AMENDED,
    PREFIX_ORDER_TRIGGERED,
    PREFIX_ORDER_CANCELLED,
    PREFIX_ORDER_EXPIRED,
    PREFIX_QUOTE_ACK,
    PREFIX_QUOTE_CANCEL_ACK,
    PREFIX_QUOTE_STATUS,
    PREFIX_COMBO_ACK,
    PREFIX_COMBO_CANCEL_ACK,
    PREFIX_COMBO_STATUS,
    PREFIX_OCO_ACK,
    PREFIX_OCO_CANCEL_ACK,
    PREFIX_OCO_CANCELLED,
    PREFIX_KILL_SWITCH_ACK,
)
#: Lines a slow client's overflow sheds: the trade feed and heartbeats,
#: the bulk of any backlog and nothing it cannot do without. Everything
#: else is the client's own or rare (SESSION is also a query reply).
_SHEDDABLE = (b"TRADE|", b"HB|")
#: How long a stopping gateway keeps flushing its sessions' last lines.
_SHUTDOWN_FLUSH_SEC = 2.0
_MAX_ENGINE_EVENTS_PER_LOOP = 1000
_MAX_DC_EVENTS_PER_LOOP = 1000
#: Longest the event loop sleeps when nothing is pending; housekeeping
#: (heartbeats, idle checks) runs at this cadence.
_LOOP_WAIT_MS = 100
#: How long a closing session may take to flush its last lines. A peer that
#: has stopped reading never drains them, and would otherwise hold its slot
#: and its gateway ID until it exits.
_CLOSE_GRACE_SEC = 5.0
#: How long a client that half-closed (``printf … | nc``) keeps receiving the
#: replies to the commands it sent before its session is closed (L011, Q8).
#: Its EXIT does not shorten this: replies are still on their way.
_HALF_CLOSE_GRACE_SEC = 2.0
#: File descriptors needed beyond one per client (listener, ZMQ, logging).
_FD_HEADROOM = 64
# Topic prefix used by edumatcher.engine.drop_copy.DropCopyPublisher for live
# (non-replay) fill events -- see ../../../docs/books/protocols-and-clients/part-3-session-behaviour/060-drop-copy.md.
_DC_EVENT_TOPIC_PREFIX = PREFIX_DROP_COPY_EVENT
#: Wire limits `order_new` declares in spec/messages/order.yaml. Checked once
#: each - symbols when the engine's snapshot lands, gateway ids at HELLO -
#: rather than per order by the validating message builder.
_MAX_SYMBOL_LEN = 16
_MAX_GATEWAY_ID_LEN = 32
#: A gateway id as config-gen accepts it (config_gen/gateway_spec.py). The
#: id is the last dot-separated part of every topic routed back to a
#: session, so a '.' in it would deliver its events to another session.
_GATEWAY_ID_RE = re.compile(rf"[A-Z][A-Z0-9_]{{0,{_MAX_GATEWAY_ID_LEN - 1}}}")
#: Largest price in ticks accepted from a client. Past 2**53 a float price
#: no longer resolves single ticks, so the grid check in to_ticks_exact is
#: meaningless; the wire's 64-bit integers end not far beyond.
_MAX_ABS_TICKS = 2**53 - 1

_TAG_ALLOWED = set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.")

log = logging.getLogger(__name__)


@dataclass
class ClientSession:
    sock: socket.socket
    addr: tuple[str, int]
    gateway_id: str | None = None
    client_name: str = ""
    role: str = "TRADER"
    authenticated: bool = False
    auth_pending: bool = False
    #: Lines that arrived behind HELLO while the engine was still answering
    #: it; handled in order once the logon is accepted.
    held_lines: list[str] = field(default_factory=list)
    dc_enabled: bool = False
    # FEED=ORDERS on HELLO: the session takes market data elsewhere and wants
    # only its own order events, not the public SESSION/HALT/RESUME/TRADE
    # broadcasts (an AI agent among hundreds would otherwise parse every
    # trade print of the exchange).
    public_feed: bool = True
    # Target gateway_ids of outstanding POS|GW=<gateway_id> queries. Added
    # when the request is sent, removed when the matching
    # system.position_snapshot.<target> reply arrives (see
    # _handle_position_snapshot_response). The engine answers every request,
    # so the set holds at most the targets in flight.
    pending_position_queries: set[str] = field(default_factory=set)
    #: monotonic time the engine accepted the logon
    authenticated_at: float = 0.0
    out_queue: deque[bytes] = field(default_factory=deque)
    out_offset: int = 0
    in_buffer: bytearray = field(default_factory=bytearray)
    closing: bool = False
    #: monotonic time ``closing`` was set; see _CLOSE_GRACE_SEC
    closing_since: float = 0.0
    #: monotonic time the client half-closed (EOF on read), 0.0 while it can
    #: still send; see _HALF_CLOSE_GRACE_SEC
    read_closed_since: float = 0.0
    connected_at: float = field(default_factory=time.monotonic)
    last_activity: float = field(default_factory=time.monotonic)
    last_outbound: float = field(default_factory=time.monotonic)
    # Last system.gateway_heartbeat sent to the engine for this session; -inf
    # so the first beat goes out on the first tick after authentication.
    last_engine_heartbeat: float = float("-inf")
    connect_emitted: bool = False
    lines_received: int = 0
    lines_sent: int = 0
    errors: int = 0
    error_times: deque[float] = field(default_factory=deque)
    rate_tokens: float = 0.0
    rate_updated: float = 0.0

    def __post_init__(self) -> None:
        self.connected_at = time.monotonic()
        self.last_activity = time.monotonic()
        self.last_outbound = time.monotonic()
        self.rate_updated = time.monotonic()

    def close(self) -> None:
        try:
            self.sock.close()
        except OSError:
            pass


#: ALF's names for the canonical order fields of models/order_fields.
_ALF_FIELD_NAMES = {
    "price": "PRICE",
    "stop_price": "STOP",
    "visible_qty": "VISIBLE",
    "trail_offset": "TRAIL",
    "order_type": "TYPE",
}


def _check_alf_type_fields(
    order_type: OrderType,
    values: dict[str, object],
    carried: tuple[str, ...],
    prefix: str,
    where: str,
) -> None:
    """Refuse an order or leg that breaks the shared per-type field rule.

    The same table REST and the engine apply (WP-API16): a field the type does
    not use is refused (``UNSUPPORTED_FIELD``) rather than silently dropped, so
    an ALF client gets the same verdict and ``reject_code`` as a REST client.
    *prefix* words the message in the command's field names (``LEG1_STOP``).
    """
    violation = check_type_fields(
        order_type,
        [name for name, value in values.items() if value is not None],
        carried=carried,
        names={f: prefix + n for f, n in _ALF_FIELD_NAMES.items()},
        where=where,
    )
    if violation is not None:
        raise ValidationError(violation.reject_code, violation.message)


class AlfGateway:
    """ALF TCP gateway process."""

    def __init__(self, config: AlfGatewayConfig) -> None:
        self.config = config
        self._running = False

        self._server: socket.socket | None = None
        self._clients: dict[int, ClientSession] = {}
        self._active_gateway_sessions: dict[str, int] = {}
        self._dc_topic_refcounts: dict[str, int] = {}
        self._gateway_roles = {gw_id: role for gw_id, role in config.gateway_roles}
        # Shared ref-data snapshot state loaded from engine symbols responses.
        self._known_symbols: set[str] = set()
        self._symbols_snapshot_loaded = False
        # The SYMBOLS/SYMBOL.../END reply, built once from the engine's answer
        # and replayed to every later logon. Asking the engine per session
        # cost a 300-symbol reply per logon: 600 agents logging on together
        # took 12 s and timed some out.
        self._symbols_reply: list[bytes] | None = None

        self._push: PushSocket = make_pusher(config.engine_pull_addr)
        #: Refusals made here, told to the engine so the audit trail holds them.
        self._rejects = RejectReporter(
            "ALF", lambda frames: self._push.send_multipart(frames)
        )
        self._sub: zmq.Socket[bytes] = make_subscriber(
            config.engine_pub_addr,
            TOPIC_SESSION_STATE,
            TOPIC_TRADE_EXECUTED,
            PREFIX_CIRCUIT_BREAKER_HALT,
            PREFIX_CIRCUIT_BREAKER_RESUME,
            # Every gateway-scoped family is subscribed once, by prefix, for
            # all gateways. A per-session SUBSCRIBE sent right before the
            # request it answers (connect, symbols, POS) races the engine's
            # reply: ZMQ applies the subscription asynchronously, and in a
            # burst of logons the reply often arrived first and was dropped
            # (AUTH_TIMEOUT, SYMBOLS_NOT_READY). Events for gateways with no
            # session here are discarded in the routing below.
            PREFIX_GATEWAY_AUTH,
            *_PRIVATE_EVENT_PREFIXES,
            PREFIX_ORDERS,
            PREFIX_SYMBOLS,
            PREFIX_QUOTE_BOOTSTRAP,
            PREFIX_QUOTE_LEGS,
            PREFIX_SESSION_STATUS,
            PREFIX_POSITION_SNAPSHOT,
            TOPIC_STARTUP_RECOVERY,
            PREFIX_GATEWAYS + _PROBE_ID_PREFIX,
            rcvhwm=_SUB_RCVHWM,
        )
        #: Last per-topic sequence seen on each private event topic (see
        #: _check_sequence). Tracked for every gateway, connected here or
        #: not, so a session that logs on later is not told of a false gap.
        self._topic_seq: dict[str, int] = {}
        # Separate SUB socket for the engine's drop-copy feed (:5557). Kept
        # distinct from self._sub (:5556) because it is a different ZMQ PUB
        # address entirely -- see edumatcher.engine.drop_copy. No topics are
        # subscribed here at startup; DC|ON subscribes this session's own
        # drop_copy.event.<GW_ID> topic on demand (see _dc_subscribe_topic).
        self._dc_sub: zmq.Socket[bytes] = make_subscriber(
            config.drop_copy_pub_addr, rcvhwm=_SUB_RCVHWM
        )
        # Sessions with queued output. Flushing only these keeps the loop
        # O(active) instead of O(connected).
        self._dirty: set[int] = set()
        # Sessions whose kernel send buffer filled up. They stay in _dirty but
        # are only retried when the selector says the socket is writable, so a
        # stalled peer cannot pin the loop at a zero select() timeout.
        self._write_blocked: set[int] = set()
        self._probe_seq = 0
        self._probes: dict[str, float] = {}
        self._next_probe = 0.0
        self._selector = selectors.DefaultSelector()
        self._next_housekeeping = 0.0

        self._global_stats: dict[str, int] = {
            "connected_clients": 0,
            "commands_received_total": 0,
            "commands_forwarded_total": 0,
            "commands_rejected_total": 0,
            "errors_total": 0,
            "disconnects_total": 0,
            "slow_client_disconnects": 0,
            "auth_failures": 0,
            "events_lost": 0,
        }
        # Health beacon (operator dashboard §8.5); attached by main().
        self._reporter: HealthReporter | None = None

    def _ensure_fd_limit(self) -> None:
        """Make sure the process may open one socket per allowed client.

        The default soft limit is often 1024, below what a full gateway
        needs; raise it up to the hard limit, and refuse to start with a
        clear message when even that is too low.
        """
        needed = self.config.max_connections + _FD_HEADROOM
        soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        if soft == resource.RLIM_INFINITY or soft >= needed:
            return
        target = needed if hard == resource.RLIM_INFINITY else min(needed, hard)
        if target > soft:
            resource.setrlimit(resource.RLIMIT_NOFILE, (target, hard))
        if target < needed:
            raise RuntimeError(
                f"alf_gateway.max_connections={self.config.max_connections} needs "
                f"{needed} file descriptors but the hard limit is {hard}; raise it "
                "(ulimit -Hn) or lower max_connections"
            )

    def run(self) -> None:
        self._ensure_fd_limit()
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((self.config.bind_address, self.config.port))
        server.listen(min(socket.SOMAXCONN, max(128, self.config.max_connections)))
        server.setblocking(False)
        # Published only once listening: callers poll it as the readiness signal.
        self._server = server
        # epoll/kqueue: one wait costs O(ready sockets), not O(connected).
        # The ZMQ sockets join through their notification fds, which are
        # edge-triggered: the loop drains them and checks zmq.EVENTS before
        # it waits, so a message left over from a capped drain is never stuck.
        self._selector.register(self._server, selectors.EVENT_READ, None)
        for zsock in (self._sub, self._dc_sub):
            self._selector.register(
                cast(int, zsock.getsockopt(zmq.FD)), selectors.EVENT_READ, None
            )

        self._running = True
        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, lambda *_: self.stop())
            signal.signal(signal.SIGTERM, lambda *_: self.stop())

        log.info(
            "listening on %s:%s (engine_pull=%s engine_pub=%s max_connections=%s)",
            self.config.bind_address,
            self.config.port,
            self.config.engine_pull_addr,
            self.config.engine_pub_addr,
            self.config.max_connections,
        )

        reporter = self._reporter
        try:
            while self._running:
                if reporter is not None:
                    reporter.tick_and_publish(self.metric_samples)
                # Wait for work instead of sleeping a fixed 10 ms. (The old
                # select() also broke once a descriptor passed 1024.)
                busy = self._has_pending_writes() or any(
                    cast(int, z.getsockopt(zmq.EVENTS)) & zmq.POLLIN
                    for z in (self._sub, self._dc_sub)
                )
                ready: list[ClientSession] = []
                writable: set[int] = set()
                accept = False
                for key, mask in self._selector.select(
                    0 if busy else _LOOP_WAIT_MS / 1000
                ):
                    if isinstance(key.data, ClientSession):
                        if mask & selectors.EVENT_READ:
                            ready.append(key.data)
                        if mask & selectors.EVENT_WRITE:
                            writable.add(key.data.sock.fileno())
                    elif key.fileobj is self._server:
                        accept = True
                if accept:
                    self._accept_new_clients()
                self._read_client_data(ready)
                self._poll_engine_events()
                self._poll_dc_events()
                now = time.monotonic()
                if now >= self._next_housekeeping:
                    self._next_housekeeping = now + _LOOP_WAIT_MS / 1000
                    self._send_heartbeats_if_due()
                    self._send_engine_heartbeats_if_due()
                    self._probe_engine_sessions_if_due(now)
                    self._drop_idle_clients()
                self._flush_client_writes(writable=writable)
            self._flush_for_shutdown()
        finally:
            self.close()

    def _flush_for_shutdown(self) -> None:
        """Give every session what it is owed before a requested stop.

        Events the engine has already published (fills among them) and
        lines already queued would otherwise die with the sockets. One
        drain of each SUB socket, a closing ERR, then flush for at most
        ``_SHUTDOWN_FLUSH_SEC``; whatever a peer has not taken by then is
        dropped by close(). Not run after a crash: the loop's state is not
        to be trusted then.
        """
        self._poll_engine_events()
        self._poll_dc_events()
        for session in list(self._clients.values()):
            self._queue_line(
                session,
                "ERR",
                {"CODE": "GATEWAY_SHUTDOWN", "DETAIL": "Gateway shutting down"},
            )
            self._close_after_flush(session)
        deadline = time.monotonic() + _SHUTDOWN_FLUSH_SEC
        while self._dirty and time.monotonic() < deadline:
            # Every dirty session counts as writable: a peer that cannot
            # take more just raises EAGAIN again, and the loop is bounded.
            self._flush_client_writes(writable=set(self._dirty))
            if self._dirty:
                time.sleep(0.01)

    def stop(self) -> None:
        log.info("stop requested")
        self._running = False

    def attach_reporter(self, reporter: HealthReporter) -> None:
        """Ship this gateway's metrics through ``reporter`` (from main())."""
        self._reporter = reporter

    def metric_samples(self) -> list[MetricSample]:
        """Design §8.5: the existing ``_global_stats``, exported as they are."""
        return gateway_stats_samples(self._global_stats, self.config.max_connections)

    def close(self) -> None:
        log.info("closing ALF gateway")
        if self._reporter is not None:
            self._reporter.stop()
        for session in list(self._clients.values()):
            self._disconnect(session, reason="gateway_shutdown")
        self._clients.clear()
        self._active_gateway_sessions.clear()

        if self._server is not None:
            self._server.close()
            self._server = None
        self._selector.close()

        if not self._push.closed:
            self._push.close()
        if not self._sub.closed:
            self._sub.close()
        if not self._dc_sub.closed:
            self._dc_sub.close()

    # ------------------------------------------------------------------
    # Networking
    # ------------------------------------------------------------------

    def _accept_new_clients(self) -> None:
        if self._server is None:
            return

        while True:
            try:
                conn, addr = self._server.accept()
            except BlockingIOError:
                break
            except OSError as exc:
                # EMFILE/ENFILE, ECONNABORTED, ENOBUFS, ...: refuse this one
                # and retry on the next tick. Breaking (not continuing)
                # matters for fd exhaustion, where the listener stays
                # readable and a retry loop would spin.
                log.warning("ALF accept failed: %s", exc)
                break
            try:
                conn.setblocking(False)
                conn.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
            except OSError as exc:
                log.warning("ALF dropping connection from %s: %s", addr, exc)
                conn.close()
                continue

            if len(self._clients) >= self.config.max_connections:
                try:
                    conn.close()
                except OSError:
                    pass
                log.warning("ALF max_connections reached, rejecting %s", addr)
                continue

            session = ClientSession(sock=conn, addr=addr)
            session.rate_tokens = float(self.config.max_commands_per_second)
            self._clients[conn.fileno()] = session
            self._selector.register(conn, selectors.EVENT_READ, session)
            self._global_stats["connected_clients"] = len(self._clients)
            log.debug("ALF new connection from %s", addr)

    def _read_client_data(self, ready: list[ClientSession]) -> None:
        for session in ready:
            if session.sock.fileno() not in self._clients:
                continue  # disconnected earlier in this pass

            try:
                chunk = session.sock.recv(4096)
            except BlockingIOError:
                continue
            except OSError as exc:
                if _is_peer_gone(exc):
                    self._disconnect(session, reason="peer_reset")
                continue

            if not chunk:
                # A half-close, not a disconnect: TCP lets us send after the
                # peer's FIN, and the replies to what it sent are owed (L011).
                session.read_closed_since = time.monotonic()
                self._set_events(session, session.sock.fileno() in self._write_blocked)
                continue

            session.in_buffer.extend(chunk)
            session.last_activity = time.monotonic()

            if (
                b"\n" not in session.in_buffer
                and len(session.in_buffer) > _MAX_LINE_BYTES
            ):
                session.in_buffer.clear()
                self._register_error(
                    session,
                    "BAD_MESSAGE",
                    "Line exceeds 4096 bytes",
                    close_connection=False,
                    reject_code="MALFORMED_MESSAGE",
                )
                continue

            self._drain_lines(session)

    def _drain_lines(self, session: ClientSession) -> None:
        while True:
            idx = session.in_buffer.find(b"\n")
            if idx < 0:
                return

            raw = bytes(session.in_buffer[:idx])
            del session.in_buffer[: idx + 1]

            if len(raw) + 1 > _MAX_LINE_BYTES:
                self._register_error(
                    session,
                    "BAD_MESSAGE",
                    "Line exceeds 4096 bytes",
                    close_connection=False,
                    reject_code="MALFORMED_MESSAGE",
                )
                continue

            try:
                line = raw.decode("utf-8").replace("\x00", "?")
            except UnicodeDecodeError:
                self._register_error(
                    session,
                    "BAD_MESSAGE",
                    "Line is not valid UTF-8",
                    close_connection=False,
                    reject_code="MALFORMED_MESSAGE",
                )
                continue
            try:
                self._handle_client_line(session, line)
            except Exception:
                self._register_error(
                    session,
                    "INTERNAL_ERROR",
                    "unexpected error",
                    close_connection=False,
                )

    def _has_pending_writes(self) -> bool:
        """Output is waiting on this gateway, not on the peer's receive window.

        A write-blocked session is excluded: retrying it before the selector
        reports writability is the busy-spin, not progress.
        """
        return bool(self._dirty - self._write_blocked)

    def _set_write_interest(self, session: ClientSession, want: bool) -> None:
        fileno = session.sock.fileno()
        if want == (fileno in self._write_blocked):
            return
        if not self._set_events(session, want):
            return
        if want:
            self._write_blocked.add(fileno)
        else:
            self._write_blocked.discard(fileno)

    def _set_events(self, session: ClientSession, want_write: bool) -> bool:
        """Watch *session* for reading (until it half-closed) and, if
        *want_write*, for writing; False if the selector refused."""
        events = (0 if session.read_closed_since else selectors.EVENT_READ) | (
            selectors.EVENT_WRITE if want_write else 0
        )
        try:
            if not events:
                self._selector.unregister(session.sock)
            else:
                try:
                    self._selector.modify(session.sock, events, session)
                except KeyError:
                    self._selector.register(session.sock, events, session)
        except KeyError, ValueError:
            return False
        return True

    def _flush_client_writes(self, writable: set[int] | None = None) -> None:
        for fileno in list(self._dirty):
            session = self._clients.get(fileno)
            if session is None:
                self._dirty.discard(fileno)
                self._write_blocked.discard(fileno)
                continue
            if fileno in self._write_blocked and not (writable and fileno in writable):
                continue  # still waiting for the peer to drain its window
            disconnected = False
            eintr_retries = 0
            while session.out_queue:
                payload = session.out_queue[0]
                unsent = payload[session.out_offset :]
                try:
                    sent = session.sock.send(unsent)
                except BlockingIOError:
                    self._set_write_interest(session, True)
                    break
                except OSError as exc:
                    if _is_peer_gone(exc):
                        self._disconnect(session, reason="peer_reset")
                        disconnected = True
                        break
                    if exc.errno == errno.EINTR and eintr_retries < _MAX_EINTR_RETRIES:
                        # Interrupted, not refused: retry rather than wait for
                        # a writability edge that has already passed. Bounded,
                        # so a socket that only ever raises EINTR still parks.
                        eintr_retries += 1
                        continue
                    # Retryable (ENOBUFS, ENOMEM, ...). Park it exactly like
                    # EAGAIN: breaking without registering write interest
                    # leaves it dirty-but-not-blocked, which is the busy-spin
                    # G1 removed (R4).
                    self._set_write_interest(session, True)
                    break

                if sent <= 0:
                    self._set_write_interest(session, True)
                    break

                eintr_retries = 0
                session.out_offset += sent
                if session.out_offset >= len(payload):
                    session.out_queue.popleft()
                    session.out_offset = 0
                    session.lines_sent += 1
                    session.last_outbound = time.monotonic()

            if disconnected:
                continue

            if not session.out_queue:
                self._set_write_interest(session, False)
                self._dirty.discard(fileno)
                if session.closing:
                    self._disconnect(session, reason="session_closed")

    # ------------------------------------------------------------------
    # Protocol dispatch
    # ------------------------------------------------------------------

    def _handle_client_line(self, session: ClientSession, line: str) -> None:
        if session.auth_pending and not line.startswith("HELLO"):
            # A script that writes its lines without waiting for WELCOME
            # (printf ... | nc) sent them in order behind HELLO; refusing them
            # as "HELLO must be the first message" was wrong on both counts.
            if len(session.held_lines) >= _MAX_HELD_LINES:
                self._register_error(
                    session,
                    "AUTH_REQUIRED",
                    "Too many lines before WELCOME",
                    close_connection=True,
                    reject_code="AUTH_REQUIRED",
                )
                return
            session.held_lines.append(line)
            return
        session.lines_received += 1
        self._global_stats["commands_received_total"] += 1

        try:
            frame = parse_alf_line(line)
        except AlfProtocolError as exc:
            self._register_error(
                session, "BAD_MESSAGE", str(exc), close_connection=False
            )
            return

        cmd = frame.command
        fields = frame.fields

        if not session.authenticated:
            if cmd == "HELLO" and session.auth_pending:
                self._register_error(
                    session,
                    "HELLO_ALREADY_PENDING",
                    "HELLO already received; awaiting auth result",
                    close_connection=False,
                    reject_code="AUTH_REQUIRED",
                )
                return

            if not self._allow_command_now(session):
                self._register_error(
                    session,
                    "RATE_LIMITED",
                    "Too many commands per second",
                    close_connection=False,
                    reject_code="RATE_LIMITED",
                    tag=self._error_tag_for(cmd, fields),
                )
                return
            if cmd != "HELLO":
                self._register_error(
                    session,
                    "AUTH_REQUIRED",
                    "HELLO must be the first message",
                    close_connection=True,
                    reject_code="AUTH_REQUIRED",
                    tag=self._error_tag_for(cmd, fields),
                )
                return
            try:
                self._handle_hello(session, fields)
            except ValidationError as exc:
                close_conn = exc.code not in {
                    "ENGINE_UNAVAILABLE",
                    "HELLO_ALREADY_PENDING",
                }
                self._register_error(
                    session,
                    exc.code,
                    exc.detail,
                    close_connection=close_conn,
                    reject_code=exc.reject_code,
                    tag=self._error_tag_for(cmd, fields),
                )
            return

        if cmd == "HELLO":
            # Ignore duplicate HELLO after successful auth.
            return

        if cmd == "PING":
            self._queue_line(session, "PONG", {"TS": iso_utc(time.time())})
            return

        if cmd in {"EXIT", "QUIT"}:
            if session.read_closed_since:
                # A script piped through nc: its replies are still on their
                # way from the engine; the half-close bound closes it (L011).
                return
            self._close_after_flush(session)
            return

        if not self._allow_command_now(session):
            self._register_error(
                session,
                "RATE_LIMITED",
                "Too many commands per second",
                close_connection=False,
                reject_code="RATE_LIMITED",
                tag=self._error_tag_for(cmd, fields),
            )
            return

        try:
            self._dispatch_authenticated(session, cmd, fields)
        except ValidationError as exc:
            self._global_stats["commands_rejected_total"] += 1
            self._register_error(
                session,
                exc.code,
                exc.detail,
                close_connection=False,
                reject_code=exc.reject_code,
                tag=self._error_tag_for(cmd, fields),
            )
        except Exception:
            log.exception(
                "[%s] unexpected error handling %s",
                session.gateway_id or session.addr,
                cmd,
            )
            self._global_stats["commands_rejected_total"] += 1
            self._register_error(
                session,
                "INTERNAL_ERROR",
                "unexpected error",
                close_connection=False,
                reject_code="INTERNAL_ERROR",
                tag=self._error_tag_for(cmd, fields),
            )

    def _dispatch_authenticated(
        self, session: ClientSession, cmd: str, fields: dict[str, str]
    ) -> None:
        if cmd == "NEW":
            self._handle_new(session, fields)
            return
        if cmd == "AMEND":
            self._handle_amend(session, fields)
            return
        if cmd == "CANCEL":
            self._handle_cancel(session, fields)
            return
        if cmd == "QUOTE":
            self._handle_quote(session, fields)
            return
        if cmd == "QUOTE_CANCEL":
            self._handle_quote_cancel(session, fields)
            return
        if cmd == "KILL":
            symbol = fields.get("SYM", "")
            self._send_to_engine(
                make_kill_switch_msg(self._require_gw(session), symbol)
            )
            return
        if cmd == "DC":
            self._handle_dc(session, fields)
            return
        if cmd == "SYMBOLS":
            self._send_to_engine(make_symbols_request_msg(self._require_gw(session)))
            return
        if cmd == "ORDERS":
            self._send_to_engine(make_orders_request_msg(self._require_gw(session)))
            return
        if cmd == "QBOOT":
            self._send_to_engine(
                make_quote_bootstrap_request_msg(
                    self._require_gw(session), fields.get("SYM", "")
                )
            )
            return
        if cmd == "QLEGS":
            self._send_to_engine(
                make_quote_legs_request_msg(
                    self._require_gw(session),
                    fields.get("SYM", ""),
                    fields.get("SHOW", "ACTIVE"),
                )
            )
            return
        if cmd == "SESSION":
            self._send_to_engine(
                make_session_state_request_msg(self._require_gw(session))
            )
            return

        if cmd == "POS":
            self._handle_pos(session, fields)
            return

        if cmd in {"STATUS", "HELP"}:
            raise ValidationError(
                "UNKNOWN_COMMAND",
                f"{cmd} is interactive-only and not supported by pm-alf-gwy",
            )

        raise ValidationError("UNKNOWN_COMMAND", f"Unknown command: {cmd}")

    def _handle_hello(self, session: ClientSession, fields: dict[str, str]) -> None:
        if session.auth_pending:
            raise ValidationError(
                "HELLO_ALREADY_PENDING",
                "HELLO already received; awaiting auth result",
            )

        client, _proto, gateway_id = validate_hello_fields(fields)

        if self._gateway_in_use(gateway_id):
            self._register_error(
                session,
                "GATEWAY_ALREADY_CONNECTED",
                f"Gateway already connected: {gateway_id}",
                close_connection=True,
            )
            return

        if not _GATEWAY_ID_RE.fullmatch(gateway_id):
            # order_new declares gateway_id max_len 32. Refusing at HELLO is
            # both earlier and clearer than the per-order check this replaces.
            self._register_error(
                session,
                "INVALID_VALUE",
                "Gateway id must be a letter followed by up to "
                f"{_MAX_GATEWAY_ID_LEN - 1} letters, digits or '_'",
                close_connection=True,
            )
            return

        feed = fields.get("FEED", "ALL")
        if feed not in ("ALL", "ORDERS"):
            raise ValidationError("INVALID_VALUE", "FEED must be ALL or ORDERS")
        session.public_feed = feed == "ALL"
        session.client_name = client
        session.gateway_id = gateway_id
        session.auth_pending = True
        session.connect_emitted = False

        try:
            self._send_to_engine(
                make_gateway_connect_msg(gateway_id), count_as_command=False
            )
        except ValidationError:
            session.auth_pending = False
            session.gateway_id = None
            session.client_name = ""
            raise
        session.connect_emitted = True

    def _handle_new(self, session: ClientSession, fields: dict[str, str]) -> None:
        if "RTAG" in fields:
            raise ValidationError("UNSUPPORTED_FIELD", "NEW uses TAG, not RTAG")
        req_type = fields.get("TYPE", "LIMIT")
        if req_type == "OCO":
            self._handle_new_oco(session, fields)
            return
        if req_type == "COMBO":
            self._handle_new_combo(session, fields)
            return
        self._handle_new_single(session, fields)

    def _handle_new_single(
        self, session: ClientSession, fields: dict[str, str]
    ) -> None:
        symbol = self._required_str(fields, "SYM")
        self._validate_symbol(symbol)

        side = self._parse_side(self._required_str(fields, "SIDE"))
        order_type = self._parse_order_type(self._required_str(fields, "TYPE"))
        quantity = safe_int(self._required_str(fields, "QTY"), "QTY", min_value=1)
        tif = self._parse_tif(fields.get("TIF", "DAY"))
        # SMP omitted entirely means "let the engine apply this gateway's
        # configured smp_action default" -- distinct from an explicit
        # SMP=NONE, which means the client deliberately allows self-trades.
        # See SmpAction's docstring in models/order.py.
        smp = self._parse_smp(fields["SMP"]) if "SMP" in fields else None

        price = safe_float(fields["PRICE"], "PRICE") if "PRICE" in fields else None
        stop_price = safe_float(fields["STOP"], "STOP") if "STOP" in fields else None
        visible = (
            safe_int(fields["VISIBLE"], "VISIBLE", min_value=1)
            if "VISIBLE" in fields
            else None
        )
        trail_offset = (
            safe_float(fields["TRAIL"], "TRAIL") if "TRAIL" in fields else None
        )

        _check_alf_type_fields(
            order_type,
            {
                "price": price,
                "stop_price": stop_price,
                "visible_qty": visible,
                "trail_offset": trail_offset,
            },
            ORDER_FIELDS,
            "",
            "on an order",
        )
        if (
            order_type == OrderType.ICEBERG
            and visible is not None
            and visible >= quantity
        ):
            raise ValidationError(
                "INVALID_VALUE", "VISIBLE must be less than QTY for TYPE=ICEBERG"
            )

        order = Order.create(
            symbol=symbol,
            side=side,
            order_type=order_type,
            quantity=quantity,
            gateway_id=self._require_gw(session),
            tif=tif,
            price_ticks=(
                self._ticks(price, symbol, "PRICE") if price is not None else None
            ),
            stop_price_ticks=(
                self._ticks(stop_price, symbol, "STOP")
                if stop_price is not None
                else None
            ),
            visible_qty=visible,
            smp_action=smp,
            trail_offset_ticks=(
                self._ticks(trail_offset, symbol, "TRAIL")
                if trail_offset is not None
                else None
            ),
            oco_group_id=None,
            client_tag=self._optional_tag(fields, "TAG"),
        )

        # The unchecked builder, on the one path measured hot enough to
        # justify it (docs-design/EduMatcher-Perf-Analysis.md section 7).
        # It skips OrderNew.validate() — worth 355 ns — but the bulk of the
        # 5.0 us it saves is the dataclass round trip the validating builder
        # makes: dict -> OrderNew -> validate -> dict. Every rule validate()
        # would have applied is already enforced above or bounded once at
        # startup; tests/test_alf_gwy_wire_bounds.py pins that field by field
        # so the correspondence cannot rot.
        self._send_to_engine(make_order_new_unchecked_msg(order.to_dict()))

    def _handle_new_oco(self, session: ClientSession, fields: dict[str, str]) -> None:
        gateway_id = self._require_gw(session)
        oco_id = self._required_str(fields, "OCO_ID")
        symbol = self._required_str(fields, "SYM")
        self._validate_symbol(symbol)

        quantity = safe_int(self._required_str(fields, "QTY"), "QTY", min_value=1)
        tif = self._parse_tif(fields.get("TIF", "DAY"))

        def _parse_leg(prefix: str) -> dict[str, Any]:
            leg_side = self._parse_side(self._required_str(fields, f"{prefix}SIDE"))
            leg_type = self._parse_order_type(
                self._required_str(fields, f"{prefix}TYPE")
            )

            _check_alf_type_fields(
                leg_type,
                {
                    "price": fields.get(f"{prefix}PRICE"),
                    "stop_price": fields.get(f"{prefix}STOP"),
                    "trail_offset": fields.get(f"{prefix}TRAIL"),
                },
                OCO_LEG_FIELDS,
                prefix,
                "on an OCO leg",
            )
            leg: dict[str, Any] = {
                "side": leg_side.value,
                "order_type": leg_type.value,
            }

            if f"{prefix}PRICE" in fields:
                leg["price_ticks"] = self._ticks(
                    safe_float(fields[f"{prefix}PRICE"], f"{prefix}PRICE"),
                    symbol,
                    f"{prefix}PRICE",
                )
            if f"{prefix}STOP" in fields:
                leg["stop_price_ticks"] = self._ticks(
                    safe_float(fields[f"{prefix}STOP"], f"{prefix}STOP"),
                    symbol,
                    f"{prefix}STOP",
                )
            if f"{prefix}TRAIL" in fields:
                leg["trail_offset_ticks"] = self._ticks(
                    safe_float(fields[f"{prefix}TRAIL"], f"{prefix}TRAIL"),
                    symbol,
                    f"{prefix}TRAIL",
                )
            return leg

        leg1 = _parse_leg("LEG1_")
        leg2 = _parse_leg("LEG2_")

        payload = {
            "oco_id": oco_id,
            "gateway_id": gateway_id,
            "symbol": symbol,
            # X27: the scale of the legs' ticks, as on order.new.
            "tick_decimals": get_tick_decimals(symbol),
            "quantity": quantity,
            "tif": tif.value,
            "leg1": leg1,
            "leg2": leg2,
        }
        client_tag = self._optional_tag(fields, "TAG")
        if client_tag is not None:
            payload["client_tag"] = client_tag
        self._send_to_engine(make_oco_order_msg(payload))

    def _handle_new_combo(self, session: ClientSession, fields: dict[str, str]) -> None:
        gateway_id = self._require_gw(session)
        combo_id = self._required_str(fields, "COMBO_ID")
        combo_type = self._parse_combo_type(
            self._required_str(fields, "COMBO_TYPE", default="AON")
        )
        tif = self._parse_tif(fields.get("TIF", "DAY"))
        # SMP omitted entirely means "let the engine apply this gateway's
        # configured smp_action default" to every leg -- distinct from an
        # explicit SMP=NONE. See SmpAction's docstring in models/order.py.
        smp_action = self._parse_smp(fields["SMP"]) if "SMP" in fields else None

        leg_count = safe_int(
            self._required_str(fields, "LEG_COUNT"), "LEG_COUNT", min_value=2
        )
        if leg_count > 10:
            raise ValidationError("INVALID_VALUE", "LEG_COUNT must be <= 10")

        legs: list[ComboLeg] = []
        for index in range(leg_count):
            prefix = f"LEG{index}"
            sym = self._required_str(fields, f"{prefix}.SYM")
            self._validate_symbol(sym)
            side = self._parse_side(self._required_str(fields, f"{prefix}.SIDE"))
            qty = safe_int(
                self._required_str(fields, f"{prefix}.QTY"),
                f"{prefix}.QTY",
                min_value=1,
            )
            leg_type = self._parse_order_type(fields.get(f"{prefix}.TYPE", "LIMIT"))

            price_raw = fields.get(f"{prefix}.PRICE")
            stop_raw = fields.get(f"{prefix}.STOP")

            price = (
                safe_float(price_raw, f"{prefix}.PRICE")
                if price_raw is not None
                else None
            )
            stop = (
                safe_float(stop_raw, f"{prefix}.STOP") if stop_raw is not None else None
            )

            _check_alf_type_fields(
                leg_type,
                {"price": price, "stop_price": stop},
                COMBO_LEG_FIELDS,
                f"{prefix}.",
                "on a combo leg",
            )

            legs.append(
                ComboLeg(
                    symbol=sym,
                    side=side,
                    order_type=leg_type,
                    quantity=qty,
                    # The leg's own scale: legs trade different instruments.
                    tick_decimals=get_tick_decimals(sym),
                    price_ticks=(
                        self._ticks(price, sym, "PRICE") if price is not None else None
                    ),
                    stop_price_ticks=(
                        self._ticks(stop, sym, "STOP") if stop is not None else None
                    ),
                    smp_action=smp_action,
                )
            )

        combo = ComboOrder.create(
            combo_id=combo_id,
            gateway_id=gateway_id,
            combo_type=combo_type,
            tif=tif,
            legs=legs,
        )
        payload = combo.to_submission_dict()
        client_tag = self._optional_tag(fields, "TAG")
        if client_tag is not None:
            payload["client_tag"] = client_tag
        self._send_to_engine(make_combo_order_msg(payload))

    def _handle_amend(self, session: ClientSession, fields: dict[str, str]) -> None:
        if "TAG" in fields:
            raise ValidationError("UNSUPPORTED_FIELD", "AMEND uses RTAG, not TAG")
        order_id = self._required_str(fields, "ID")
        price = safe_float(fields["PRICE"], "PRICE") if "PRICE" in fields else None
        qty = safe_int(fields["QTY"], "QTY", min_value=1) if "QTY" in fields else None
        if price is None and qty is None:
            raise ValidationError("MISSING_FIELD", "AMEND requires PRICE and/or QTY")

        self._send_to_engine(
            make_order_amend_msg(
                order_id,
                self._require_gw(session),
                price=price,
                qty=qty,
                request_tag=self._optional_tag(fields, "RTAG"),
            )
        )

    def _handle_cancel(self, session: ClientSession, fields: dict[str, str]) -> None:
        gateway_id = self._require_gw(session)
        if "TAG" in fields:
            raise ValidationError("UNSUPPORTED_FIELD", "CANCEL uses RTAG, not TAG")
        combo_id = fields.get("COMBO_ID")
        if combo_id:
            if "RTAG" in fields:
                raise ValidationError(
                    "UNSUPPORTED_FIELD", "RTAG is only supported for CANCEL|ID"
                )
            self._send_to_engine(make_combo_cancel_msg(combo_id, gateway_id))
            return

        oco_id = fields.get("OCO_ID")
        if oco_id:
            if "RTAG" in fields:
                raise ValidationError(
                    "UNSUPPORTED_FIELD", "RTAG is only supported for CANCEL|ID"
                )
            self._send_to_engine(make_oco_cancel_msg(oco_id, gateway_id))
            return

        order_id = fields.get("ID")
        if not order_id:
            raise ValidationError(
                "MISSING_FIELD", "CANCEL requires ID, COMBO_ID, or OCO_ID"
            )

        self._send_to_engine(
            make_order_cancel_msg(
                order_id,
                gateway_id,
                request_tag=self._optional_tag(fields, "RTAG"),
            )
        )

    def _handle_quote(self, session: ClientSession, fields: dict[str, str]) -> None:
        self._require_role(session, "MARKET_MAKER")

        symbol = self._required_str(fields, "SYM")
        self._validate_symbol(symbol)

        bid = safe_float(self._required_str(fields, "BID"), "BID")
        ask = safe_float(self._required_str(fields, "ASK"), "ASK")
        bid_qty = safe_int(
            self._required_str(fields, "BID_QTY"), "BID_QTY", min_value=1
        )
        ask_qty = safe_int(
            self._required_str(fields, "ASK_QTY"), "ASK_QTY", min_value=1
        )
        tif = self._parse_tif(fields.get("TIF", "DAY"))

        if bid >= ask:
            raise ValidationError("INVALID_VALUE", "QUOTE requires BID < ASK")

        payload: dict[str, Any] = {
            "gateway_id": self._require_gw(session),
            "symbol": symbol,
            # Ticks on the wire (design section 15.2, quotes joined in 6.1b).
            "tick_decimals": get_tick_decimals(symbol),
            "bid_price_ticks": self._ticks(bid, symbol, "BID"),
            "bid_qty": bid_qty,
            "ask_price_ticks": self._ticks(ask, symbol, "ASK"),
            "ask_qty": ask_qty,
            "tif": tif.value,
        }
        quote_id = fields.get("QUOTE_ID")
        if quote_id:
            payload["quote_id"] = quote_id

        self._send_to_engine(make_quote_new_msg(payload))

    def _handle_quote_cancel(
        self, session: ClientSession, fields: dict[str, str]
    ) -> None:
        self._require_role(session, "MARKET_MAKER")
        symbol = self._required_str(fields, "SYM")
        self._validate_symbol(symbol)
        self._send_to_engine(make_quote_cancel_msg(self._require_gw(session), symbol))

    def _handle_dc(self, session: ClientSession, fields: dict[str, str]) -> None:
        """Toggle asynchronous drop-copy relay for this session.

        ``DC|ON`` subscribes this session to the engine's drop-copy feed
        (``DROP_COPY_PUB_ADDR``, :5557) scoped to this session's own
        ``gateway_id`` -- every subsequent fill for this gateway arrives
        asynchronously as a ``DC_FILL`` line, mirroring how a real exchange
        relays drop copy down a participant's own session rather than
        requiring a separate connection. ``DC|OFF`` unsubscribes. Mirrors
        the on/off semantics of a real FIX drop-copy session being
        provisioned per participant -- see ../../../docs/books/protocols-and-clients/part-3-session-behaviour/060-drop-copy.md.
        """
        state = self._required_str(fields, "STATE")
        gateway_id = self._require_gw(session)

        if state == "ON":
            if not session.dc_enabled:
                self._dc_subscribe_topic(f"{_DC_EVENT_TOPIC_PREFIX}{gateway_id}")
                session.dc_enabled = True
            self._queue_line(session, "DC_ACK", {"STATE": "ON"})
            return
        if state == "OFF":
            if session.dc_enabled:
                self._dc_unsubscribe_topic(f"{_DC_EVENT_TOPIC_PREFIX}{gateway_id}")
                session.dc_enabled = False
            self._queue_line(session, "DC_ACK", {"STATE": "OFF"})
            return
        raise ValidationError("INVALID_VALUE", "DC STATE must be ON or OFF")

    def _handle_pos(self, session: ClientSession, fields: dict[str, str]) -> None:
        """``POS|GW=<gateway_id>``: ask the engine what that gateway (e.g.
        a running pm-mm-bot) is holding.

        Unlike ``pm-alf-console``'s bare ``POS`` (a local fill/P&L ledger
        this process has no equivalent of -- ``pm-alf-gwy`` is a stateless
        protocol relay), a bare ``POS`` here has nothing to answer with and
        stays rejected as interactive-only. ``GW=`` is required.

        ``system.position_request`` is a shared, non-gateway-scoped topic:
        any gateway may ask about any ``gateway_id`` (see
        ``engine/main.py::_handle_position_request``, which looks the id up
        directly with no sender-identity check). The reply arrives on
        ``system.position_snapshot.<target>``, covered by the prefix
        subscription made at startup, and is routed back by
        ``_handle_position_snapshot_response``.
        """
        target = fields.get("GW", "").upper()
        if not target:
            raise ValidationError("MISSING_FIELD", "POS requires GW=<gateway_id>")
        if not _GATEWAY_ID_RE.fullmatch(target):
            # The engine answers on a topic named after the (clamped) id; one
            # it would rename could never be matched to this query.
            raise ValidationError("INVALID_VALUE", f"GW: invalid gateway id '{target}'")
        self._send_to_engine(make_position_request_msg(target))
        # After the send: a request the engine never got gets no reply.
        session.pending_position_queries.add(target)

    def _handle_position_snapshot_response(
        self, gateway_id: str, payload: dict[str, Any]
    ) -> None:
        """Route a system.position_snapshot.<gateway_id> reply back to
        whichever session(s) currently have a POS|GW=<gateway_id> query
        outstanding.

        Cannot reuse ``_session_for_gateway`` here (that looks up the
        session whose *own* gateway_id matches -- always true for
        QBOOT/QLEGS/SESSION, never true for a cross-gateway POS query)
        so this scans connected sessions for a matching entry in
        ``pending_position_queries`` instead. More than one session may be
        querying the same target concurrently; every match is answered.
        """
        positions = payload.get("positions", [])
        if not isinstance(positions, list):
            positions = []
        for session in self._clients.values():
            if gateway_id not in session.pending_position_queries:
                continue
            session.pending_position_queries.discard(gateway_id)
            self._queue_line(
                session,
                "POSITION",
                {
                    "GW": gateway_id,
                    "COUNT": str(len(positions)),
                    # OK, NOT_CONNECTED or UNKNOWN_GATEWAY: an empty list
                    # is not "flat" for the last two (L030).
                    "STATUS": str(payload.get("status", "OK")),
                },
            )
            for pos in positions:
                if not isinstance(pos, dict):
                    continue
                self._queue_line(
                    session,
                    "POS_ENTRY",
                    {
                        "SYM": str(pos.get("symbol", "")),
                        "NET_QTY": str(pos.get("net_qty", "")),
                        "AVG_COST": str(pos.get("avg_cost", "")),
                    },
                )
            self._queue_line(session, "END", {"TYPE": "POSITION"})

    # ------------------------------------------------------------------
    # Engine event polling
    # ------------------------------------------------------------------

    def _poll_engine_events(self) -> None:
        budget = _MAX_ENGINE_EVENTS_PER_LOOP
        while budget > 0 and self._sub.poll(timeout=0):
            try:
                frames = self._sub.recv_multipart()
            except zmq.ZMQError as exc:
                if exc.errno != errno.EINTR:
                    log.warning(
                        "ALF gateway SUB recv error (errno=%s); dropping remaining events for this tick",
                        exc.errno,
                    )
                break

            budget -= 1

            try:
                topic = frames[0].decode()
                if self._for_absent_gateway(topic):
                    # Most of this socket is other gateways' order events
                    # (see the subscription). Their payload is never read,
                    # so it is not decoded: only the sequence is kept.
                    self._check_sequence(topic, frames)
                    continue
                topic, payload = decode(frames)
            except Exception:
                # Not sequence-checked: the next event on its topic reports
                # it as lost, which to the client it is.
                log.warning("decode error on engine SUB event", exc_info=True)
                continue

            # One malformed event must not take every session down with it
            # (the loop has no other guard): log it, drop it, carry on.
            try:
                self._check_sequence(topic, frames)
                self._handle_engine_event(topic, payload)
            except Exception:
                log.exception("ALF gateway dropped unhandled engine event %s", topic)

    def _for_absent_gateway(self, topic: str) -> bool:
        """A private order event for a gateway with no session here.

        Exactly what _route_gateway_scoped_event would discard. Replies
        routed otherwise (auth, symbols, POS) are never in this set.
        """
        return (
            topic.startswith(_PRIVATE_EVENT_PREFIXES)
            and topic.rpartition(".")[2].upper() not in self._active_gateway_sessions
        )

    def _check_sequence(self, topic: str, frames: list[bytes]) -> None:
        """Tell a session when the engine's events for it were dropped.

        The engine numbers each topic (``SequencedPublisher``), and this
        socket subscribes to every private family whole, so a jump means the
        PUB dropped events at the high-water mark: fills, acks or cancels
        the client will never see. The ERR comes before the event that
        revealed the gap, untagged like the other unsolicited ERRs, and
        tells the client to reconcile with ``ORDERS``.
        """
        if not topic.startswith(_PRIVATE_EVENT_PREFIXES):
            return
        seq = decode_sequence(frames)
        if seq is None:
            return
        last = self._topic_seq.get(topic)
        self._topic_seq[topic] = seq
        # First sight of the topic, or a lower number: the engine restarted.
        if last is None or seq <= last + 1:
            return
        missed = seq - last - 1
        self._global_stats["events_lost"] += missed
        family, _, gateway_id = topic.rpartition(".")
        log.warning("engine dropped %d event(s) on %s", missed, topic)
        session = self._session_for_gateway(gateway_id.upper())
        if session is None:
            return
        self._queue_line(
            session,
            "ERR",
            {
                "CODE": "EVENTS_LOST",
                "TOPIC": family,
                "COUNT": str(missed),
                "DETAIL": "Exchange events for this session were lost - "
                "reconcile with ORDERS",
            },
        )

    def _handle_engine_event(self, topic: str, payload: dict[str, Any]) -> None:
        if topic.startswith(PREFIX_GATEWAY_AUTH):
            gateway_id = topic.rsplit(".", 1)[-1].upper()
            self._handle_gateway_auth(gateway_id, payload)
            return

        if topic.startswith(PREFIX_SYMBOLS):
            gateway_id = topic.rsplit(".", 1)[-1].upper()
            self._handle_symbols_response(gateway_id, payload)
            return

        if topic.startswith(PREFIX_ORDERS):
            gateway_id = topic.rsplit(".", 1)[-1].upper()
            self._handle_orders_response(gateway_id, payload)
            return

        if topic.startswith(PREFIX_QUOTE_BOOTSTRAP):
            gateway_id = topic.rsplit(".", 1)[-1].upper()
            self._handle_qboot_response(gateway_id, payload)
            return

        if topic.startswith(PREFIX_QUOTE_LEGS):
            gateway_id = topic.rsplit(".", 1)[-1].upper()
            self._handle_qlegs_response(gateway_id, payload)
            return

        if topic.startswith(PREFIX_POSITION_SNAPSHOT):
            gateway_id = topic.rsplit(".", 1)[-1].upper()
            self._handle_position_snapshot_response(gateway_id, payload)
            return

        if topic.startswith(PREFIX_SESSION_STATUS):
            gateway_id = topic.rsplit(".", 1)[-1].upper()
            self._handle_session_status_response(gateway_id, payload)
            return

        if topic == TOPIC_STARTUP_RECOVERY:
            self._handle_engine_restart()
            return

        if topic.startswith(PREFIX_GATEWAYS + _PROBE_ID_PREFIX):
            self._handle_session_probe(topic.rsplit(".", 1)[-1], payload)
            return

        if topic == TOPIC_SESSION_STATE:
            self._broadcast(
                "SESSION",
                {
                    "STATE": str(payload.get("state", "")),
                    "PREV_STATE": str(payload.get("prev_state", "")),
                },
            )
            return

        if topic.startswith(PREFIX_CIRCUIT_BREAKER_HALT):
            self._broadcast(
                "HALT",
                {
                    "SYMBOL": str(payload.get("symbol", "")),
                    "LEVEL": str(payload.get("level", "")),
                },
            )
            return

        if topic.startswith(PREFIX_CIRCUIT_BREAKER_RESUME):
            self._broadcast(
                "RESUME",
                {
                    "SYMBOL": str(payload.get("symbol", "")),
                    "SRC": str(payload.get("halt_source", "")),
                },
            )
            return

        if topic == TOPIC_TRADE_EXECUTED:
            self._broadcast(
                "TRADE",
                {
                    "SYMBOL": str(payload.get("symbol", "")),
                    "PRICE": str(payload.get("price", "")),
                    "QTY": str(payload.get("quantity", "")),
                    "SIDE": str(payload.get("aggressor_side", "")),
                },
            )
            return

        self._route_gateway_scoped_event(topic, payload)

    def _poll_dc_events(self) -> None:
        """Poll the drop-copy SUB socket (:5557) and relay to subscribed sessions.

        Separate from :meth:`_poll_engine_events` because drop copy lives on
        its own ZMQ PUB socket, distinct from the main event bus (:5556).
        Only sessions that sent ``DC|ON`` are subscribed to any topic on
        this socket at all (see ``_handle_dc``/``_dc_subscribe_topic``), so
        this poll is a no-op whenever no connected session has opted in.
        """
        budget = _MAX_DC_EVENTS_PER_LOOP
        while budget > 0 and self._dc_sub.poll(timeout=0):
            try:
                topic, payload = decode(self._dc_sub.recv_multipart())
            except zmq.ZMQError as exc:
                if exc.errno != errno.EINTR:
                    log.warning(
                        "ALF gateway drop-copy SUB recv error (errno=%s); "
                        "dropping remaining DC events for this tick",
                        exc.errno,
                    )
                break
            except Exception:
                log.warning("decode error on drop-copy SUB event", exc_info=True)
                budget -= 1
                continue

            budget -= 1

            if not topic.startswith(_DC_EVENT_TOPIC_PREFIX):
                continue
            gateway_id = topic[len(_DC_EVENT_TOPIC_PREFIX) :].upper()
            session = self._session_for_gateway(gateway_id)
            if session is None or not session.dc_enabled:
                continue

            try:
                self._queue_line(
                    session,
                    "DC_FILL",
                    {
                        "SEQ": str(payload.get("seq", "")),
                        "ORDER_ID": str(payload.get("order_id", "")),
                        "SYMBOL": str(payload.get("symbol", "")),
                        "FILL_QTY": str(payload.get("fill_qty", "")),
                        "FILL_PRICE": str(payload.get("fill_price", "")),
                        "LIQUIDITY": str(payload.get("liquidity_flag", "")),
                    },
                )
            except Exception:
                log.exception("ALF gateway dropped unhandled drop-copy event %s", topic)

    def _handle_gateway_auth(self, gateway_id: str, payload: dict[str, Any]) -> None:
        target = self._find_pending_auth_session(gateway_id)
        if target is None:
            return

        accepted = bool(payload.get("accepted", False))
        reason = str(payload.get("reason", ""))

        if not accepted:
            self._global_stats["auth_failures"] += 1
            target.auth_pending = False
            # The engine refused this connect, so it holds no session for it;
            # a disconnect sent on close would tear down the one that does.
            target.connect_emitted = False
            self._register_error(
                target,
                "AUTH_FAILED",
                reason or f"Gateway not configured: {gateway_id}",
                close_connection=True,
            )
            return

        target.auth_pending = False
        target.authenticated = True
        target.authenticated_at = time.monotonic()
        target.gateway_id = gateway_id
        target.role = self._gateway_roles.get(gateway_id, "TRADER")
        self._active_gateway_sessions[gateway_id] = target.sock.fileno()

        self._queue_line(
            target,
            "WELCOME",
            {
                "PROTO": "ALF1",
                "GW": self.config.name,
                "ID": gateway_id,
                "HBINT": str(self.config.heartbeat_interval_sec),
                "IDLE": str(self.config.idle_timeout_sec),
            },
        )

        if self._symbols_reply is not None:
            for line in self._symbols_reply:
                self._queue_raw(target, line)
        else:
            self._send_to_engine(
                make_symbols_request_msg(gateway_id), count_as_command=False
            )

        held, target.held_lines = target.held_lines, []
        for held_line in held:
            self._handle_client_line(target, held_line)

    def _handle_symbols_response(
        self, gateway_id: str, payload: dict[str, Any]
    ) -> None:
        entries = [e for e in payload.get("symbols", []) if isinstance(e, dict)]
        ticks: dict[str, int] = {}
        symbols: list[str] = []
        for entry in entries:
            sym = str(entry.get("symbol", "")).upper()
            if not sym:
                continue
            symbols.append(sym)
            tick_decimals = entry.get("tick_decimals")
            if isinstance(tick_decimals, int):
                ticks[sym] = tick_decimals
                register_tick_decimals(sym, tick_decimals)

        # order_new declares symbol max_len 16. The gateway no longer pays
        # for that check per order (see _handle_new_single), so it is made
        # once here, against the only source symbols ever come from. A symbol
        # this long is a configuration error, and discovering it on the first
        # order of the day would be a poor place to learn about it.
        oversized = [sym for sym in symbols if len(sym) > _MAX_SYMBOL_LEN]
        if oversized:
            log.error(
                "engine sent symbol(s) longer than the %d-character wire limit; "
                "orders for them will be refused: %s",
                _MAX_SYMBOL_LEN,
                ", ".join(sorted(oversized)),
            )
        symbols = [sym for sym in symbols if len(sym) <= _MAX_SYMBOL_LEN]

        # Replace, never union: a symbol the engine has stopped listing must
        # stop being tradable with this snapshot, not linger until restart.
        self._symbols_snapshot_loaded = True
        self._known_symbols = set(symbols)

        reply = [build_line("SYMBOLS", {"COUNT": str(len(symbols))})]
        for sym in symbols:
            # TICK stays the tick size on the CALF wire — the value a client
            # multiplies a price by. The engine now sends the exponent, so the
            # conversion happens here instead of `_infer_decimals` undoing it.
            decimals = ticks.get(sym)
            tick = "" if decimals is None else f"{10 ** -decimals:.{decimals}f}"
            reply.append(build_line("SYMBOL", {"SYM": sym, "TICK": tick}))
        reply.append(build_line("END", {"TYPE": "SYMBOLS"}))
        self._symbols_reply = reply

        session = self._session_for_gateway(gateway_id)
        if session is None:
            return
        for line in reply:
            self._queue_raw(session, line)

    def _handle_orders_response(self, gateway_id: str, payload: dict[str, Any]) -> None:
        session = self._session_for_gateway(gateway_id)
        if session is None:
            return

        orders = payload.get("orders", [])
        if not isinstance(orders, list):
            orders = []

        self._queue_line(
            session,
            "ORDERS",
            {"COUNT": str(len(orders)), "GW": gateway_id},
        )

        for od in orders:
            if not isinstance(od, dict):
                continue
            fields = {
                "ID": str(od.get("id", "")),
                "SYM": str(od.get("symbol", "")),
                "SIDE": str(od.get("side", "")),
                "TYPE": str(od.get("order_type", "")),
                "QTY": str(od.get("quantity", "")),
                "REMAINING": str(od.get("remaining_qty", "")),
                "PRICE": (
                    str(od.get("price", "")) if od.get("price") is not None else ""
                ),
                "STATUS": str(od.get("status", "")),
            }
            self._queue_line(session, "ORDER", fields)

        self._queue_line(session, "END", {"TYPE": "ORDERS"})

    def _handle_qboot_response(self, gateway_id: str, payload: dict[str, Any]) -> None:
        session = self._session_for_gateway(gateway_id)
        if session is None:
            return

        quotes = payload.get("quotes", [])
        if not isinstance(quotes, list):
            quotes = []

        self._queue_line(session, "QBOOT", {"COUNT": str(len(quotes))})
        for quote in quotes:
            if not isinstance(quote, dict):
                continue
            self._queue_line(
                session,
                "QUOTE",
                {
                    "QUOTE_ID": str(quote.get("quote_id", "")),
                    "SYM": str(quote.get("symbol", "")),
                    "BID": str(quote.get("bid_price", "")),
                    "ASK": str(quote.get("ask_price", "")),
                    "BID_QTY": str(quote.get("bid_qty", "")),
                    "ASK_QTY": str(quote.get("ask_qty", "")),
                    # ActiveQuote names it ``state`` (L015).
                    "STATUS": str(quote.get("state", "")),
                },
            )
        self._queue_line(session, "END", {"TYPE": "QBOOT"})

    def _handle_qlegs_response(self, gateway_id: str, payload: dict[str, Any]) -> None:
        session = self._session_for_gateway(gateway_id)
        if session is None:
            return

        legs = payload.get("legs", [])
        if not isinstance(legs, list):
            legs = []
        recent = payload.get("recent", [])
        if not isinstance(recent, list):
            recent = []
        show_requested = str(payload.get("show_requested", "ACTIVE"))

        self._queue_line(
            session,
            "QLEGS",
            {
                "COUNT": str(len(legs)),
                "RECENT_COUNT": str(len(recent)),
                "SHOW": show_requested,
            },
        )
        for leg in legs:
            if not isinstance(leg, dict):
                continue
            self._queue_line(
                session,
                "LEG",
                {
                    "QUOTE_ID": str(leg.get("quote_id", "")),
                    "SYM": str(leg.get("symbol", "")),
                    "SIDE": str(leg.get("leg_side", "")),
                    "ORDER_ID": str(leg.get("order_id", "")),
                    # Display money, straight from the engine. Empty rather
                    # than a placeholder when absent, matching every other
                    # optional PRICE on this wire.
                    "PRICE": (
                        str(leg.get("price", ""))
                        if leg.get("price") is not None
                        else ""
                    ),
                    "QTY": str(leg.get("qty", "")),
                    "REMAINING": str(leg.get("remaining", "")),
                    "FILLED": str(leg.get("filled", "")),
                    "STATUS": str(leg.get("status", "")),
                    "QUOTE_STATUS": str(leg.get("quote_status", "")),
                },
            )
        for entry in recent:
            if not isinstance(entry, dict):
                continue
            quote_id = str(entry.get("quote_id", ""))
            self._queue_line(
                session,
                "RECENT_LEG",
                {
                    "QUOTE_ID": quote_id,
                    "SYM": str(entry.get("symbol", "")),
                    "QUOTE_STATUS": str(entry.get("quote_status", "")),
                    "REASON": str(entry.get("reason", "")),
                    "REMOVED_AT_NS": str(entry.get("removed_at_ns", "")),
                },
            )
            # Per-leg detail (price/qty/remaining/filled/status), when the
            # engine had it available at removal time — see
            # docs-design/EduMatcher-QLEGS-RECENT.md §9.3. Emitted as
            # separate, optional lines rather than folded into RECENT_LEG's
            # field set so existing parsers of RECENT_LEG are unaffected,
            # and so a missing snapshot (bid_leg/ask_leg is None) is simply
            # the absence of a line rather than a row of blank fields.
            for leg_line_type, leg_field, leg_side in (
                ("RECENT_BID_LEG", "bid_leg", "BUY"),
                ("RECENT_ASK_LEG", "ask_leg", "SELL"),
            ):
                leg = entry.get(leg_field)
                if not isinstance(leg, dict):
                    continue
                self._queue_line(
                    session,
                    leg_line_type,
                    {
                        "QUOTE_ID": quote_id,
                        "SIDE": leg_side,
                        "ORDER_ID": str(leg.get("order_id", "")),
                        "PRICE": (
                            str(leg.get("price", ""))
                            if leg.get("price") is not None
                            else ""
                        ),
                        "QTY": str(leg.get("qty", "")),
                        "REMAINING": str(leg.get("remaining", "")),
                        "FILLED": str(leg.get("filled", "")),
                        "STATUS": str(leg.get("status", "")),
                    },
                )
        self._queue_line(session, "END", {"TYPE": "QLEGS"})

    def _handle_session_status_response(
        self, gateway_id: str, payload: dict[str, Any]
    ) -> None:
        """Reply to a client-initiated ``SESSION`` query.

        Reuses the ``SESSION`` message type already emitted for unsolicited
        session-state broadcasts (see ``_poll_engine_events``'s
        ``session.state`` branch) so existing clients/parsers only need to
        recognise one line shape for "current session state" — whether it
        arrived because the state changed or because it was explicitly
        queried. ``PREV_STATE`` is left empty here since a query has no
        previous state to report.
        """
        session = self._session_for_gateway(gateway_id)
        if session is None:
            return

        self._queue_line(
            session,
            "SESSION",
            {
                "STATE": str(payload.get("state", "")),
                "PREV_STATE": "",
                "SESSIONS_ENABLED": (
                    "TRUE" if bool(payload.get("sessions_enabled", True)) else "FALSE"
                ),
            },
        )

    def _route_gateway_scoped_event(self, topic: str, payload: dict[str, Any]) -> None:
        if "." not in topic:
            return
        gateway_id = topic.rsplit(".", 1)[-1].upper()
        session = self._session_for_gateway(gateway_id)
        if session is None:
            return

        fields: dict[str, str] | None = None
        msg_type: str | None = None

        if topic.startswith(PREFIX_ORDER_ACK):
            msg_type = "ACK"
            fields = {
                "ORDER_ID": str(payload.get("order_id", "")),
                "ACCEPTED": "TRUE" if bool(payload.get("accepted", False)) else "FALSE",
                "REASON": str(payload.get("reason", "")),
                "SYMBOL": str(payload.get("symbol", "")),
                "SIDE": str(payload.get("side", "")),
                "TYPE": str(payload.get("order_type", "")),
            }
            if payload.get("reject_code") is not None:
                fields["REJECT_CODE"] = str(payload["reject_code"])
            if payload.get("client_tag") is not None:
                fields["TAG"] = str(payload["client_tag"])
            if payload.get("request_tag") is not None:
                fields["RTAG"] = str(payload["request_tag"])
        elif topic.startswith(PREFIX_ORDER_FILL):
            msg_type = "FILL"
            fields = {
                "ORDER_ID": str(payload.get("order_id", "")),
                "FILL_QTY": str(payload.get("fill_qty", "")),
                "FILL_PRICE": str(payload.get("fill_price", "")),
                "REMAINING": str(payload.get("remaining_qty", "")),
                "STATUS": str(payload.get("status", "")),
                # SYMBOL/SIDE let a client book a fill it no longer (or not
                # yet) tracks -- an OCO leg filling before its ack, an order
                # from before a reconnect -- into the right position.
                "SYMBOL": str(payload.get("symbol", "")),
                "SIDE": str(payload.get("side", "")),
                "TRADE_IDS": ",".join(
                    str(trade_id) for trade_id in payload.get("trade_ids", [])
                ),
            }
            if payload.get("client_tag") is not None:
                fields["TAG"] = str(payload["client_tag"])
            # G9: maker/taker attribution on the private fill, matching the
            # drop-copy DC_FILL line's existing LIQUIDITY field.
            if payload.get("liquidity_flag") is not None:
                fields["LIQUIDITY"] = str(payload["liquidity_flag"])
        elif topic.startswith(PREFIX_ORDER_AMENDED):
            msg_type = "AMENDED"
            fields = {
                "ORDER_ID": str(payload.get("order_id", "")),
                "PRICE": (
                    str(payload.get("price", ""))
                    if payload.get("price") is not None
                    else ""
                ),
                "QTY": str(payload.get("qty", "")),
                "REMAINING": str(payload.get("remaining_qty", "")),
                "PRIORITY_RESET": (
                    "TRUE" if bool(payload.get("priority_reset", False)) else "FALSE"
                ),
            }
            if payload.get("client_tag") is not None:
                fields["TAG"] = str(payload["client_tag"])
            if payload.get("request_tag") is not None:
                fields["RTAG"] = str(payload["request_tag"])
        elif topic.startswith(PREFIX_ORDER_TRIGGERED):
            # A stop fired; sent before the fills it explains.
            msg_type = "TRIGGERED"
            symbol = str(payload.get("symbol", ""))
            fields = {
                "ORDER_ID": str(payload.get("order_id", "")),
                "SYMBOL": symbol,
                "TYPE": str(payload.get("order_type", "")),
                "STOP": format_price_ticks(int(payload["stop_price_ticks"]), symbol),
                "BECOMES": str(payload.get("becomes", "")),
            }
            if payload.get("trigger_trade_id") is not None:
                fields["TRADE_ID"] = str(payload["trigger_trade_id"])
            if payload.get("trigger_price_ticks") is not None:
                fields["TRADE_PRICE"] = format_price_ticks(
                    int(payload["trigger_price_ticks"]), symbol
                )
            if payload.get("client_tag") is not None:
                fields["TAG"] = str(payload["client_tag"])
        elif topic.startswith(PREFIX_ORDER_CANCELLED):
            msg_type = "CANCELLED"
            fields = {"ORDER_ID": str(payload.get("order_id", ""))}
            if payload.get("client_tag") is not None:
                fields["TAG"] = str(payload["client_tag"])
            if payload.get("request_tag") is not None:
                fields["RTAG"] = str(payload["request_tag"])
            if payload.get("cancel_reason") is not None:
                fields["CANCEL_REASON"] = str(payload["cancel_reason"])
        elif topic.startswith(PREFIX_ORDER_EXPIRED):
            msg_type = "EXPIRED"
            fields = {"ORDER_ID": str(payload.get("order_id", ""))}
            if payload.get("client_tag") is not None:
                fields["TAG"] = str(payload["client_tag"])
        elif topic.startswith(PREFIX_QUOTE_ACK):
            msg_type = "QUOTE_ACK"
            fields = {
                "QUOTE_ID": str(payload.get("quote_id", "")),
                # SYM lets a text client tell which instrument an ack is for
                # without keeping its own book of outstanding quotes — the
                # topic is per-gateway, not per-symbol. Empty only when the
                # quote was rejected before its symbol was known.
                "SYM": str(payload.get("symbol", "")),
                "ACCEPTED": "TRUE" if bool(payload.get("accepted", False)) else "FALSE",
                "REASON": str(payload.get("reason", "")),
                "BID_ID": str(payload.get("bid_order_id", "")),
                "ASK_ID": str(payload.get("ask_order_id", "")),
            }
        elif topic.startswith(PREFIX_QUOTE_STATUS):
            msg_type = "QUOTE_STATUS"
            fields = {
                "QUOTE_ID": str(payload.get("quote_id", "")),
                "STATUS": str(payload.get("status", "")),
                "REASON": str(payload.get("reason", "")),
            }
        elif topic.startswith(PREFIX_COMBO_ACK):
            msg_type = "COMBO_ACK"
            fields = {
                "COMBO_ID": str(payload.get("combo_id", "")),
                "ACCEPTED": "TRUE" if bool(payload.get("accepted", False)) else "FALSE",
                "REASON": str(payload.get("reason", "")),
            }
        elif topic.startswith(PREFIX_COMBO_STATUS):
            msg_type = "COMBO_STATUS"
            reason = str(payload.get("reason", ""))
            fields = {
                "COMBO_ID": str(payload.get("combo_id", "")),
                "STATUS": str(payload.get("status", "")),
                "REASON": reason,
            }
        elif topic.startswith(PREFIX_OCO_ACK):
            msg_type = "OCO_ACK"
            fields = {
                "OCO_ID": str(payload.get("oco_id", "")),
                "ACCEPTED": "TRUE" if bool(payload.get("accepted", False)) else "FALSE",
                "LEG1_ID": str(payload.get("order_id_1", "")),
                "LEG2_ID": str(payload.get("order_id_2", "")),
                "REASON": str(payload.get("reason", "")),
            }
        elif topic.startswith(PREFIX_OCO_CANCELLED):
            msg_type = "OCO_CANCELLED"
            fields = {
                "OCO_ID": str(payload.get("oco_id", "")),
                "CANCELLED_ID": str(payload.get("cancelled_order_id", "")),
                "REASON": str(payload.get("reason", "")),
            }
        # WP-API17 moved structure-cancel outcomes onto their own *.cancel_ack
        # topics. ALF is frozen at 1.0, so they are rendered as the frames an
        # ALF client always got for them: the submit-ack frame for a refusal
        # (and for every quote cancel), and nothing for an accepted OCO or
        # combo cancel, whose leg cancels and COMBO_STATUS say it.
        elif topic.startswith(PREFIX_OCO_CANCEL_ACK):
            if not bool(payload.get("accepted", False)):
                msg_type = "OCO_ACK"
                fields = {
                    "OCO_ID": str(payload.get("oco_id", "")),
                    "ACCEPTED": "FALSE",
                    "LEG1_ID": "",
                    "LEG2_ID": "",
                    "REASON": str(payload.get("reason", "")),
                }
        elif topic.startswith(PREFIX_COMBO_CANCEL_ACK):
            if not bool(payload.get("accepted", False)):
                msg_type = "COMBO_ACK"
                fields = {
                    "COMBO_ID": str(payload.get("combo_id", "")),
                    "ACCEPTED": "FALSE",
                    "REASON": str(payload.get("reason", "")),
                }
        elif topic.startswith(PREFIX_QUOTE_CANCEL_ACK):
            msg_type = "QUOTE_ACK"
            fields = {
                "QUOTE_ID": str(payload.get("quote_id", "")),
                "SYM": str(payload.get("symbol", "")),
                "ACCEPTED": "TRUE" if bool(payload.get("accepted", False)) else "FALSE",
                "REASON": str(payload.get("reason", "")),
                "BID_ID": "",
                "ASK_ID": "",
            }
        elif topic.startswith(PREFIX_KILL_SWITCH_ACK):
            msg_type = "KILL_ACK"
            fields = {
                "ACCEPTED": "TRUE" if bool(payload.get("accepted", False)) else "FALSE",
                "REASON": str(payload.get("reason", "")),
                "ORDERS": str(payload.get("cancelled_orders", 0)),
                "QUOTES": str(payload.get("cancelled_quotes", 0)),
            }

        if msg_type is not None and fields is not None:
            self._queue_line(session, msg_type, fields)

    def _probe_engine_sessions_if_due(self, now: float) -> None:
        if now < self._next_probe:
            return
        self._next_probe = now + _SESSION_PROBE_SEC
        # A probe the engine never answered (it was down) is forgotten.
        self._probes = {pid: at for pid, at in self._probes.items() if now - at < 60.0}
        if not any(s.authenticated for s in self._clients.values()):
            return
        self._probe_seq += 1
        probe_id = f"{_PROBE_ID_PREFIX}{self._probe_seq}"
        self._probes[probe_id] = now
        self._send_to_engine(
            make_gateways_request_msg(probe_id),
            count_as_command=False,
            require_engine=False,
        )

    def _handle_session_probe(self, probe_id: str, payload: dict[str, Any]) -> None:
        """Drop every session the engine does not hold, of those that were
        logged on before the probe was sent."""
        sent_at = self._probes.pop(probe_id, None)
        if sent_at is None:
            return
        held = {
            str(g.get("id", "")).upper()
            for g in payload.get("gateways", [])
            if isinstance(g, dict) and g.get("connected")
        }
        for session in list(self._clients.values()):
            if (
                session.authenticated
                and session.authenticated_at < sent_at
                and session.gateway_id not in held
            ):
                self._drop_lost_session(
                    session, "The exchange no longer holds this session"
                )

    def _drop_lost_session(self, session: ClientSession, detail: str) -> None:
        """Close a session the engine has forgotten, so its client logs on again."""
        # Nothing to disconnect on the engine side.
        session.connect_emitted = False
        self._register_error(
            session,
            "SESSION_LOST",
            f"{detail} - log on again",
            close_connection=True,
        )

    def _handle_engine_restart(self) -> None:
        """A restarted engine holds no sessions: every one here is dead."""
        lost = [s for s in self._clients.values() if s.authenticated or s.auth_pending]
        # A first start also announces itself; with no session to lose it is
        # not news.
        log.log(
            logging.WARNING if lost else logging.INFO,
            "engine (re)started; closing %d session(s) so their clients log on again",
            len(lost),
        )
        # Its configuration may have changed with it, so the symbol set this
        # gateway validates against is stale until a fresh snapshot arrives.
        self._symbols_reply = None
        self._symbols_snapshot_loaded = False
        self._known_symbols = set()
        # Its topic counters restarted at 1.
        self._topic_seq.clear()
        for session in lost:
            self._drop_lost_session(session, "The exchange engine restarted")

    # ------------------------------------------------------------------
    # Maintenance
    # ------------------------------------------------------------------

    def _send_heartbeats_if_due(self) -> None:
        now = time.monotonic()
        for session in self._clients.values():
            if not session.authenticated or session.closing:
                continue
            if now - session.last_outbound < self.config.heartbeat_interval_sec:
                continue
            self._queue_line(session, "HB", {"TS": iso_utc(time.time())})

    def _send_engine_heartbeats_if_due(self) -> None:
        """Tell the engine each authenticated session is still alive.

        One beat per session, so a session that closes stops being reported
        and the engine frees its ID if the disconnect never reaches it.
        """
        now = time.monotonic()
        for session in self._clients.values():
            if not session.authenticated or session.closing or not session.gateway_id:
                continue
            if now - session.last_engine_heartbeat < _ENGINE_HEARTBEAT_SEC:
                continue
            session.last_engine_heartbeat = now
            log.debug("engine heartbeat sent gateway_id=%s", session.gateway_id)
            self._send_to_engine(
                make_gateway_heartbeat_msg(session.gateway_id, _ENGINE_HEARTBEAT_SEC),
                count_as_command=False,
                require_engine=False,
            )

    def _drop_idle_clients(self) -> None:
        now = time.monotonic()
        for session in list(self._clients.values()):
            if session.closing:
                # Already told why; only the flush is outstanding.
                if now - session.closing_since > _CLOSE_GRACE_SEC:
                    self._disconnect(session, reason="close_timeout")
                continue
            if (
                session.read_closed_since
                and now - session.read_closed_since >= _HALF_CLOSE_GRACE_SEC
            ):
                # The client can send nothing more; what it was owed has had
                # its chance to arrive.
                self._close_after_flush(session)
                continue
            if (
                not session.authenticated
                and now - session.connected_at > self.config.handshake_timeout_sec
            ):
                self._queue_line(
                    session,
                    "ERR",
                    {
                        "CODE": "AUTH_TIMEOUT",
                        "DETAIL": "Handshake timeout",
                    },
                )
                self._close_after_flush(session)
                continue

            if now - session.last_activity <= self.config.idle_timeout_sec:
                continue
            self._queue_line(
                session,
                "ERR",
                {"CODE": "IDLE_TIMEOUT", "DETAIL": "Session idle timeout"},
            )
            self._close_after_flush(session)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _required_str(
        self, fields: dict[str, str], key: str, *, default: str | None = None
    ) -> str:
        if key in fields:
            value = fields[key].strip()
            if value:
                return value
        if default is not None:
            return default
        raise ValidationError("MISSING_FIELD", f"{key} is required")

    @staticmethod
    def _ticks(price: float, symbol: str, field: str) -> int:
        """Convert a client price to ticks, refusing one off the tick grid.

        ``to_ticks`` would round it instead, so a client that asked for
        100.005 on a 2-decimal symbol would silently get a resting order at a
        price it never sent. The legacy ``CODE=`` stays ``INVALID_VALUE`` so
        the existing ERR vocabulary is unchanged; ``REJECT_CODE`` carries the
        machine-readable answer.
        """
        try:
            ticks = to_ticks_exact(price, symbol)
        except TickViolation as exc:
            raise ValidationError(
                "INVALID_VALUE", f"{field}: {exc}", "TICK_VIOLATION"
            ) from exc
        except OverflowError as exc:  # a finite price whose ticks are not
            raise ValidationError("INVALID_VALUE", f"{field}: out of range") from exc
        if abs(ticks) > _MAX_ABS_TICKS:
            raise ValidationError("INVALID_VALUE", f"{field}: out of range")
        return ticks

    def _optional_tag(self, fields: dict[str, str], key: str) -> str | None:
        if key not in fields:
            return None
        value = fields[key].strip()
        if not value:
            return None
        if len(value) > 64:
            raise ValidationError("INVALID_VALUE", f"{key} exceeds 64 characters")
        if any(ch not in _TAG_ALLOWED for ch in value):
            raise ValidationError("INVALID_VALUE", f"{key} contains illegal character")
        return value

    @staticmethod
    def _error_tag_for(cmd: str, fields: dict[str, str]) -> str | None:
        key = "RTAG" if cmd in {"AMEND", "CANCEL"} else "TAG"
        value = fields.get(key)
        if value is None:
            return None
        return value[:64] or None

    def _parse_side(self, raw: str) -> Side:
        try:
            return Side(raw)
        except ValueError as exc:
            raise ValidationError(
                "INVALID_VALUE", f"SIDE: invalid value '{raw}'"
            ) from exc

    def _parse_order_type(self, raw: str) -> OrderType:
        try:
            return OrderType(raw)
        except ValueError as exc:
            raise ValidationError(
                "INVALID_VALUE", f"TYPE: invalid value '{raw}'"
            ) from exc

    def _parse_tif(self, raw: str) -> TIF:
        try:
            return TIF(raw)
        except ValueError as exc:
            raise ValidationError(
                "INVALID_VALUE", f"TIF: invalid value '{raw}'"
            ) from exc

    def _parse_smp(self, raw: str) -> SmpAction:
        try:
            return SmpAction(raw)
        except ValueError as exc:
            raise ValidationError(
                "INVALID_VALUE", f"SMP: invalid value '{raw}'"
            ) from exc

    def _parse_combo_type(self, raw: str) -> ComboType:
        try:
            return ComboType(raw)
        except ValueError as exc:
            raise ValidationError(
                "INVALID_VALUE", f"COMBO_TYPE: invalid value '{raw}'"
            ) from exc

    def _validate_symbol(self, symbol: str) -> None:
        if not self._symbols_snapshot_loaded:
            raise ValidationError(
                "SYMBOLS_NOT_READY",
                "Symbol metadata not loaded yet; retry shortly",
            )
        if symbol not in self._known_symbols:
            raise ValidationError("SYMBOL_NOT_CONFIGURED", f"Unknown symbol: {symbol}")

    def _require_gw(self, session: ClientSession) -> str:
        if session.gateway_id is None:
            raise ValidationError("AUTH_REQUIRED", "Session not authenticated")
        return session.gateway_id

    def _require_role(self, session: ClientSession, required: str) -> None:
        if session.role != required:
            raise ValidationError(
                "ROLE_DENIED",
                f"Command requires role {required}; current role is {session.role}",
            )

    def _allow_command_now(self, session: ClientSession) -> bool:
        now = time.monotonic()
        elapsed = now - session.rate_updated
        session.rate_updated = now

        max_rate = float(self.config.max_commands_per_second)
        session.rate_tokens = min(max_rate, session.rate_tokens + elapsed * max_rate)
        if session.rate_tokens < 1.0:
            return False

        session.rate_tokens -= 1.0
        return True

    def _queue_line(
        self, session: ClientSession, msg_type: str, fields: dict[str, str]
    ) -> None:
        try:
            line = build_line(msg_type, fields)
        except AlfProtocolError:
            # Engine text relayed as-is (a REASON, say) may hold the field
            # separator. Deliver it with the '|' blanked, as build_line does
            # for newlines, rather than lose the event; retried only on
            # failure so the hot path pays nothing.
            line = build_line(
                msg_type, {k: str(v).replace("|", " ") for k, v in fields.items()}
            )
        self._queue_raw(session, line)

    def _queue_raw(self, session: ClientSession, payload: bytes) -> None:
        if session.closing:
            # Its last line (the reason it is closing) is queued; anything
            # after it would only delay the close or follow the goodbye.
            return
        if len(session.out_queue) >= self.config.max_client_queue:
            self._global_stats["slow_client_disconnects"] += 1
            queued = iter(session.out_queue)
            kept: deque[bytes] = deque()
            if session.out_offset:
                # A line already partly on the wire must be finished, or the
                # ERR is glued onto its first half and the client parses a
                # corrupt frame instead of the reason it is being dropped.
                kept.append(next(queued)[session.out_offset :])
            # The overflow is the public feed's doing; the client's own
            # events (fills, acks, cancels) still go out ahead of the ERR,
            # for as long as the close grace lets it drain them.
            kept.extend(line for line in queued if not line.startswith(_SHEDDABLE))
            if not payload.startswith(_SHEDDABLE):
                kept.append(payload)
            kept.append(
                b"ERR|CODE=SLOW_CLIENT|DETAIL=Outbound queue full - disconnecting\n"
            )
            session.out_queue = kept
            session.out_offset = 0
            self._close_after_flush(session)
            return
        session.out_queue.append(payload)
        self._dirty.add(session.sock.fileno())

    def _send_to_engine(
        self,
        frames: list[bytes],
        *,
        count_as_command: bool = True,
        require_engine: bool = True,
    ) -> None:
        try:
            self._push.send_multipart(frames)
        except zmq.Again:
            if self._push.closed:
                return
            if not require_engine:
                return
            raise ValidationError(
                "ENGINE_UNAVAILABLE",
                "Engine unavailable: command not forwarded; retry shortly",
            )
        except zmq.ZMQError as exc:
            if self._push.closed:
                return
            if exc.errno == zmq.EAGAIN:
                if not require_engine:
                    return
                raise ValidationError(
                    "ENGINE_UNAVAILABLE",
                    "Engine unavailable: command not forwarded; retry shortly",
                )
            raise
        if count_as_command:
            self._global_stats["commands_forwarded_total"] += 1

    def _register_error(
        self,
        session: ClientSession,
        code: str,
        detail: str,
        *,
        close_connection: bool,
        reject_code: RejectCode | None = None,
        tag: str | None = None,
    ) -> None:
        self._global_stats["errors_total"] += 1
        session.errors += 1
        fields = {
            "CODE": code,
            "REJECT_CODE": str(
                reject_code or ValidationError(code, detail).reject_code
            ),
            "DETAIL": detail,
        }
        if tag:
            fields["TAG"] = tag
        self._queue_line(session, "ERR", fields)
        self._rejects.report(
            fields["REJECT_CODE"],
            session.gateway_id or "",
            f"{session.addr[0]}:{session.addr[1]}",
            detail,
        )
        log.debug(
            "[%s] rejected code=%s reject_code=%s detail=%s",
            session.gateway_id or session.addr,
            code,
            fields["REJECT_CODE"],
            detail,
        )

        now = time.monotonic()
        session.error_times.append(now)
        while (
            session.error_times
            and now - session.error_times[0] > self.config.error_window_sec
        ):
            session.error_times.popleft()

        if len(session.error_times) >= self.config.max_errors_before_disconnect:
            self._queue_line(
                session,
                "ERR",
                {
                    "CODE": "MAX_ERRORS",
                    "DETAIL": "Too many protocol errors - disconnecting",
                },
            )
            close_connection = True

        if close_connection:
            self._close_after_flush(session)

    def _close_after_flush(self, session: ClientSession) -> None:
        if not session.closing:
            session.closing = True
            session.closing_since = time.monotonic()
        self._dirty.add(session.sock.fileno())

    def _disconnect(self, session: ClientSession, *, reason: str) -> None:
        gateway_id = session.gateway_id
        log.info("[%s] disconnected reason=%s", gateway_id or session.addr, reason)

        if (
            gateway_id
            and self._active_gateway_sessions.get(gateway_id) == session.sock.fileno()
        ):
            self._active_gateway_sessions.pop(gateway_id, None)

        if gateway_id and session.dc_enabled:
            self._dc_unsubscribe_topic(f"{_DC_EVENT_TOPIC_PREFIX}{gateway_id}")
            session.dc_enabled = False

        if gateway_id and session.connect_emitted:
            self._send_to_engine(
                make_gateway_disconnect_msg(gateway_id, reason=reason),
                count_as_command=False,
                require_engine=False,
            )
            session.connect_emitted = False

        fileno = session.sock.fileno()
        try:
            self._selector.unregister(session.sock)
        except KeyError, ValueError:
            pass
        self._dirty.discard(fileno)
        self._write_blocked.discard(fileno)
        session.close()
        self._clients.pop(fileno, None)
        self._global_stats["connected_clients"] = len(self._clients)
        self._global_stats["disconnects_total"] += 1

    def _dc_subscribe_topic(self, topic: str) -> None:
        """Refcounted SUBSCRIBE on the drop-copy socket (:5557).

        Targets ``self._dc_sub`` -- a different ZMQ PUB address from the
        main event bus, not just a different topic namespace.
        """
        ref = self._dc_topic_refcounts.get(topic, 0)
        if ref == 0:
            self._dc_sub.setsockopt(zmq.SUBSCRIBE, topic.encode("utf-8"))
        self._dc_topic_refcounts[topic] = ref + 1

    def _dc_unsubscribe_topic(self, topic: str) -> None:
        ref = self._dc_topic_refcounts.get(topic, 0)
        if ref <= 1:
            self._dc_topic_refcounts.pop(topic, None)
            self._dc_sub.setsockopt(zmq.UNSUBSCRIBE, topic.encode("utf-8"))
            return
        self._dc_topic_refcounts[topic] = ref - 1

    def _gateway_in_use(self, gateway_id: str) -> bool:
        if gateway_id in self._active_gateway_sessions:
            return True
        for session in self._clients.values():
            if session.gateway_id == gateway_id and (
                session.auth_pending or session.authenticated
            ):
                return True
        return False

    def _session_for_gateway(self, gateway_id: str) -> ClientSession | None:
        fileno = self._active_gateway_sessions.get(gateway_id)
        if fileno is None:
            return None
        return self._clients.get(fileno)

    def _find_pending_auth_session(self, gateway_id: str) -> ClientSession | None:
        for session in self._clients.values():
            if session.gateway_id == gateway_id and session.auth_pending:
                return session
        return None

    def _broadcast(self, msg_type: str, fields: dict[str, str]) -> None:
        line: bytes | None = None
        for session in self._clients.values():
            if session.authenticated and session.public_feed:
                if line is None:
                    # Once, not per session; '|' in engine text blanked as
                    # in _queue_line.
                    try:
                        line = build_line(msg_type, fields)
                    except AlfProtocolError:
                        line = build_line(
                            msg_type,
                            {k: v.replace("|", " ") for k, v in fields.items()},
                        )
                self._queue_raw(session, line)
