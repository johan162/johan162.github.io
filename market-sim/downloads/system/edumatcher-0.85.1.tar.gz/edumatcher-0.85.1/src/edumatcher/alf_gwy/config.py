"""Configuration loading helpers for ``pm-alf-gwy``."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


from edumatcher.config_include import load_config_mapping
from edumatcher.config import (
    DROP_COPY_PUB_ADDR,
    ENGINE_PUB_ADDR,
    ENGINE_PULL_ADDR,
    resolve_gateway_bind_host,
)
from edumatcher.config_coerce import as_bool, as_int, as_str


@dataclass(frozen=True)
class AlfGatewayConfig:
    """Runtime settings for ALF TCP gateway."""

    enabled: bool = True
    name: str = "alf-gwy01"
    bind_address: str = field(default_factory=resolve_gateway_bind_host)
    port: int = 5565
    engine_pull_addr: str = ENGINE_PULL_ADDR
    engine_pub_addr: str = ENGINE_PUB_ADDR
    drop_copy_pub_addr: str = DROP_COPY_PUB_ADDR
    heartbeat_interval_sec: int = 5
    handshake_timeout_sec: int = 10
    idle_timeout_sec: int = 30
    max_connections: int = 1024
    max_client_queue: int = 10_000
    max_commands_per_second: int = 100
    max_errors_before_disconnect: int = 50
    error_window_sec: int = 60
    gateway_roles: tuple[tuple[str, str], ...] = ()


def _optional_str(raw: object, label: str) -> str | None:
    return None if raw is None else as_str(raw, label)


def _as_int(raw: object, field: str) -> int:
    return as_int(raw, f"alf_gateway.{field}")


def _parse_gateway_roles(raw: Any) -> tuple[tuple[str, str], ...]:
    participants = raw.get("participants") if isinstance(raw, dict) else None
    if not isinstance(participants, list):
        return ()

    parsed: list[tuple[str, str]] = []
    for idx, item in enumerate(participants):
        if not isinstance(item, dict):
            raise ValueError(f"participants[{idx}] must be a mapping")
        gw_id = str(item.get("id", "")).strip().upper()
        role = str(item.get("role", "TRADER")).strip().upper()
        if not gw_id:
            raise ValueError(f"participants[{idx}].id must be a non-empty string")
        parsed.append((gw_id, role))

    for idx, (gw_id, _role) in enumerate(parsed):
        for other_idx, (other_id, _other_role) in enumerate(parsed):
            if idx == other_idx:
                continue
            if other_id.startswith(gw_id):
                raise ValueError(
                    "participants IDs must not be prefixes of each other "
                    f"({gw_id!r}, {other_id!r})"
                )
    return tuple(parsed)


def _load_alf_gateway_config_from_raw(raw: dict[str, Any]) -> AlfGatewayConfig:
    gw_roles = _parse_gateway_roles(raw)

    section = raw.get("alf_gateway")
    if section is None:
        return AlfGatewayConfig(gateway_roles=gw_roles)
    if not isinstance(section, dict):
        raise ValueError("alf_gateway must be a mapping")

    enabled = as_bool(section.get("enabled", True), "alf_gateway.enabled")
    name = as_str(section.get("name", "alf-gwy01"), "alf_gateway.name")
    bind_address = resolve_gateway_bind_host(
        _optional_str(section.get("bind_address"), "alf_gateway.bind_address")
    )
    port = _as_int(section.get("port", 5565), "port")
    if port <= 0 or port > 65535:
        raise ValueError("alf_gateway.port must be in 1-65535")
    heartbeat_interval_sec = _as_int(
        section.get("heartbeat_interval_sec", 5), "heartbeat_interval_sec"
    )
    handshake_timeout_sec = _as_int(
        section.get("handshake_timeout_sec", 10), "handshake_timeout_sec"
    )
    idle_timeout_sec = _as_int(section.get("idle_timeout_sec", 30), "idle_timeout_sec")
    max_connections = _as_int(section.get("max_connections", 1024), "max_connections")
    max_client_queue = _as_int(
        section.get("max_client_queue", 10_000), "max_client_queue"
    )
    max_commands_per_second = _as_int(
        section.get("max_commands_per_second", 100), "max_commands_per_second"
    )
    max_errors_before_disconnect = _as_int(
        section.get("max_errors_before_disconnect", 50),
        "max_errors_before_disconnect",
    )
    error_window_sec = _as_int(section.get("error_window_sec", 60), "error_window_sec")

    if port <= 0:
        raise ValueError("alf_gateway.port must be > 0")
    if heartbeat_interval_sec <= 0:
        raise ValueError("alf_gateway.heartbeat_interval_sec must be > 0")
    if handshake_timeout_sec <= 0:
        raise ValueError("alf_gateway.handshake_timeout_sec must be > 0")
    if idle_timeout_sec <= 0:
        raise ValueError("alf_gateway.idle_timeout_sec must be > 0")
    if max_connections <= 0:
        raise ValueError("alf_gateway.max_connections must be > 0")
    if max_client_queue <= 0:
        raise ValueError("alf_gateway.max_client_queue must be > 0")
    if max_commands_per_second <= 0:
        raise ValueError("alf_gateway.max_commands_per_second must be > 0")
    if max_errors_before_disconnect <= 0:
        raise ValueError("alf_gateway.max_errors_before_disconnect must be > 0")
    if error_window_sec <= 0:
        raise ValueError("alf_gateway.error_window_sec must be > 0")

    return AlfGatewayConfig(
        enabled=enabled,
        name=name,
        bind_address=bind_address,
        port=port,
        engine_pull_addr=ENGINE_PULL_ADDR,
        engine_pub_addr=ENGINE_PUB_ADDR,
        drop_copy_pub_addr=DROP_COPY_PUB_ADDR,
        heartbeat_interval_sec=heartbeat_interval_sec,
        handshake_timeout_sec=handshake_timeout_sec,
        idle_timeout_sec=idle_timeout_sec,
        max_connections=max_connections,
        max_client_queue=max_client_queue,
        max_commands_per_second=max_commands_per_second,
        max_errors_before_disconnect=max_errors_before_disconnect,
        error_window_sec=error_window_sec,
        gateway_roles=gw_roles,
    )


def load_alf_gateway_config(path: Path) -> AlfGatewayConfig:
    """Load optional ``alf_gateway`` section from engine config YAML."""
    if not path.exists():
        return AlfGatewayConfig()

    raw = load_config_mapping(path).data

    return _load_alf_gateway_config_from_raw(raw)


def validate_alf_gateway_section(raw: dict[str, Any]) -> None:
    """Validate the ``alf_gateway`` section using runtime loader semantics."""
    _load_alf_gateway_config_from_raw(raw)


def load_default_alf_gateway_config() -> AlfGatewayConfig:
    """Return this subsystem's section of the deployed compiled configuration.

    Falls back to dataclass defaults when nothing has been deployed yet, which
    is exactly what the YAML loader above did for a missing file — many tools
    that read this section, such as the spies and viewers, must still run
    against an exchange whose configuration was never installed.

    The import is deferred because ``config_artifact`` imports this module to
    describe the artifact's shape.
    """
    from edumatcher.config_artifact import load_compiled_config

    compiled = load_compiled_config()
    return AlfGatewayConfig() if compiled is None else compiled.alf_gateway
