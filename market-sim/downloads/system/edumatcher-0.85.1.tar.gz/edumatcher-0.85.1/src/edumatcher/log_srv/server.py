"""``pm-log-srv`` LALF TCP server runtime.

Architecture mirrors ``edumatcher.md_gateway.gateway.MarketDataGateway``
exactly: a single-threaded, non-blocking ``select()``-based accept/read/write
loop, not asyncio. (docs-design/EduMatcher-log-srv.md §7.3 describes an
asyncio-per-connection design; this implementation deliberately follows the
pattern actually used elsewhere in this codebase — CALF's own gateway is
select-based, not asyncio — for architectural consistency. See the design
doc correction noted in this module's own docstring history / the
accompanying implementation notes.) The one place this process *does* use a
dedicated background thread is the SQLite writer (§7.4,
``edumatcher.log_srv.writer.WriterThread``), since batching writes on a
timer is a genuinely different concern from the non-blocking network loop
and doing it inline would block that loop on disk I/O.

Design priorities, in the same order ``md_gateway/gateway.py`` states them:
- Correctness first: strict LALF validation (§15) and deterministic behavior
- Maintainability: clear decomposition, heavily documented control flow
- Defensive behavior: bounded queues, explicit disconnect paths
"""

from __future__ import annotations

import logging
import secrets
import select
import signal
import socket
import threading
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

from edumatcher.health import HealthReporter, counter, gauge
from edumatcher.models.generated.health import MetricSample
from edumatcher.log_srv.config import LogServerConfig
from edumatcher.log_srv.schema import (
    CLOSE_OPEN_PROCESSES,
    DELETE_OLD_LOG_EVENTS,
    INCREMENT_TOTAL_CONNECTIONS,
    INCREMENT_TOTAL_ERRORS_SENT,
    PRUNE_CHUNK_ROWS,
    UPDATE_PROCESS_DISCONNECTED,
    UPDATE_PROCESS_HEARTBEAT,
    UPSERT_PROCESS_CONNECT,
    UPSERT_SERVER_STATS_INIT,
    open_db,
)
from edumatcher.log_srv.pubsub import LogPubSubHub
from edumatcher.log_srv.session import LogSession
from edumatcher.log_srv.writer import LogEventRow, WriterThread
from edumatcher.logclient.protocol import (
    ERR_BAD_MESSAGE,
    ERR_HELLO_TIMEOUT,
    ERR_INVALID_LEVEL,
    ERR_MISSING_FIELD,
    ERR_PAYLOAD_TOO_LARGE,
    ERR_PROTO_MISMATCH,
    HELLO_TIMEOUT_SEC,
    PROTO_VERSION,
    FrameReader,
    LalfProtocolError,
    build_header_line,
    iso_utc,
    validate_log_fields,
)

log = logging.getLogger(__name__)


def _sqlite_int(raw: str | None) -> int | None:
    """``raw`` as an int SQLite can store, or ``None`` (missing, not an
    integer, or outside the signed 64-bit range)."""
    if raw is None:
        return None
    try:
        value = int(raw)
    except ValueError:
        return None
    return value if _SQLITE_INT_MIN <= value <= _SQLITE_INT_MAX else None


_DEBUG_SUMMARY_INTERVAL_SEC = 5.0
#: Most bytes read from one client in one main-loop pass, so one busy client
#: cannot starve the others, while a burst is not limited to one recv a pass.
_READ_BUDGET_BYTES = 64 * 1024
#: SQLite stores INTEGER as a signed 64-bit value; a larger bind raises
#: OverflowError, which no sqlite3.Error handler catches.
_SQLITE_INT_MIN = -(2**63)
_SQLITE_INT_MAX = 2**63 - 1
_RETENTION_CHECK_INTERVAL_SEC = 3600  # once per hour, per §6.5/§7.2 step 6


class LogServer:
    """``pm-log-srv`` TCP server: accepts LALF connections, persists LOG rows."""

    def __init__(self, config: LogServerConfig) -> None:
        self.config = config

        self._running = False
        self._server: socket.socket | None = None
        self._clients: dict[int, LogSession] = {}
        # Health beacon (operator dashboard §8.5); attached by main().
        self._reporter: HealthReporter | None = None
        self._events_in = 0

        self._closed = False
        self._conn = open_db(Path(config.db_path))
        self._conn.execute(UPSERT_SERVER_STATS_INIT, (iso_utc(time.time()),))
        # A row still open here was left by a server that stopped without
        # close() (a crash): no client of it is connected any more.
        self._conn.execute(
            CLOSE_OPEN_PROCESSES, (iso_utc(time.time()), "server_restart")
        )
        self._conn.commit()

        # LALF-PS is constructed before the writer so the writer can be
        # handed its persisted-batch callback at construction time; the hub
        # binds no sockets until start() is called from run().
        self._pubsub: LogPubSubHub | None = None
        if config.pubsub_enabled:
            self._pubsub = LogPubSubHub(
                pub_addr=config.pub_addr,
                pull_addr=config.pull_addr,
                db_path=Path(config.db_path),
                server_name=config.name,
                lease_sec=float(config.lease_sec),
                max_lease_sec=float(config.max_lease_sec),
                max_subscribers=config.max_subscribers,
                notify_interval_ms=config.notify_interval_ms,
                backfill_chunk_rows=config.backfill_chunk_rows,
                max_backfill_minutes=config.max_backfill_minutes,
                max_backfill_rows=config.max_backfill_rows,
                max_pending_rows=config.max_pending_rows,
                pub_sndhwm=config.pub_sndhwm,
                state_interval_sec=float(config.heartbeat_interval_sec),
            )

        self._writer = WriterThread(
            self._conn,
            batch_size=config.write_batch_size,
            batch_interval_ms=config.write_batch_interval_ms,
            on_persisted=(
                self._pubsub.on_batch_persisted if self._pubsub is not None else None
            ),
        )

        self._debug_counts: defaultdict[str, int] = defaultdict(int)
        self._debug_last_summary = time.monotonic()
        # -inf, not 0: monotonic() counts from host boot, so 0 delayed the
        # first prune by up to an hour on a recently booted host.
        self._last_retention_check = float("-inf")
        #: Cutoff of the prune in progress (one chunk per loop pass), or None.
        self._prune_cutoff: str | None = None
        self._pruned = 0
        self._last_heartbeat_flush = 0.0
        #: ERR replies not yet added to server_stats (flushed with heartbeats).
        self._errors_sent_unflushed = 0
        #: Set each loop pass while the writer backlog exceeds
        #: max_client_queue and client reads are suspended (§5.8).
        self._backlogged = False

        # A dedicated connection is used for the (rare, background) DELETE
        # pruning statement rather than sharing the writer thread's
        # connection, since it runs from the main loop thread — SQLite
        # connections are not meant to be shared across threads without
        # check_same_thread=False plus external serialization, and the
        # writer thread already owns exclusive use of its connection for
        # inserts. A second connection avoids adding cross-thread locking
        # to the (much hotter) insert path just to support hourly pruning.
        self._prune_conn = open_db(Path(config.db_path))

    # ------------------------------------------------------------------
    # Debug summary
    # ------------------------------------------------------------------

    def _dbg_count(self, key: str, amount: int = 1) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        self._debug_counts[key] += amount
        self._flush_debug_summary()

    def _flush_debug_summary(self, force: bool = False) -> None:
        if not log.isEnabledFor(logging.DEBUG):
            return
        now = time.monotonic()
        if not force and now - self._debug_last_summary < _DEBUG_SUMMARY_INTERVAL_SEC:
            return
        if not self._debug_counts:
            self._debug_last_summary = now
            return
        summary = ", ".join(
            f"{key}={value}" for key, value in sorted(self._debug_counts.items())
        )
        log.debug("log_srv flow summary: %s", summary)
        self._debug_counts.clear()
        self._debug_last_summary = now

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def run(self) -> None:
        """Start TCP listener, writer thread, and process loop until stopped."""
        server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server.bind((self.config.bind_address, self.config.port))
        server.listen(128)
        server.setblocking(False)
        # Published only once listening: callers poll it as the readiness signal.
        self._server = server

        self._running = True
        self._writer.start()
        if self._pubsub is not None:
            self._pubsub.start()

        if threading.current_thread() is threading.main_thread():
            signal.signal(signal.SIGINT, lambda *_: self.stop())
            signal.signal(signal.SIGTERM, lambda *_: self.stop())

        log.info(
            "pm-log-srv %r listening on %s:%s db=%s (cwd=%s) retention_days=%s",
            self.config.name,
            self.config.bind_address,
            self.config.port,
            Path(self.config.db_path).resolve(),
            Path.cwd(),
            self.config.retention_days,
        )

        reporter = self._reporter
        try:
            while self._running:
                if reporter is not None:
                    reporter.tick_and_publish(self.metric_samples)
                self._accept_new_clients()
                busy = self._read_client_data() > 0
                self._send_heartbeats_if_due()
                self._flush_client_writes()
                self._drop_idle_clients()
                self._persist_heartbeats_if_due()
                self._service_pubsub()
                self._run_retention_if_due()
                if not self._writer.is_alive:
                    # Nothing accepted from here on could ever be stored,
                    # and backpressure would soon stop every client.
                    log.critical("log writer thread stopped; stopping pm-log-srv")
                    raise RuntimeError("log writer thread stopped")
                if not busy:
                    time.sleep(0.01)
        finally:
            self.close()

    def stop(self) -> None:
        log.info("stop requested")
        self._running = False

    def attach_reporter(self, reporter: HealthReporter) -> None:
        """Ship this process's health beacon through ``reporter`` (main())."""
        self._reporter = reporter

    def metric_samples(self) -> list[MetricSample]:
        """Design §8.5: ingest, sessions, writer backlog, LALF-PS leases."""
        return [
            counter("log.events_in", self._events_in),
            gauge(
                "log.sessions",
                sum(1 for s in self._clients.values() if s.authenticated),
            ),
            gauge("log.writer_queue", self._writer.pending),
            gauge(
                "log.ps_subscriptions",
                self._pubsub.subscriber_count if self._pubsub is not None else 0,
            ),
        ]

    def close(self) -> None:
        """Stop everything once; ``run()`` and ``main()`` both call this."""
        if self._closed:
            return
        self._closed = True
        if self._reporter is not None:
            self._reporter.stop()
        self._flush_debug_summary(force=True)
        log.info("closing pm-log-srv")
        for session in list(self._clients.values()):
            self._disconnect(session, reason="server_stop")
        self._clients.clear()
        self._flush_errors_sent()

        if self._server is not None:
            self._server.close()
            self._server = None

        if self._pubsub is not None:
            self._pubsub.stop()

        try:
            self._writer.stop()
        finally:
            if hasattr(self, "_conn"):
                self._conn.close()
            if hasattr(self, "_prune_conn"):
                self._prune_conn.close()

    # ------------------------------------------------------------------
    # Network IO
    # ------------------------------------------------------------------

    def _accept_new_clients(self) -> None:
        if self._server is None:
            return

        while True:
            try:
                conn, addr = self._server.accept()
            except BlockingIOError:
                break
            except OSError as exc:
                log.warning("accept failed: %s", exc)
                break

            conn.setblocking(False)
            session = LogSession(
                sock=conn,
                addr=addr,
                reader=FrameReader(max_payload_bytes=self.config.max_message_bytes),
            )
            self._clients[conn.fileno()] = session
            log.info(
                "client connected addr=%s:%s fd=%d", addr[0], addr[1], conn.fileno()
            )

    def _read_client_data(self) -> int:
        """Read what the clients sent; return the number of bytes read."""
        # Backpressure (§5.8/§7.4/§15.13): while the writer thread holds more
        # than max_client_queue uncommitted rows, read from no socket at all.
        # Unread bytes stay in the kernel buffers, so TCP flow control slows
        # every producer's send() equally until the disk catches up — and no
        # accepted row is ever discarded.
        self._backlogged = self._writer.pending > self.config.max_client_queue
        if self._backlogged:
            self._dbg_count("reads_throttled")
            return 0
        if not self._clients:
            return 0

        # A session closing after an ERR or EXIT is only flushed, not read:
        # anything it sends after that point is not accepted.
        readable = [s.sock for s in self._clients.values() if not s.closing]
        if not readable:
            return 0
        try:
            ready, _, _ = select.select(readable, [], [], 0)
        except (OSError, ValueError) as exc:
            log.warning("read select failed: %s", exc)
            return 0

        total = 0

        for sock_obj in ready:
            self._dbg_count("readable_sockets")
            session = self._clients.get(sock_obj.fileno())
            if session is None:
                continue

            # A client that never reads its replies (ERR/PONG) is not read
            # from either, so its outbound queue cannot grow without bound.
            if len(session.out_queue) > self.config.max_client_queue:
                continue

            total += self._read_session(session)
        return total

    def _read_session(self, session: LogSession) -> int:
        """Read one ready client until EAGAIN or the per-pass byte budget."""
        read = 0
        while read < _READ_BUDGET_BYTES and not session.closing:
            try:
                chunk = session.sock.recv(4096)
            except BlockingIOError:
                break
            except OSError:
                # ECONNRESET and friends: the peer is gone, not idle.
                self._disconnect(session, reason="io_error")
                break

            if not chunk:
                self._disconnect(session, reason="peer_closed")
                break

            read += len(chunk)
            session.reader.feed(chunk)
            session.last_activity = time.monotonic()
            self._drain_frames(session)
        return read

    def _drain_frames(self, session: LogSession) -> None:
        while True:
            try:
                frame = session.reader.next_frame()
            except LalfProtocolError as exc:
                log.warning(
                    "dropping client fd=%d due to protocol error: %s",
                    session.sock.fileno(),
                    exc,
                )
                self._queue_line(
                    session, "ERR", {"CODE": ERR_BAD_MESSAGE, "MSG": str(exc)}
                )
                self._close_after_flush(session)
                return
            if frame is None:
                return
            self._handle_frame(session, frame)
            if session.closing:
                return

    def _flush_client_writes(self) -> None:
        """Flush queued outbound bytes to all clients (mirrors md_gateway)."""
        for session in list(self._clients.values()):
            failed = False
            while session.out_queue:
                payload = session.out_queue[0]
                unsent = payload[session.out_offset :]
                try:
                    sent = session.sock.send(unsent)
                except BlockingIOError:
                    break
                except OSError:
                    failed = True
                    break

                if sent <= 0:
                    break

                session.out_offset += sent

                if session.out_offset >= len(payload):
                    session.out_queue.pop(0)
                    session.out_offset = 0

            if failed:
                self._disconnect(session, reason="io_error")
            elif session.closing and not session.out_queue:
                self._disconnect(session, reason=session.close_reason)

    # ------------------------------------------------------------------
    # Protocol handling
    # ------------------------------------------------------------------

    def _handle_frame(self, session: LogSession, frame: Any) -> None:
        msg_type = frame.msg_type
        fields = frame.fields

        if not session.authenticated:
            if msg_type != "HELLO":
                self._queue_line(
                    session,
                    "ERR",
                    {"CODE": "AUTH_REQUIRED", "MSG": "send HELLO first"},
                )
                self._close_after_flush(session)
                return
            self._handle_hello(session, fields)
            return

        if msg_type == "HELLO":
            # §15.5/§15.9: a second HELLO on an already-established
            # connection is a protocol violation.
            self._queue_line(
                session,
                "ERR",
                {"CODE": ERR_PROTO_MISMATCH, "MSG": "HELLO already completed"},
            )
            self._close_after_flush(session)
            return

        if msg_type == "LOG":
            self._register_process(session)
            self._handle_log(session, fields, frame.payload or b"", frame.truncated)
        elif msg_type == "HB":
            self._register_process(session)
            session.last_activity = time.monotonic()
        elif msg_type == "PING":
            self._queue_line(session, "PONG", {})
        elif msg_type == "EXIT":
            self._close_after_flush(session, reason="client_exit")
        else:
            self._queue_line(
                session,
                "ERR",
                {"CODE": ERR_BAD_MESSAGE, "MSG": f"unsupported {msg_type}"},
            )

    def _handle_hello(self, session: LogSession, fields: dict[str, str]) -> None:
        client = fields.get("CLIENT", "")
        pid_raw = fields.get("PID", "")
        host = fields.get("HOST", "")
        proto = fields.get("PROTO", "")
        instance = fields.get("INSTANCE")

        missing = [k for k in ("CLIENT", "PID", "HOST", "PROTO") if not fields.get(k)]
        if missing:
            self._queue_line(
                session,
                "ERR",
                {"CODE": ERR_MISSING_FIELD, "MSG": f"missing: {','.join(missing)}"},
            )
            self._close_after_flush(session)
            return

        if proto != PROTO_VERSION:
            self._queue_line(
                session,
                "ERR",
                {"CODE": ERR_PROTO_MISMATCH, "MSG": f"expected PROTO={PROTO_VERSION}"},
            )
            self._close_after_flush(session)
            return

        pid = _sqlite_int(pid_raw)
        if pid is None:
            self._queue_line(
                session,
                "ERR",
                {"CODE": ERR_MISSING_FIELD, "MSG": "PID must be a 64-bit integer"},
            )
            self._close_after_flush(session)
            return

        session.client = client
        session.pid = pid
        session.host = host
        session.instance = instance
        session.authenticated = True
        session.session_id = secrets.token_hex(4)
        session.last_activity = time.monotonic()
        session.persisted_activity = session.last_activity

        now_iso = iso_utc(time.time())
        session.connected_at_iso = now_iso
        with self._writer.lock, self._conn:
            self._conn.execute(INCREMENT_TOTAL_CONNECTIONS)

        welcome_fields = {
            "PROTO": PROTO_VERSION,
            "SRV": self.config.name,
            "HBINT": str(self.config.heartbeat_interval_sec),
            "SESSION": session.session_id,
        }
        self._queue_line(session, "WELCOME", welcome_fields)
        log.info(
            "client authenticated fd=%d client=%s pid=%d host=%s session=%s",
            session.sock.fileno(),
            client,
            pid,
            host,
            session.session_id,
        )

    def _handle_log(
        self,
        session: LogSession,
        fields: dict[str, str],
        payload: bytes,
        cut_by_reader: bool = False,
    ) -> None:
        err_code = validate_log_fields(fields)
        if err_code == ERR_MISSING_FIELD:
            self._queue_line(
                session,
                "ERR",
                {"CODE": ERR_MISSING_FIELD, "MSG": "LOG missing a required field"},
            )
            self._dbg_count("log_rejected_missing_field")
            return
        if err_code == ERR_INVALID_LEVEL:
            self._queue_line(
                session,
                "ERR",
                {
                    "CODE": ERR_INVALID_LEVEL,
                    "MSG": f"unknown LEVEL value: {fields.get('LEVEL')}",
                },
            )
            self._dbg_count("log_rejected_invalid_level")
            return

        seq = _sqlite_int(fields["SEQ"]) or 0
        if seq and session.last_seq and seq != session.last_seq + 1:
            log.debug(
                "SEQ gap on fd=%d client=%s: expected %d got %d",
                session.sock.fileno(),
                session.client,
                session.last_seq + 1,
                seq,
            )
        if seq:
            session.last_seq = seq

        truncated = False
        message = payload.decode("utf-8", errors="replace")
        max_bytes = self.config.max_message_bytes
        if cut_by_reader or len(payload) > max_bytes:
            # Truncate, store anyway, advisory ERR — never drop (§15.7/§15.9).
            truncated = True
            cut = payload[:max_bytes]
            while cut:
                try:
                    message = cut.decode("utf-8")
                    break
                except UnicodeDecodeError:
                    cut = cut[:-1]
            else:
                message = ""
            self._queue_line(
                session,
                "ERR",
                {
                    "CODE": ERR_PAYLOAD_TOO_LARGE,
                    "MSG": f"message exceeds max_message_bytes={max_bytes}, truncated",
                },
            )

        line_no = _sqlite_int(fields.get("LINE"))

        row = LogEventRow(
            client_ts=fields.get("TS", iso_utc(time.time())),
            server_ts=iso_utc(time.time()),
            process=session.client,
            instance=session.instance,
            pid=session.pid,
            host=session.host,
            session=session.session_id,
            level=fields["LEVEL"],
            logger=fields.get("LOGGER", ""),
            module=fields.get("MODULE"),
            line=line_no,
            has_exception=fields.get("EXC") == "1",
            truncated=truncated,
            message=message,
            tpl=fields.get("TPL"),
        )
        self._writer.enqueue(row)
        self._events_in += 1
        self._dbg_count("log_events_enqueued")

    def _register_process(self, session: LogSession) -> None:
        """Write this session's ``processes`` row, once, on first activity.

        Registration is deferred out of the handshake so that
        :func:`edumatcher.logclient.discovery._probe_server` — which sends
        ``HELLO``, reads ``WELCOME`` and hangs up purely to decide whether
        a server is listening — does not leave behind a record of a process
        that never ran. Such probes outnumbered real sessions by orders of
        magnitude and made every process-level diagnostic unusable.
        """
        if session.registered:
            return
        session.registered = True
        now_iso = iso_utc(time.time())
        with self._writer.lock, self._conn:
            self._conn.execute(
                UPSERT_PROCESS_CONNECT,
                (
                    session.session_id,
                    session.client,
                    session.instance,
                    session.pid,
                    session.host,
                    session.connected_at_iso or now_iso,
                    now_iso,
                    now_iso,
                ),
            )

    # ------------------------------------------------------------------
    # Heartbeat / idle / retention
    # ------------------------------------------------------------------

    def _send_heartbeats_if_due(self) -> None:
        # §15.10: HB is client -> server only; the server does not itself
        # send HB. Nothing to do here — kept as an explicit no-op method
        # (rather than omitted) so the run() loop's shape stays identical
        # to md_gateway's, which does send server -> client HB for its own
        # different protocol. See _drop_idle_clients for the receive-side
        # half of LALF's liveness contract.
        return

    def _drop_idle_clients(self) -> None:
        now = time.monotonic()
        for session in list(self._clients.values()):
            if (
                not session.authenticated
                and now - session.connected_at > HELLO_TIMEOUT_SEC
            ):
                if session.closing:
                    # Its ERR was given one flush pass and has still not
                    # gone out; do not wait on a client that will not read.
                    self._disconnect(session, reason=session.close_reason)
                    continue
                self._queue_line(
                    session,
                    "ERR",
                    {"CODE": ERR_HELLO_TIMEOUT, "MSG": "no HELLO received"},
                )
                self._close_after_flush(session, reason="hello_timeout")
                continue
            # While reads are throttled for backpressure, a client's
            # heartbeats sit unread in the kernel buffer: silence then is the
            # server's doing, not evidence the client is dead.
            if session.authenticated and not self._backlogged:
                idle = now - session.last_activity
                max_idle = 2 * self.config.heartbeat_interval_sec
                if idle > max_idle:
                    self._disconnect(session, reason="idle_timeout")

    def _service_pubsub(self) -> None:
        """Give the LALF-PS hub one servicing pass per main-loop iteration.

        Every ZeroMQ socket operation in the process happens inside this
        call, on this thread — the writer thread only ever hands the hub
        rows across a queue (see :mod:`edumatcher.log_srv.pubsub`). A
        failure here is logged and swallowed rather than propagated: the
        log-distribution interface is an observability convenience, and it
        must never be able to take down the collector that every other
        ``pm-*`` process depends on for its logging.
        """
        if self._pubsub is None:
            return
        try:
            self._pubsub.poll()
        except Exception:  # pragma: no cover - defensive
            log.exception("LALF-PS servicing pass failed; continuing")

    def _persist_heartbeats_if_due(self) -> None:
        """Write each live session's last-contact time to ``processes``.

        The main loop spins at 100 Hz and every inbound frame refreshes
        ``last_activity``, so persisting on receipt would mean a write per
        process per heartbeat. Instead this flushes on the heartbeat
        interval, batching every session into one transaction and skipping
        those that have not been heard from since the last pass.

        Without this, ``processes.last_heartbeat_at`` would stay NULL and
        ``last_seen_at`` would advance only on LOG frames — which is what
        made ``pm-log-cli diagnose`` report a quiet-but-healthy process as
        silent, having no way to tell it apart from a wedged one.
        """
        now = time.monotonic()
        if now - self._last_heartbeat_flush < self.config.heartbeat_interval_sec:
            return
        self._last_heartbeat_flush = now
        self._flush_errors_sent()

        due = [
            s
            for s in self._clients.values()
            if s.authenticated
            and s.registered
            and s.last_activity > s.persisted_activity
        ]
        if not due:
            return

        now_iso = iso_utc(time.time())
        with self._writer.lock, self._conn:
            self._conn.executemany(
                UPDATE_PROCESS_HEARTBEAT,
                [(now_iso, s.session_id) for s in due],
            )
        for s in due:
            s.persisted_activity = s.last_activity

    def _flush_errors_sent(self) -> None:
        """Add the ERR replies counted since the last flush to server_stats.

        Counted in memory rather than committed per reply: on disk each
        commit costs a WAL fsync on the main loop (1.24 ms measured).
        """
        if not self._errors_sent_unflushed:
            return
        with self._writer.lock, self._conn:
            self._conn.execute(
                INCREMENT_TOTAL_ERRORS_SENT, (self._errors_sent_unflushed,)
            )
        self._errors_sent_unflushed = 0

    def _run_retention_if_due(self) -> None:
        """Prune hourly, one chunk per loop pass until a chunk comes back short.

        One chunk (``PRUNE_CHUNK_ROWS`` rows, about 25 ms) per pass keeps a
        large prune from stopping the loop: deleting 1.1 M rows in one go
        blocked every read and publish for 5 s.
        """
        if self.config.retention_days is None:
            return
        if self._prune_cutoff is None:
            now = time.monotonic()
            if now - self._last_retention_check < _RETENTION_CHECK_INTERVAL_SEC:
                return
            self._last_retention_check = now
            self._prune_cutoff = iso_utc(
                time.time() - self.config.retention_days * 86400
            )
            self._pruned = 0
        # One committed chunk per statement, so the writer thread never
        # waits behind more than one bounded DELETE.
        with self._prune_conn:
            cur = self._prune_conn.execute(
                DELETE_OLD_LOG_EVENTS, (self._prune_cutoff, PRUNE_CHUNK_ROWS)
            )
            count = max(cur.rowcount, 0)
        self._pruned += count
        if count < PRUNE_CHUNK_ROWS:
            if self._pruned:
                log.info(
                    "retention: pruned %d log_events rows older than %s",
                    self._pruned,
                    self._prune_cutoff,
                )
            self._prune_cutoff = None

    # ------------------------------------------------------------------
    # Queue/disconnect helpers
    # ------------------------------------------------------------------

    def _queue_line(
        self, session: LogSession, msg_type: str, fields: dict[str, str]
    ) -> None:
        self._queue_raw(session, build_header_line(msg_type, fields))
        if msg_type == "ERR":
            self._errors_sent_unflushed += 1

    def _queue_raw(self, session: LogSession, payload: bytes) -> None:
        session.out_queue.append(payload)

    def _disconnect(self, session: LogSession, reason: str = "unspecified") -> None:
        fd = session.sock.fileno()
        client = session.client or "-"
        try:
            session.sock.close()
        except OSError:
            pass
        self._clients.pop(fd, None)
        if session.registered:
            with self._writer.lock, self._conn:
                self._conn.execute(
                    UPDATE_PROCESS_DISCONNECTED,
                    (iso_utc(time.time()), reason, session.session_id),
                )
        log.info("client disconnected fd=%d client=%s reason=%s", fd, client, reason)

    def _close_after_flush(
        self, session: LogSession, reason: str = "protocol_error"
    ) -> None:
        session.closing = True
        session.close_reason = reason
        log.debug("session fd=%d marked closing-after-flush", session.sock.fileno())
