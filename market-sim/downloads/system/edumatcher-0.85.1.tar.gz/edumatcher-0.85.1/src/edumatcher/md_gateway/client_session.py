"""Client session state for CALF TCP connections."""

from __future__ import annotations

import socket
import time
from collections import deque
from dataclasses import dataclass, field


@dataclass
class ClientSession:
    """One connected TCP client and its protocol/session state."""

    sock: socket.socket
    addr: tuple[str, int]
    in_buffer: bytearray = field(default_factory=bytearray)
    out_queue: deque[bytes] = field(default_factory=deque)
    out_offset: int = 0
    closing: bool = False
    #: When ``closing`` was set, and why: the session is disconnected with
    #: this reason once its queue drains or CLOSE_GRACE_SEC passes.
    closing_since: float = 0.0
    close_reason: str = "close_after_flush"

    # Authentication/session state
    authenticated: bool = False
    client_id: str = ""
    #: Set at the first bytes received. A connection closed before that (a
    #: TCP liveness probe) is logged at DEBUG and not counted as a disconnect.
    heard_from: bool = False

    # Absolute connection timestamp for handshake-timeout checks.
    connected_at: float = field(default_factory=time.monotonic)

    # Last inbound line or completed send, for the idle-timeout check (the
    # HELLO deadline uses connected_at).
    last_activity: float = field(default_factory=time.monotonic)

    # Token-bucket limiter used for inbound client message pacing.
    rate_tokens: float = 100.0
    rate_updated: float = field(default_factory=time.monotonic)

    # Per-client subscriptions. Stream key is (channel, symbol)
    subscriptions: set[tuple[str, str]] = field(default_factory=set)

    # Last timestamp at which this session received market data (not heartbeat).
    last_market_data_sent: float = field(default_factory=time.monotonic)

    # Last timestamp at which heartbeat was queued for this client.
    last_heartbeat_sent: float = field(default_factory=time.monotonic)

    def close(self) -> None:
        try:
            self.sock.close()
        except OSError:
            pass

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass
