"""Argparse builder for pm-config-gen CLI."""

from __future__ import annotations

import argparse
import math

from edumatcher.config_gen.defaults import (
    DEFAULT_ACE_INITIAL_BAND_PCT,
    DEFAULT_DEPTH_SNAPSHOT_TOLERANCE_TICKS,
    DEFAULT_DROP_COPY_BUFFER_SIZE,
    DEFAULT_MM_MIN_QTY,
    DEFAULT_MM_SEED_SPREAD_TICKS,
    DEFAULT_MM_SPREAD_TICKS,
    DEFAULT_QUOTE_HISTORY_MAXLEN,
    DEFAULT_RECENT_TRADES_MAXLEN,
    DEFAULT_SNAPSHOT_INTERVAL_SEC,
    DEFAULT_TICK_DECIMALS,
)


def finite_float(text: str) -> float:
    """``float(text)``, refusing "nan" and "inf" with a ValueError.

    ``float()`` accepts both, and NaN passes every ``x <= 0`` check, so it
    would reach the generated file.
    """
    value = float(text)
    if not math.isfinite(value):
        raise ValueError(f"{text!r} is not a finite number")
    return value


def _finite_float_arg(text: str) -> float:
    try:
        return finite_float(text)
    except ValueError:
        raise argparse.ArgumentTypeError(
            f"must be a finite number, got {text!r}"
        ) from None


def _port_arg(text: str) -> int:
    try:
        port = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError(f"must be a TCP port, got {text!r}") from None
    if not 1 <= port <= 65535:
        raise argparse.ArgumentTypeError(f"must be in 1-65535, got {port}")
    return port


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="pm-config-gen",
        description=(
            "Generate a parser-compatible engine_config.yaml from concise CLI inputs."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
        # An abbreviation (--snapshot) would be accepted by argparse but missed
        # by the checks that look for an option by its full name.
        allow_abbrev=False,
    )
    from edumatcher.cli_version import add_version_argument

    add_version_argument(parser, "pm-config-gen")

    parser.add_argument(
        "--symbols",
        nargs="+",
        action="extend",
        required=True,
        metavar="SYM",
        help="One or more symbols.",
    )
    parser.add_argument(
        "--participants",
        nargs="+",
        action="extend",
        required=True,
        metavar="GW_SPEC",
        help="One or more participant specs (ID[:ROLE[:DISCONNECT]]). ID is "
        "uppercase letters, digits and _, starting with a letter.",
    )
    parser.add_argument(
        "--participant-desc",
        action="append",
        default=[],
        metavar="GW_ID:TEXT",
        help="Free-text description for one participant, written as "
        "participants[].description. GW_ID must be one of the IDs given to "
        "--participants. Quote it when TEXT has spaces. Can be repeated.",
    )
    parser.add_argument(
        "--participant-smp",
        action="append",
        default=[],
        metavar="GW_ID:SMP_ACTION",
        help="Gateway-level self-match-prevention default (NONE, CANCEL_AGGRESSOR, "
        "CANCEL_RESTING, CANCEL_BOTH), applied by the engine to any order, combo "
        "leg, or quote from GW_ID that doesn't specify its own SMP=. GW_ID must "
        "be one of the IDs given to --participants. Omit for a participant to leave its "
        "default at NONE. Can be repeated.",
    )
    parser.add_argument(
        "--participant-default-smp",
        choices=["NONE", "CANCEL_AGGRESSOR", "CANCEL_RESTING", "CANCEL_BOTH"],
        type=str.upper,
        default=None,
        metavar="SMP_ACTION",
        help="Write participant_defaults.smp_action: the self-match-prevention default "
        "every participant inherits unless it has its own smp_action "
        "(--participant-smp GW_ID:SMP_ACTION overrides it per participant, "
        "including GW_ID:NONE). Choices: %(choices)s.",
    )
    parser.add_argument(
        "--participant-default-disconnect",
        choices=["CANCEL_ALL", "CANCEL_QUOTES_ONLY", "LEAVE_ALL"],
        type=str.upper,
        default=None,
        metavar="DISCONNECT",
        help="Write participant_defaults.disconnect_behaviour: the disconnect behaviour "
        "inherited by every participant whose --participants spec does not name one "
        "(replacing the per-role default for those participants). "
        "Choices: %(choices)s.",
    )
    parser.add_argument(
        "--symbol-opts",
        action="append",
        default=[],
        metavar="SYMBOL:KEY=VALUE[,KEY=VALUE]",
        help=(
            "Per-symbol overrides. Keys: tick_decimals, static_band, "
            "dynamic_band, max_order_qty, max_order_value, level, "
            "cb_shift_l1..l3, cb_halt_l1..l3 (minutes > 0), mm_spread_ticks, "
            "mm_min_qty, enforce_mm_obligation, ace_enabled, ace_initial_band, "
            "ace_random_end_ns. An unknown symbol or key, or a bad value, is "
            "an error. Can be repeated."
        ),
    )
    parser.add_argument(
        "--symbol-static-band",
        action="append",
        default=[],
        metavar="SYM:PCT",
        help="Per-symbol collar static band pct in (0,1). Can be repeated.",
    )
    parser.add_argument(
        "--symbol-dynamic-band",
        action="append",
        default=[],
        metavar="SYM:PCT",
        help="Per-symbol collar dynamic band pct in (0,1). Can be repeated.",
    )
    parser.add_argument(
        "--symbol-max-order-qty",
        action="append",
        default=[],
        metavar="SYM:N",
        help="Per-symbol order_limits.max_order_qty in shares (> 0). Can be repeated.",
    )
    parser.add_argument(
        "--symbol-max-order-value",
        action="append",
        default=[],
        metavar="SYM:AMOUNT",
        help=(
            "Per-symbol order_limits.max_order_value as notional (> 0). "
            "Can be repeated."
        ),
    )
    parser.add_argument(
        "--symbol-risk-level",
        action="append",
        default=[],
        metavar="SYM:LEVEL",
        help="Per-symbol risk level key override. Can be repeated.",
    )
    parser.add_argument(
        "--outstanding-shares",
        action="append",
        default=[],
        metavar="SYM:N",
        help="Per-symbol outstanding shares (positive integer). Can be repeated.",
    )

    sess_group = parser.add_mutually_exclusive_group()
    sess_group.add_argument(
        "--sessions-enabled",
        dest="sessions_enabled",
        action="store_true",
        help=(
            "Enable scheduler-driven sessions. Without it pm-config-gen writes "
            "sessions_enabled: false (an absent key would mean enabled)."
        ),
    )
    sess_group.add_argument(
        "--no-sessions-enabled",
        dest="sessions_enabled",
        action="store_false",
        help="Disable scheduler-driven sessions.",
    )
    parser.set_defaults(sessions_enabled=False)

    parser.add_argument(
        "--snapshot-interval",
        type=_finite_float_arg,
        default=DEFAULT_SNAPSHOT_INTERVAL_SEC,
        metavar="SECS",
        help="Snapshot interval seconds (> 0).",
    )
    parser.add_argument(
        "--quote-history-maxlen",
        type=int,
        default=DEFAULT_QUOTE_HISTORY_MAXLEN,
        metavar="N",
        help="Max RECENT/ALL quote-history entries kept per gateway (> 0).",
    )
    parser.add_argument(
        "--drop-copy-buffer-size",
        type=int,
        default=DEFAULT_DROP_COPY_BUFFER_SIZE,
        metavar="N",
        help="Drop-copy replay buffer size in messages (> 0).",
    )
    parser.add_argument(
        "--recent-trades-maxlen",
        type=int,
        default=DEFAULT_RECENT_TRADES_MAXLEN,
        metavar="N",
        help="Recent trades retained per book snapshot (> 0).",
    )
    parser.add_argument(
        "--depth-snapshot-tolerance-ticks",
        type=int,
        default=DEFAULT_DEPTH_SNAPSHOT_TOLERANCE_TICKS,
        metavar="N",
        help="Depth snapshot window around last trade in ticks (> 0).",
    )

    parser.add_argument(
        "--no-collars",
        action="store_true",
        help="Set enforce_collars: false.",
    )
    parser.add_argument(
        "--no-circuit-breakers",
        action="store_true",
        help="Set enforce_circuit_breakers: false.",
    )

    parser.add_argument(
        "--static-band",
        type=_finite_float_arg,
        default=None,
        metavar="PCT",
        help="DEFAULT static band pct in (0,1).",
    )
    parser.add_argument(
        "--dynamic-band",
        type=_finite_float_arg,
        default=None,
        metavar="PCT",
        help="DEFAULT dynamic band pct in (0,1).",
    )

    parser.add_argument(
        "--risk-level",
        action="append",
        default=[],
        metavar="LEVEL_SPEC",
        help="Repeatable NAME:STATIC_PCT[:DYNAMIC_PCT]",
    )

    parser.add_argument(
        "--cb-levels",
        nargs="+",
        action="extend",
        default=None,
        metavar="CB_SPEC",
        help=(
            "NAME:SHIFT_PCT[:HALT_MINS] entries, HALT_MINS > 0; omit it for a "
            "rest-of-day halt. Writes circuit_breaker_defaults, which is not "
            "written without it. Can be repeated."
        ),
    )
    parser.add_argument(
        "--cb-window-ns",
        type=int,
        default=None,
        metavar="NS",
        help="CB reference window nanoseconds.",
    )

    parser.add_argument(
        "--no-ace",
        action="store_true",
        help=(
            "Disable Automated Corridor Expansion. A halt then reopens at the "
            "equilibrium price whatever it is, with no corridor and no extensions."
        ),
    )
    parser.add_argument(
        "--ace-initial-band",
        type=_finite_float_arg,
        default=None,
        metavar="PCT",
        help=(
            "Reopening corridor half-width as a fraction of the reference price "
            f"(default {DEFAULT_ACE_INITIAL_BAND_PCT})."
        ),
    )
    parser.add_argument(
        "--ace-expansions",
        nargs="+",
        default=None,
        metavar="EXP_SPEC",
        help=(
            "WIDEN_PCT:MINUTES rungs of the expansion ladder, in order. The last "
            "rung repeats indefinitely, which is what lets the corridor eventually "
            "contain any price. Default: 0.10:2 0.20:5 (Nasdaq's ladder)."
        ),
    )
    parser.add_argument(
        "--ace-random-end-ns",
        type=int,
        default=None,
        metavar="NS",
        help=(
            "Upper bound of the uniform random tail added to every call phase. "
            "0 disables the random end, making reopen times predictable."
        ),
    )
    parser.add_argument(
        "--ace-random-seed",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Seed the random-end generator for reproducible demos. Omit for OS "
            "entropy, which is what a real venue wants."
        ),
    )

    parser.add_argument(
        "--mm-spread-ticks",
        type=int,
        default=DEFAULT_MM_SPREAD_TICKS,
        metavar="N",
        help="Global MM max spread ticks.",
    )
    parser.add_argument(
        "--mm-seed-spread-ticks",
        type=int,
        default=DEFAULT_MM_SEED_SPREAD_TICKS,
        metavar="N",
        help="Half-spread, in ticks, for the seeded MM stub quote (bid/ask sit this many ticks either side of the seeded midpoint).",
    )
    parser.add_argument(
        "--mm-min-qty",
        type=int,
        default=DEFAULT_MM_MIN_QTY,
        metavar="N",
        help="Global MM min qty.",
    )

    mm_group = parser.add_mutually_exclusive_group()
    mm_group.add_argument(
        "--enforce-mm-obligations",
        dest="enforce_mm_obligations",
        action="store_true",
        help="Enable MM obligations globally.",
    )
    mm_group.add_argument(
        "--no-enforce-mm-obligations",
        dest="enforce_mm_obligations",
        action="store_false",
        help="Disable MM obligations globally.",
    )
    parser.set_defaults(enforce_mm_obligations=False)

    parser.add_argument(
        "--tick-decimals",
        type=int,
        default=DEFAULT_TICK_DECIMALS,
        metavar="N",
        help="Default symbol tick decimals.",
    )
    parser.add_argument(
        "--seed-last-prices",
        action="store_true",
        help=(
            "Emit last_buy_price/last_sell_price as null placeholders to fill "
            "in by hand; a null is no reference price. For real ones use "
            "--seed-mm-mid-range with --seed-last-prices-from-mm."
        ),
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        metavar="N",
        help="Deterministic RNG seed for generated training values.",
    )
    parser.add_argument(
        "--seed-mm-mid-range",
        default=None,
        metavar="MIN:MAX",
        help=(
            "Seed MM quotes from a random midpoint in the inclusive MIN:MAX range, "
            "rounded to the symbol tick grid."
        ),
    )
    parser.add_argument(
        "--seed-last-prices-from-mm",
        action="store_true",
        help=(
            "When seeding MM quotes, set last_buy_price/last_sell_price to the same "
            "midpoint used for the generated quote."
        ),
    )
    parser.add_argument(
        "--no-mm-seed-quotes",
        action="store_true",
        help=(
            "Set require_mm_seed_quotes: false and emit no market_maker_quotes "
            "entries, so the book starts genuinely empty even though a "
            "MARKET_MAKER gateway is configured. --seed-mm-mid-range then only "
            "seeds last prices (with --seed-last-prices-from-mm)."
        ),
    )

    parser.add_argument(
        "--post-trade-gateway",
        action="store_true",
        help="Emit a top-level post_trade_gateway section for pm-ralf-gwy.",
    )
    parser.add_argument(
        "--post-trade-name",
        default=None,
        metavar="NAME",
        help="post_trade_gateway.name override.",
    )
    parser.add_argument(
        "--post-trade-bind-address",
        default=None,
        metavar="ADDR",
        help="post_trade_gateway.bind_address override.",
    )
    parser.add_argument(
        "--post-trade-port",
        type=_port_arg,
        default=None,
        metavar="N",
        help="post_trade_gateway.port override (1-65535).",
    )
    parser.add_argument(
        "--post-trade-replay-retention-sec",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.replay_retention_sec override (> 0).",
    )
    parser.add_argument(
        "--post-trade-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--post-trade-idle-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.idle_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--post-trade-max-connections",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.max_connections override (> 0).",
    )
    parser.add_argument(
        "--post-trade-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="post_trade_gateway.max_client_queue override (> 0).",
    )
    parser.add_argument(
        "--post-trade-allowed-roles",
        nargs="+",
        default=None,
        metavar="ROLE",
        help="post_trade_gateway.allowed_roles override (default: CLEARING DROP_COPY AUDIT).",
    )

    parser.add_argument(
        "--market-data-gateway",
        action="store_true",
        help="Emit a top-level market_data_gateway section for pm-md-gwy.",
    )
    parser.add_argument(
        "--market-data-enabled",
        dest="market_data_enabled",
        action="store_true",
        default=None,
        help="Set market_data_gateway.enabled: true.",
    )
    parser.add_argument(
        "--market-data-disabled",
        dest="market_data_enabled",
        action="store_false",
        default=None,
        help="Set market_data_gateway.enabled: false.",
    )
    parser.add_argument(
        "--market-data-name",
        default=None,
        metavar="NAME",
        help="market_data_gateway.name override.",
    )
    parser.add_argument(
        "--market-data-bind-address",
        default=None,
        metavar="ADDR",
        help="market_data_gateway.bind_address override.",
    )
    parser.add_argument(
        "--market-data-port",
        type=_port_arg,
        default=None,
        metavar="N",
        help="market_data_gateway.port override (1-65535).",
    )
    parser.add_argument(
        "--market-data-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--market-data-idle-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.idle_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--market-data-replay-window-sec",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.replay_window_sec override (> 0).",
    )
    parser.add_argument(
        "--market-data-max-connections",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.max_connections override (> 0).",
    )
    parser.add_argument(
        "--market-data-max-symbols-per-client",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.max_symbols_per_client override (> 0).",
    )
    parser.add_argument(
        "--market-data-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.max_client_queue override (> 0).",
    )
    parser.add_argument(
        "--market-data-depth-levels",
        type=int,
        default=None,
        metavar="N",
        help="market_data_gateway.depth_levels override (> 0).",
    )

    parser.add_argument(
        "--api-gateway",
        action="store_true",
        help="Emit a top-level api_gateways section for pm-api-gwy.",
    )
    parser.add_argument(
        "--api-gateway-name",
        default="default",
        metavar="NAME",
        help="Name for the generated api_gateways entry when using a single API gateway.",
    )
    parser.add_argument(
        "--api-gateway-instance",
        action="append",
        default=[],
        metavar="NAME:GATEWAY[,GATEWAY...][:PORT]",
        help=(
            "Repeatable named API gateway process. Generates credentials only for "
            "the listed gateway IDs and optionally overrides port. Use NAME::PORT "
            "for an identity-free read-only gateway."
        ),
    )
    parser.add_argument(
        "--api-gateway-enabled",
        dest="api_gateway_enabled",
        action="store_true",
        default=None,
        help="Set api_gateways.<name>.enabled: true.",
    )
    parser.add_argument(
        "--api-gateway-disabled",
        dest="api_gateway_enabled",
        action="store_false",
        default=None,
        help="Set api_gateways.<name>.enabled: false.",
    )
    parser.add_argument(
        "--api-gateway-host",
        default=None,
        metavar="ADDR",
        help="api_gateways.<name>.host override.",
    )
    parser.add_argument(
        "--api-gateway-port",
        type=_port_arg,
        default=None,
        metavar="N",
        help="api_gateways.<name>.port override (1-65535).",
    )
    parser.add_argument(
        "--api-gateway-swagger-enabled",
        dest="api_gateway_swagger_enabled",
        action="store_true",
        default=None,
        help="Set api_gateways.<name>.swagger_enabled: true.",
    )
    parser.add_argument(
        "--api-gateway-swagger-disabled",
        dest="api_gateway_swagger_enabled",
        action="store_false",
        default=None,
        help="Set api_gateways.<name>.swagger_enabled: false.",
    )
    parser.add_argument(
        "--api-gateway-log-level",
        default=None,
        choices=["debug", "info", "warning", "error"],
        help="api_gateways.<name>.log_level override.",
    )
    parser.add_argument(
        "--api-gateway-stats-db",
        default=None,
        metavar="PATH",
        help="api_gateways.<name>.stats_db override.",
    )
    parser.add_argument(
        "--api-key",
        action="append",
        default=[],
        metavar="KEY:GATEWAY_ID[:DESCRIPTION]",
        help=(
            "Explicit api_gateways credential for single-instance generation. Use GATEWAY_ID=null for a read-only "
            "market-data key. Can be repeated."
        ),
    )
    api_key_group = parser.add_mutually_exclusive_group()
    api_key_group.add_argument(
        "--api-gateway-generate-keys",
        dest="api_gateway_generate_keys",
        action="store_true",
        default=None,
        help="Generate one API key for each participant when api_gateways is written.",
    )
    api_key_group.add_argument(
        "--no-api-gateway-generate-keys",
        dest="api_gateway_generate_keys",
        action="store_false",
        default=None,
        help="Do not auto-generate API keys for the participants.",
    )
    parser.add_argument(
        "--api-keys-for",
        nargs="+",
        default=None,
        metavar="GW_ID",
        help=(
            "Write an API key for each listed participant to api_keys.yaml beside "
            "--output, and point the API gateway at it with credentials_file. "
            "Needs --output (or --dry-run). The keys follow from --seed, or from a "
            "fixed default seed when --seed is not given, so the same command "
            "always yields the same keys: pass your own --seed outside a classroom."
        ),
    )
    readonly_key_group = parser.add_mutually_exclusive_group()
    readonly_key_group.add_argument(
        "--api-gateway-readonly-key",
        dest="api_gateway_readonly_key",
        action="store_true",
        default=None,
        help=(
            "Generate a read-only API key (gateway_id: null) for the dashboards "
            "(the default whenever an API gateway is written)."
        ),
    )
    readonly_key_group.add_argument(
        "--no-api-gateway-readonly-key",
        dest="api_gateway_readonly_key",
        action="store_false",
        default=None,
        help="Do not generate the read-only API key.",
    )
    parser.add_argument(
        "--api-gateway-rate-limit-writes-per-second",
        type=int,
        default=None,
        metavar="N",
        help="api_gateways.<name>.rate_limit.writes_per_second override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-rate-limit-burst",
        type=int,
        default=None,
        metavar="N",
        help="api_gateways.<name>.rate_limit.burst override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-engine-auth-sec",
        type=_finite_float_arg,
        default=None,
        metavar="SECS",
        help="api_gateways.<name>.timeouts.engine_auth_sec override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-engine-reply-sec",
        type=_finite_float_arg,
        default=None,
        metavar="SECS",
        help="api_gateways.<name>.timeouts.engine_reply_sec override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-wait-ack-sec",
        type=_finite_float_arg,
        default=None,
        metavar="SECS",
        help="api_gateways.<name>.timeouts.wait_ack_sec override (> 0).",
    )
    parser.add_argument(
        "--api-gateway-order-retention-sec",
        type=int,
        default=None,
        metavar="SECS",
        help=(
            "api_gateways.<name>.order_retention_sec override (>= 0). Seconds a "
            "terminal order stays in the gateway's in-memory cache. 0 "
            "disables eviction."
        ),
    )

    # ── ALF gateway ───────────────────────────────────────────────────────────
    parser.add_argument(
        "--alf-gateway",
        action="store_true",
        help="Emit a top-level alf_gateway section for pm-alf-gwy.",
    )
    parser.add_argument(
        "--alf-enabled",
        dest="alf_enabled",
        action="store_true",
        default=None,
        help="Set alf_gateway.enabled: true.",
    )
    parser.add_argument(
        "--alf-disabled",
        dest="alf_enabled",
        action="store_false",
        default=None,
        help="Set alf_gateway.enabled: false.",
    )
    parser.add_argument(
        "--alf-name",
        default=None,
        metavar="NAME",
        help="alf_gateway.name override.",
    )
    parser.add_argument(
        "--alf-bind-address",
        default=None,
        metavar="ADDR",
        help="alf_gateway.bind_address override.",
    )
    parser.add_argument(
        "--alf-port",
        type=_port_arg,
        default=None,
        metavar="N",
        help="alf_gateway.port override (1-65535).",
    )
    parser.add_argument(
        "--alf-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="alf_gateway.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--alf-handshake-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="alf_gateway.handshake_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--alf-idle-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="alf_gateway.idle_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--alf-max-connections",
        type=int,
        default=None,
        metavar="N",
        help="alf_gateway.max_connections override (> 0).",
    )
    parser.add_argument(
        "--alf-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="alf_gateway.max_client_queue override (> 0).",
    )
    parser.add_argument(
        "--alf-max-commands-per-second",
        type=int,
        default=None,
        metavar="N",
        help="alf_gateway.max_commands_per_second override (> 0).",
    )
    parser.add_argument(
        "--alf-max-errors-before-disconnect",
        type=int,
        default=None,
        metavar="N",
        help="alf_gateway.max_errors_before_disconnect override (> 0).",
    )
    parser.add_argument(
        "--alf-error-window-sec",
        type=int,
        default=None,
        metavar="N",
        help="alf_gateway.error_window_sec override (> 0).",
    )

    # ── BALF gateway ──────────────────────────────────────────────────────────
    parser.add_argument(
        "--balf-gateway",
        action="store_true",
        help="Emit a top-level balf_gateway section for pm-balf-gwy.",
    )
    parser.add_argument(
        "--balf-name",
        default=None,
        metavar="NAME",
        help="balf_gateway.name override.",
    )
    parser.add_argument(
        "--balf-bind-address",
        default=None,
        metavar="ADDR",
        help="balf_gateway.bind_address override.",
    )
    parser.add_argument(
        "--balf-port",
        type=_port_arg,
        default=None,
        metavar="N",
        help="balf_gateway.port override (1-65535).",
    )
    parser.add_argument(
        "--balf-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-heartbeat-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.heartbeat_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-idle-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.idle_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-auth-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.auth_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-max-connections",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.max_connections override (> 0).",
    )
    parser.add_argument(
        "--balf-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.max_client_queue override (> 0).",
    )
    parser.add_argument(
        "--balf-max-messages-per-second",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.max_messages_per_second override (> 0).",
    )
    parser.add_argument(
        "--balf-max-errors-before-disconnect",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.max_errors_before_disconnect override (> 0).",
    )
    parser.add_argument(
        "--balf-error-window-sec",
        type=int,
        default=None,
        metavar="N",
        help="balf_gateway.error_window_sec override (> 0).",
    )
    parser.add_argument(
        "--balf-duplicate-session-policy",
        default=None,
        choices=["REJECT_NEW", "EVICT_OLD"],
        help="balf_gateway.duplicate_session_policy override.",
    )

    parser.add_argument(
        "--dc-gateway",
        action="store_true",
        help="Emit a top-level dc_gateway section for pm-dc-gwy.",
    )
    parser.add_argument(
        "--dc-name",
        default=None,
        metavar="NAME",
        help="dc_gateway.name override.",
    )
    parser.add_argument(
        "--dc-bind-address",
        default=None,
        metavar="ADDR",
        help="dc_gateway.bind_address override.",
    )
    parser.add_argument(
        "--dc-port",
        type=_port_arg,
        default=None,
        metavar="N",
        help="dc_gateway.port override (1-65535).",
    )
    parser.add_argument(
        "--dc-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="dc_gateway.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--dc-idle-timeout-sec",
        type=int,
        default=None,
        metavar="N",
        help="dc_gateway.idle_timeout_sec override (> 0).",
    )
    parser.add_argument(
        "--dc-max-connections",
        type=int,
        default=None,
        metavar="N",
        help="dc_gateway.max_connections override (> 0).",
    )
    parser.add_argument(
        "--dc-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="dc_gateway.max_client_queue override (> 0).",
    )

    parser.add_argument(
        "--log-server",
        action="store_true",
        help="Emit a top-level log_server section for pm-log-srv.",
    )
    parser.add_argument(
        "--log-server-enabled",
        dest="log_server_enabled",
        action="store_true",
        default=None,
        help="Set log_server.enabled: true.",
    )
    parser.add_argument(
        "--log-server-disabled",
        dest="log_server_enabled",
        action="store_false",
        default=None,
        help="Set log_server.enabled: false.",
    )
    parser.add_argument(
        "--log-server-name",
        default=None,
        metavar="NAME",
        help="log_server.name override.",
    )
    parser.add_argument(
        "--log-server-bind-address",
        default=None,
        metavar="ADDR",
        help="log_server.bind_address override.",
    )
    parser.add_argument(
        "--log-server-port",
        type=_port_arg,
        default=None,
        metavar="N",
        help="log_server.port override (1-65535).",
    )
    parser.add_argument(
        "--log-server-db-path",
        default=None,
        metavar="PATH",
        help="log_server.db_path override.",
    )
    parser.add_argument(
        "--log-server-retention-days",
        type=int,
        default=None,
        metavar="N",
        help=(
            "log_server.retention_days override (>= 0; 0 means unbounded "
            "retention). Default 30."
        ),
    )
    parser.add_argument(
        "--log-server-max-message-bytes",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_message_bytes override (> 0).",
    )
    parser.add_argument(
        "--log-server-max-client-queue",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_client_queue override (> 0).",
    )
    parser.add_argument(
        "--log-server-write-batch-size",
        type=int,
        default=None,
        metavar="N",
        help="log_server.write_batch_size override (> 0).",
    )
    parser.add_argument(
        "--log-server-write-batch-interval-ms",
        type=int,
        default=None,
        metavar="N",
        help="log_server.write_batch_interval_ms override (> 0).",
    )
    parser.add_argument(
        "--log-server-heartbeat-interval-sec",
        type=int,
        default=None,
        metavar="N",
        help="log_server.heartbeat_interval_sec override (> 0).",
    )
    parser.add_argument(
        "--log-server-pubsub-enabled",
        dest="log_server_pubsub_enabled",
        action="store_true",
        default=None,
        help="Set log_server.pubsub_enabled: true (LALF-PS log distribution).",
    )
    parser.add_argument(
        "--log-server-pubsub-disabled",
        dest="log_server_pubsub_enabled",
        action="store_false",
        default=None,
        help="Set log_server.pubsub_enabled: false (bind no ZeroMQ sockets).",
    )
    parser.add_argument(
        "--log-server-pub-port",
        type=_port_arg,
        default=None,
        metavar="N",
        help="log_server.pub_port override — LALF-PS ZeroMQ PUB port (1-65535).",
    )
    parser.add_argument(
        "--log-server-pull-port",
        type=_port_arg,
        default=None,
        metavar="N",
        help="log_server.pull_port override — LALF-PS ZeroMQ PULL port (1-65535).",
    )
    parser.add_argument(
        "--log-server-lease-sec",
        type=int,
        default=None,
        metavar="N",
        help=(
            "log_server.lease_sec override (> 0) — subscription lease TTL; a "
            "subscriber that stops renewing is reaped after this long."
        ),
    )
    parser.add_argument(
        "--log-server-max-lease-sec",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_lease_sec override (>= lease_sec).",
    )
    parser.add_argument(
        "--log-server-max-subscribers",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_subscribers override (> 0).",
    )
    parser.add_argument(
        "--log-server-notify-interval-ms",
        type=int,
        default=None,
        metavar="N",
        help="log_server.notify_interval_ms override (> 0).",
    )
    parser.add_argument(
        "--log-server-backfill-chunk-rows",
        type=int,
        default=None,
        metavar="N",
        help="log_server.backfill_chunk_rows override (> 0).",
    )
    parser.add_argument(
        "--log-server-max-backfill-minutes",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_backfill_minutes override (> 0).",
    )
    parser.add_argument(
        "--log-server-max-backfill-rows",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_backfill_rows override (> 0).",
    )
    parser.add_argument(
        "--log-server-max-pending-rows",
        type=int,
        default=None,
        metavar="N",
        help="log_server.max_pending_rows override (> 0).",
    )
    parser.add_argument(
        "--log-server-pub-sndhwm",
        type=int,
        default=None,
        metavar="N",
        help="log_server.pub_sndhwm override (> 0).",
    )

    # monitor: health beacons and pm-monitor (operator dashboard)
    parser.add_argument(
        "--monitor",
        action="store_true",
        help=(
            "Emit a top-level monitor section (health beacons and pm-monitor) "
            "with every field. Without it every process uses the defaults; "
            "--comment-default-config-fields shows them as comments."
        ),
    )
    parser.add_argument(
        "--monitor-enabled",
        dest="monitor_enabled",
        action="store_true",
        default=None,
        help="Set monitor.enabled: true.",
    )
    parser.add_argument(
        "--monitor-disabled",
        dest="monitor_enabled",
        action="store_false",
        default=None,
        help="Set monitor.enabled: false (no beacons; pm-monitor idles).",
    )
    parser.add_argument(
        "--monitor-bind-address",
        default=None,
        metavar="ADDR",
        help="monitor.bind_address override (default 127.0.0.1).",
    )
    parser.add_argument(
        "--monitor-host",
        default=None,
        metavar="HOST",
        help="monitor.host override: where every process sends its beacons.",
    )
    parser.add_argument(
        "--monitor-pull-port",
        type=_port_arg,
        default=None,
        metavar="PORT",
        help="monitor.pull_port override, beacons in (default 5610).",
    )
    parser.add_argument(
        "--monitor-pub-port",
        type=_port_arg,
        default=None,
        metavar="PORT",
        help="monitor.pub_port override, snapshots and events out (default 5611).",
    )
    parser.add_argument(
        "--monitor-beacon-interval-sec",
        type=_finite_float_arg,
        default=None,
        metavar="SEC",
        help="monitor.beacon_interval_sec override (> 0, default 2).",
    )
    parser.add_argument(
        "--monitor-hung-after-sec",
        type=_finite_float_arg,
        default=None,
        metavar="SEC",
        help="monitor.hung_after_sec override (> beacon interval, default 5).",
    )
    parser.add_argument(
        "--monitor-silent-after-beacons",
        type=int,
        default=None,
        metavar="N",
        help="monitor.silent_after_beacons override (> 0, default 3).",
    )
    parser.add_argument(
        "--monitor-book-metrics-interval-sec",
        type=_finite_float_arg,
        default=None,
        metavar="SEC",
        help="monitor.book_metrics_interval_sec override (> 0, default 10).",
    )
    parser.add_argument(
        "--monitor-raw-hours",
        type=int,
        default=None,
        metavar="N",
        help="monitor.retention.raw_hours override (> 0, default 6).",
    )
    parser.add_argument(
        "--monitor-minute-days",
        type=int,
        default=None,
        metavar="N",
        help="monitor.retention.minute_days override (> 0, default 7).",
    )
    parser.add_argument(
        "--monitor-threshold",
        action="append",
        default=None,
        metavar="RULE:WARN:CRIT",
        help=(
            "monitor.thresholds.<RULE> override, repeatable, e.g. "
            "host_cpu_pct:70:90. Rules: host_cpu_pct, host_mem_pct, "
            "disk_free_pct (warn above crit), engine_handle_p99_us, "
            "reject_pct_5m, rss_growth_pct_1h, heap_bloat_ratio."
        ),
    )

    sched_group = parser.add_mutually_exclusive_group()
    sched_group.add_argument(
        "--schedule",
        dest="schedule",
        action="store_true",
        default=None,
        help=(
            "Write the schedule section; needs --sessions-enabled, where it "
            "is the default."
        ),
    )
    sched_group.add_argument(
        "--no-schedule",
        dest="schedule",
        action="store_false",
        default=None,
        help="Leave the schedule section out (with --sessions-enabled).",
    )

    parser.add_argument("--pre-open", default=None, metavar="HH:MM")
    parser.add_argument(
        "--opening-auction",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--continuous",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--closing-auction",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--closing-end",
        default=None,
        metavar="HH:MM",
    )

    parser.add_argument(
        "--weekend",
        action="store_true",
        default=False,
        help=(
            "Also emit a weekend: block (Sat+Sun) using the --weekend-* "
            "times below; needs --sessions-enabled. Without this flag, "
            "weekends are CLOSED."
        ),
    )
    parser.add_argument(
        "--weekend-pre-open",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--weekend-opening-auction",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--weekend-continuous",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--weekend-closing-auction",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--weekend-closing-end",
        default=None,
        metavar="HH:MM",
    )

    holidays_group = parser.add_mutually_exclusive_group()
    holidays_group.add_argument(
        "--holidays",
        dest="holidays",
        action="store_true",
        default=False,
        help=(
            "Also emit a holidays: block using the --holidays-* times "
            "below; needs --sessions-enabled. Without this flag, bank "
            "holidays are CLOSED."
        ),
    )
    holidays_group.add_argument(
        "--no-holidays",
        dest="holidays",
        action="store_false",
        default=False,
        help="Suppress the holidays: block (the default).",
    )
    parser.add_argument(
        "--holidays-pre-open",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--holidays-opening-auction",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--holidays-continuous",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--holidays-closing-auction",
        default=None,
        metavar="HH:MM",
    )
    parser.add_argument(
        "--holidays-closing-end",
        default=None,
        metavar="HH:MM",
    )

    parser.add_argument(
        "--country",
        type=str,
        default=None,
        metavar="COUNTRY",
        help=(
            "Country pm-scheduler uses for its bank-holiday/weekend calendar "
            '(name, e.g. "Sweden", or ISO 3166-1 alpha-2 code, e.g. "SE"). '
            'Defaults to "Sweden" when omitted.'
        ),
    )

    parser.add_argument(
        "--session-timezone",
        type=str,
        default=None,
        metavar="TZ",
        help=(
            "IANA timezone every process bucketing events into a trading day "
            "(pm-stats, pm-clearing, ...) uses, e.g. America/New_York. "
            'Defaults to "Europe/Stockholm" when omitted.'
        ),
    )

    parser.add_argument(
        "--index",
        action="append",
        default=[],
        metavar="ID[:DESCRIPTION]",
        help=(
            "Define an index (repeatable, up to 5). "
            "ID is letters and digits only; DESCRIPTION is optional text after the first colon."
        ),
    )
    parser.add_argument(
        "--index-constituents",
        action="append",
        default=[],
        metavar="ID:SYM[,SYM,...]",
        help=(
            "Constituent symbols for an index, all in one flag; once per index. "
            "Each needs --outstanding-shares and a reference price "
            "(--seed-mm-mid-range with --seed-last-prices-from-mm)."
        ),
    )
    parser.add_argument(
        "--index-base-value",
        action="append",
        default=[],
        metavar="ID:VALUE",
        help="Override base_value for an index (default: 1000.0). Once per index.",
    )
    parser.add_argument(
        "--index-interval",
        action="append",
        default=[],
        metavar="ID:SECS",
        help="Override publish_interval_sec for an index (default: 1.0). Once per index.",
    )
    parser.add_argument(
        "--index-history-file",
        action="append",
        default=[],
        metavar="ID:PATH",
        help="Override history_file path for an index. Once per index.",
    )
    parser.add_argument(
        "--index-state-file",
        action="append",
        default=[],
        metavar="ID:PATH",
        help="Override state_file path for an index. Once per index.",
    )

    parser.add_argument(
        "--combo",
        action="append",
        default=[],
        metavar="COMBO_SPEC",
        help=(
            "Seed a market-maker combo order: ID:TYPE:TIF:SYM/SIDE/TYPE/QTY[/PRICE[/STOP[/SMP]]],...\n"
            "PRICE and STOP are display prices (e.g. 209.50), written to the file as given and\n"
            "checked against the leg symbol's tick grid. They are not tick counts: 20950 means 20950.00.\n"
            "Example: SEED-PAIR:AON:DAY:AAPL/BUY/LIMIT/100/209.50,MSFT/SELL/LIMIT/50/415.50\n"
            "Can be repeated."
        ),
    )

    parser.add_argument(
        "--output", default=None, metavar="FILE", help="Output file path."
    )
    parser.add_argument(
        "--split",
        action="store_true",
        help=(
            "Write the symbols and the participants to symbols.yaml and "
            "participants.yaml beside --output, and list them under 'include:' in "
            "the main file. Keeps a config with hundreds of either readable."
        ),
    )
    parser.add_argument(
        "--force", action="store_true", help="Overwrite existing output file."
    )
    parser.add_argument(
        "--dry-run", action="store_true", help="Print only, do not write."
    )
    parser.add_argument(
        "--comment-default-config-fields",
        action="store_true",
        help=(
            "Add a commented-out header showing every optional section with its "
            "default values, ready to uncomment: the engine settings and the "
            "process sections (gateways, api_gateways, log_server, monitor, "
            "indices, schedule), each field explained. A section's own option "
            "(e.g. --log-server, --monitor) writes it for real instead."
        ),
    )

    return parser
