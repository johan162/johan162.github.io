"""Parser for --symbol-opts SYMBOL:KEY=VALUE[,KEY=VALUE,...]."""

from __future__ import annotations

from dataclasses import dataclass, field

from edumatcher.config_gen.cli_parser import finite_float


@dataclass
class SymbolOverride:
    tick_decimals: int | None = None
    static_band_pct: float | None = None
    dynamic_band_pct: float | None = None
    max_order_qty: int | None = None
    max_order_value: float | None = None
    cb_shift: dict[str, float] = field(default_factory=dict)
    cb_halt_mins: dict[str, int | None] = field(default_factory=dict)
    level: str | None = None
    mm_spread_ticks: int | None = None
    mm_min_qty: int | None = None
    enforce_mm_obligation: bool | None = None
    # ACE reopening overrides. The expansion ladder itself is exchange-level
    # here — a list of rungs does not fit a comma-separated option — but the
    # loader does accept a per-symbol `expansions:` when hand-edited.
    ace_enabled: bool | None = None
    ace_initial_band_pct: float | None = None
    ace_random_end_max_ns: int | None = None


_ALLOWED_KEYS = {
    "tick_decimals",
    "static_band",
    "dynamic_band",
    "max_order_qty",
    "max_order_value",
    "cb_shift_l1",
    "cb_halt_l1",
    "cb_shift_l2",
    "cb_halt_l2",
    "cb_shift_l3",
    "cb_halt_l3",
    "level",
    "mm_spread_ticks",
    "mm_min_qty",
    "enforce_mm_obligation",
    "ace_enabled",
    "ace_initial_band",
    "ace_random_end_ns",
}


def parse_symbol_opts(
    specs: list[str],
    allowed_symbols: set[str],
) -> dict[str, SymbolOverride]:
    """Parse every --symbol-opts spec; any problem is a ValueError.

    Like the dedicated per-symbol flags, a bad spec is refused rather than
    left out of the file with a warning.
    """
    overrides: dict[str, SymbolOverride] = {}

    for raw in specs:
        symbol, csv_payload = _split_symbol_spec(raw)
        if symbol not in allowed_symbols:
            raise ValueError(f"--symbol-opts references unknown symbol '{symbol}'")

        override = overrides.setdefault(symbol, SymbolOverride())
        for token in csv_payload.split(","):
            token = token.strip()
            if not token:
                continue
            if "=" not in token:
                raise ValueError(
                    f"Invalid --symbol-opts '{raw}': '{token}' is not KEY=VALUE"
                )

            key_raw, value_raw = token.split("=", 1)
            key = key_raw.strip().lower()
            value = value_raw.strip()
            if key not in _ALLOWED_KEYS:
                raise ValueError(
                    f"Invalid --symbol-opts '{raw}': unknown key '{key_raw}'; "
                    f"one of {', '.join(sorted(_ALLOWED_KEYS))}"
                )

            try:
                _apply_symbol_option(override=override, key=key, value=value)
            except ValueError as exc:
                raise ValueError(
                    f"Invalid --symbol-opts '{raw}': {key}={value} ({exc})"
                ) from None

    return overrides


def _split_symbol_spec(raw: str) -> tuple[str, str]:
    if ":" not in raw:
        raise ValueError(
            f"Invalid --symbol-opts '{raw}': expected SYMBOL:KEY=VALUE[,KEY=VALUE]"
        )
    symbol_raw, payload = raw.split(":", 1)
    symbol = symbol_raw.strip().upper()
    if not symbol:
        raise ValueError(f"Invalid --symbol-opts '{raw}': symbol cannot be empty")
    if not payload.strip():
        raise ValueError(
            f"Invalid --symbol-opts '{raw}': KEY=VALUE payload cannot be empty"
        )
    return symbol, payload


def _apply_symbol_option(override: SymbolOverride, key: str, value: str) -> None:
    """Apply one KEY=VALUE to *override*; a bad value is a ValueError."""
    if key == "tick_decimals":
        parsed_int = int(value)
        if not (0 <= parsed_int <= 8):
            raise ValueError("tick_decimals must be in range 0..8")
        override.tick_decimals = parsed_int
        return

    if key == "static_band":
        parsed_float = float(value)
        if not (0 < parsed_float < 1):
            raise ValueError("static_band must be in (0, 1)")
        override.static_band_pct = parsed_float
        return

    if key == "dynamic_band":
        parsed_float = float(value)
        if not (0 < parsed_float < 1):
            raise ValueError("dynamic_band must be in (0, 1)")
        override.dynamic_band_pct = parsed_float
        return

    if key == "max_order_qty":
        parsed_int = int(value)
        if parsed_int <= 0:
            raise ValueError("max_order_qty must be > 0")
        override.max_order_qty = parsed_int
        return

    if key == "max_order_value":
        parsed_float = finite_float(value)
        if parsed_float <= 0:
            raise ValueError("max_order_value must be > 0")
        override.max_order_value = parsed_float
        return

    if key.startswith("cb_shift_l"):
        level = key.split("_")[-1].upper()
        parsed_float = float(value)
        if not (0 < parsed_float < 1):
            raise ValueError("cb_shift must be in (0, 1)")
        override.cb_shift[level] = parsed_float
        return

    if key.startswith("cb_halt_l"):
        level = key.split("_")[-1].upper()
        parsed_int = int(value)
        if parsed_int <= 0:
            raise ValueError(
                "cb_halt must be > 0 minutes; omit it for a rest-of-day halt"
            )
        override.cb_halt_mins[level] = parsed_int
        return

    if key == "level":
        parsed_level = value.strip().upper()
        if not parsed_level:
            raise ValueError("level cannot be empty")
        override.level = parsed_level
        return

    if key == "mm_spread_ticks":
        parsed_int = int(value)
        if parsed_int <= 0:
            raise ValueError("mm_spread_ticks must be > 0")
        override.mm_spread_ticks = parsed_int
        return

    if key == "mm_min_qty":
        parsed_int = int(value)
        if parsed_int <= 0:
            raise ValueError("mm_min_qty must be > 0")
        override.mm_min_qty = parsed_int
        return

    if key == "enforce_mm_obligation":
        if value.lower() in ("true", "1", "yes"):
            override.enforce_mm_obligation = True
        elif value.lower() in ("false", "0", "no"):
            override.enforce_mm_obligation = False
        else:
            raise ValueError("enforce_mm_obligation must be true or false")
        return

    if key == "ace_enabled":
        if value.lower() in ("true", "1", "yes"):
            override.ace_enabled = True
        elif value.lower() in ("false", "0", "no"):
            override.ace_enabled = False
        else:
            raise ValueError("ace_enabled must be true or false")
        return

    if key == "ace_initial_band":
        parsed_float = float(value)
        if not (0 < parsed_float < 1):
            raise ValueError("ace_initial_band must be in (0, 1)")
        override.ace_initial_band_pct = parsed_float
        return

    if key == "ace_random_end_ns":
        parsed_int = int(value)
        if parsed_int < 0:
            raise ValueError("ace_random_end_ns must be >= 0")
        override.ace_random_end_max_ns = parsed_int
        return
