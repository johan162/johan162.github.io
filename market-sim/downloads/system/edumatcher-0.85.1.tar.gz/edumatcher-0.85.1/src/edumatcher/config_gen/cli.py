"""pm-config-gen — generate engine_config.yaml from high-level CLI inputs."""

from __future__ import annotations

import argparse
import math
import os
import shlex
import sys
from collections.abc import Callable
from datetime import date
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any, TypeVar

from dataclasses import fields, replace

import holidays

from edumatcher.cli_pipe import pipe_safe
from edumatcher.cli_version import package_version

from edumatcher.config_deploy import CompileError, compile_config
from edumatcher.engine.config_loader import is_known_timezone
from edumatcher.models.order import SmpAction
from edumatcher.models.participant import DisconnectBehaviour, ParticipantRole
from edumatcher.models.price import TickViolation, to_ticks_exact_at
from edumatcher.monitor.config import (
    INVERTED_THRESHOLDS,
    THRESHOLD_RULES,
    MonitorConfig,
    monitor_config_from_raw,
)

from edumatcher.config_gen.builder import ConfigBuilder, ConfigSpec
from edumatcher.config_gen.builder import ApiCredentialSpec, ApiGatewaySpec
from edumatcher.config_gen.builder import AlfGatewaySpec
from edumatcher.config_gen.builder import BalfGatewaySpec
from edumatcher.config_gen.builder import ComboLegSpec, ComboSpec
from edumatcher.config_gen.builder import DcGatewaySpec
from edumatcher.config_gen.builder import IndexSpec
from edumatcher.config_gen.builder import LogServerSpec
from edumatcher.config_gen.builder import MarketDataGatewaySpec
from edumatcher.config_gen.builder import PostTradeGatewaySpec
from edumatcher.config_gen.cb_spec import CbSpec, parse_cb_spec
from edumatcher.config_gen.defaults import (
    DEFAULT_ACE_INITIAL_BAND_PCT,
    DEFAULT_ACE_RANDOM_END_MAX_NS,
    DEFAULT_CB_WINDOW_NS,
    DEFAULT_HOLIDAYS_SCHEDULE,
    DEFAULT_SCHEDULE,
    DEFAULT_WEEKEND_SCHEDULE,
    DEFAULT_ALF_GATEWAY_BIND_ADDRESS,
    DEFAULT_ALF_GATEWAY_ERROR_WINDOW_SEC,
    DEFAULT_ALF_GATEWAY_HANDSHAKE_TIMEOUT_SEC,
    DEFAULT_ALF_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_ALF_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_ALF_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_ALF_GATEWAY_MAX_COMMANDS_PER_SECOND,
    DEFAULT_ALF_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_ALF_GATEWAY_MAX_ERRORS_BEFORE_DISCONNECT,
    DEFAULT_ALF_GATEWAY_NAME,
    DEFAULT_ALF_GATEWAY_PORT,
    DEFAULT_ACE_EXPANSIONS,
    DEFAULT_API_GATEWAY_ENGINE_AUTH_SEC,
    DEFAULT_API_GATEWAY_ENGINE_REPLY_SEC,
    DEFAULT_API_GATEWAY_HOST,
    DEFAULT_API_GATEWAY_LOG_LEVEL,
    DEFAULT_API_GATEWAY_PORT,
    DEFAULT_API_GATEWAY_RATE_LIMIT_BURST,
    DEFAULT_API_GATEWAY_RATE_LIMIT_WRITES_PER_SECOND,
    DEFAULT_API_GATEWAY_STATS_DB,
    DEFAULT_API_GATEWAY_ORDER_RETENTION_SEC,
    DEFAULT_API_GATEWAY_WAIT_ACK_SEC,
    DEFAULT_BALF_GATEWAY_AUTH_TIMEOUT_SEC,
    DEFAULT_BALF_GATEWAY_BIND_ADDRESS,
    DEFAULT_BALF_GATEWAY_DUPLICATE_SESSION_POLICY,
    DEFAULT_BALF_GATEWAY_ERROR_WINDOW_SEC,
    DEFAULT_BALF_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_BALF_GATEWAY_HEARTBEAT_TIMEOUT_SEC,
    DEFAULT_BALF_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_BALF_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_BALF_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_BALF_GATEWAY_MAX_ERRORS_BEFORE_DISCONNECT,
    DEFAULT_BALF_GATEWAY_MAX_MESSAGES_PER_SECOND,
    DEFAULT_BALF_GATEWAY_NAME,
    DEFAULT_BALF_GATEWAY_PORT,
    DEFAULT_DC_GATEWAY_BIND_ADDRESS,
    DEFAULT_DC_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_DC_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_DC_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_DC_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_DC_GATEWAY_NAME,
    DEFAULT_DC_GATEWAY_PORT,
    DEFAULT_LOG_SERVER_BACKFILL_CHUNK_ROWS,
    DEFAULT_LOG_SERVER_BIND_ADDRESS,
    DEFAULT_LOG_SERVER_DB_PATH,
    DEFAULT_LOG_SERVER_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_LOG_SERVER_LEASE_SEC,
    DEFAULT_LOG_SERVER_MAX_BACKFILL_MINUTES,
    DEFAULT_LOG_SERVER_MAX_BACKFILL_ROWS,
    DEFAULT_LOG_SERVER_MAX_CLIENT_QUEUE,
    DEFAULT_LOG_SERVER_MAX_LEASE_SEC,
    DEFAULT_LOG_SERVER_MAX_MESSAGE_BYTES,
    DEFAULT_LOG_SERVER_MAX_PENDING_ROWS,
    DEFAULT_LOG_SERVER_MAX_SUBSCRIBERS,
    DEFAULT_LOG_SERVER_NAME,
    DEFAULT_LOG_SERVER_NOTIFY_INTERVAL_MS,
    DEFAULT_LOG_SERVER_PORT,
    DEFAULT_LOG_SERVER_PUB_PORT,
    DEFAULT_LOG_SERVER_PUB_SNDHWM,
    DEFAULT_LOG_SERVER_PULL_PORT,
    DEFAULT_LOG_SERVER_RETENTION_DAYS,
    DEFAULT_LOG_SERVER_WRITE_BATCH_INTERVAL_MS,
    DEFAULT_LOG_SERVER_WRITE_BATCH_SIZE,
    DEFAULT_INDEX_BASE_VALUE,
    DEFAULT_INDEX_PUBLISH_INTERVAL_SEC,
    DEFAULT_MARKET_DATA_GATEWAY_BIND_ADDRESS,
    DEFAULT_MARKET_DATA_GATEWAY_DEPTH_LEVELS,
    DEFAULT_MARKET_DATA_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_MARKET_DATA_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_MARKET_DATA_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_MARKET_DATA_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_MARKET_DATA_GATEWAY_MAX_SYMBOLS_PER_CLIENT,
    DEFAULT_MARKET_DATA_GATEWAY_NAME,
    DEFAULT_MARKET_DATA_GATEWAY_PORT,
    DEFAULT_MARKET_DATA_GATEWAY_REPLAY_WINDOW_SEC,
    DEFAULT_POST_TRADE_GATEWAY_ALLOWED_ROLES,
    DEFAULT_POST_TRADE_GATEWAY_BIND_ADDRESS,
    DEFAULT_POST_TRADE_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_POST_TRADE_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_POST_TRADE_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_POST_TRADE_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_POST_TRADE_GATEWAY_NAME,
    DEFAULT_POST_TRADE_GATEWAY_PORT,
    DEFAULT_POST_TRADE_GATEWAY_REPLAY_RETENTION_SEC,
)
from edumatcher.config_gen.gateway_spec import GatewaySpec, parse_gateway_spec
from edumatcher.config_gen.renderer import (
    render_credentials_file,
    render_include_file,
    render_yaml,
)
from edumatcher.config_gen.risk_spec import parse_risk_level_spec
from edumatcher.config_gen.symbol_spec import SymbolOverride
from edumatcher.config_gen.symbol_spec import parse_symbol_opts
from edumatcher.config_gen.warnings import evaluate_diagnostics


from edumatcher.config_gen.cli_parser import build_parser, finite_float
from edumatcher.config_gen.cli_comments import build_default_engine_field_comment_lines

# (dest, flag, default) of every schedule time option, weekdays first.
_SCHEDULE_TIME_OPTIONS: tuple[tuple[str, str, str], ...] = tuple(
    (f"{prefix}{dest}", f"--{prefix.replace('_', '-')}{flag}", defaults[key])
    for prefix, defaults in (
        ("", DEFAULT_SCHEDULE),
        ("weekend_", DEFAULT_WEEKEND_SCHEDULE),
        ("holidays_", DEFAULT_HOLIDAYS_SCHEDULE),
    )
    for dest, flag, key in (
        ("pre_open", "pre-open", "pre_open"),
        ("opening_auction", "opening-auction", "opening_auction_start"),
        ("continuous", "continuous", "continuous_start"),
        ("closing_auction", "closing-auction", "closing_auction_start"),
        ("closing_end", "closing-end", "closing_auction_end"),
    )
)

# (dest, flag, default) of the options that shape circuit_breaker_defaults.
_BREAKER_OPTIONS: tuple[tuple[str, str, object], ...] = (
    ("cb_window_ns", "--cb-window-ns", DEFAULT_CB_WINDOW_NS),
    ("ace_initial_band", "--ace-initial-band", DEFAULT_ACE_INITIAL_BAND_PCT),
    ("ace_random_end_ns", "--ace-random-end-ns", DEFAULT_ACE_RANDOM_END_MAX_NS),
    ("ace_expansions", "--ace-expansions", None),
    ("ace_random_seed", "--ace-random-seed", None),
)


def _needs(flags: list[str]) -> str:
    return "needs" if len(flags) == 1 else "need"


def _resolve_gated_options(args: argparse.Namespace) -> None:
    """Refuse options that would be dropped, then fill in their defaults.

    The schedule is written only with --sessions-enabled (and not with
    --no-schedule), and circuit_breaker_defaults only with --cb-levels. An
    option shaping either one without it used to be accepted and silently
    left out of the file.
    """
    schedule_given = [
        flag
        for dest, flag, _ in _SCHEDULE_TIME_OPTIONS
        if getattr(args, dest) is not None
    ]
    if args.schedule:
        schedule_given.insert(0, "--schedule")
    schedule_given += [
        flag for flag in ("--weekend", "--holidays") if getattr(args, flag[2:])
    ]
    if schedule_given and not args.sessions_enabled:
        raise ValueError(
            f"{', '.join(schedule_given)} {_needs(schedule_given)} "
            "--sessions-enabled: without it the file has sessions_enabled: false "
            "and no schedule"
        )
    if schedule_given and args.schedule is False:
        raise ValueError(
            f"{', '.join(schedule_given)} cannot be combined with --no-schedule, "
            "which leaves the schedule out of the file"
        )
    for dest, _flag, default in _SCHEDULE_TIME_OPTIONS:
        if getattr(args, dest) is None:
            setattr(args, dest, default)

    breaker_given = [
        flag for dest, flag, _ in _BREAKER_OPTIONS if getattr(args, dest) is not None
    ]
    if args.no_ace:
        breaker_given.append("--no-ace")
    if breaker_given and not args.cb_levels:
        raise ValueError(
            f"{', '.join(breaker_given)} {_needs(breaker_given)} --cb-levels: "
            "circuit_breaker_defaults, which they shape, is written only with it"
        )
    for dest, _flag, breaker_default in _BREAKER_OPTIONS:
        if getattr(args, dest) is None:
            setattr(args, dest, breaker_default)


def _validate_basic_args(args: argparse.Namespace) -> None:
    if args.snapshot_interval <= 0:
        raise ValueError("--snapshot-interval must be > 0")
    if args.quote_history_maxlen <= 0:
        raise ValueError("--quote-history-maxlen must be > 0")
    if args.drop_copy_buffer_size <= 0:
        raise ValueError("--drop-copy-buffer-size must be > 0")
    if args.recent_trades_maxlen <= 0:
        raise ValueError("--recent-trades-maxlen must be > 0")
    if args.depth_snapshot_tolerance_ticks <= 0:
        raise ValueError("--depth-snapshot-tolerance-ticks must be > 0")
    if not (0 <= args.tick_decimals <= 8):
        raise ValueError("--tick-decimals must be in range 0..8")
    if args.mm_spread_ticks <= 0:
        raise ValueError("--mm-spread-ticks must be > 0")
    if args.mm_min_qty <= 0:
        raise ValueError("--mm-min-qty must be > 0")
    if args.mm_seed_spread_ticks <= 0:
        raise ValueError("--mm-seed-spread-ticks must be > 0")
    if args.cb_window_ns <= 0:
        raise ValueError("--cb-window-ns must be > 0")
    if not (0 < args.ace_initial_band < 1):
        raise ValueError("--ace-initial-band must be in (0, 1)")
    if args.ace_random_end_ns < 0:
        raise ValueError("--ace-random-end-ns must be >= 0")
    if (
        args.post_trade_replay_retention_sec is not None
        and args.post_trade_replay_retention_sec <= 0
    ):
        raise ValueError("--post-trade-replay-retention-sec must be > 0")
    if (
        args.post_trade_heartbeat_interval_sec is not None
        and args.post_trade_heartbeat_interval_sec <= 0
    ):
        raise ValueError("--post-trade-heartbeat-interval-sec must be > 0")
    if (
        args.post_trade_idle_timeout_sec is not None
        and args.post_trade_idle_timeout_sec <= 0
    ):
        raise ValueError("--post-trade-idle-timeout-sec must be > 0")
    if (
        args.post_trade_max_connections is not None
        and args.post_trade_max_connections <= 0
    ):
        raise ValueError("--post-trade-max-connections must be > 0")
    if (
        args.post_trade_max_client_queue is not None
        and args.post_trade_max_client_queue <= 0
    ):
        raise ValueError("--post-trade-max-client-queue must be > 0")
    if (
        args.market_data_heartbeat_interval_sec is not None
        and args.market_data_heartbeat_interval_sec <= 0
    ):
        raise ValueError("--market-data-heartbeat-interval-sec must be > 0")
    if (
        args.market_data_idle_timeout_sec is not None
        and args.market_data_idle_timeout_sec <= 0
    ):
        raise ValueError("--market-data-idle-timeout-sec must be > 0")
    if (
        args.market_data_replay_window_sec is not None
        and args.market_data_replay_window_sec <= 0
    ):
        raise ValueError("--market-data-replay-window-sec must be > 0")
    if (
        args.market_data_max_connections is not None
        and args.market_data_max_connections <= 0
    ):
        raise ValueError("--market-data-max-connections must be > 0")
    if (
        args.market_data_max_symbols_per_client is not None
        and args.market_data_max_symbols_per_client <= 0
    ):
        raise ValueError("--market-data-max-symbols-per-client must be > 0")
    if (
        args.market_data_max_client_queue is not None
        and args.market_data_max_client_queue <= 0
    ):
        raise ValueError("--market-data-max-client-queue must be > 0")
    if args.market_data_depth_levels is not None and args.market_data_depth_levels <= 0:
        raise ValueError("--market-data-depth-levels must be > 0")
    if (
        args.api_gateway_rate_limit_writes_per_second is not None
        and args.api_gateway_rate_limit_writes_per_second <= 0
    ):
        raise ValueError("--api-gateway-rate-limit-writes-per-second must be > 0")
    if (
        args.api_gateway_rate_limit_burst is not None
        and args.api_gateway_rate_limit_burst <= 0
    ):
        raise ValueError("--api-gateway-rate-limit-burst must be > 0")
    if (
        args.api_gateway_engine_auth_sec is not None
        and args.api_gateway_engine_auth_sec <= 0
    ):
        raise ValueError("--api-gateway-engine-auth-sec must be > 0")
    if (
        args.api_gateway_engine_reply_sec is not None
        and args.api_gateway_engine_reply_sec <= 0
    ):
        raise ValueError("--api-gateway-engine-reply-sec must be > 0")
    if (
        args.api_gateway_order_retention_sec is not None
        and args.api_gateway_order_retention_sec < 0
    ):
        # >= 0, not > 0: zero is meaningful here and disables eviction.
        raise ValueError("--api-gateway-order-retention-sec must be >= 0")
    if args.api_gateway_wait_ack_sec is not None and args.api_gateway_wait_ack_sec <= 0:
        raise ValueError("--api-gateway-wait-ack-sec must be > 0")

    for flag, value in (
        ("--alf-heartbeat-interval-sec", args.alf_heartbeat_interval_sec),
        ("--alf-handshake-timeout-sec", args.alf_handshake_timeout_sec),
        ("--alf-idle-timeout-sec", args.alf_idle_timeout_sec),
        ("--alf-max-connections", args.alf_max_connections),
        ("--alf-max-client-queue", args.alf_max_client_queue),
        ("--alf-max-commands-per-second", args.alf_max_commands_per_second),
        ("--alf-max-errors-before-disconnect", args.alf_max_errors_before_disconnect),
        ("--alf-error-window-sec", args.alf_error_window_sec),
    ):
        if value is not None and value <= 0:
            raise ValueError(f"{flag} must be > 0")

    if (
        args.balf_heartbeat_interval_sec is not None
        and args.balf_heartbeat_interval_sec <= 0
    ):
        raise ValueError("--balf-heartbeat-interval-sec must be > 0")
    if (
        args.balf_heartbeat_timeout_sec is not None
        and args.balf_heartbeat_timeout_sec <= 0
    ):
        raise ValueError("--balf-heartbeat-timeout-sec must be > 0")
    if args.balf_idle_timeout_sec is not None and args.balf_idle_timeout_sec <= 0:
        raise ValueError("--balf-idle-timeout-sec must be > 0")
    if args.balf_auth_timeout_sec is not None and args.balf_auth_timeout_sec <= 0:
        raise ValueError("--balf-auth-timeout-sec must be > 0")
    if args.balf_max_connections is not None and args.balf_max_connections <= 0:
        raise ValueError("--balf-max-connections must be > 0")
    if args.balf_max_client_queue is not None and args.balf_max_client_queue <= 0:
        raise ValueError("--balf-max-client-queue must be > 0")
    if (
        args.balf_max_messages_per_second is not None
        and args.balf_max_messages_per_second <= 0
    ):
        raise ValueError("--balf-max-messages-per-second must be > 0")
    if (
        args.balf_max_errors_before_disconnect is not None
        and args.balf_max_errors_before_disconnect <= 0
    ):
        raise ValueError("--balf-max-errors-before-disconnect must be > 0")
    if args.balf_error_window_sec is not None and args.balf_error_window_sec <= 0:
        raise ValueError("--balf-error-window-sec must be > 0")

    if (
        args.dc_heartbeat_interval_sec is not None
        and args.dc_heartbeat_interval_sec <= 0
    ):
        raise ValueError("--dc-heartbeat-interval-sec must be > 0")
    if args.dc_idle_timeout_sec is not None and args.dc_idle_timeout_sec <= 0:
        raise ValueError("--dc-idle-timeout-sec must be > 0")
    if args.dc_max_connections is not None and args.dc_max_connections <= 0:
        raise ValueError("--dc-max-connections must be > 0")
    if args.dc_max_client_queue is not None and args.dc_max_client_queue <= 0:
        raise ValueError("--dc-max-client-queue must be > 0")

    if (
        args.log_server_retention_days is not None
        and args.log_server_retention_days < 0
    ):
        raise ValueError("--log-server-retention-days must be >= 0")
    if (
        args.log_server_max_message_bytes is not None
        and args.log_server_max_message_bytes <= 0
    ):
        raise ValueError("--log-server-max-message-bytes must be > 0")
    if (
        args.log_server_max_client_queue is not None
        and args.log_server_max_client_queue <= 0
    ):
        raise ValueError("--log-server-max-client-queue must be > 0")
    if (
        args.log_server_write_batch_size is not None
        and args.log_server_write_batch_size <= 0
    ):
        raise ValueError("--log-server-write-batch-size must be > 0")
    if (
        args.log_server_write_batch_interval_ms is not None
        and args.log_server_write_batch_interval_ms <= 0
    ):
        raise ValueError("--log-server-write-batch-interval-ms must be > 0")
    if (
        args.log_server_heartbeat_interval_sec is not None
        and args.log_server_heartbeat_interval_sec <= 0
    ):
        raise ValueError("--log-server-heartbeat-interval-sec must be > 0")

    _validate_log_server_pubsub_args(args)

    if args.static_band is not None and not (0 < args.static_band < 1):
        raise ValueError("--static-band must be in (0, 1)")
    if args.dynamic_band is not None and not (0 < args.dynamic_band < 1):
        raise ValueError("--dynamic-band must be in (0, 1)")

    if args.seed_last_prices_from_mm and args.seed_mm_mid_range is None:
        raise ValueError("--seed-last-prices-from-mm requires --seed-mm-mid-range")

    _validate_schedule_order(args)

    if args.country is not None:
        _validate_country(args.country)

    if args.session_timezone is not None:
        _validate_session_timezone(args.session_timezone)


_LOG_SERVER_PUBSUB_POSITIVE_INT_FLAGS = (
    ("log_server_lease_sec", "--log-server-lease-sec"),
    ("log_server_max_lease_sec", "--log-server-max-lease-sec"),
    ("log_server_max_subscribers", "--log-server-max-subscribers"),
    ("log_server_notify_interval_ms", "--log-server-notify-interval-ms"),
    ("log_server_backfill_chunk_rows", "--log-server-backfill-chunk-rows"),
    ("log_server_max_backfill_minutes", "--log-server-max-backfill-minutes"),
    ("log_server_max_backfill_rows", "--log-server-max-backfill-rows"),
    ("log_server_max_pending_rows", "--log-server-max-pending-rows"),
    ("log_server_pub_sndhwm", "--log-server-pub-sndhwm"),
)


def _validate_log_server_pubsub_args(args: argparse.Namespace) -> None:
    """Validate the LALF-PS flags, including their two cross-field rules.

    The per-flag ``> 0`` checks mirror every other numeric flag in this
    module. The two relational checks are the ones worth stating here
    rather than leaving to the runtime loader: a generated file that binds
    two of pm-log-srv's three ports to the same number, or that sets a
    lease ceiling below the default lease, is one pm-log-srv would refuse
    to start on — and finding that out at generation time is much cheaper
    than finding it out at startup.
    """
    for attr, flag in _LOG_SERVER_PUBSUB_POSITIVE_INT_FLAGS:
        value = getattr(args, attr, None)
        if value is not None and value <= 0:
            raise ValueError(f"{flag} must be > 0")

    # The three ports must be distinct. Compare *effective* values so an
    # override that collides with another port's default is still caught.
    port = args.log_server_port or DEFAULT_LOG_SERVER_PORT
    pub_port = args.log_server_pub_port or DEFAULT_LOG_SERVER_PUB_PORT
    pull_port = args.log_server_pull_port or DEFAULT_LOG_SERVER_PULL_PORT
    if len({port, pub_port, pull_port}) != 3:
        raise ValueError(
            "log_server port, pub_port and pull_port must all be different "
            f"(got port={port}, pub_port={pub_port}, pull_port={pull_port})"
        )

    lease_sec = args.log_server_lease_sec or DEFAULT_LOG_SERVER_LEASE_SEC
    max_lease_sec = args.log_server_max_lease_sec or DEFAULT_LOG_SERVER_MAX_LEASE_SEC
    if max_lease_sec < lease_sec:
        raise ValueError(
            "--log-server-max-lease-sec must be >= --log-server-lease-sec "
            f"(got max_lease_sec={max_lease_sec}, lease_sec={lease_sec})"
        )


def _parse_hhmm_to_minutes(value: str, flag_name: str) -> int:
    text = value.strip()
    parts = text.split(":", 1)
    if len(parts) != 2:
        raise ValueError(f"{flag_name} must be in HH:MM format, got '{value}'")
    try:
        hours = int(parts[0])
        minutes = int(parts[1])
    except ValueError as exc:
        raise ValueError(f"{flag_name} must be in HH:MM format, got '{value}'") from exc
    if not (0 <= hours <= 23 and 0 <= minutes <= 59):
        raise ValueError(f"{flag_name} must be a valid HH:MM time, got '{value}'")
    return hours * 60 + minutes


def _validate_ordered_times(ordered_flags: tuple[tuple[str, str], ...]) -> None:
    """Ensure a block of five schedule flags is well-formed and strictly
    increasing. Shared by the weekdays/weekend/holidays blocks below.
    """
    parsed = [
        (flag_name, raw_value, _parse_hhmm_to_minutes(raw_value, flag_name))
        for flag_name, raw_value in ordered_flags
    ]
    for (flag_a, value_a, minutes_a), (flag_b, value_b, minutes_b) in zip(
        parsed, parsed[1:]
    ):
        if minutes_a >= minutes_b:
            raise ValueError(
                f"Schedule times must be strictly increasing: {flag_a} ({value_a}) "
                f"must be earlier than {flag_b} ({value_b})"
            )


def _validate_schedule_order(args: argparse.Namespace) -> None:
    """Ensure every schedule block's five times are well-formed and
    strictly increasing.

    A block where e.g. --continuous is before --opening-auction would let
    the engine reach an inconsistent session state, so the weekdays block is
    validated regardless of whether --sessions-enabled/--schedule end up
    emitting the section, matching the treatment of other argument sanity
    checks above. --weekend-*/--holidays-* are validated only when their
    block will actually be emitted (--weekend / --holidays) -- their flags
    carry defaults even when unused, and those defaults have nothing to be
    inconsistent with if the block never reaches the YAML.
    """
    _validate_ordered_times(
        (
            ("--pre-open", args.pre_open),
            ("--opening-auction", args.opening_auction),
            ("--continuous", args.continuous),
            ("--closing-auction", args.closing_auction),
            ("--closing-end", args.closing_end),
        )
    )
    if getattr(args, "weekend", False):
        _validate_ordered_times(
            (
                ("--weekend-pre-open", args.weekend_pre_open),
                ("--weekend-opening-auction", args.weekend_opening_auction),
                ("--weekend-continuous", args.weekend_continuous),
                ("--weekend-closing-auction", args.weekend_closing_auction),
                ("--weekend-closing-end", args.weekend_closing_end),
            )
        )
    if getattr(args, "holidays", False):
        _validate_ordered_times(
            (
                ("--holidays-pre-open", args.holidays_pre_open),
                ("--holidays-opening-auction", args.holidays_opening_auction),
                ("--holidays-continuous", args.holidays_continuous),
                ("--holidays-closing-auction", args.holidays_closing_auction),
                ("--holidays-closing-end", args.holidays_closing_end),
            )
        )


def _validate_country(country: str) -> None:
    """Reject a --country value pm-scheduler's holiday calendar won't recognise.

    pm-scheduler itself tolerates an unrecognised country by falling back to
    the default (Sweden) with a warning rather than failing (so a stale
    generated config never crashes the scheduler). Generation time is a
    better place to catch a typo, though, so pm-config-gen fails fast instead
    of silently emitting a config that won't do what was asked.
    """
    if not country.strip():
        raise ValueError("--country must not be blank")
    try:
        holidays.country_holidays(country)
    except NotImplementedError as exc:
        raise ValueError(
            f"--country {country!r} is not recognised by the holidays package"
        ) from exc


def _validate_session_timezone(name: str) -> None:
    """Reject a --session-timezone value zoneinfo will not recognise."""
    if not name.strip():
        raise ValueError("--session-timezone must not be blank")
    if not is_known_timezone(name):
        raise ValueError(
            f"--session-timezone {name!r} is not a recognised IANA timezone"
        )


def _parse_seed_mm_mid_range(raw: str) -> tuple[float, float]:
    if ":" not in raw:
        raise ValueError(f"Invalid --seed-mm-mid-range '{raw}': expected MIN:MAX")

    min_raw, max_raw = raw.split(":", 1)
    try:
        min_price = finite_float(min_raw.strip())
        max_price = finite_float(max_raw.strip())
    except ValueError as exc:
        raise ValueError(
            f"Invalid --seed-mm-mid-range '{raw}': MIN and MAX must be finite numbers"
        ) from exc

    if min_price <= 0 or max_price <= 0:
        raise ValueError("--seed-mm-mid-range values must be > 0")
    if min_price >= max_price:
        raise ValueError("--seed-mm-mid-range requires MIN < MAX")

    return (min_price, max_price)


def _parse_outstanding_shares(
    specs: list[str],
    allowed_symbols: set[str],
) -> dict[str, int]:
    result: dict[str, int] = {}
    for raw in specs:
        if ":" not in raw:
            raise ValueError(f"Invalid --outstanding-shares '{raw}': expected SYM:N")
        sym_raw, val_raw = raw.split(":", 1)
        sym = sym_raw.strip().upper()
        if not sym:
            raise ValueError(
                f"Invalid --outstanding-shares '{raw}': symbol cannot be empty"
            )
        if sym not in allowed_symbols:
            raise ValueError(f"--outstanding-shares references unknown symbol '{sym}'")
        try:
            value = int(val_raw.strip())
        except ValueError:
            raise ValueError(
                f"--outstanding-shares '{raw}': value must be a positive integer"
            )
        if value <= 0:
            raise ValueError(f"--outstanding-shares '{raw}': value must be > 0")
        result[sym] = value
    return result


def _parse_ace_expansion(raw: str) -> tuple[float, int]:
    """Parse one ``WIDEN_PCT:MINUTES`` rung into (widen_pct, min_duration_ns)."""
    parts = raw.split(":")
    if len(parts) != 2:
        raise ValueError(
            f"Invalid --ace-expansions '{raw}': expected WIDEN_PCT:MINUTES"
        )
    try:
        widen_pct = float(parts[0])
    except ValueError as exc:
        raise ValueError(
            f"Invalid --ace-expansions '{raw}': WIDEN_PCT must be numeric"
        ) from exc
    if not (0 < widen_pct < 1):
        raise ValueError(
            f"Invalid --ace-expansions '{raw}': WIDEN_PCT must be in (0, 1)"
        )
    try:
        minutes = int(parts[1])
    except ValueError as exc:
        raise ValueError(
            f"Invalid --ace-expansions '{raw}': MINUTES must be an integer"
        ) from exc
    if minutes <= 0:
        raise ValueError(f"Invalid --ace-expansions '{raw}': MINUTES must be > 0")
    return widen_pct, minutes * 60 * 1_000_000_000


def _parse_symbol_band_specs(
    specs: list[str],
    allowed_symbols: set[str],
    flag_name: str,
) -> dict[str, float]:
    result: dict[str, float] = {}
    for raw in specs:
        if ":" not in raw:
            raise ValueError(f"Invalid {flag_name} '{raw}': expected SYM:PCT")
        sym_raw, val_raw = raw.split(":", 1)
        sym = sym_raw.strip().upper()
        if not sym:
            raise ValueError(f"Invalid {flag_name} '{raw}': symbol cannot be empty")
        if sym not in allowed_symbols:
            raise ValueError(f"{flag_name} references unknown symbol '{sym}'")
        try:
            value = float(val_raw.strip())
        except ValueError:
            raise ValueError(f"{flag_name} '{raw}': value must be numeric")
        if not (0 < value < 1):
            raise ValueError(f"{flag_name} '{raw}': value must be in (0, 1)")
        result[sym] = value
    return result


#: Order-limit caps are integers (shares) or floats (notional); the parser is
#: the same either way, so the numeric type travels with the caller's `cast`.
_Cap = TypeVar("_Cap", int, float)


def _parse_symbol_cap_specs(
    specs: list[str],
    allowed_symbols: set[str],
    flag_name: str,
    cast: Callable[[str], _Cap],
) -> dict[str, _Cap]:
    """Parse repeated ``SYM:VALUE`` order-limit flags.

    Shares its shape with :func:`_parse_symbol_band_specs`; the difference is
    the domain — a cap is any positive number, not a fraction in ``(0, 1)`` —
    so the numeric type is the caller's to choose.
    """
    result: dict[str, _Cap] = {}
    for raw in specs:
        if ":" not in raw:
            raise ValueError(f"Invalid {flag_name} '{raw}': expected SYM:VALUE")
        sym_raw, val_raw = raw.split(":", 1)
        sym = sym_raw.strip().upper()
        if not sym:
            raise ValueError(f"Invalid {flag_name} '{raw}': symbol cannot be empty")
        if sym not in allowed_symbols:
            raise ValueError(f"{flag_name} references unknown symbol '{sym}'")
        try:
            value = cast(val_raw.strip())
        except ValueError:
            raise ValueError(f"{flag_name} '{raw}': value must be numeric")
        if value <= 0:
            raise ValueError(f"{flag_name} '{raw}': value must be > 0")
        result[sym] = value
    return result


def _parse_symbol_level_specs(
    specs: list[str],
    allowed_symbols: set[str],
) -> dict[str, str]:
    result: dict[str, str] = {}
    for raw in specs:
        if ":" not in raw:
            raise ValueError(f"Invalid --symbol-risk-level '{raw}': expected SYM:LEVEL")
        sym_raw, level_raw = raw.split(":", 1)
        sym = sym_raw.strip().upper()
        if not sym:
            raise ValueError(
                f"Invalid --symbol-risk-level '{raw}': symbol cannot be empty"
            )
        if sym not in allowed_symbols:
            raise ValueError(f"--symbol-risk-level references unknown symbol '{sym}'")
        level = level_raw.strip().upper()
        if not level:
            raise ValueError(
                f"Invalid --symbol-risk-level '{raw}': level cannot be empty"
            )
        result[sym] = level
    return result


def _parse_gateway_smp_specs(
    specs: list[str],
    allowed_gateways: set[str],
) -> dict[str, SmpAction]:
    result: dict[str, SmpAction] = {}
    for raw in specs:
        if ":" not in raw:
            raise ValueError(
                f"Invalid --participant-smp '{raw}': expected GW_ID:SMP_ACTION"
            )
        gw_raw, smp_raw = raw.split(":", 1)
        gateway_id = gw_raw.strip().upper()
        if not gateway_id:
            raise ValueError(
                f"Invalid --participant-smp '{raw}': gateway ID cannot be empty"
            )
        if gateway_id not in allowed_gateways:
            raise ValueError(
                f"--participant-smp references unknown gateway_id '{gateway_id}'"
            )
        if gateway_id in result:
            raise ValueError(f"Duplicate --participant-smp for gateway '{gateway_id}'")
        smp_str = smp_raw.strip().upper()
        try:
            smp_action = SmpAction(smp_str)
        except ValueError:
            raise ValueError(
                f"Invalid --participant-smp '{raw}': smp_action '{smp_str}' is invalid"
            ) from None
        result[gateway_id] = smp_action
    return result


def _parse_gateway_desc_specs(
    specs: list[str],
    allowed_gateways: set[str],
) -> dict[str, str]:
    result: dict[str, str] = {}
    for raw in specs:
        if ":" not in raw:
            raise ValueError(f"Invalid --participant-desc '{raw}': expected GW_ID:TEXT")
        gw_raw, text_raw = raw.split(":", 1)
        gateway_id = gw_raw.strip()
        if gateway_id not in allowed_gateways:
            raise ValueError(
                f"--participant-desc references unknown gateway_id '{gateway_id}'"
            )
        if gateway_id in result:
            raise ValueError(f"Duplicate --participant-desc for gateway '{gateway_id}'")
        text = text_raw.strip()
        if not text:
            raise ValueError(
                f"Invalid --participant-desc '{raw}': description cannot be empty"
            )
        result[gateway_id] = text
    return result


def _parse_api_credentials(
    specs: list[str], allowed_gateways: set[str]
) -> tuple[ApiCredentialSpec, ...]:
    credentials: list[ApiCredentialSpec] = []
    seen_keys: set[str] = set()
    for raw in specs:
        parts = raw.split(":", 2)
        if len(parts) < 2:
            raise ValueError(
                f"Invalid --api-key '{raw}': expected KEY:GATEWAY_ID[:DESCRIPTION]"
            )
        api_key = parts[0].strip()
        gateway_raw = parts[1].strip()
        description = parts[2].strip() if len(parts) == 3 else ""
        if not api_key:
            raise ValueError(f"Invalid --api-key '{raw}': key cannot be empty")
        if api_key in seen_keys:
            raise ValueError(f"Duplicate --api-key value '{api_key}'")
        seen_keys.add(api_key)
        gateway_id = None if gateway_raw.lower() == "null" else gateway_raw.upper()
        if gateway_id is not None and gateway_id not in allowed_gateways:
            raise ValueError(f"--api-key references unknown gateway_id '{gateway_id}'")
        credentials.append(
            ApiCredentialSpec(
                api_key=api_key,
                gateway_id=gateway_id,
                description=description,
            )
        )
    return tuple(credentials)


def _parse_api_gateway_instance(
    raw: str, allowed_gateways: set[str]
) -> tuple[str, tuple[str, ...], int | None]:
    parts = raw.split(":")
    if len(parts) not in (2, 3):
        raise ValueError(
            f"Invalid --api-gateway-instance '{raw}': expected NAME:GATEWAY[,GATEWAY...][:PORT]"
        )
    name = parts[0].strip()
    if not name:
        raise ValueError(
            f"Invalid --api-gateway-instance '{raw}': name cannot be empty"
        )

    gateway_ids = tuple(
        gateway_raw.strip().upper()
        for gateway_raw in parts[1].split(",")
        if gateway_raw.strip()
    )
    if not gateway_ids and len(parts) == 2:
        raise ValueError(
            f"Invalid --api-gateway-instance '{raw}': at least one gateway ID is required"
        )
    for gateway_id in gateway_ids:
        if gateway_id not in allowed_gateways:
            raise ValueError(
                f"--api-gateway-instance '{raw}' references unknown gateway_id '{gateway_id}'"
            )

    port: int | None = None
    if len(parts) == 3 and parts[2].strip():
        try:
            port = int(parts[2].strip())
        except ValueError as exc:
            raise ValueError(
                f"Invalid --api-gateway-instance '{raw}': PORT must be an integer"
            ) from exc
        if not 1 <= port <= 65535:
            raise ValueError(
                f"Invalid --api-gateway-instance '{raw}': PORT must be in 1-65535"
            )
    return name, gateway_ids, port


def _parse_specs(args: argparse.Namespace) -> tuple[
    list[str],
    list[GatewaySpec],
    dict[str, tuple[float, float | None]],
    list[CbSpec],
    list[tuple[float, int]],
    dict[str, SymbolOverride],
    dict[str, int],
    tuple[float, float] | None,
]:
    symbols = [s.upper() for s in args.symbols]
    duplicates = sorted({s for s in symbols if symbols.count(s) > 1})
    if duplicates:
        raise ValueError(
            f"--symbols lists {', '.join(duplicates)} more than once "
            "(names are upper-cased)"
        )

    gateways = [parse_gateway_spec(raw) for raw in args.participants]

    gateway_smp = _parse_gateway_smp_specs(
        specs=args.participant_smp,
        allowed_gateways={gw.gateway_id for gw in gateways},
    )
    if gateway_smp:
        gateways = [
            (
                replace(gw, smp_action=gateway_smp[gw.gateway_id], smp_explicit=True)
                if gw.gateway_id in gateway_smp
                else gw
            )
            for gw in gateways
        ]

    gateway_desc = _parse_gateway_desc_specs(
        specs=args.participant_desc,
        allowed_gateways={gw.gateway_id for gw in gateways},
    )
    gateways = [
        replace(gw, description=gateway_desc.get(gw.gateway_id, "")) for gw in gateways
    ]

    risk_levels: dict[str, tuple[float, float | None]] = {}
    for raw in args.risk_level:
        spec = parse_risk_level_spec(raw)
        risk_levels[spec.name] = (spec.static_pct, spec.dynamic_pct)

    cb_levels: list[CbSpec] = []
    if args.cb_levels is not None:
        cb_levels = [parse_cb_spec(raw) for raw in args.cb_levels]

    ace_expansions = (
        [_parse_ace_expansion(raw) for raw in args.ace_expansions]
        if args.ace_expansions is not None
        else list(DEFAULT_ACE_EXPANSIONS)
    )

    symbol_overrides = parse_symbol_opts(
        specs=args.symbol_opts,
        allowed_symbols=set(symbols),
    )

    symbol_static_bands = _parse_symbol_band_specs(
        specs=args.symbol_static_band,
        allowed_symbols=set(symbols),
        flag_name="--symbol-static-band",
    )
    for sym, static_band in symbol_static_bands.items():
        symbol_overrides.setdefault(sym, SymbolOverride()).static_band_pct = static_band

    symbol_dynamic_bands = _parse_symbol_band_specs(
        specs=args.symbol_dynamic_band,
        allowed_symbols=set(symbols),
        flag_name="--symbol-dynamic-band",
    )
    for sym, dynamic_band in symbol_dynamic_bands.items():
        symbol_overrides.setdefault(sym, SymbolOverride()).dynamic_band_pct = (
            dynamic_band
        )

    symbol_max_order_qtys = _parse_symbol_cap_specs(
        specs=args.symbol_max_order_qty,
        allowed_symbols=set(symbols),
        flag_name="--symbol-max-order-qty",
        cast=int,
    )
    for sym, max_order_qty in symbol_max_order_qtys.items():
        symbol_overrides.setdefault(sym, SymbolOverride()).max_order_qty = max_order_qty

    symbol_max_order_values = _parse_symbol_cap_specs(
        specs=args.symbol_max_order_value,
        allowed_symbols=set(symbols),
        flag_name="--symbol-max-order-value",
        cast=finite_float,
    )
    for sym, max_order_value in symbol_max_order_values.items():
        symbol_overrides.setdefault(sym, SymbolOverride()).max_order_value = (
            max_order_value
        )

    symbol_risk_levels = _parse_symbol_level_specs(
        specs=args.symbol_risk_level,
        allowed_symbols=set(symbols),
    )
    for sym, risk_level in symbol_risk_levels.items():
        symbol_overrides.setdefault(sym, SymbolOverride()).level = risk_level

    outstanding_shares = _parse_outstanding_shares(
        specs=args.outstanding_shares,
        allowed_symbols=set(symbols),
    )

    seed_mm_mid_range = (
        _parse_seed_mm_mid_range(args.seed_mm_mid_range)
        if args.seed_mm_mid_range is not None
        else None
    )

    return (
        symbols,
        gateways,
        risk_levels,
        cb_levels,
        ace_expansions,
        symbol_overrides,
        outstanding_shares,
        seed_mm_mid_range,
    )


def _resolve_emit_schedule(args: argparse.Namespace) -> bool:
    if args.schedule is None:
        return bool(args.sessions_enabled)
    return bool(args.schedule)


def _engine_tuning_was_requested(argv: list[str]) -> bool:
    tuning_options = (
        "--snapshot-interval",
        "--quote-history-maxlen",
        "--drop-copy-buffer-size",
        "--recent-trades-maxlen",
        "--depth-snapshot-tolerance-ticks",
    )
    return any(
        argument == option or argument.startswith(f"{option}=")
        for argument in argv
        for option in tuning_options
    )


def _print_diagnostics(lines: list[str]) -> None:
    for line in lines:
        print(line, file=sys.stderr)


def _build_post_trade_gateway_spec(
    args: argparse.Namespace,
) -> PostTradeGatewaySpec | None:
    emit = any(
        value is not None
        for value in (
            args.post_trade_name,
            args.post_trade_bind_address,
            args.post_trade_port,
            args.post_trade_replay_retention_sec,
            args.post_trade_heartbeat_interval_sec,
            args.post_trade_idle_timeout_sec,
            args.post_trade_max_connections,
            args.post_trade_max_client_queue,
            args.post_trade_allowed_roles,
        )
    ) or bool(args.post_trade_gateway)

    if not emit:
        return None

    allowed_roles = tuple(
        role.upper()
        for role in (
            args.post_trade_allowed_roles or DEFAULT_POST_TRADE_GATEWAY_ALLOWED_ROLES
        )
    )

    return PostTradeGatewaySpec(
        name=str(args.post_trade_name or DEFAULT_POST_TRADE_GATEWAY_NAME),
        bind_address=str(
            args.post_trade_bind_address or DEFAULT_POST_TRADE_GATEWAY_BIND_ADDRESS
        ),
        port=int(args.post_trade_port or DEFAULT_POST_TRADE_GATEWAY_PORT),
        replay_retention_sec=int(
            args.post_trade_replay_retention_sec
            or DEFAULT_POST_TRADE_GATEWAY_REPLAY_RETENTION_SEC
        ),
        heartbeat_interval_sec=int(
            args.post_trade_heartbeat_interval_sec
            or DEFAULT_POST_TRADE_GATEWAY_HEARTBEAT_INTERVAL_SEC
        ),
        idle_timeout_sec=int(
            args.post_trade_idle_timeout_sec
            or DEFAULT_POST_TRADE_GATEWAY_IDLE_TIMEOUT_SEC
        ),
        max_connections=int(
            args.post_trade_max_connections
            or DEFAULT_POST_TRADE_GATEWAY_MAX_CONNECTIONS
        ),
        max_client_queue=int(
            args.post_trade_max_client_queue
            or DEFAULT_POST_TRADE_GATEWAY_MAX_CLIENT_QUEUE
        ),
        allowed_roles=allowed_roles,
    )


def _build_market_data_gateway_spec(
    args: argparse.Namespace,
) -> MarketDataGatewaySpec | None:
    emit = any(
        value is not None
        for value in (
            args.market_data_enabled,
            args.market_data_name,
            args.market_data_bind_address,
            args.market_data_port,
            args.market_data_heartbeat_interval_sec,
            args.market_data_idle_timeout_sec,
            args.market_data_replay_window_sec,
            args.market_data_max_connections,
            args.market_data_max_symbols_per_client,
            args.market_data_max_client_queue,
            args.market_data_depth_levels,
        )
    ) or bool(args.market_data_gateway)

    if not emit:
        return None

    enabled = (
        bool(args.market_data_enabled) if args.market_data_enabled is not None else True
    )

    return MarketDataGatewaySpec(
        enabled=enabled,
        name=str(args.market_data_name or DEFAULT_MARKET_DATA_GATEWAY_NAME),
        bind_address=str(
            args.market_data_bind_address or DEFAULT_MARKET_DATA_GATEWAY_BIND_ADDRESS
        ),
        port=int(args.market_data_port or DEFAULT_MARKET_DATA_GATEWAY_PORT),
        heartbeat_interval_sec=int(
            args.market_data_heartbeat_interval_sec
            or DEFAULT_MARKET_DATA_GATEWAY_HEARTBEAT_INTERVAL_SEC
        ),
        idle_timeout_sec=int(
            args.market_data_idle_timeout_sec
            or DEFAULT_MARKET_DATA_GATEWAY_IDLE_TIMEOUT_SEC
        ),
        replay_window_sec=int(
            args.market_data_replay_window_sec
            or DEFAULT_MARKET_DATA_GATEWAY_REPLAY_WINDOW_SEC
        ),
        max_connections=int(
            args.market_data_max_connections
            or DEFAULT_MARKET_DATA_GATEWAY_MAX_CONNECTIONS
        ),
        max_symbols_per_client=int(
            args.market_data_max_symbols_per_client
            or DEFAULT_MARKET_DATA_GATEWAY_MAX_SYMBOLS_PER_CLIENT
        ),
        max_client_queue=int(
            args.market_data_max_client_queue
            or DEFAULT_MARKET_DATA_GATEWAY_MAX_CLIENT_QUEUE
        ),
        depth_levels=int(
            args.market_data_depth_levels or DEFAULT_MARKET_DATA_GATEWAY_DEPTH_LEVELS
        ),
    )


def _build_alf_gateway_spec(
    args: argparse.Namespace,
) -> AlfGatewaySpec | None:
    emit = any(
        value is not None
        for value in (
            args.alf_enabled,
            args.alf_name,
            args.alf_bind_address,
            args.alf_port,
            args.alf_heartbeat_interval_sec,
            args.alf_handshake_timeout_sec,
            args.alf_idle_timeout_sec,
            args.alf_max_connections,
            args.alf_max_client_queue,
            args.alf_max_commands_per_second,
            args.alf_max_errors_before_disconnect,
            args.alf_error_window_sec,
        )
    ) or bool(args.alf_gateway)

    if not emit:
        return None

    return AlfGatewaySpec(
        enabled=bool(args.alf_enabled) if args.alf_enabled is not None else True,
        name=str(args.alf_name or DEFAULT_ALF_GATEWAY_NAME),
        bind_address=str(args.alf_bind_address or DEFAULT_ALF_GATEWAY_BIND_ADDRESS),
        port=int(args.alf_port or DEFAULT_ALF_GATEWAY_PORT),
        heartbeat_interval_sec=int(
            args.alf_heartbeat_interval_sec
            or DEFAULT_ALF_GATEWAY_HEARTBEAT_INTERVAL_SEC
        ),
        handshake_timeout_sec=int(
            args.alf_handshake_timeout_sec or DEFAULT_ALF_GATEWAY_HANDSHAKE_TIMEOUT_SEC
        ),
        idle_timeout_sec=int(
            args.alf_idle_timeout_sec or DEFAULT_ALF_GATEWAY_IDLE_TIMEOUT_SEC
        ),
        max_connections=int(
            args.alf_max_connections or DEFAULT_ALF_GATEWAY_MAX_CONNECTIONS
        ),
        max_client_queue=int(
            args.alf_max_client_queue or DEFAULT_ALF_GATEWAY_MAX_CLIENT_QUEUE
        ),
        max_commands_per_second=int(
            args.alf_max_commands_per_second
            or DEFAULT_ALF_GATEWAY_MAX_COMMANDS_PER_SECOND
        ),
        max_errors_before_disconnect=int(
            args.alf_max_errors_before_disconnect
            or DEFAULT_ALF_GATEWAY_MAX_ERRORS_BEFORE_DISCONNECT
        ),
        error_window_sec=int(
            args.alf_error_window_sec or DEFAULT_ALF_GATEWAY_ERROR_WINDOW_SEC
        ),
    )


def _build_balf_gateway_spec(
    args: argparse.Namespace,
) -> BalfGatewaySpec | None:
    emit = any(
        value is not None
        for value in (
            args.balf_name,
            args.balf_bind_address,
            args.balf_port,
            args.balf_heartbeat_interval_sec,
            args.balf_heartbeat_timeout_sec,
            args.balf_idle_timeout_sec,
            args.balf_auth_timeout_sec,
            args.balf_max_connections,
            args.balf_max_client_queue,
            args.balf_max_messages_per_second,
            args.balf_max_errors_before_disconnect,
            args.balf_error_window_sec,
            args.balf_duplicate_session_policy,
        )
    ) or bool(args.balf_gateway)

    if not emit:
        return None

    return BalfGatewaySpec(
        name=str(args.balf_name or DEFAULT_BALF_GATEWAY_NAME),
        bind_address=str(args.balf_bind_address or DEFAULT_BALF_GATEWAY_BIND_ADDRESS),
        port=int(args.balf_port or DEFAULT_BALF_GATEWAY_PORT),
        heartbeat_interval_sec=int(
            args.balf_heartbeat_interval_sec
            or DEFAULT_BALF_GATEWAY_HEARTBEAT_INTERVAL_SEC
        ),
        heartbeat_timeout_sec=int(
            args.balf_heartbeat_timeout_sec
            or DEFAULT_BALF_GATEWAY_HEARTBEAT_TIMEOUT_SEC
        ),
        idle_timeout_sec=int(
            args.balf_idle_timeout_sec or DEFAULT_BALF_GATEWAY_IDLE_TIMEOUT_SEC
        ),
        auth_timeout_sec=int(
            args.balf_auth_timeout_sec or DEFAULT_BALF_GATEWAY_AUTH_TIMEOUT_SEC
        ),
        max_connections=int(
            args.balf_max_connections or DEFAULT_BALF_GATEWAY_MAX_CONNECTIONS
        ),
        max_client_queue=int(
            args.balf_max_client_queue or DEFAULT_BALF_GATEWAY_MAX_CLIENT_QUEUE
        ),
        max_messages_per_second=int(
            args.balf_max_messages_per_second
            or DEFAULT_BALF_GATEWAY_MAX_MESSAGES_PER_SECOND
        ),
        max_errors_before_disconnect=int(
            args.balf_max_errors_before_disconnect
            or DEFAULT_BALF_GATEWAY_MAX_ERRORS_BEFORE_DISCONNECT
        ),
        error_window_sec=int(
            args.balf_error_window_sec or DEFAULT_BALF_GATEWAY_ERROR_WINDOW_SEC
        ),
        duplicate_session_policy=str(
            args.balf_duplicate_session_policy
            or DEFAULT_BALF_GATEWAY_DUPLICATE_SESSION_POLICY
        ),
    )


def _build_dc_gateway_spec(
    args: argparse.Namespace,
) -> DcGatewaySpec | None:
    emit = any(
        value is not None
        for value in (
            args.dc_name,
            args.dc_bind_address,
            args.dc_port,
            args.dc_heartbeat_interval_sec,
            args.dc_idle_timeout_sec,
            args.dc_max_connections,
            args.dc_max_client_queue,
        )
    ) or bool(args.dc_gateway)

    if not emit:
        return None

    return DcGatewaySpec(
        name=str(args.dc_name or DEFAULT_DC_GATEWAY_NAME),
        bind_address=str(args.dc_bind_address or DEFAULT_DC_GATEWAY_BIND_ADDRESS),
        port=int(args.dc_port or DEFAULT_DC_GATEWAY_PORT),
        heartbeat_interval_sec=int(
            args.dc_heartbeat_interval_sec or DEFAULT_DC_GATEWAY_HEARTBEAT_INTERVAL_SEC
        ),
        idle_timeout_sec=int(
            args.dc_idle_timeout_sec or DEFAULT_DC_GATEWAY_IDLE_TIMEOUT_SEC
        ),
        max_connections=int(
            args.dc_max_connections or DEFAULT_DC_GATEWAY_MAX_CONNECTIONS
        ),
        max_client_queue=int(
            args.dc_max_client_queue or DEFAULT_DC_GATEWAY_MAX_CLIENT_QUEUE
        ),
    )


#: (option dest, monitor field) for the scalar --monitor-* overrides.
_MONITOR_FIELDS: tuple[tuple[str, str], ...] = (
    ("monitor_enabled", "enabled"),
    ("monitor_bind_address", "bind_address"),
    ("monitor_host", "host"),
    ("monitor_pull_port", "pull_port"),
    ("monitor_pub_port", "pub_port"),
    ("monitor_beacon_interval_sec", "beacon_interval_sec"),
    ("monitor_hung_after_sec", "hung_after_sec"),
    ("monitor_silent_after_beacons", "silent_after_beacons"),
    ("monitor_book_metrics_interval_sec", "book_metrics_interval_sec"),
)


def _parse_monitor_thresholds(values: list[str]) -> dict[str, dict[str, float]]:
    """``RULE:WARN:CRIT`` options as a ``thresholds`` mapping."""
    out: dict[str, dict[str, float]] = {}
    for value in values:
        parts = value.split(":")
        if len(parts) != 3:
            raise ValueError(
                f"--monitor-threshold {value!r}: expected RULE:WARN:CRIT, "
                "e.g. host_cpu_pct:70:90"
            )
        rule, warn_text, crit_text = parts
        if rule not in THRESHOLD_RULES:
            raise ValueError(
                f"--monitor-threshold {value!r}: unknown rule {rule!r}; one of "
                + ", ".join(THRESHOLD_RULES)
            )
        if rule in out:
            raise ValueError(f"--monitor-threshold given twice for {rule!r}")
        try:
            out[rule] = {
                "warn": finite_float(warn_text),
                "crit": finite_float(crit_text),
            }
        except ValueError:
            raise ValueError(
                f"--monitor-threshold {value!r}: WARN and CRIT must be finite numbers"
            ) from None
    return out


def _build_monitor_spec(args: argparse.Namespace) -> MonitorConfig | None:
    """The ``monitor`` block the options ask for, or ``None`` to omit it.

    Built through pm-monitor's own loader, so defaults and range checks are
    the runtime's; the cross-field rules the loader leaves to the verifier
    (M029 band order, M030 hung above the interval, distinct ports) are
    checked here too, so pm-config-gen never writes a block pm-config-deploy
    would refuse. A host that cannot reach the bind address (M031) is only a
    warning, as in the verifier.
    """
    raw: dict[str, Any] = {
        field: getattr(args, dest)
        for dest, field in _MONITOR_FIELDS
        if getattr(args, dest, None) is not None
    }
    retention = {
        key: value
        for key, value in (
            ("raw_hours", getattr(args, "monitor_raw_hours", None)),
            ("minute_days", getattr(args, "monitor_minute_days", None)),
        )
        if value is not None
    }
    if retention:
        raw["retention"] = retention
    if getattr(args, "monitor_threshold", None):
        raw["thresholds"] = _parse_monitor_thresholds(args.monitor_threshold)
    if not raw and not getattr(args, "monitor", False):
        return None
    try:
        config = monitor_config_from_raw({"monitor": raw})
    except ValueError as exc:
        raise ValueError(f"monitor options: {exc}") from None
    if config.pull_port == config.pub_port:
        raise ValueError(
            f"--monitor-pull-port and --monitor-pub-port must differ "
            f"(both {config.pull_port})"
        )
    if config.hung_after_sec <= config.beacon_interval_sec:
        raise ValueError(
            f"--monitor-hung-after-sec ({config.hung_after_sec:g}) must be greater "
            f"than the beacon interval ({config.beacon_interval_sec:g}) (M030)"
        )
    for f in fields(config.thresholds):
        band = getattr(config.thresholds, f.name)
        inverted = f.name in INVERTED_THRESHOLDS
        if (band.warn <= band.crit) if inverted else (band.warn >= band.crit):
            order = "above" if inverted else "below"
            raise ValueError(
                f"monitor threshold {f.name}: warn ({band.warn:g}) must be strictly "
                f"{order} crit ({band.crit:g}) (M029)"
            )
    wildcard = config.bind_address in ("0.0.0.0", "::", "*")
    loopback = {"127.0.0.1", "localhost", "::1"}
    if not (
        wildcard
        or config.bind_address == config.host
        or (config.bind_address in loopback and config.host in loopback)
    ):
        print(
            f"[WARN] monitor.bind_address ({config.bind_address}) is neither a "
            f"wildcard nor monitor.host ({config.host}): beacons sent to "
            f"{config.host} may not reach pm-monitor (M031)",
            file=sys.stderr,
        )
    return config


def _build_log_server_spec(
    args: argparse.Namespace,
) -> LogServerSpec | None:
    emit = any(
        value is not None
        for value in (
            args.log_server_enabled,
            args.log_server_name,
            args.log_server_bind_address,
            args.log_server_port,
            args.log_server_db_path,
            args.log_server_retention_days,
            args.log_server_max_message_bytes,
            args.log_server_max_client_queue,
            args.log_server_write_batch_size,
            args.log_server_write_batch_interval_ms,
            args.log_server_heartbeat_interval_sec,
            args.log_server_pubsub_enabled,
            args.log_server_pub_port,
            args.log_server_pull_port,
            args.log_server_lease_sec,
            args.log_server_max_lease_sec,
            args.log_server_max_subscribers,
            args.log_server_notify_interval_ms,
            args.log_server_backfill_chunk_rows,
            args.log_server_max_backfill_minutes,
            args.log_server_max_backfill_rows,
            args.log_server_max_pending_rows,
            args.log_server_pub_sndhwm,
        )
    ) or bool(args.log_server)

    if not emit:
        return None

    enabled = (
        bool(args.log_server_enabled) if args.log_server_enabled is not None else True
    )
    pubsub_enabled = (
        bool(args.log_server_pubsub_enabled)
        if args.log_server_pubsub_enabled is not None
        else True
    )

    retention_days = (
        int(args.log_server_retention_days)
        if args.log_server_retention_days is not None
        else DEFAULT_LOG_SERVER_RETENTION_DAYS
    )

    return LogServerSpec(
        enabled=enabled,
        name=str(args.log_server_name or DEFAULT_LOG_SERVER_NAME),
        bind_address=str(
            args.log_server_bind_address or DEFAULT_LOG_SERVER_BIND_ADDRESS
        ),
        port=int(args.log_server_port or DEFAULT_LOG_SERVER_PORT),
        db_path=str(args.log_server_db_path or DEFAULT_LOG_SERVER_DB_PATH),
        retention_days=retention_days,
        max_message_bytes=int(
            args.log_server_max_message_bytes or DEFAULT_LOG_SERVER_MAX_MESSAGE_BYTES
        ),
        max_client_queue=int(
            args.log_server_max_client_queue or DEFAULT_LOG_SERVER_MAX_CLIENT_QUEUE
        ),
        write_batch_size=int(
            args.log_server_write_batch_size or DEFAULT_LOG_SERVER_WRITE_BATCH_SIZE
        ),
        write_batch_interval_ms=int(
            args.log_server_write_batch_interval_ms
            or DEFAULT_LOG_SERVER_WRITE_BATCH_INTERVAL_MS
        ),
        heartbeat_interval_sec=int(
            args.log_server_heartbeat_interval_sec
            or DEFAULT_LOG_SERVER_HEARTBEAT_INTERVAL_SEC
        ),
        pubsub_enabled=pubsub_enabled,
        pub_port=int(args.log_server_pub_port or DEFAULT_LOG_SERVER_PUB_PORT),
        pull_port=int(args.log_server_pull_port or DEFAULT_LOG_SERVER_PULL_PORT),
        lease_sec=int(args.log_server_lease_sec or DEFAULT_LOG_SERVER_LEASE_SEC),
        max_lease_sec=int(
            args.log_server_max_lease_sec or DEFAULT_LOG_SERVER_MAX_LEASE_SEC
        ),
        max_subscribers=int(
            args.log_server_max_subscribers or DEFAULT_LOG_SERVER_MAX_SUBSCRIBERS
        ),
        notify_interval_ms=int(
            args.log_server_notify_interval_ms or DEFAULT_LOG_SERVER_NOTIFY_INTERVAL_MS
        ),
        backfill_chunk_rows=int(
            args.log_server_backfill_chunk_rows
            or DEFAULT_LOG_SERVER_BACKFILL_CHUNK_ROWS
        ),
        max_backfill_minutes=int(
            args.log_server_max_backfill_minutes
            or DEFAULT_LOG_SERVER_MAX_BACKFILL_MINUTES
        ),
        max_backfill_rows=int(
            args.log_server_max_backfill_rows or DEFAULT_LOG_SERVER_MAX_BACKFILL_ROWS
        ),
        max_pending_rows=int(
            args.log_server_max_pending_rows or DEFAULT_LOG_SERVER_MAX_PENDING_ROWS
        ),
        pub_sndhwm=int(args.log_server_pub_sndhwm or DEFAULT_LOG_SERVER_PUB_SNDHWM),
    )


def _build_api_gateway_specs(
    args: argparse.Namespace,
    gateways: list[GatewaySpec],
) -> tuple[ApiGatewaySpec, ...]:
    emit = any(
        value is not None
        for value in (
            args.api_gateway_enabled,
            args.api_gateway_host,
            args.api_gateway_port,
            args.api_gateway_swagger_enabled,
            args.api_gateway_log_level,
            args.api_gateway_stats_db,
            args.api_gateway_generate_keys,
            args.api_gateway_rate_limit_writes_per_second,
            args.api_gateway_rate_limit_burst,
            args.api_gateway_engine_auth_sec,
            args.api_gateway_engine_reply_sec,
            args.api_gateway_wait_ack_sec,
            args.api_gateway_order_retention_sec,
        )
    ) or bool(
        args.api_gateway
        or args.api_gateway_instance
        or args.api_key
        or args.api_gateway_readonly_key
        or args.api_keys_for
    )

    if not emit:
        return ()

    allowed_gateways = {gateway.gateway_id for gateway in gateways}
    parsed_instances = [
        _parse_api_gateway_instance(raw, allowed_gateways)
        for raw in args.api_gateway_instance
    ]
    if parsed_instances and args.api_key:
        raise ValueError(
            "--api-key is only supported for single API gateway generation; "
            "use generated keys with --api-gateway-instance"
        )

    keys_for: tuple[str, ...] = ()
    if args.api_keys_for:
        if parsed_instances:
            raise ValueError(
                "--api-keys-for is only supported for single API gateway "
                "generation, not with --api-gateway-instance"
            )
        if args.api_gateway_generate_keys is False:
            raise ValueError(
                "--api-keys-for generates keys; it cannot be combined with "
                "--no-api-gateway-generate-keys"
            )
        keys_for = tuple(dict.fromkeys(i.upper() for i in args.api_keys_for))
        unknown = [i for i in keys_for if i not in allowed_gateways]
        if unknown:
            raise ValueError(
                f"--api-keys-for references unknown gateway_id '{unknown[0]}'"
            )

    seen_names: set[str] = set()
    seen_gateway_ids: dict[str, str] = {}
    for name, gateway_ids, _port in parsed_instances:
        if name in seen_names:
            raise ValueError(f"duplicate --api-gateway-instance name '{name}'")
        seen_names.add(name)
        for gateway_id in gateway_ids:
            existing = seen_gateway_ids.get(gateway_id)
            if existing is not None:
                raise ValueError(
                    f"gateway_id '{gateway_id}' is assigned to both API gateway "
                    f"instances '{existing}' and '{name}'"
                )
            seen_gateway_ids[gateway_id] = name

    enabled = (
        bool(args.api_gateway_enabled) if args.api_gateway_enabled is not None else True
    )
    swagger_enabled = (
        bool(args.api_gateway_swagger_enabled)
        if args.api_gateway_swagger_enabled is not None
        else True
    )
    generate_keys = (
        bool(args.api_gateway_generate_keys)
        if args.api_gateway_generate_keys is not None
        else True
    )
    credentials = _parse_api_credentials(
        specs=args.api_key,
        allowed_gateways=allowed_gateways,
    )

    host = str(args.api_gateway_host or DEFAULT_API_GATEWAY_HOST)
    log_level = str(args.api_gateway_log_level or DEFAULT_API_GATEWAY_LOG_LEVEL)
    stats_db = str(args.api_gateway_stats_db or DEFAULT_API_GATEWAY_STATS_DB)
    # On unless --no-api-gateway-readonly-key: pm-dash, terminal-gui and
    # book-gui read through such a key (M032).
    generate_readonly_key = args.api_gateway_readonly_key is not False
    rate_limit_writes_per_second = int(
        args.api_gateway_rate_limit_writes_per_second
        or DEFAULT_API_GATEWAY_RATE_LIMIT_WRITES_PER_SECOND
    )
    rate_limit_burst = int(
        args.api_gateway_rate_limit_burst or DEFAULT_API_GATEWAY_RATE_LIMIT_BURST
    )
    engine_auth_sec = float(
        args.api_gateway_engine_auth_sec or DEFAULT_API_GATEWAY_ENGINE_AUTH_SEC
    )
    engine_reply_sec = float(
        args.api_gateway_engine_reply_sec or DEFAULT_API_GATEWAY_ENGINE_REPLY_SEC
    )
    wait_ack_sec = float(
        args.api_gateway_wait_ack_sec or DEFAULT_API_GATEWAY_WAIT_ACK_SEC
    )
    # `or` would turn an explicit 0 into the default, and 0 is a meaningful
    # value here — it disables eviction. Test for None instead.
    order_retention_sec = (
        DEFAULT_API_GATEWAY_ORDER_RETENTION_SEC
        if args.api_gateway_order_retention_sec is None
        else int(args.api_gateway_order_retention_sec)
    )

    def make_spec(
        *,
        name: str,
        port: int,
        gateway_ids: tuple[str, ...] | None = None,
        credentials: tuple[ApiCredentialSpec, ...] = (),
        readonly_key: bool | None = None,
        credentials_file: str = "",
    ) -> ApiGatewaySpec:
        return ApiGatewaySpec(
            name=name,
            enabled=enabled,
            host=host,
            port=port,
            swagger_enabled=swagger_enabled,
            log_level=log_level,
            stats_db=stats_db,
            credentials=credentials,
            gateway_ids=gateway_ids,
            generate_keys=generate_keys,
            generate_readonly_key=(
                generate_readonly_key if readonly_key is None else readonly_key
            ),
            rate_limit_writes_per_second=rate_limit_writes_per_second,
            rate_limit_burst=rate_limit_burst,
            engine_auth_sec=engine_auth_sec,
            engine_reply_sec=engine_reply_sec,
            wait_ack_sec=wait_ack_sec,
            order_retention_sec=order_retention_sec,
            credentials_file=credentials_file,
        )

    base_port = int(args.api_gateway_port or DEFAULT_API_GATEWAY_PORT)
    if parsed_instances:
        return tuple(
            make_spec(
                name=name,
                port=port if port is not None else base_port + index,
                gateway_ids=gateway_ids,
                readonly_key=generate_readonly_key and not gateway_ids,
            )
            for index, (name, gateway_ids, port) in enumerate(parsed_instances)
        )

    return (
        make_spec(
            name=str(args.api_gateway_name),
            port=base_port,
            credentials=credentials,
            gateway_ids=keys_for or None,
            credentials_file=_API_KEYS_FILE if keys_for else "",
        ),
    )


_INDEX_DETAIL_FLAGS = (
    ("index_constituents", "--index-constituents"),
    ("index_base_value", "--index-base-value"),
    ("index_interval", "--index-interval"),
    ("index_history_file", "--index-history-file"),
    ("index_state_file", "--index-state-file"),
)


def _reject_repeated_index_flag(flag: str, idx_id: str, seen: dict[str, Any]) -> None:
    # Each of these flags sets one value per index; a second occurrence for the
    # same id used to silently replace the first.
    if idx_id in seen:
        hint = (
            "list all of its constituents in one flag, e.g. ID:SYM1,SYM2"
            if flag == "--index-constituents"
            else "give each index one value"
        )
        raise ValueError(f"{flag} given more than once for index '{idx_id}'; {hint}")


def _parse_index_specs(
    args: argparse.Namespace, outstanding_shares: dict[str, int]
) -> tuple[IndexSpec, ...]:
    """Parse all --index* flags and return a tuple of IndexSpec objects."""
    if not args.index:
        stray = [flag for attr, flag in _INDEX_DETAIL_FLAGS if getattr(args, attr)]
        if stray:
            raise ValueError(
                f"{', '.join(stray)} given without --index; define the index "
                "with --index ID[:DESCRIPTION] first"
            )
        return ()

    allowed_symbols = {s.upper() for s in args.symbols}

    # ── --index ID[:DESCRIPTION] ────────────────────────────────────────────
    index_defs: dict[str, str] = {}  # ordered: id -> description
    for raw in args.index:
        if ":" in raw:
            idx_id_raw, description = raw.split(":", 1)
        else:
            idx_id_raw, description = raw, ""
        idx_id = idx_id_raw.strip().upper()
        if not idx_id:
            raise ValueError(f"Invalid --index '{raw}': id cannot be empty")
        # Letters and digits only: the config verifier (S045) rejects anything
        # else, and the id becomes part of file names and CALF topics.
        if not (idx_id.isascii() and idx_id.isalnum()):
            raise ValueError(
                f"Invalid --index '{raw}': id must contain only letters and digits"
            )
        if idx_id in index_defs:
            raise ValueError(f"Duplicate --index id '{idx_id}'")
        index_defs[idx_id] = description.strip() or f"Index {idx_id}"

    if len(index_defs) > 5:
        raise ValueError("--index: maximum 5 indices per exchange")

    # ── --index-constituents ID:SYM[,SYM,...] ───────────────────────────────
    index_constituents: dict[str, list[str]] = {}
    for raw in args.index_constituents:
        if ":" not in raw:
            raise ValueError(
                f"Invalid --index-constituents '{raw}': expected ID:SYM[,SYM,...]"
            )
        idx_id_raw, syms_raw = raw.split(":", 1)
        idx_id = idx_id_raw.strip().upper()
        if idx_id not in index_defs:
            raise ValueError(
                f"--index-constituents references unknown index '{idx_id}'"
            )
        _reject_repeated_index_flag("--index-constituents", idx_id, index_constituents)
        syms = [s.strip().upper() for s in syms_raw.split(",") if s.strip()]
        if not syms:
            raise ValueError(
                f"--index-constituents '{raw}': at least one symbol required"
            )
        for sym in syms:
            if sym not in allowed_symbols:
                raise ValueError(
                    f"--index-constituents '{raw}': symbol '{sym}' is not in --symbols"
                )
            if sym not in outstanding_shares:
                raise ValueError(
                    f"--index-constituents '{raw}': symbol '{sym}' has no "
                    f"outstanding shares; pm-index weights constituents by market "
                    f"cap, so add --outstanding-shares {sym}:N"
                )
        duplicates = sorted({sym for sym in syms if syms.count(sym) > 1})
        if duplicates:
            raise ValueError(
                f"--index-constituents '{raw}': duplicate symbol(s) "
                f"{', '.join(duplicates)}"
            )
        index_constituents[idx_id] = syms

    # ── --index-base-value ID:VALUE ──────────────────────────────────────────
    index_base_values: dict[str, float] = {}
    for raw in args.index_base_value:
        if ":" not in raw:
            raise ValueError(f"Invalid --index-base-value '{raw}': expected ID:VALUE")
        idx_id_raw, val_raw = raw.split(":", 1)
        idx_id = idx_id_raw.strip().upper()
        if idx_id not in index_defs:
            raise ValueError(f"--index-base-value references unknown index '{idx_id}'")
        _reject_repeated_index_flag("--index-base-value", idx_id, index_base_values)
        try:
            value = finite_float(val_raw.strip())
        except ValueError as exc:
            raise ValueError(
                f"--index-base-value '{raw}': value must be a finite number"
            ) from exc
        if value <= 0:
            raise ValueError(f"--index-base-value '{raw}': value must be > 0")
        index_base_values[idx_id] = value

    # ── --index-interval ID:SECS ─────────────────────────────────────────────
    index_intervals: dict[str, float] = {}
    for raw in args.index_interval:
        if ":" not in raw:
            raise ValueError(f"Invalid --index-interval '{raw}': expected ID:SECS")
        idx_id_raw, val_raw = raw.split(":", 1)
        idx_id = idx_id_raw.strip().upper()
        if idx_id not in index_defs:
            raise ValueError(f"--index-interval references unknown index '{idx_id}'")
        _reject_repeated_index_flag("--index-interval", idx_id, index_intervals)
        try:
            value = finite_float(val_raw.strip())
        except ValueError as exc:
            raise ValueError(
                f"--index-interval '{raw}': value must be a finite number"
            ) from exc
        if value <= 0:
            raise ValueError(f"--index-interval '{raw}': value must be > 0")
        index_intervals[idx_id] = value

    # ── --index-history-file ID:PATH ─────────────────────────────────────────
    index_history_files: dict[str, str] = {}
    for raw in args.index_history_file:
        if ":" not in raw:
            raise ValueError(f"Invalid --index-history-file '{raw}': expected ID:PATH")
        idx_id_raw, path_raw = raw.split(":", 1)
        idx_id = idx_id_raw.strip().upper()
        if idx_id not in index_defs:
            raise ValueError(
                f"--index-history-file references unknown index '{idx_id}'"
            )
        _reject_repeated_index_flag("--index-history-file", idx_id, index_history_files)
        path = path_raw.strip()
        if not path:
            raise ValueError(f"--index-history-file '{raw}': path cannot be empty")
        index_history_files[idx_id] = path

    # ── --index-state-file ID:PATH ───────────────────────────────────────────
    index_state_files: dict[str, str] = {}
    for raw in args.index_state_file:
        if ":" not in raw:
            raise ValueError(f"Invalid --index-state-file '{raw}': expected ID:PATH")
        idx_id_raw, path_raw = raw.split(":", 1)
        idx_id = idx_id_raw.strip().upper()
        if idx_id not in index_defs:
            raise ValueError(f"--index-state-file references unknown index '{idx_id}'")
        _reject_repeated_index_flag("--index-state-file", idx_id, index_state_files)
        path = path_raw.strip()
        if not path:
            raise ValueError(f"--index-state-file '{raw}': path cannot be empty")
        index_state_files[idx_id] = path

    # ── Validate: every index must have at least one constituent ─────────────
    for idx_id in index_defs:
        if not index_constituents.get(idx_id):
            raise ValueError(
                f"Index '{idx_id}' has no constituents. "
                f"Use --index-constituents {idx_id}:SYM[,SYM,...]"
            )

    return tuple(
        IndexSpec(
            id=idx_id,
            description=index_defs[idx_id],
            constituents=tuple(index_constituents[idx_id]),
            base_value=index_base_values.get(idx_id, DEFAULT_INDEX_BASE_VALUE),
            publish_interval_sec=index_intervals.get(
                idx_id, DEFAULT_INDEX_PUBLISH_INTERVAL_SEC
            ),
            history_file=index_history_files.get(idx_id, ""),
            state_file=index_state_files.get(idx_id, ""),
        )
        for idx_id in index_defs
    )


def _validate_seed_mm_mid_range_grid(
    seed_mm_mid_range: tuple[float, float] | None,
    tick_decimals_by_symbol: dict[str, int],
    mm_seed_spread_ticks: int,
) -> None:
    """The mid-range must hold a price on every symbol's own tick grid.

    The builder snaps each symbol's seed to that symbol's tick_decimals, so a
    range that fits the global grid can still be empty (or leave no positive
    bid) for a symbol with fewer decimals.
    """
    if seed_mm_mid_range is None:
        return
    min_price, max_price = seed_mm_mid_range
    for sym, tick_decimals in tick_decimals_by_symbol.items():
        tick_size = 10 ** (-tick_decimals)
        min_steps = math.ceil(min_price / tick_size)
        max_steps = math.floor(max_price / tick_size)
        if min_steps > max_steps:
            raise ValueError(
                f"--seed-mm-mid-range does not contain any prices on {sym}'s "
                f"tick grid (tick_decimals={tick_decimals})"
            )
        if min_steps <= mm_seed_spread_ticks:
            raise ValueError(
                f"--seed-mm-mid-range minimum must allow a positive bid after "
                f"applying the {mm_seed_spread_ticks}-tick seed spread on "
                f"{sym}'s tick grid (tick_decimals={tick_decimals})"
            )


def _validate_seed_spread_against_mm_obligations(
    symbols: list[str],
    symbol_overrides: dict[str, SymbolOverride],
    mm_spread_ticks: int,
    mm_seed_spread_ticks: int,
) -> None:
    """Reject seed quotes wider than their effective MM spread obligation.

    ``mm_seed_spread_ticks`` is the distance from the midpoint to each quote
    side, while ``mm_spread_ticks`` is the complete bid-ask spread. A seed
    therefore occupies ``2 * mm_seed_spread_ticks`` ticks and must fit the
    global or symbol-specific obligation before it is written to YAML.
    """
    seed_spread_ticks = 2 * mm_seed_spread_ticks
    for symbol in symbols:
        override = symbol_overrides.get(symbol)
        max_spread_ticks = (
            override.mm_spread_ticks
            if override is not None and override.mm_spread_ticks is not None
            else mm_spread_ticks
        )
        if seed_spread_ticks > max_spread_ticks:
            raise ValueError(
                f"seed quote spread ({seed_spread_ticks} ticks) exceeds "
                f"mm_max_spread_ticks ({max_spread_ticks}) for {symbol}; "
                "reduce --mm-seed-spread-ticks or raise the effective "
                "--mm-spread-ticks"
            )


def _tick_decimals_by_symbol(
    symbols: list[str],
    symbol_overrides: dict[str, SymbolOverride],
    default_tick_decimals: int,
) -> dict[str, int]:
    result: dict[str, int] = {}
    for sym in symbols:
        override = symbol_overrides.get(sym)
        result[sym] = (
            override.tick_decimals
            if override is not None and override.tick_decimals is not None
            else default_tick_decimals
        )
    return result


def _parse_leg_price(raw: str, tick_decimals: int, symbol: str, label: str) -> float:
    """Parse a combo leg price/stop_price, which is display money.

    Whether the price sits on the symbol's tick grid is checked here rather
    than left to the engine: pm-config-gen should not write a file its own
    loader will refuse to read.
    """
    text = raw.strip()
    try:
        price = finite_float(text)
    except ValueError as exc:
        raise ValueError(f"{label} must be a decimal price") from exc
    try:
        to_ticks_exact_at(price, tick_decimals, symbol)
    except TickViolation as exc:
        raise ValueError(
            f"{label} {price} is not a multiple of {symbol}'s tick size "
            f"{exc.tick_size:.{tick_decimals}f} (tick_decimals={tick_decimals})"
        ) from exc
    return price


def _parse_combo_specs(
    args: argparse.Namespace,
    allowed_symbols: set[str],
    tick_decimals_by_symbol: dict[str, int],
) -> list[ComboSpec]:
    """Parse all --combo flags and return a list of ComboSpec objects."""
    from edumatcher.models.combo import ComboType
    from edumatcher.models.order import Side, OrderType, SmpAction, TIF as TIFEnum

    combos: list[ComboSpec] = []
    seen_ids: set[str] = set()

    for raw in args.combo:
        parts = raw.split(":", 3)
        if len(parts) != 4:
            raise ValueError(
                f"Invalid --combo '{raw}': expected ID:TYPE:TIF:SYM/SIDE/TYPE/QTY[/PRICE[/STOP[/SMP]]],..."
            )
        combo_id, combo_type_raw, tif_raw, legs_raw = parts
        combo_id = combo_id.strip()
        if not combo_id:
            raise ValueError(f"Invalid --combo '{raw}': combo_id cannot be empty")
        if combo_id in seen_ids:
            raise ValueError(f"Duplicate --combo combo_id '{combo_id}'")
        seen_ids.add(combo_id)

        combo_type = combo_type_raw.strip().upper()
        try:
            ComboType(combo_type)
        except ValueError as exc:
            raise ValueError(
                f"Invalid --combo '{raw}': combo_type '{combo_type}' is invalid"
            ) from exc

        tif = tif_raw.strip().upper()
        try:
            TIFEnum(tif)
        except ValueError as exc:
            raise ValueError(
                f"Invalid --combo '{raw}': tif '{tif}' is invalid"
            ) from exc

        leg_specs_raw = [s.strip() for s in legs_raw.split(",") if s.strip()]
        if len(leg_specs_raw) < 2:
            raise ValueError(f"Invalid --combo '{raw}': at least 2 legs required")
        if len(leg_specs_raw) > 10:
            raise ValueError(f"Invalid --combo '{raw}': at most 10 legs supported")

        seen_leg_symbols: set[str] = set()
        legs: list[ComboLegSpec] = []
        for leg_raw in leg_specs_raw:
            fields = leg_raw.split("/")
            if len(fields) < 4:
                raise ValueError(
                    f"Invalid --combo '{raw}': leg '{leg_raw}' requires SYM/SIDE/TYPE/QTY"
                )
            sym = fields[0].strip().upper()
            side_str = fields[1].strip().upper()
            order_type_str = fields[2].strip().upper()
            try:
                qty = int(fields[3].strip())
            except ValueError as exc:
                raise ValueError(
                    f"Invalid --combo '{raw}': leg quantity must be an integer"
                ) from exc
            if qty <= 0:
                raise ValueError(f"Invalid --combo '{raw}': leg quantity must be > 0")

            price: float | None = None
            stop_price: float | None = None
            smp_action_str = "NONE"
            leg_tick_decimals = tick_decimals_by_symbol.get(
                sym, int(args.tick_decimals)
            )

            if len(fields) >= 5 and fields[4].strip().lower() not in ("", "null"):
                try:
                    price = _parse_leg_price(
                        fields[4],
                        leg_tick_decimals,
                        sym,
                        f"Invalid --combo '{raw}': leg price",
                    )
                except ValueError as exc:
                    raise ValueError(str(exc)) from exc
            if len(fields) >= 6 and fields[5].strip().lower() not in ("", "null"):
                try:
                    stop_price = _parse_leg_price(
                        fields[5],
                        leg_tick_decimals,
                        sym,
                        f"Invalid --combo '{raw}': leg stop_price",
                    )
                except ValueError as exc:
                    raise ValueError(str(exc)) from exc
            if len(fields) >= 7 and fields[6].strip():
                smp_action_str = fields[6].strip().upper()

            if sym not in allowed_symbols:
                raise ValueError(
                    f"Invalid --combo '{raw}': leg symbol '{sym}' not in --symbols"
                )
            if sym in seen_leg_symbols:
                raise ValueError(
                    f"Invalid --combo '{raw}': duplicate leg symbol '{sym}'"
                )
            seen_leg_symbols.add(sym)

            try:
                Side(side_str)
            except ValueError as exc:
                raise ValueError(
                    f"Invalid --combo '{raw}': leg side '{side_str}' is invalid"
                ) from exc
            try:
                OrderType(order_type_str)
            except ValueError as exc:
                raise ValueError(
                    f"Invalid --combo '{raw}': leg order_type '{order_type_str}' is invalid"
                ) from exc
            try:
                SmpAction(smp_action_str)
            except ValueError as exc:
                raise ValueError(
                    f"Invalid --combo '{raw}': leg smp_action '{smp_action_str}' is invalid"
                ) from exc

            legs.append(
                ComboLegSpec(
                    symbol=sym,
                    side=side_str,
                    order_type=order_type_str,
                    quantity=qty,
                    price=price,
                    stop_price=stop_price,
                    smp_action=smp_action_str,
                )
            )

        combos.append(
            ComboSpec(
                combo_id=combo_id,
                combo_type=combo_type,
                tif=tif,
                legs=tuple(legs),
            )
        )

    return combos


#: Where ``--api-keys-for`` writes the keys, beside the main file.
_API_KEYS_FILE = "api_keys.yaml"

#: The sections ``--split`` moves out of the main file, and where they go.
_SPLIT_FILES = {"symbols": "symbols.yaml", "participants": "participants.yaml"}


def _write_output(
    output_path: Path, content: str, force: bool, mode: int | None = None
) -> None:
    if output_path.exists() and not force:
        raise FileExistsError("Output file already exists")
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if mode is None:
        output_path.write_text(content, encoding="utf-8")
        return
    # Restrict the mode before any content is written, also when --force
    # overwrites an existing, more open file.
    fd = os.open(output_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, mode)
    os.fchmod(fd, mode)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        handle.write(content)


def _validate_generated(content: str, parts: dict[str, str] | None = None) -> None:
    """Compile the rendered files as pm-config-deploy will, or raise ValueError.

    The same gate as the deploy: pm-cverifier's ERRORs, then every loader.
    A config it refuses is never written or printed: it would only move the
    failure from generation to deployment.
    """
    with TemporaryDirectory() as tmp:
        tmp_path = Path(tmp) / "engine_config.yaml"
        tmp_path.write_text(content, encoding="utf-8")
        for name, text in (parts or {}).items():
            (Path(tmp) / name).write_text(text, encoding="utf-8")
        try:
            compile_config(tmp_path)
        except CompileError as exc:
            if exc.findings:
                detail = "\n".join(
                    f"  {f.code} [{f.path}]: {f.message}" for f in exc.findings
                )
                detail = f"pm-config-deploy would refuse it:\n{detail}"
            else:
                # A loader refused it; its own message names the field.
                detail = str(exc.__cause__ or exc)
            raise ValueError(f"Generated config failed validation: {detail}") from exc


def _require_index_reference_prices(config: dict[str, Any]) -> None:
    """Refuse a config pm-index could not start on.

    pm-index sets each index's initial divisor from its constituents' last
    prices, and exits at startup if a constituent has neither last_buy_price
    nor last_sell_price. pm-config-gen only emits real prices when it seeds
    them from a market-maker midpoint.
    """
    symbols = config.get("symbols", {})
    for idx in config.get("indices", []):
        missing = [
            sym
            for sym in idx["constituents"]
            if symbols[sym].get("last_buy_price") is None
            and symbols[sym].get("last_sell_price") is None
        ]
        if missing:
            raise ValueError(
                f"index '{idx['id']}': constituent(s) {', '.join(missing)} have no "
                "reference price, so pm-index could not compute the initial divisor. "
                "Add a MARKET_MAKER participant with --seed-mm-mid-range MIN:MAX "
                "--seed-last-prices-from-mm"
            )


@pipe_safe
def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    try:
        _resolve_gated_options(args)
        _validate_basic_args(args)
        (
            symbols,
            gateways,
            risk_levels,
            cb_levels,
            ace_expansions,
            symbol_overrides,
            outstanding_shares,
            seed_mm_mid_range,
        ) = _parse_specs(args)
        indices = _parse_index_specs(args, outstanding_shares)
        tick_decimals_by_symbol = _tick_decimals_by_symbol(
            symbols, symbol_overrides, int(args.tick_decimals)
        )
        _validate_seed_mm_mid_range_grid(
            seed_mm_mid_range,
            tick_decimals_by_symbol,
            int(args.mm_seed_spread_ticks),
        )
        combos = _parse_combo_specs(
            args,
            allowed_symbols=set(symbols),
            tick_decimals_by_symbol=tick_decimals_by_symbol,
        )
    except ValueError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(2) from exc

    has_mm_gateway = any(g.role == ParticipantRole.MARKET_MAKER for g in gateways)
    if seed_mm_mid_range is not None and not has_mm_gateway:
        print(
            "[ERROR] --seed-mm-mid-range requires at least one MARKET_MAKER gateway",
            file=sys.stderr,
        )
        raise SystemExit(2)
    if seed_mm_mid_range is not None and has_mm_gateway and not args.no_mm_seed_quotes:
        try:
            _validate_seed_spread_against_mm_obligations(
                symbols,
                symbol_overrides,
                int(args.mm_spread_ticks),
                int(args.mm_seed_spread_ticks),
            )
        except ValueError as exc:
            print(f"[ERROR] {exc}", file=sys.stderr)
            raise SystemExit(2) from exc

    try:
        spec = ConfigSpec(
            symbols=symbols,
            gateways=gateways,
            gateway_default_smp=(
                SmpAction(args.participant_default_smp)
                if args.participant_default_smp is not None
                else None
            ),
            gateway_default_disconnect=(
                DisconnectBehaviour(args.participant_default_disconnect)
                if args.participant_default_disconnect is not None
                else None
            ),
            sessions_enabled=bool(args.sessions_enabled),
            country=str(args.country) if args.country is not None else None,
            session_timezone=(
                str(args.session_timezone)
                if args.session_timezone is not None
                else None
            ),
            snapshot_interval_sec=float(args.snapshot_interval),
            quote_history_maxlen=int(args.quote_history_maxlen),
            drop_copy_buffer_size=int(args.drop_copy_buffer_size),
            recent_trades_maxlen=int(args.recent_trades_maxlen),
            depth_snapshot_tolerance_ticks=int(args.depth_snapshot_tolerance_ticks),
            emit_engine_tuning=_engine_tuning_was_requested(sys.argv[1:]),
            enforce_collars=not args.no_collars,
            enforce_circuit_breakers=not args.no_circuit_breakers,
            static_band_pct=args.static_band,
            dynamic_band_pct=args.dynamic_band,
            risk_levels=risk_levels,
            cb_levels=cb_levels,
            ace_enabled=not args.no_ace,
            ace_initial_band_pct=float(args.ace_initial_band),
            ace_random_end_max_ns=int(args.ace_random_end_ns),
            ace_random_seed=args.ace_random_seed,
            ace_expansions=ace_expansions,
            cb_window_ns=int(args.cb_window_ns),
            mm_spread_ticks=int(args.mm_spread_ticks),
            mm_min_qty=int(args.mm_min_qty),
            mm_seed_spread_ticks=int(args.mm_seed_spread_ticks),
            enforce_mm_obligations=bool(args.enforce_mm_obligations),
            emit_mm_defaults=has_mm_gateway and bool(args.enforce_mm_obligations),
            tick_decimals=int(args.tick_decimals),
            seed_last_prices=bool(args.seed_last_prices),
            random_seed=args.seed,
            seed_mm_mid_range=seed_mm_mid_range,
            seed_last_prices_from_mm=bool(args.seed_last_prices_from_mm),
            require_mm_seed_quotes=not args.no_mm_seed_quotes,
            emit_schedule=_resolve_emit_schedule(args),
            pre_open=str(args.pre_open),
            opening_auction=str(args.opening_auction),
            continuous=str(args.continuous),
            closing_auction=str(args.closing_auction),
            closing_end=str(args.closing_end),
            emit_weekend=bool(args.weekend),
            weekend_pre_open=str(args.weekend_pre_open),
            weekend_opening_auction=str(args.weekend_opening_auction),
            weekend_continuous=str(args.weekend_continuous),
            weekend_closing_auction=str(args.weekend_closing_auction),
            weekend_closing_end=str(args.weekend_closing_end),
            emit_holidays=bool(args.holidays),
            holidays_pre_open=str(args.holidays_pre_open),
            holidays_opening_auction=str(args.holidays_opening_auction),
            holidays_continuous=str(args.holidays_continuous),
            holidays_closing_auction=str(args.holidays_closing_auction),
            holidays_closing_end=str(args.holidays_closing_end),
            symbol_overrides=symbol_overrides,
            outstanding_shares=outstanding_shares,
            post_trade_gateway=_build_post_trade_gateway_spec(args),
            market_data_gateway=_build_market_data_gateway_spec(args),
            balf_gateway=_build_balf_gateway_spec(args),
            alf_gateway=_build_alf_gateway_spec(args),
            dc_gateway=_build_dc_gateway_spec(args),
            log_server=_build_log_server_spec(args),
            monitor=_build_monitor_spec(args),
            api_gateways=_build_api_gateway_specs(args, gateways),
            indices=indices,
            combos=combos,
        )
    except ValueError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(2) from exc

    output_path = Path(args.output) if args.output else None
    for flag, used in (("--split", args.split), ("--api-keys-for", args.api_keys_for)):
        if used and output_path is None and not args.dry_run:
            print(f"[ERROR] {flag} needs --output (or --dry-run).", file=sys.stderr)
            raise SystemExit(2)
    split_names = list(_SPLIT_FILES.values()) if args.split else []
    if args.api_keys_for:
        split_names.append(_API_KEYS_FILE)
    output_exists = bool(
        output_path
        and not args.force
        and any(
            p.exists()
            for p in (output_path, *(output_path.parent / n for n in split_names))
        )
    )

    diagnostics = evaluate_diagnostics(
        spec=spec,
        raw_symbols=args.symbols,
        output_exists=output_exists,
    )

    # Fatal if user requested file output but file exists and no --force.
    if output_exists:
        _print_diagnostics(diagnostics)
        raise SystemExit(1)

    builder = ConfigBuilder(spec)
    config = builder.build()
    try:
        _require_index_reference_prices(config)
    except ValueError as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        raise SystemExit(2) from exc
    # shlex.join, not " ".join: the header is meant to be copy-pasted and
    # re-run, so an argument with spaces must keep its quotes.
    cmd_line = "pm-config-gen " + shlex.join(sys.argv[1:])
    default_config_field_comment_lines = (
        build_default_engine_field_comment_lines(config)
        if args.comment_default_config_fields
        else None
    )
    rendered = render_yaml(
        config=config,
        command=cmd_line,
        generated_version=package_version(),
        generated_date=str(date.today()),
        default_engine_field_comments=default_config_field_comment_lines,
        included=_SPLIT_FILES if args.split else None,
    )
    parts = {
        name: render_include_file(config, key, package_version(), str(date.today()))
        for key, name in _SPLIT_FILES.items()
        if args.split
    }
    for name, credentials in builder.credential_files().items():
        parts[name] = render_credentials_file(
            credentials, package_version(), str(date.today())
        )
    if args.api_keys_for and args.seed is None:
        print(
            f"[NOTE] No --seed given: {_API_KEYS_FILE} holds the keys derived from "
            "the default seed, which anyone can reproduce from a participant ID. "
            "Pass --seed N for keys only you can regenerate.",
            file=sys.stderr,
        )

    _print_diagnostics(diagnostics)

    mm_quotes_pending_fill = (
        has_mm_gateway and seed_mm_mid_range is None and not args.no_mm_seed_quotes
    )
    # The one deliberate exception: with MM quote stubs the bid/ask prices are
    # null placeholders for the operator to fill in, so the template cannot
    # load until they do (the hint below says so).
    if not mm_quotes_pending_fill:
        try:
            _validate_generated(rendered, parts)
        except ValueError as exc:
            print(f"[ERROR] {exc}", file=sys.stderr)
            print("[ERROR] Nothing was written.", file=sys.stderr)
            raise SystemExit(2) from exc
        print(
            "[INFO] Generated config passes pm-config-deploy --check.",
            file=sys.stderr,
        )

    if args.dry_run or output_path is None:
        print(rendered, end="")
        for name, text in parts.items():
            print(f"\n# ==== {name} ====")
            print(text, end="")
        if not args.dry_run and output_path is None:
            print(
                "[INFO] No --output specified; YAML printed to stdout.",
                file=sys.stderr,
            )
        return

    _write_output(output_path=output_path, content=rendered, force=bool(args.force))
    for name, text in parts.items():
        _write_output(
            output_path.parent / name,
            text,
            force=bool(args.force),
            # The keys file holds secrets.
            mode=0o600 if name == _API_KEYS_FILE else None,
        )
    print(f"[INFO] Wrote generated config to {output_path}", file=sys.stderr)
    for name in parts:
        print(f"[INFO] Wrote {output_path.parent / name}", file=sys.stderr)

    if mm_quotes_pending_fill:
        print(
            "[HINT] Fill all market_maker_quotes bid_price/ask_price values: "
            "pm-config-deploy refuses the file until they are set "
            "(pm-cverifier reports each one as S014).",
            file=sys.stderr,
        )
    print(f"[HINT] Check it with: pm-cverifier {output_path}", file=sys.stderr)
    print(f"[HINT] Install it with: pm-config-deploy {output_path}", file=sys.stderr)


if __name__ == "__main__":
    main()
