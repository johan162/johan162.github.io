"""Build the config mapping emitted by pm-config-gen."""

from __future__ import annotations

from dataclasses import dataclass, field, fields
from decimal import ROUND_CEILING, ROUND_FLOOR, Decimal
import random
import string
from typing import Any

from edumatcher.models.order import SmpAction
from edumatcher.monitor.config import MonitorConfig
from edumatcher.models.participant import DisconnectBehaviour, ParticipantRole

from .cb_spec import CbSpec
from .defaults import (
    DEFAULT_API_GATEWAY_ENGINE_AUTH_SEC,
    DEFAULT_API_GATEWAY_ENGINE_REPLY_SEC,
    DEFAULT_API_GATEWAY_HOST,
    DEFAULT_API_GATEWAY_KEY_BYTES,
    DEFAULT_API_KEYS_SEED,
    DEFAULT_API_GATEWAY_LOG_LEVEL,
    DEFAULT_API_GATEWAY_PORT,
    DEFAULT_API_GATEWAY_RATE_LIMIT_BURST,
    DEFAULT_API_GATEWAY_RATE_LIMIT_WRITES_PER_SECOND,
    DEFAULT_API_GATEWAY_STATS_DB,
    DEFAULT_API_GATEWAY_SWAGGER_ENABLED,
    DEFAULT_API_GATEWAY_ORDER_RETENTION_SEC,
    DEFAULT_API_GATEWAY_WAIT_ACK_SEC,
    DEFAULT_ALF_GATEWAY_BIND_ADDRESS,
    DEFAULT_ALF_GATEWAY_ERROR_WINDOW_SEC,
    DEFAULT_ALF_GATEWAY_HANDSHAKE_TIMEOUT_SEC,
    DEFAULT_ALF_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_ALF_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_ALF_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_ALF_GATEWAY_MAX_COMMANDS_PER_SECOND,
    DEFAULT_ALF_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_ALF_GATEWAY_MAX_ERRORS_BEFORE_DISCONNECT,
    DEFAULT_ALF_GATEWAY_NAME,
    DEFAULT_ALF_GATEWAY_PORT,
    DEFAULT_BALF_GATEWAY_AUTH_TIMEOUT_SEC,
    DEFAULT_BALF_GATEWAY_BIND_ADDRESS,
    DEFAULT_BALF_GATEWAY_DUPLICATE_SESSION_POLICY,
    DEFAULT_BALF_GATEWAY_ERROR_WINDOW_SEC,
    DEFAULT_BALF_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_BALF_GATEWAY_HEARTBEAT_TIMEOUT_SEC,
    DEFAULT_BALF_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_BALF_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_BALF_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_BALF_GATEWAY_MAX_ERRORS_BEFORE_DISCONNECT,
    DEFAULT_BALF_GATEWAY_MAX_MESSAGES_PER_SECOND,
    DEFAULT_BALF_GATEWAY_NAME,
    DEFAULT_BALF_GATEWAY_PORT,
    DEFAULT_INDEX_BASE_VALUE,
    DEFAULT_DC_GATEWAY_BIND_ADDRESS,
    DEFAULT_DC_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_DC_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_DC_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_DC_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_DC_GATEWAY_NAME,
    DEFAULT_DC_GATEWAY_PORT,
    DEFAULT_LOG_SERVER_BACKFILL_CHUNK_ROWS,
    DEFAULT_LOG_SERVER_BIND_ADDRESS,
    DEFAULT_LOG_SERVER_DB_PATH,
    DEFAULT_LOG_SERVER_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_LOG_SERVER_LEASE_SEC,
    DEFAULT_LOG_SERVER_MAX_BACKFILL_MINUTES,
    DEFAULT_LOG_SERVER_MAX_BACKFILL_ROWS,
    DEFAULT_LOG_SERVER_MAX_CLIENT_QUEUE,
    DEFAULT_LOG_SERVER_MAX_LEASE_SEC,
    DEFAULT_LOG_SERVER_MAX_MESSAGE_BYTES,
    DEFAULT_LOG_SERVER_MAX_PENDING_ROWS,
    DEFAULT_LOG_SERVER_MAX_SUBSCRIBERS,
    DEFAULT_LOG_SERVER_NAME,
    DEFAULT_LOG_SERVER_NOTIFY_INTERVAL_MS,
    DEFAULT_LOG_SERVER_PORT,
    DEFAULT_LOG_SERVER_PUB_PORT,
    DEFAULT_LOG_SERVER_PUB_SNDHWM,
    DEFAULT_LOG_SERVER_PUBSUB_ENABLED,
    DEFAULT_LOG_SERVER_PULL_PORT,
    DEFAULT_LOG_SERVER_RETENTION_DAYS,
    DEFAULT_LOG_SERVER_WRITE_BATCH_INTERVAL_MS,
    DEFAULT_LOG_SERVER_WRITE_BATCH_SIZE,
    DEFAULT_INDEX_DATA_DIR,
    DEFAULT_INDEX_PUBLISH_INTERVAL_SEC,
    DEFAULT_MARKET_DATA_GATEWAY_BIND_ADDRESS,
    DEFAULT_MARKET_DATA_GATEWAY_DEPTH_LEVELS,
    DEFAULT_MARKET_DATA_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_MARKET_DATA_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_MARKET_DATA_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_MARKET_DATA_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_MARKET_DATA_GATEWAY_MAX_SYMBOLS_PER_CLIENT,
    DEFAULT_MARKET_DATA_GATEWAY_NAME,
    DEFAULT_MARKET_DATA_GATEWAY_PORT,
    DEFAULT_MARKET_DATA_GATEWAY_REPLAY_WINDOW_SEC,
    DEFAULT_ACE_ENABLED,
    DEFAULT_ACE_EXPANSIONS,
    DEFAULT_ACE_INITIAL_BAND_PCT,
    DEFAULT_ACE_RANDOM_END_MAX_NS,
    DEFAULT_CB_WINDOW_NS,
    DEFAULT_DEPTH_SNAPSHOT_TOLERANCE_TICKS,
    DEFAULT_DROP_COPY_BUFFER_SIZE,
    DEFAULT_DYNAMIC_BAND_PCT,
    DEFAULT_MM_MIN_QTY,
    DEFAULT_MM_SEED_SPREAD_TICKS,
    DEFAULT_MM_SPREAD_TICKS,
    DEFAULT_MM_STUB_QTY,
    DEFAULT_POST_TRADE_GATEWAY_ALLOWED_ROLES,
    DEFAULT_POST_TRADE_GATEWAY_BIND_ADDRESS,
    DEFAULT_POST_TRADE_GATEWAY_HEARTBEAT_INTERVAL_SEC,
    DEFAULT_POST_TRADE_GATEWAY_IDLE_TIMEOUT_SEC,
    DEFAULT_POST_TRADE_GATEWAY_MAX_CLIENT_QUEUE,
    DEFAULT_POST_TRADE_GATEWAY_MAX_CONNECTIONS,
    DEFAULT_POST_TRADE_GATEWAY_NAME,
    DEFAULT_POST_TRADE_GATEWAY_PORT,
    DEFAULT_POST_TRADE_GATEWAY_REPLAY_RETENTION_SEC,
    DEFAULT_QUOTE_HISTORY_MAXLEN,
    DEFAULT_RECENT_TRADES_MAXLEN,
    DEFAULT_SNAPSHOT_INTERVAL_SEC,
    DEFAULT_STATIC_BAND_PCT,
    DEFAULT_TICK_DECIMALS,
)
from .gateway_spec import GatewaySpec
from .symbol_spec import SymbolOverride


@dataclass
class ConfigSpec:
    symbols: list[str]
    gateways: list[GatewaySpec]
    #: Written as the top-level ``participant_defaults`` block when either is set.
    gateway_default_smp: SmpAction | None = None
    gateway_default_disconnect: DisconnectBehaviour | None = None
    sessions_enabled: bool = False
    country: str | None = None
    session_timezone: str | None = None
    snapshot_interval_sec: float = DEFAULT_SNAPSHOT_INTERVAL_SEC
    quote_history_maxlen: int = DEFAULT_QUOTE_HISTORY_MAXLEN
    drop_copy_buffer_size: int = DEFAULT_DROP_COPY_BUFFER_SIZE
    recent_trades_maxlen: int = DEFAULT_RECENT_TRADES_MAXLEN
    depth_snapshot_tolerance_ticks: int = DEFAULT_DEPTH_SNAPSHOT_TOLERANCE_TICKS
    emit_engine_tuning: bool = False
    enforce_collars: bool = True
    enforce_circuit_breakers: bool = True
    static_band_pct: float | None = None
    dynamic_band_pct: float | None = None
    risk_levels: dict[str, tuple[float, float | None]] = field(default_factory=dict)
    cb_levels: list[CbSpec] = field(default_factory=list)
    cb_window_ns: int = DEFAULT_CB_WINDOW_NS
    ace_enabled: bool = DEFAULT_ACE_ENABLED
    ace_initial_band_pct: float = DEFAULT_ACE_INITIAL_BAND_PCT
    ace_random_end_max_ns: int = DEFAULT_ACE_RANDOM_END_MAX_NS
    ace_random_seed: int | None = None
    #: (widen_pct, min_duration_ns) per rung; the last rung repeats.
    ace_expansions: list[tuple[float, int]] = field(
        default_factory=lambda: list(DEFAULT_ACE_EXPANSIONS)
    )
    mm_spread_ticks: int = DEFAULT_MM_SPREAD_TICKS
    mm_seed_spread_ticks: int = DEFAULT_MM_SEED_SPREAD_TICKS
    mm_min_qty: int = DEFAULT_MM_MIN_QTY
    enforce_mm_obligations: bool = False
    emit_mm_defaults: bool = False
    tick_decimals: int = DEFAULT_TICK_DECIMALS
    seed_last_prices: bool = False
    random_seed: int | None = None
    seed_mm_mid_range: tuple[float, float] | None = None
    seed_last_prices_from_mm: bool = False
    require_mm_seed_quotes: bool = True
    emit_schedule: bool = True
    pre_open: str = "09:00"
    opening_auction: str = "09:25"
    continuous: str = "09:30"
    closing_auction: str = "16:00"
    closing_end: str = "16:05"
    emit_weekend: bool = False
    weekend_pre_open: str = "10:00"
    weekend_opening_auction: str = "10:25"
    weekend_continuous: str = "10:30"
    weekend_closing_auction: str = "14:00"
    weekend_closing_end: str = "14:05"
    emit_holidays: bool = False
    holidays_pre_open: str = "10:00"
    holidays_opening_auction: str = "10:25"
    holidays_continuous: str = "10:30"
    holidays_closing_auction: str = "14:00"
    holidays_closing_end: str = "14:05"
    symbol_overrides: dict[str, SymbolOverride] = field(default_factory=dict)
    outstanding_shares: dict[str, int] = field(default_factory=dict)
    post_trade_gateway: PostTradeGatewaySpec | None = None
    market_data_gateway: MarketDataGatewaySpec | None = None
    balf_gateway: BalfGatewaySpec | None = None
    alf_gateway: AlfGatewaySpec | None = None
    dc_gateway: DcGatewaySpec | None = None
    log_server: LogServerSpec | None = None
    #: The ``monitor`` block, already resolved and validated by
    #: ``monitor_config_from_raw`` (``None``: not emitted, defaults apply).
    monitor: MonitorConfig | None = None
    api_gateways: tuple[ApiGatewaySpec, ...] = ()
    indices: tuple[IndexSpec, ...] = ()
    combos: list[ComboSpec] = field(default_factory=list)


@dataclass(frozen=True)
class PostTradeGatewaySpec:
    name: str = DEFAULT_POST_TRADE_GATEWAY_NAME
    bind_address: str = DEFAULT_POST_TRADE_GATEWAY_BIND_ADDRESS
    port: int = DEFAULT_POST_TRADE_GATEWAY_PORT
    replay_retention_sec: int = DEFAULT_POST_TRADE_GATEWAY_REPLAY_RETENTION_SEC
    heartbeat_interval_sec: int = DEFAULT_POST_TRADE_GATEWAY_HEARTBEAT_INTERVAL_SEC
    idle_timeout_sec: int = DEFAULT_POST_TRADE_GATEWAY_IDLE_TIMEOUT_SEC
    max_connections: int = DEFAULT_POST_TRADE_GATEWAY_MAX_CONNECTIONS
    max_client_queue: int = DEFAULT_POST_TRADE_GATEWAY_MAX_CLIENT_QUEUE
    allowed_roles: tuple[str, ...] = DEFAULT_POST_TRADE_GATEWAY_ALLOWED_ROLES


@dataclass(frozen=True)
class MarketDataGatewaySpec:
    enabled: bool = True
    name: str = DEFAULT_MARKET_DATA_GATEWAY_NAME
    bind_address: str = DEFAULT_MARKET_DATA_GATEWAY_BIND_ADDRESS
    port: int = DEFAULT_MARKET_DATA_GATEWAY_PORT
    heartbeat_interval_sec: int = DEFAULT_MARKET_DATA_GATEWAY_HEARTBEAT_INTERVAL_SEC
    idle_timeout_sec: int = DEFAULT_MARKET_DATA_GATEWAY_IDLE_TIMEOUT_SEC
    replay_window_sec: int = DEFAULT_MARKET_DATA_GATEWAY_REPLAY_WINDOW_SEC
    max_connections: int = DEFAULT_MARKET_DATA_GATEWAY_MAX_CONNECTIONS
    max_symbols_per_client: int = DEFAULT_MARKET_DATA_GATEWAY_MAX_SYMBOLS_PER_CLIENT
    max_client_queue: int = DEFAULT_MARKET_DATA_GATEWAY_MAX_CLIENT_QUEUE
    depth_levels: int = DEFAULT_MARKET_DATA_GATEWAY_DEPTH_LEVELS


@dataclass(frozen=True)
class AlfGatewaySpec:
    enabled: bool = True
    name: str = DEFAULT_ALF_GATEWAY_NAME
    bind_address: str = DEFAULT_ALF_GATEWAY_BIND_ADDRESS
    port: int = DEFAULT_ALF_GATEWAY_PORT
    heartbeat_interval_sec: int = DEFAULT_ALF_GATEWAY_HEARTBEAT_INTERVAL_SEC
    handshake_timeout_sec: int = DEFAULT_ALF_GATEWAY_HANDSHAKE_TIMEOUT_SEC
    idle_timeout_sec: int = DEFAULT_ALF_GATEWAY_IDLE_TIMEOUT_SEC
    max_connections: int = DEFAULT_ALF_GATEWAY_MAX_CONNECTIONS
    max_client_queue: int = DEFAULT_ALF_GATEWAY_MAX_CLIENT_QUEUE
    max_commands_per_second: int = DEFAULT_ALF_GATEWAY_MAX_COMMANDS_PER_SECOND
    max_errors_before_disconnect: int = DEFAULT_ALF_GATEWAY_MAX_ERRORS_BEFORE_DISCONNECT
    error_window_sec: int = DEFAULT_ALF_GATEWAY_ERROR_WINDOW_SEC


@dataclass(frozen=True)
class BalfGatewaySpec:
    name: str = DEFAULT_BALF_GATEWAY_NAME
    bind_address: str = DEFAULT_BALF_GATEWAY_BIND_ADDRESS
    port: int = DEFAULT_BALF_GATEWAY_PORT
    heartbeat_interval_sec: int = DEFAULT_BALF_GATEWAY_HEARTBEAT_INTERVAL_SEC
    heartbeat_timeout_sec: int = DEFAULT_BALF_GATEWAY_HEARTBEAT_TIMEOUT_SEC
    idle_timeout_sec: int = DEFAULT_BALF_GATEWAY_IDLE_TIMEOUT_SEC
    auth_timeout_sec: int = DEFAULT_BALF_GATEWAY_AUTH_TIMEOUT_SEC
    max_connections: int = DEFAULT_BALF_GATEWAY_MAX_CONNECTIONS
    max_client_queue: int = DEFAULT_BALF_GATEWAY_MAX_CLIENT_QUEUE
    max_messages_per_second: int = DEFAULT_BALF_GATEWAY_MAX_MESSAGES_PER_SECOND
    max_errors_before_disconnect: int = (
        DEFAULT_BALF_GATEWAY_MAX_ERRORS_BEFORE_DISCONNECT
    )
    error_window_sec: int = DEFAULT_BALF_GATEWAY_ERROR_WINDOW_SEC
    duplicate_session_policy: str = DEFAULT_BALF_GATEWAY_DUPLICATE_SESSION_POLICY


@dataclass(frozen=True)
class DcGatewaySpec:
    name: str = DEFAULT_DC_GATEWAY_NAME
    bind_address: str = DEFAULT_DC_GATEWAY_BIND_ADDRESS
    port: int = DEFAULT_DC_GATEWAY_PORT
    heartbeat_interval_sec: int = DEFAULT_DC_GATEWAY_HEARTBEAT_INTERVAL_SEC
    idle_timeout_sec: int = DEFAULT_DC_GATEWAY_IDLE_TIMEOUT_SEC
    max_connections: int = DEFAULT_DC_GATEWAY_MAX_CONNECTIONS
    max_client_queue: int = DEFAULT_DC_GATEWAY_MAX_CLIENT_QUEUE


@dataclass(frozen=True)
class LogServerSpec:
    enabled: bool = True
    name: str = DEFAULT_LOG_SERVER_NAME
    bind_address: str = DEFAULT_LOG_SERVER_BIND_ADDRESS
    port: int = DEFAULT_LOG_SERVER_PORT
    db_path: str = DEFAULT_LOG_SERVER_DB_PATH
    retention_days: int | None = DEFAULT_LOG_SERVER_RETENTION_DAYS
    max_message_bytes: int = DEFAULT_LOG_SERVER_MAX_MESSAGE_BYTES
    max_client_queue: int = DEFAULT_LOG_SERVER_MAX_CLIENT_QUEUE
    write_batch_size: int = DEFAULT_LOG_SERVER_WRITE_BATCH_SIZE
    write_batch_interval_ms: int = DEFAULT_LOG_SERVER_WRITE_BATCH_INTERVAL_MS
    heartbeat_interval_sec: int = DEFAULT_LOG_SERVER_HEARTBEAT_INTERVAL_SEC

    # LALF-PS — the ZeroMQ log-distribution interface (../../../docs/books/operator-guide/part-6-observe-and-recover/040-log-server.md)
    pubsub_enabled: bool = DEFAULT_LOG_SERVER_PUBSUB_ENABLED
    pub_port: int = DEFAULT_LOG_SERVER_PUB_PORT
    pull_port: int = DEFAULT_LOG_SERVER_PULL_PORT
    lease_sec: int = DEFAULT_LOG_SERVER_LEASE_SEC
    max_lease_sec: int = DEFAULT_LOG_SERVER_MAX_LEASE_SEC
    max_subscribers: int = DEFAULT_LOG_SERVER_MAX_SUBSCRIBERS
    notify_interval_ms: int = DEFAULT_LOG_SERVER_NOTIFY_INTERVAL_MS
    backfill_chunk_rows: int = DEFAULT_LOG_SERVER_BACKFILL_CHUNK_ROWS
    max_backfill_minutes: int = DEFAULT_LOG_SERVER_MAX_BACKFILL_MINUTES
    max_backfill_rows: int = DEFAULT_LOG_SERVER_MAX_BACKFILL_ROWS
    max_pending_rows: int = DEFAULT_LOG_SERVER_MAX_PENDING_ROWS
    pub_sndhwm: int = DEFAULT_LOG_SERVER_PUB_SNDHWM


@dataclass(frozen=True)
class ApiCredentialSpec:
    api_key: str
    gateway_id: str | None
    description: str = ""


@dataclass(frozen=True)
class IndexSpec:
    id: str
    description: str
    constituents: tuple[str, ...]
    base_value: float = DEFAULT_INDEX_BASE_VALUE
    publish_interval_sec: float = DEFAULT_INDEX_PUBLISH_INTERVAL_SEC
    history_file: str = ""  # empty → derived from id
    state_file: str = ""  # empty → derived from id


@dataclass(frozen=True)
class ComboLegSpec:
    symbol: str
    side: str
    order_type: str
    quantity: int
    #: Display money, like every price in engine_config.yaml.
    price: float | None = None
    stop_price: float | None = None
    smp_action: str = "NONE"


@dataclass(frozen=True)
class ComboSpec:
    combo_id: str
    combo_type: str = "AON"
    tif: str = "DAY"
    legs: tuple[ComboLegSpec, ...] = ()


@dataclass(frozen=True)
class ApiGatewaySpec:
    name: str = "default"
    enabled: bool = True
    host: str = DEFAULT_API_GATEWAY_HOST
    port: int = DEFAULT_API_GATEWAY_PORT
    swagger_enabled: bool = DEFAULT_API_GATEWAY_SWAGGER_ENABLED
    log_level: str = DEFAULT_API_GATEWAY_LOG_LEVEL
    stats_db: str = DEFAULT_API_GATEWAY_STATS_DB
    credentials: tuple[ApiCredentialSpec, ...] = ()
    gateway_ids: tuple[str, ...] | None = None
    generate_keys: bool = True
    generate_readonly_key: bool = False
    #: File (beside the main one) that holds the credentials; empty = inline.
    credentials_file: str = ""
    rate_limit_writes_per_second: int = DEFAULT_API_GATEWAY_RATE_LIMIT_WRITES_PER_SECOND
    rate_limit_burst: int = DEFAULT_API_GATEWAY_RATE_LIMIT_BURST
    engine_auth_sec: float = DEFAULT_API_GATEWAY_ENGINE_AUTH_SEC
    engine_reply_sec: float = DEFAULT_API_GATEWAY_ENGINE_REPLY_SEC
    wait_ack_sec: float = DEFAULT_API_GATEWAY_WAIT_ACK_SEC
    order_retention_sec: int = DEFAULT_API_GATEWAY_ORDER_RETENTION_SEC


class ConfigBuilder:
    def __init__(self, spec: ConfigSpec):
        self.spec = spec
        self._rng = random.Random(spec.random_seed)

    def build(self) -> dict[str, Any]:
        cfg: dict[str, Any] = {
            "sessions_enabled": self.spec.sessions_enabled,
            "enforce_collars": self.spec.enforce_collars,
            "enforce_circuit_breakers": self.spec.enforce_circuit_breakers,
            "require_mm_seed_quotes": self.spec.require_mm_seed_quotes,
        }

        if self.spec.emit_engine_tuning:
            cfg["engine_tuning"] = {
                "snapshot_interval_sec": self.spec.snapshot_interval_sec,
                "quote_history_maxlen": self.spec.quote_history_maxlen,
                "drop_copy_buffer_size": self.spec.drop_copy_buffer_size,
                "recent_trades_maxlen": self.spec.recent_trades_maxlen,
                "depth_snapshot_tolerance_ticks": self.spec.depth_snapshot_tolerance_ticks,
            }

        locale: dict[str, str] = {}
        if self.spec.country is not None:
            locale["country"] = self.spec.country
        if self.spec.session_timezone is not None:
            locale["session_timezone"] = self.spec.session_timezone
        if locale:
            cfg["locale"] = locale

        if self._should_emit_mm_defaults():
            cfg["mm_obligation_defaults"] = self._build_mm_defaults()

        risk_controls = self._build_risk_controls()
        if risk_controls is not None:
            cfg["risk_controls"] = risk_controls

        if self.spec.cb_levels:
            cfg["circuit_breaker_defaults"] = self._build_cb_defaults()

        participant_defaults = self._build_gateway_default()
        if participant_defaults:
            cfg["participant_defaults"] = participant_defaults
        cfg["participants"] = self._build_gateways()
        if self.spec.alf_gateway is not None:
            cfg["alf_gateway"] = self._build_alf_gateway()
        if self.spec.post_trade_gateway is not None:
            cfg["post_trade_gateway"] = self._build_post_trade_gateway()
        if self.spec.market_data_gateway is not None:
            cfg["market_data_gateway"] = self._build_market_data_gateway()
        if self.spec.balf_gateway is not None:
            cfg["balf_gateway"] = self._build_balf_gateway()
        if self.spec.dc_gateway is not None:
            cfg["dc_gateway"] = self._build_dc_gateway()
        if self.spec.log_server is not None:
            cfg["log_server"] = self._build_log_server()
        if self.spec.monitor is not None:
            cfg["monitor"] = self._build_monitor()
        if self.spec.api_gateways:
            cfg["api_gateways"] = self._build_api_gateways()
        cfg["symbols"] = self._build_symbols()

        if self.spec.combos:
            cfg["market_maker_combos"] = self._build_combos()

        if self.spec.indices:
            cfg["indices"] = self._build_indices()

        if self.spec.sessions_enabled and self.spec.emit_schedule:
            # --pre-open etc. populate the `weekdays:` shorthand -- the
            # common case of one schedule for every Mon-Fri session. Weekend
            # and holiday overrides are opt-in (--weekend / --holidays);
            # per-individual-weekday overrides have no CLI flags of their
            # own and are left for hand-editing the generated YAML (see
            # ../../../docs/books/operator-guide/part-4-run-a-market/030-sessions-and-scheduling.md).
            schedule: dict[str, Any] = {
                "weekdays": {
                    "pre_open": self.spec.pre_open,
                    "opening_auction_start": self.spec.opening_auction,
                    "continuous_start": self.spec.continuous,
                    "closing_auction_start": self.spec.closing_auction,
                    "closing_auction_end": self.spec.closing_end,
                }
            }
            if self.spec.emit_weekend:
                schedule["weekend"] = {
                    "pre_open": self.spec.weekend_pre_open,
                    "opening_auction_start": self.spec.weekend_opening_auction,
                    "continuous_start": self.spec.weekend_continuous,
                    "closing_auction_start": self.spec.weekend_closing_auction,
                    "closing_auction_end": self.spec.weekend_closing_end,
                }
            if self.spec.emit_holidays:
                schedule["holidays"] = {
                    "pre_open": self.spec.holidays_pre_open,
                    "opening_auction_start": self.spec.holidays_opening_auction,
                    "continuous_start": self.spec.holidays_continuous,
                    "closing_auction_start": self.spec.holidays_closing_auction,
                    "closing_auction_end": self.spec.holidays_closing_end,
                }
            cfg["schedule"] = schedule

        return cfg

    def _build_alf_gateway(self) -> dict[str, Any]:
        spec = self.spec.alf_gateway
        if spec is None:
            return {}

        return {
            "enabled": spec.enabled,
            "name": spec.name,
            "bind_address": spec.bind_address,
            "port": spec.port,
            "heartbeat_interval_sec": spec.heartbeat_interval_sec,
            "handshake_timeout_sec": spec.handshake_timeout_sec,
            "idle_timeout_sec": spec.idle_timeout_sec,
            "max_connections": spec.max_connections,
            "max_client_queue": spec.max_client_queue,
            "max_commands_per_second": spec.max_commands_per_second,
            "max_errors_before_disconnect": spec.max_errors_before_disconnect,
            "error_window_sec": spec.error_window_sec,
        }

    def _build_post_trade_gateway(self) -> dict[str, Any]:
        spec = self.spec.post_trade_gateway
        if spec is None:
            return {}

        return {
            "name": spec.name,
            "bind_address": spec.bind_address,
            "port": spec.port,
            "replay_retention_sec": spec.replay_retention_sec,
            "heartbeat_interval_sec": spec.heartbeat_interval_sec,
            "idle_timeout_sec": spec.idle_timeout_sec,
            "max_connections": spec.max_connections,
            "max_client_queue": spec.max_client_queue,
            "allowed_roles": list(spec.allowed_roles),
        }

    def _build_market_data_gateway(self) -> dict[str, Any]:
        spec = self.spec.market_data_gateway
        if spec is None:
            return {}

        return {
            "enabled": spec.enabled,
            "name": spec.name,
            "bind_address": spec.bind_address,
            "port": spec.port,
            "heartbeat_interval_sec": spec.heartbeat_interval_sec,
            "idle_timeout_sec": spec.idle_timeout_sec,
            "replay_window_sec": spec.replay_window_sec,
            "max_connections": spec.max_connections,
            "max_symbols_per_client": spec.max_symbols_per_client,
            "max_client_queue": spec.max_client_queue,
            "depth_levels": spec.depth_levels,
        }

    def _build_balf_gateway(self) -> dict[str, Any]:
        spec = self.spec.balf_gateway
        if spec is None:
            return {}

        return {
            "name": spec.name,
            "bind_address": spec.bind_address,
            "port": spec.port,
            "heartbeat_interval_sec": spec.heartbeat_interval_sec,
            "heartbeat_timeout_sec": spec.heartbeat_timeout_sec,
            "idle_timeout_sec": spec.idle_timeout_sec,
            "auth_timeout_sec": spec.auth_timeout_sec,
            "max_connections": spec.max_connections,
            "max_client_queue": spec.max_client_queue,
            "max_messages_per_second": spec.max_messages_per_second,
            "max_errors_before_disconnect": spec.max_errors_before_disconnect,
            "error_window_sec": spec.error_window_sec,
            "duplicate_session_policy": spec.duplicate_session_policy,
        }

    def _build_dc_gateway(self) -> dict[str, Any]:
        spec = self.spec.dc_gateway
        if spec is None:
            return {}

        return {
            "name": spec.name,
            "bind_address": spec.bind_address,
            "port": spec.port,
            "heartbeat_interval_sec": spec.heartbeat_interval_sec,
            "idle_timeout_sec": spec.idle_timeout_sec,
            "max_connections": spec.max_connections,
            "max_client_queue": spec.max_client_queue,
        }

    def _build_log_server(self) -> dict[str, Any]:
        spec = self.spec.log_server
        if spec is None:
            return {}

        return {
            "enabled": spec.enabled,
            "name": spec.name,
            "bind_address": spec.bind_address,
            "port": spec.port,
            "db_path": spec.db_path,
            "retention_days": spec.retention_days,
            "max_message_bytes": spec.max_message_bytes,
            "max_client_queue": spec.max_client_queue,
            "write_batch_size": spec.write_batch_size,
            "write_batch_interval_ms": spec.write_batch_interval_ms,
            "heartbeat_interval_sec": spec.heartbeat_interval_sec,
            "pubsub_enabled": spec.pubsub_enabled,
            "pub_port": spec.pub_port,
            "pull_port": spec.pull_port,
            "lease_sec": spec.lease_sec,
            "max_lease_sec": spec.max_lease_sec,
            "max_subscribers": spec.max_subscribers,
            "notify_interval_ms": spec.notify_interval_ms,
            "backfill_chunk_rows": spec.backfill_chunk_rows,
            "max_backfill_minutes": spec.max_backfill_minutes,
            "max_backfill_rows": spec.max_backfill_rows,
            "max_pending_rows": spec.max_pending_rows,
            "pub_sndhwm": spec.pub_sndhwm,
        }

    def _build_monitor(self) -> dict[str, Any]:
        """Every field of the ``monitor`` block, defaults included, so the
        generated file documents what pm-monitor will run with."""
        m = self.spec.monitor
        if m is None:
            return {}

        def num(value: float) -> float | int:
            return int(value) if float(value).is_integer() else value

        return {
            "enabled": m.enabled,
            "bind_address": m.bind_address,
            "host": m.host,
            "pull_port": m.pull_port,
            "pub_port": m.pub_port,
            "beacon_interval_sec": num(m.beacon_interval_sec),
            "hung_after_sec": num(m.hung_after_sec),
            "silent_after_beacons": m.silent_after_beacons,
            "book_metrics_interval_sec": num(m.book_metrics_interval_sec),
            "retention": {
                "raw_hours": m.retention.raw_hours,
                "minute_days": m.retention.minute_days,
            },
            "thresholds": {
                f.name: {
                    "warn": num(getattr(m.thresholds, f.name).warn),
                    "crit": num(getattr(m.thresholds, f.name).crit),
                }
                for f in fields(m.thresholds)
            },
        }

    def _build_api_gateways(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        gateway_owners: dict[str, str] = {}
        for spec in self.spec.api_gateways:
            for credential in self._effective_api_credentials(spec):
                if credential.gateway_id is None:
                    continue
                existing = gateway_owners.get(credential.gateway_id)
                if existing is not None and existing != spec.name:
                    raise ValueError(
                        f"gateway_id {credential.gateway_id!r} is used by multiple "
                        f"api_gateways entries: {existing!r} and {spec.name!r}"
                    )
                gateway_owners[credential.gateway_id] = spec.name
            payload[spec.name] = self._build_api_gateway(spec)
        return payload

    def _build_api_gateway(self, spec: ApiGatewaySpec) -> dict[str, Any]:
        return {
            "enabled": spec.enabled,
            "host": spec.host,
            "port": spec.port,
            "swagger_enabled": spec.swagger_enabled,
            "log_level": spec.log_level,
            "stats_db": spec.stats_db,
            "order_retention_sec": spec.order_retention_sec,
            **(
                {"credentials_file": spec.credentials_file}
                if spec.credentials_file
                else {"credentials": self._credential_payload(spec)}
            ),
            "rate_limit": {
                "writes_per_second": spec.rate_limit_writes_per_second,
                "burst": spec.rate_limit_burst,
            },
            "timeouts": {
                "engine_auth_sec": spec.engine_auth_sec,
                "engine_reply_sec": spec.engine_reply_sec,
                "wait_ack_sec": spec.wait_ack_sec,
            },
        }

    def _credential_payload(self, spec: ApiGatewaySpec) -> list[dict[str, Any]]:
        return [
            {
                "api_key": item.api_key,
                "gateway_id": item.gateway_id,
                "description": item.description,
            }
            for item in self._effective_api_credentials(spec)
        ]

    def credential_files(self) -> dict[str, list[dict[str, Any]]]:
        """The credentials of every gateway that keeps them in a file, by file."""
        files: dict[str, list[dict[str, Any]]] = {}
        for spec in self.spec.api_gateways:
            if spec.credentials_file:
                files.setdefault(spec.credentials_file, []).extend(
                    self._credential_payload(spec)
                )
        return files

    def _effective_api_credentials(
        self, spec: ApiGatewaySpec
    ) -> list[ApiCredentialSpec]:
        credentials = list(spec.credentials)
        explicit_gateway_ids = {item.gateway_id for item in credentials}
        included_gateway_ids = (
            None if spec.gateway_ids is None else set(spec.gateway_ids)
        )

        if spec.generate_keys:
            for gateway in self.spec.gateways:
                if (
                    included_gateway_ids is not None
                    and gateway.gateway_id not in included_gateway_ids
                ):
                    continue
                if gateway.gateway_id in explicit_gateway_ids:
                    continue
                credentials.append(
                    ApiCredentialSpec(
                        api_key=self._generated_api_key(gateway.gateway_id, spec),
                        gateway_id=gateway.gateway_id,
                        description=f"Generated key for {gateway.gateway_id}",
                    )
                )
        if spec.generate_readonly_key and None not in explicit_gateway_ids:
            credentials.append(
                ApiCredentialSpec(
                    api_key=self._generated_api_key("readonly", spec),
                    gateway_id=None,
                    description="Generated read-only market-data key",
                )
            )

        return credentials

    def _generated_api_key(self, label: str, gateway: ApiGatewaySpec) -> str:
        alphabet = string.ascii_lowercase + string.digits
        seed = self.spec.random_seed
        if seed is None and gateway.credentials_file:
            # A keys file is meant to be regenerated identically.
            seed = DEFAULT_API_KEYS_SEED
        rng = random.Random(f"api:{seed}:{label}") if seed is not None else self._rng
        token = "".join(
            rng.choice(alphabet) for _ in range(DEFAULT_API_GATEWAY_KEY_BYTES * 2)
        )
        return f"key-{label.lower()}-{token}"

    def _should_emit_mm_defaults(self) -> bool:
        if self.spec.emit_mm_defaults:
            return True
        for override in self.spec.symbol_overrides.values():
            if (
                override.mm_spread_ticks is not None
                or override.mm_min_qty is not None
                or override.enforce_mm_obligation is not None
            ):
                return True
        return False

    def _build_mm_defaults(self) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "enforce_mm_obligation": self.spec.enforce_mm_obligations,
            "mm_max_spread_ticks": self.spec.mm_spread_ticks,
            "mm_min_qty": self.spec.mm_min_qty,
        }

        symbol_overrides: dict[str, Any] = {}
        for symbol, override in self.spec.symbol_overrides.items():
            if (
                override.mm_spread_ticks is None
                and override.mm_min_qty is None
                and override.enforce_mm_obligation is None
            ):
                continue
            symbol_enforce = (
                override.enforce_mm_obligation
                if override.enforce_mm_obligation is not None
                else self.spec.enforce_mm_obligations
            )
            symbol_overrides[symbol] = {
                "enforce_mm_obligation": symbol_enforce,
                "mm_max_spread_ticks": (
                    override.mm_spread_ticks
                    if override.mm_spread_ticks is not None
                    else self.spec.mm_spread_ticks
                ),
                "mm_min_qty": (
                    override.mm_min_qty
                    if override.mm_min_qty is not None
                    else self.spec.mm_min_qty
                ),
            }
        if symbol_overrides:
            payload["symbols"] = symbol_overrides

        return payload

    def _build_risk_controls(self) -> dict[str, Any] | None:
        levels: dict[str, Any] = {}
        default_level: str | None = None

        if (
            self.spec.static_band_pct is not None
            or self.spec.dynamic_band_pct is not None
        ):
            levels["DEFAULT"] = {
                "collar": {
                    "static_band_pct": (
                        self.spec.static_band_pct
                        if self.spec.static_band_pct is not None
                        else DEFAULT_STATIC_BAND_PCT
                    ),
                    "dynamic_band_pct": (
                        self.spec.dynamic_band_pct
                        if self.spec.dynamic_band_pct is not None
                        else DEFAULT_DYNAMIC_BAND_PCT
                    ),
                }
            }
            default_level = "DEFAULT"

        for name, (static_pct, dynamic_pct) in self.spec.risk_levels.items():
            levels[name] = {
                "collar": {
                    "static_band_pct": static_pct,
                    "dynamic_band_pct": (
                        dynamic_pct
                        if dynamic_pct is not None
                        else DEFAULT_DYNAMIC_BAND_PCT
                    ),
                }
            }

        if not levels:
            return None

        payload: dict[str, Any] = {"levels": levels}
        if default_level is not None:
            payload["default_level"] = default_level
        return payload

    def _build_cb_defaults(self) -> dict[str, Any]:
        levels: dict[str, Any] = {}
        for level in self.spec.cb_levels:
            halt_ns = None
            if level.halt_mins is not None and level.halt_mins > 0:
                halt_ns = level.halt_mins * 60 * 1_000_000_000

            levels[level.name] = {
                "price_shift_pct": level.shift_pct,
                "halt_duration_ns": halt_ns,
            }

        reopening: dict[str, Any] = {
            "enabled": self.spec.ace_enabled,
            "initial_band_pct": self.spec.ace_initial_band_pct,
            "random_end_max_ns": self.spec.ace_random_end_max_ns,
            "expansions": [
                {"widen_pct": pct, "min_duration_ns": dur}
                for pct, dur in self.spec.ace_expansions
            ],
        }
        if self.spec.ace_random_seed is not None:
            reopening["random_seed"] = self.spec.ace_random_seed

        return {
            "reference_window_ns": self.spec.cb_window_ns,
            "levels": levels,
            "reopening": reopening,
        }

    def _build_gateway_default(self) -> dict[str, Any]:
        default: dict[str, Any] = {}
        if self.spec.gateway_default_smp is not None:
            default["smp_action"] = self.spec.gateway_default_smp.value
        if self.spec.gateway_default_disconnect is not None:
            default["disconnect_behaviour"] = self.spec.gateway_default_disconnect.value
        return default

    def _build_gateways(self) -> list[dict[str, Any]]:
        inherited_smp = self.spec.gateway_default_smp or SmpAction.NONE
        inherits_disconnect = self.spec.gateway_default_disconnect is not None
        gateways: list[dict[str, Any]] = []
        for gw in self.spec.gateways:
            payload: dict[str, Any] = {
                "id": gw.gateway_id,
                "role": gw.role.value,
            }
            # A gateway that took the role default rather than naming a
            # value inherits participant_defaults.disconnect_behaviour instead.
            if gw.disconnect_explicit or not inherits_disconnect:
                payload["disconnect_behaviour"] = gw.disconnect_behaviour.value
            if gw.description:
                payload["description"] = gw.description
            if gw.role == ParticipantRole.MARKET_MAKER:
                payload["quote_refresh_policy"] = "INACTIVATE_ON_ANY_FILL"
            if (
                gw.smp_explicit or gw.smp_action != SmpAction.NONE
            ) and gw.smp_action != inherited_smp:
                payload["smp_action"] = gw.smp_action.value
            gateways.append(payload)
        return gateways

    def _build_symbols(self) -> dict[str, Any]:
        mm_gateways = [
            gw.gateway_id
            for gw in self.spec.gateways
            if gw.role == ParticipantRole.MARKET_MAKER
        ]

        symbols: dict[str, Any] = {}
        for symbol in self.spec.symbols:
            override = self.spec.symbol_overrides.get(symbol, SymbolOverride())
            # Every seeded price is snapped to the symbol's own grid: a
            # symbol at 0 decimals cannot take a 2-decimal seed, and the
            # engine loader refuses an off-grid price (CV18).
            tick_decimals = (
                override.tick_decimals
                if override.tick_decimals is not None
                else self.spec.tick_decimals
            )
            payload: dict[str, Any] = {"tick_decimals": tick_decimals}

            if override.level is not None:
                payload["level"] = override.level

            seeded_midpoint = self._seeded_midpoint(tick_decimals)

            if self.spec.seed_last_prices_from_mm and seeded_midpoint is not None:
                midpoint = float(seeded_midpoint)
                payload["last_buy_price"] = midpoint
                payload["last_sell_price"] = midpoint
            elif self.spec.seed_last_prices:
                payload["last_buy_price"] = None
                payload["last_sell_price"] = None

            if (
                override.static_band_pct is not None
                or override.dynamic_band_pct is not None
            ):
                collar: dict[str, Any] = {}
                if override.static_band_pct is not None:
                    collar["static_band_pct"] = override.static_band_pct
                if override.dynamic_band_pct is not None:
                    collar["dynamic_band_pct"] = override.dynamic_band_pct
                payload["collar"] = collar

            if (
                override.max_order_qty is not None
                or override.max_order_value is not None
            ):
                order_limits: dict[str, Any] = {}
                if override.max_order_qty is not None:
                    order_limits["max_order_qty"] = override.max_order_qty
                if override.max_order_value is not None:
                    order_limits["max_order_value"] = override.max_order_value
                payload["order_limits"] = order_limits

            cb_levels: dict[str, dict[str, Any]] = {}
            for level_name in sorted(
                set(override.cb_shift) | set(override.cb_halt_mins)
            ):
                level_payload: dict[str, Any] = {}
                if level_name in override.cb_shift:
                    level_payload["price_shift_pct"] = override.cb_shift[level_name]
                if level_name in override.cb_halt_mins:
                    halt_mins = override.cb_halt_mins[level_name]
                    if halt_mins is None or halt_mins == 0:
                        level_payload["halt_duration_ns"] = None
                    else:
                        level_payload["halt_duration_ns"] = (
                            halt_mins * 60 * 1_000_000_000
                        )
                cb_levels[level_name] = level_payload

            sym_reopening: dict[str, Any] = {}
            if override.ace_enabled is not None:
                sym_reopening["enabled"] = override.ace_enabled
            if override.ace_initial_band_pct is not None:
                sym_reopening["initial_band_pct"] = override.ace_initial_band_pct
            if override.ace_random_end_max_ns is not None:
                sym_reopening["random_end_max_ns"] = override.ace_random_end_max_ns

            if cb_levels or sym_reopening:
                cb_payload: dict[str, Any] = {}
                if cb_levels:
                    cb_payload["levels"] = cb_levels
                if sym_reopening:
                    cb_payload["reopening"] = sym_reopening
                payload["circuit_breaker"] = cb_payload

            if mm_gateways and self.spec.require_mm_seed_quotes:
                payload["market_maker_quotes"] = [
                    self._build_mm_quote_seed(
                        gateway_id=gateway_id,
                        tick_decimals=tick_decimals,
                        seeded_midpoint=seeded_midpoint,
                    )
                    for gateway_id in mm_gateways
                ]

            outstanding = self.spec.outstanding_shares.get(symbol)
            if outstanding is not None:
                payload["outstanding_shares"] = outstanding

            symbols[symbol] = payload

        return symbols

    def _build_indices(self) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for spec in self.spec.indices:
            history_file = (
                spec.history_file or f"{DEFAULT_INDEX_DATA_DIR}/{spec.id}_history.jsonl"
            )
            state_file = (
                spec.state_file or f"{DEFAULT_INDEX_DATA_DIR}/{spec.id}_state.json"
            )
            result.append(
                {
                    "id": spec.id,
                    "description": spec.description,
                    "base_value": spec.base_value,
                    "publish_interval_sec": spec.publish_interval_sec,
                    "history_file": history_file,
                    "state_file": state_file,
                    "constituents": list(spec.constituents),
                }
            )
        return result

    def _seeded_midpoint(self, tick_decimals: int) -> Decimal | None:
        if self.spec.seed_mm_mid_range is None:
            return None

        min_price, max_price = self.spec.seed_mm_mid_range
        tick_size = Decimal(1).scaleb(-tick_decimals)
        min_steps = int(
            (Decimal(str(min_price)) / tick_size).to_integral_value(
                rounding=ROUND_CEILING
            )
        )
        max_steps = int(
            (Decimal(str(max_price)) / tick_size).to_integral_value(
                rounding=ROUND_FLOOR
            )
        )
        midpoint_steps = self._rng.randint(min_steps, max_steps)
        return Decimal(midpoint_steps) * tick_size

    def _build_mm_quote_seed(
        self,
        gateway_id: str,
        tick_decimals: int,
        seeded_midpoint: Decimal | None,
    ) -> dict[str, Any]:
        if seeded_midpoint is None:
            bid_price: float | None = None
            ask_price: float | None = None
        else:
            tick_size = Decimal(1).scaleb(-tick_decimals)
            half_spread = self.spec.mm_seed_spread_ticks * tick_size
            bid_price = float(seeded_midpoint - half_spread)
            ask_price = float(seeded_midpoint + half_spread)

        return {
            "gateway_id": gateway_id,
            "bid_price": bid_price,
            "ask_price": ask_price,
            "bid_qty": DEFAULT_MM_STUB_QTY,
            "ask_qty": DEFAULT_MM_STUB_QTY,
            "tif": "DAY",
            "seed_once": True,
        }

    def _build_combos(self) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for combo in self.spec.combos:
            result.append(
                {
                    "combo_id": combo.combo_id,
                    "combo_type": combo.combo_type,
                    "tif": combo.tif,
                    "legs": [
                        {
                            "symbol": leg.symbol,
                            "side": leg.side,
                            "order_type": leg.order_type,
                            "quantity": leg.quantity,
                            "price": leg.price,
                            "stop_price": leg.stop_price,
                            "smp_action": leg.smp_action,
                        }
                        for leg in combo.legs
                    ],
                }
            )
        return result
